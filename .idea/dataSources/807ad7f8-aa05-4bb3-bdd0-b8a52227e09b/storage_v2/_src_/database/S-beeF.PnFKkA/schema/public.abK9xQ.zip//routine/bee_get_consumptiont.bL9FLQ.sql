create function bee_get_consumptiont(dfrom date, dto date, id_external_pnt integer)
    returns TABLE(id_external_point integer, date_from date, date_to date, prev_value numeric, curr_value numeric, id_tariff_option integer, sosial_norm numeric, over_sosial_norm numeric, id_sys integer, is_legal integer, consumed_without_sub numeric, reporting_quantity numeric)
    language plpgsql
as
$$
declare 
   NUMBER_EXPR TEXT := E'^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$';
   first_day date  =  date_trunc('month',dfrom)::date;
   last_day date = (date_trunc('month', dto::date) + interval '1 month' - interval '1 day')::date  ;
begin 
	
 return QUERY( select 
   		apn.rowid as id_external_point,    		
	    first_day  as date_from, 
        last_day  as date_to, 
	    
        coalesce(r196.valman, 0) as prev_value,
        coalesce(r195.valman, 0)  as curr_value, 
        
        case
         when ardp2009.paramval is not NULL	and ardp2009.paramval = '383'	then 2
         when apnt.tarifid in (142, 144, 147, 148) then 2
         when apnt.tarifid in (143, 145, 146, 149)  then 3
         when apnt.tarifid in (138, 139, 140, 141)  then 4
         when apnt.tarifid in (150, 154, 155, 156, 151)  then 5
         when apnt.tarifid in (152, 157, 158, 159, 153, 160, 161, 162)  then 6
         
        else        1 
        end::int as id_tariff_option,
        
        coalesce(r1446.valman, 0)  as sosial_norm,
        coalesce(r1174.valman, 0)  as over_sosial_norm,
        
        case
	 	  when right((select split_part(kod, ' ', 1) from denet where length(kod) = 6), 2) = '66' 
	 	   then '66'||  right((select split_part(kod, ' ', 1) from denet where length(kod) = 9), 1)

	 	  else right((select split_part(kod, ' ', 1) from denet where length(kod) = 6), 2) 
	  	  
	  end::int as id_sys,     
            case when lower(left((select current_database()), 4))  like 'beeu' 
			then 1
			else 0
		end		as is_legal, 
		
     case WHEN lower(left((select current_database()), 4))  like 'beeu' 
               THEN
                 CASE when ardp2009.paramval is not NULL	and ardp2009.paramval = '383' and r1179.valman is not NULL	
                      then r1179.valman::NUMERIC
                      when r850.valman is not null then r850.valman::NUMERIC 
                      else 0
                END
                else CASE WHEN   r975_985.valman is not NULL 
                          THEN r975_985.valman::NUMERIC 
              		      ELSE 0 
             	      END 
           END   	      
          as consumed_without_sub,
         
          case WHEN lower(left((select current_database()), 4))  like 'beeu' 
               THEN
                 CASE when ardp2009.paramval is not NULL	and ardp2009.paramval = '383' and r1179.valman is not NULL
                      	 then r1179.valman::NUMERIC
                      when  r407.valman is not null 
                         then r407.valman::numeric
                      else 0
                END
                else CASE WHEN  r975_407.valman is not NULL 
                            THEN r975_407.valman::numeric
              		      ELSE 0 
             	      END 
           END as reporting_quantity 
         
     from agreepoint as apn
     join agreement  as amn on amn.rowid = apn.linkid
     


left JOIN   ( SELECT max(valman::numeric) AS valman, linkid, max(operdate) AS operdate FROM  regdevoper WHERE paramid = 195 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r195 on r195.linkid= apn.rowid 

left join  ( SELECT min(valman::numeric) AS valman, linkid FROM  regdevoper WHERE paramid = 196 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r196 on r196.linkid= apn.rowid 

left join   ( SELECT sum(valman::NUMERIC) AS valman, linkid FROM  regdevoper WHERE paramid = 198 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS  r198 on r198.linkid= apn.rowid


left join   ( SELECT sum(valman::NUMERIC) AS valman, linkid FROM  regdevoper WHERE paramid = 1446 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r1446 on r1446.linkid= apn.rowid 

left join   ( SELECT sum(valman::NUMERIC) AS valman, linkid FROM  regdevoper WHERE paramid = 1174 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r1174 on r1174.linkid= apn.rowid

left join  ( SELECT sum(valman::NUMERIC) AS valman, linkid FROM  regdevoper WHERE paramid = 1179 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r1179 on r1179.linkid= apn.rowid 

left join (    select * from agreepoint_tarif at2 
                join (select pointid as pnt, max(period) as per from agreepoint_tarif where period <= last_day group by pointid
                      )  as at3 on at2.pointid = at3.pnt and at2.period = at3.per
               
          ) as apnt on apnt.pointid = apn.linkid
          
 left join (select ard.paramid, ard.linkid as link, ard.paramval from agreeregdev_period as ard
                join (  select max(period) as period, ad.linkid from agreeregdev_period as ad where paramid = 2009 group by linkid)as ard1
               on ard.period = ard1.period and ard.linkid = ard1.linkid   
               where ard.paramid = 2009 ) as ardp2009 on ardp2009.link = apn.rowid          
               
left join  ( SELECT sum(valman::NUMERIC) AS valman, linkid FROM  regdevoper WHERE paramid = 407 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r407 on r407.linkid= apn.rowid 

left join  ( SELECT sum(valman::NUMERIC) AS valman, linkid FROM  regdevoper WHERE paramid = 850 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r850 on r850.linkid= apn.rowid

left join  ( SELECT sum(valman::NUMERIC) AS valman, linkid,  max(operdate) AS operdate FROM  regdevoper975 WHERE paramid = 195 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r975_195 on r975_195.linkid= apn.rowid

left join  ( SELECT sum(valman::NUMERIC) AS valman, linkid FROM  regdevoper975 WHERE paramid = 407 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r975_407 on r975_407.linkid= apn.rowid

left join  ( SELECT sum(valman::NUMERIC) AS valman, linkid FROM  regdevoper975 WHERE paramid = 985 AND operdate between first_day and last_day and valman ~ NUMBER_EXPR GROUP BY linkid
) AS r975_985 on r975_985.linkid= apn.rowid 

          

WHERE  (id_external_pnt is null or apn.rowid = id_external_pnt) and (amn.accdir not in (538,1476,1110,319)) AND (r975_195.operdate IS NOT NULL OR r195.operdate  IS NOT NULL  )
);

end;
$$;

alter function bee_get_consumptiont(date, date, integer) owner to postgres;

