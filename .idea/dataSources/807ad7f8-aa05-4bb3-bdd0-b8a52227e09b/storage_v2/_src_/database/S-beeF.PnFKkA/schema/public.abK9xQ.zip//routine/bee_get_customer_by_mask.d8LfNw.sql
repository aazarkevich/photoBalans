create function bee_get_customer_by_mask(lid integer, mask character varying) returns text
    language plpgsql
as
$$
/*
	ОТБОР КОД АБОНЕНТОВ ПО МАСКЕ
	lid : код места обработки
	mask: фильтр
*/ 
DECLARE
  Rec     RECORD;
  AboList TEXT := '';
--
BEGIN
	FOR Rec IN (   SELECT cust.abo_code::text as cod 
	                 FROM customer AS cust
	            LEFT JOIN agreement AS amn ON amn.abo_code = cust.abo_code
	                WHERE (    (amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = lid))) 
	                        OR (amn.locid IS NULL AND cust.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = lid))) )
	                  AND cust.abo_name ILIKE mask )
	LOOP 
		IF Rec.cod IS NOT NULL THEN AboList = AboList || Rec.cod || '|';
		END IF;		
	END LOOP;

	RETURN AboList;

END;
$$;

comment on function bee_get_customer_by_mask(integer, varchar) is 'Отбор код абонентов по маске. Используется в Agreement.java, AppUtils.java';

alter function bee_get_customer_by_mask(integer, varchar) owner to pgsql;

