create function bee_get_change_main_docid(docid integer) returns integer
    language plpgsql
as
$$
/*
	ito06 2015-07-09 Получить rowid документа по исправлению docid
*/
DECLARE rid integer;
BEGIN
	select wher from bee_docs_change where who  = docid into rid;
	IF rid IS NULL 
	   THEN	RETURN 0;
	   ELSE RETURN rid;
	END IF;
END;
$$;

comment on function bee_get_change_main_docid(integer) is 'Существует ли исправление по документу. Используется в RepAktChange.java, AppUtils.java';

alter function bee_get_change_main_docid(integer) owner to pgsql;

