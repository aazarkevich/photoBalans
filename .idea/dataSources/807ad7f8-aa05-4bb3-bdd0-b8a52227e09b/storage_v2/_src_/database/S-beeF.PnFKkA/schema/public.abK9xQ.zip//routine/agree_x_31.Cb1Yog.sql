create function agree_x_31(dbn character varying, agr_num character varying, tagid integer, src_host character varying, src_port character varying) returns void
    language plpgsql
as
$$
DECLARE
   Pnt RECORD; -- for agreepoint
   Rec RECORD; -- for params 
   XRec RECORD;
BEGIN
      RAISE NOTICE '*** agree_x_31:agrnum=%, tagid=%',agr_num,tagid;
      -- SCAN POINTS
      FOR Pnt IN (SELECT DISTINCT rowid
          FROM agree_get_agreepoint(dbn,agr_num,tagid,src_host, src_port) ORDER BY rowid
      ) LOOP -- NEXT POINT
         FOR Rec IN (SELECT DISTINCT rowid,paramid,paramval,linkid
            FROM agree_get_agreeregdev(dbn,agr_num,tagid,src_host, src_port) x
            WHERE  x.linkid = Pnt.rowid
         )
         LOOP
            -- NEXT PARAMS RECORD FROM agreeregdev
            -- IF RECORD WAS CHANGED (DELETE+INSERT rowid is different) 
            /*
            begin
               UPDATE agreeregdev 
               SET 
                  rowid = Rec.rowid
               WHERE  
                  linkid  =  Pnt.rowid
                  AND paramid  =  Rec.paramid
                  AND paramval =  Rec.paramval
                  AND rowid   <>  Rec.rowid;
               EXCEPTION
                  WHEN others THEN 
                  RAISE NOTICE 'agree_x_31: other : update agreeregdev *';
            END;    
            */ 
            -- IF RECORD WAS CHANGED (UPDATE)
            /* 
            begin           
            UPDATE agreeregdev
            SET 
               paramid  = Rec.paramid, 
               paramval = Rec.paramval
            WHERE  
                   linkid =  Pnt.rowid
               AND rowid  =  Rec.rowid
               --AND ((paramid <> Rec.paramid) OR (paramval  <> Rec.paramval)
               --)
               ;
            EXception
               WHEN others THEN RAISE NOTICE '*** agree_x_31 2 : update agreeregdev **';
            END;
            */
            begin           
               delete from agreeregdev
               WHERE  
                  linkid =  Pnt.rowid;
            EXception
               WHEN others THEN RAISE NOTICE '*** agree_x_31 2 : update agreeregdev **';
            END;              
         END LOOP; 

        -- INSERT NEW ONE
        FOR XRec IN (SELECT DISTINCT rowid,paramid,paramval,linkid
            FROM agree_get_agreeregdev(dbn,agr_num,tagid,src_host, src_port) x
            WHERE  
               x.linkid = Pnt.rowid
               AND x.rowid NOT IN (
                    SELECT rowid FROM agreeregdev WHERE linkid = Pnt.rowid
               )
        ) LOOP
           --RAISE NOTICE '*** agree_x_31 loop: % : %',src_host,Pnt.rowid;
           BEGIN
              INSERT INTO agreeregdev 
              (     /*rowid,*/     paramid,     paramval,     linkid) VALUES
              (/*XRec.rowid,*/XRec.paramid,XRec.paramval,XRec.linkid);
              RAISE NOTICE '*** agree_x_31 OK insert: % : %',src_host,Pnt.rowid;
           EXCEPTION
              WHEN unique_violation THEN 
                 RAISE NOTICE '*** agree_x_31 unique';
                 CONTINUE;
              WHEN others THEN 
                 RAISE NOTICE '*** agree_x_31 other';
                 CONTINUE;
           END;
        END LOOP; 
        ------------------------------------------
     END LOOP; -- POINTS DONE
END;
--
--
$$;

comment on function agree_x_31(varchar, varchar, integer, varchar, varchar) is 'Добавление/изменение постоянных параметров точки учета из указанного филиала в базу централизованных/смешнных для указанного договора. Используется в agree_w(int, varchar, varchar), agree_x(varchar, int, varchar)';

alter function agree_x_31(varchar, varchar, integer, varchar, varchar) owner to pgsql;

