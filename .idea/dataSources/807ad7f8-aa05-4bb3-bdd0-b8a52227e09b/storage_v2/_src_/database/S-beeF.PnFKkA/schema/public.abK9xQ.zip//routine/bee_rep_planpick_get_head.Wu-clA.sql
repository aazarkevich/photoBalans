create function bee_rep_planpick_get_head(_pointid integer, _per date)
    returns TABLE(docnum character varying, docdat date, cust_name character varying, obj_name character varying, adr character varying, disp_name character varying, day_start character varying, day_end character varying, month_year character varying)
    language plpgsql
as
$$
/*
	ito06 2020-08-27 Шапка отчета: плановые часы пиковой нагрузки
*/
BEGIN
  return query
  select 
		amn.docnumber AS docnum,
		amn.docdate AS docdat, 
		cust.abo_name AS cust_name,
		apn.prodnumber AS obj_name,
		ard.paramval::varchar AS adr,
		''::varchar AS disp_name,
		(EXTRACT (DAY FROM (SELECT (date_trunc('MONTH',  _per))::DATE)))::varchar AS day_start,
      	(EXTRACT (DAY FROM (SELECT (date_trunc('MONTH', _per) + INTERVAL '1 MONTH - 1 day')::DATE)))::varchar AS day_end,
        ( CASE WHEN EXTRACT (MONTH FROM _per) = 1
		          THEN 'января'
		       WHEN EXTRACT (MONTH FROM _per) = 2
		          THEN 'февраля'
		       WHEN EXTRACT (MONTH FROM _per) = 3
		          THEN 'марта'
		       WHEN EXTRACT (MONTH FROM _per) = 4
		          THEN 'апреля' 
		       WHEN EXTRACT (MONTH FROM _per) = 5
		          THEN 'мая'
		       WHEN EXTRACT (MONTH FROM _per) = 6
		          THEN 'июня'
		       WHEN EXTRACT (MONTH FROM _per) = 7
		          THEN 'июля'
		       WHEN EXTRACT (MONTH FROM _per) = 8
		          THEN 'августа'
		       WHEN EXTRACT (MONTH FROM _per) = 9
		          THEN 'сентября'
		       WHEN EXTRACT (MONTH FROM _per) = 10
		          THEN 'октября'	
		       WHEN EXTRACT (MONTH FROM _per) = 11
		          THEN 'ноября'		      		 
		       ELSE 'декабря'
		  END		 
		 || ' ' || EXTRACT (YEAR FROM _per) )::varchar AS month_year
   from agreepoint AS apn
   join agreement AS amn ON amn.rowid = apn.linkid
   join customer AS cust ON cust.abo_code = amn.abo_code
left join agreeregdev As ard On ard.linkid = apn.rowid AND ard.paramid=410 
   
  where apn.rowid = _pointid;			   
END;
$$;

comment on function bee_rep_planpick_get_head(integer, date) is ' Шапка отчета: плановые часы пиковой нагрузки. Используется в RepAktPlanPick.java';

alter function bee_rep_planpick_get_head(integer, date) owner to postgres;

