create function bee_add_bee_docs(agreeid integer, prefix integer, docnumber integer, doctype integer, docdate date, docvi integer, ed boolean, tag boolean) returns integer
    language plpgsql
as
$$
/*
	add ito06 2016-03-01,  если договор централизованный "прямой", то номер ему не присваеваем
	Ввод нового документа
*/
DECLARE
	NR     INTEGER;	
	_doctyp int = 0;
BEGIN
	BEGIN
		--** 2016-03-02
		select amn.doctype from agreement AS amn where rowid = agreeid INTO _doctyp;
		IF _doctyp = 1911 THEN docnumber = null; END IF;
		--**
		INSERT INTO bee_docs 
		        (linkid,  pref,   docnum,    doctyp,  docdat,  docvid, edit, doc_tag) VALUES
			(agreeid, prefix, docnumber, doctype, docdate, docvi,  ed,  tag ) 
		RETURNING rowid INTO NR;
	EXCEPTION
		WHEN UNIQUE_VIOLATION THEN RETURN -1;
	END;
	RETURN NR;

END;
$$;

comment on function bee_add_bee_docs(integer, integer, integer, integer, date, integer, boolean, boolean) is 'Добавление нового документа. Используется в DocMain.java, GroupDocsProcessing.java, PaymentDocs.java, AppUtils.java';

alter function bee_add_bee_docs(integer, integer, integer, integer, date, integer, boolean, boolean) owner to pgsql;

