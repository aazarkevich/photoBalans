create function bee_repakt2_change_fill_content(bd_rowid integer, diff boolean, _doctyp integer) returns SETOF integer[]
    language plpgsql
as
$$
/*
	add ito06 2015-12-10  добавили входной параметр _doctyp
	ito06 2015-07-09 Акт (соц. норма) для исправления - создание временной таблицы
*/
DECLARE
	_tartyp1 int = 0;
	_tartyp2 int = 0;

BEGIN
        IF _doctyp  = 1 
           THEN	--исправление
		_tartyp1 = 1707;
		_tartyp2 = 1142;
	   ELSIF _doctyp  = 2
	      THEN 	
		--корректировка 
		_tartyp1 = 1069;  
		_tartyp1 = 1159;         
		
        END IF;
	DROP TABLE IF EXISTS tmp_repakt2_change_content;
	CREATE TEMPORARY table tmp_repakt2_change_content 
	  AS ( SELECT * 
		FROM		 ((select * from bee_repakt2_change_get_intermediate_content1($1, diff, _tartyp1))
			UNION ALL (select * from bee_repakt2_change_get_intermediate_content2($1, diff, _tartyp2))) AS a
			WHERE tot_amount IS NOT NULL
			ORDER BY period, grp, tarname_grp);
END;
$$;

comment on function bee_repakt2_change_fill_content(integer, boolean, integer) is 'Акт (соц. норма) для исправления. Используется в bee_repakt2_change_get_content(int)';

alter function bee_repakt2_change_fill_content(integer, boolean, integer) owner to pgsql;

