create function bee_repakt2_change_get_tmp_loss(bd_rowid integer, row_typ integer, _tartyp character varying) returns SETOF numeric[]
    language plpgsql
as
$$
/*
   ito07 181107 bee_get_doc_tax
	add ito06 2015-12-10  добавили входной параметр _tartyp
	ito06 2015-07-09: Акт (соц. норма) для исправления или корректировки	
*/
BEGIN
	RETURN QUERY EXECUTE('
	  SELECT ARRAY[
	  sum(amount), 
	  sum(sum_no_tax), 
	  price, 
	  sum(sum_no_tax) * bee_get_doc_tax(1163,' || bd_rowid || '), 
	  sum(sum_no_tax) * (1 + bee_get_doc_tax(1163,'|| bd_rowid ||'))
	  ] AS m_tar
	  FROM bee_docs_result
	 WHERE linkid = '||$1||'
	   AND row_typ = '||$2||'
	   AND tar_typ IN ('||$3||')
	 GROUP BY price');
END;
$$;

comment on function bee_repakt2_change_get_tmp_loss(integer, integer, varchar) is 'Акт (соц. норма) для исправления или корректировки. Используется в bee_repakt2_change_get_content_loss(int, int)';

alter function bee_repakt2_change_get_tmp_loss(integer, integer, varchar) owner to pgsql;

