create function bee_get_accessrights_to_user(usrname character varying, form character varying, param character varying) returns boolean
    language plpgsql
as
$$
DECLARE flv boolean = false; --по умолчанию видимость - false
        fld boolean = true; --  по умолчанию заблокировано
        formid int = 0;
        usergrp int = 0;
        
BEGIN
        SELECT rowid FROM  dic_forms WHERE forms_name = $2 INTO formid; 
        SELECT grp FROM deusers WHERE usr = $1 INTO usergrp; 
        
	SELECT visible, disabled 
	  FROM dic_access_rights AS dar
          
          JOIN (  SELECT CASE WHEN  dar.mod IS NOT NULL
		                 THEN dar.mod
		              ELSE  CASE WHEN darw.mod IS NOT NULL AND du.mod ='a'
                                            THEN  darw.mod
                                          ELSE darr.mod 
                                    END     
                         END AS mod
                    FROM deusers AS du
               LEFT JOIN ( SELECT distinct dar.mod,dar.grp FROM dic_access_rights AS dar
                             JOIN deusers  AS du ON  du.grp = dar.grp AND dar.mod = du.mod  AND du.usr = $1 
                            WHERE  dar.forms = formid 
                         ) AS dar ON du.grp =  dar.grp
                   
               LEFT JOIN ( SELECT distinct dar.mod,dar.grp FROM dic_access_rights AS dar
                            WHERE  dar.forms = formid AND dar.grp = usergrp
                            AND dar.mod ='w'
                         ) AS  darw ON  du.grp =  darw.grp
                  
               LEFT JOIN ( SELECT distinct dar.mod,dar.grp   FROM dic_access_rights AS dar
                            WHERE  dar.forms = formid AND dar.grp = usergrp
                              AND dar.mod ='r'
                         ) AS  darr ON du.grp =  darr.grp
                    WHERE usr = $1 
               ) AS a ON  a.mod  = dar.mod        
  
          WHERE dar.forms = formid AND dar.grp = usergrp
          LIMIT 1 into flv, fld; 

	IF param = 'visible' 
	     THEN IF flv IS NOT NULL 
	                THEN RETURN flv;
                      ELSE RETURN false;
                  END IF;                    
             ELSE IF flv IS NOT NULL 
                       THEN  RETURN fld;
                     ELSE RETURN true;
                  END IF; 
        END IF;
END;
$$;

comment on function bee_get_accessrights_to_user(varchar, varchar, varchar) is 'Используется в Login.java, AppUtils.java';

alter function bee_get_accessrights_to_user(varchar, varchar, varchar) owner to pgsql;

