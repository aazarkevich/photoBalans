create function bee_rep_get_rephead(loc integer, str_d date, end_d date, fil character varying) returns SETOF bee_rephead
    language plpgsql
as
$$
/*
	ito06 2015-01-21  Шапка для сводных отчетов
*/
DECLARE tmp varchar;        
	_fil varchar;
	ListConn TEXT[];
	Result TEXT;
BEGIN
	IF $4 = '%' 
	   THEN RETURN QUERY
		(SELECT 		
			CASE 
			    WHEN $1 = mes.rowid
			      THEN mes.nam::varchar
			    ELSE (mes.nam || ' ' || res.nam)::varchar	
			END 										AS fil_name,
			(TO_CHAR($2,'DD.MM.YYYY'))::varchar						AS s_dat,
			(TO_CHAR($3+'1 month'::interval - '1 day'::interval,'DD.MM.YYYY'))::varchar	AS e_dat	
		   FROM denet AS res
		   JOIN denet AS mes ON mes.kod = substring(res.kod from 1 for 6)
		  WHERE res.rowid = $1 limit 1);
	 ELSIF $4 = 'f66apps%' 
	     THEN RETURN QUERY
		(SELECT 		
			res.nam::varchar									AS fil_name,
			(TO_CHAR($2,'DD.MM.YYYY'))::varchar						AS s_dat,
			(TO_CHAR($3+'1 month'::interval - '1 day'::interval,'DD.MM.YYYY'))::varchar	AS e_dat	
		   FROM denet AS res
		   
		  WHERE res.rowid = 693 limit 1);		  
		  
	   ELSE IF substring(fil from 2 for 2)  ='66' 
		   THEN _fil = substring(fil from 8 for 1);
		        IF _fil = '0' THEN tmp = 'g10m66r04';
		            ELSIF _fil ='1' THEN  tmp = 'g10m66r02'; 
		            ELSIF _fil ='2' THEN  tmp = 'g10m66r01'; 
		            ELSIF _fil ='3' THEN  tmp = 'g10m66r03'; 
                         END IF; 
		   
	           ELSE  tmp = 'g10m'||substring(fil from 2 for 2);
	        END IF; 

	        SELECT * FROM dblink_get_connections() INTO ListConn;
		IF 'deconn' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn') INTO Result; END IF;  
		SELECT dblink_connect_u('deconn', 'dbname=beeU  port=5432  host='''|| fil ||''' user=pgsql') INTO Result;
	
	        SELECT DISTINCT points.* FROM dblink('deconn','select nam from denet where kod = '''||tmp ||''';') AS points(nam varchar) INTO _fil ;
		RETURN QUERY
		(SELECT 		
			_fil										AS fil_name,
			(TO_CHAR($2,'DD.MM.YYYY'))::varchar						AS s_dat,
			(TO_CHAR($3+'1 month'::interval - '1 day'::interval,'DD.MM.YYYY'))::varchar	AS e_dat	
		   FROM denet AS res		
		  WHERE res.rowid = $1 limit 1);

	  	SELECT dblink_disconnect('deconn') INTO Result;
	END IF;
END;
$$;

comment on function bee_rep_get_rephead(integer, date, date, varchar) is 'Используется в RepCreate29.java';

alter function bee_rep_get_rephead(integer, date, date, varchar) owner to pgsql;

