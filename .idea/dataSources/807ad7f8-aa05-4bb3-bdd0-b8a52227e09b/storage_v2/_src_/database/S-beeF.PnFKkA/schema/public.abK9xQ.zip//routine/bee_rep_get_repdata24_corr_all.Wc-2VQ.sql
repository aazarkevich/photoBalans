create function bee_rep_get_repdata24_corr_all(loc_id integer, s_dat date, e_dat date) returns SETOF bee_repdata24
    language plpgsql
as
$$
/*
	add ito06 2015-08-06
	ito06 2012-02-10 Ведомость по объему услуг
*/
BEGIN
RETURN QUERY(
	SELECT * FROM(
		 (SELECT * FROM bee_rep_get_repdata24_cont_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tmp) ) AS a
		WHERE dat >'1999-12-31'
		ORDER BY nn, dat);
END;
$$;

comment on function bee_rep_get_repdata24_corr_all(integer, date, date) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24(int, date, date), bee_rep_get_repdata24_all(int, date, date)б bee_rep_get_repdata24_all_cust(int, date, date), bee_rep_get_repdata24_cust(int, date, date)';

alter function bee_rep_get_repdata24_corr_all(integer, date, date) owner to pgsql;

