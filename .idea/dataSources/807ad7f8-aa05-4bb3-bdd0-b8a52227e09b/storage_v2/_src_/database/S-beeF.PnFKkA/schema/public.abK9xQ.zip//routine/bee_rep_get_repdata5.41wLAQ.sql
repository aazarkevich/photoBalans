create function bee_rep_get_repdata5(loc integer, strdate date, enddate date) returns SETOF bee_rep_tab5
    language sql
as
$$
    /*
    ito16
    10.11.24
    */
SELECT
  a.grp AS grp,
  a.adrfio AS adrfio,
  a.account AS account,
  a.prdnum AS prdnum,
  a.docnum AS docnum,
  char_length(a.docnum) AS doc_length,
  to_char(b.date,'DD.MM.YYYY') AS date1,
  b.val195 AS v195,
  b.val196 AS v196,
  b.val407 AS v407,
  to_char(b.date975,'DD.MM.YYYY') AS date975,
  b.val195in975 AS v195in975,
  b.val196in975 AS v196in975,
  b.val407in975 AS v407in975,
  b.orderdate   AS orderdate
FROM(
	SELECT 
	  apn.rowid                              AS id,
	  bee_get_oper_regdevval(apn.rowid,715)  AS grp,
	  (ard.paramval || ', ' || cst.abo_name) AS adrfio,
	  char_length(apn.account)               AS acc_length,
	  apn.account  				 AS account,
	  apn.prodnumber			 AS prdnum,
	  amn.docnumber				 AS docnum
	-----------------------------------------------------------------------	
	FROM customer AS cst
	  JOIN agreement     AS amn    ON (amn.abo_code = cst.abo_code OR amn.abo_code=0)
	  JOIN agreepoint    AS apn    ON apn.linkid    = amn.rowid
	  JOIN agreeregdev   AS ard    ON ard.linkid    = apn.rowid
	  JOIN regdevoper    AS rdo    ON rdo.linkid    = apn.rowid AND rdo.paramid=407 AND rdo.valman ~ E'^\\d{1,}' AND rdo.operdate>($2-'1 month'::interval)
	WHERE
	  cst.locid = $1 AND 
	  ard.paramid = 417 AND 
	  ard.paramval IS NOT NULL AND
	  rdo.valman::numeric>0
	GROUP BY grp,adrfio,acc_length,account,prdnum,docnum,apn.rowid
) AS a 
JOIN( SELECT * FROM bee_rep7function($1,$2,$3)) AS b on a.id IN (b.bid,b.aid)
GROUP BY grp,adrfio,account,prdnum,docnum,date1,v195,v196,v407,date975,v196in975,v195in975,v407in975,orderdate
ORDER BY doc_length,docnum,account,adrfio,orderdate;
$$;

comment on function bee_rep_get_repdata5(integer, date, date) is ' Формирование корректировочной ведомости потребления электроэнергии по данным ОАО Донэнерго и ООО Донэнергосбыт все. Используется в RepCreate7.java';

alter function bee_rep_get_repdata5(integer, date, date) owner to pgsql;

