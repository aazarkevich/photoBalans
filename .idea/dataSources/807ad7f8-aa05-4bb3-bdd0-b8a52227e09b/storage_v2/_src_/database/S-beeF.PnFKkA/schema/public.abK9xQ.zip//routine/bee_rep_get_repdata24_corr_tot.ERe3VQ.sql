create function bee_rep_get_repdata24_corr_tot(loc_id integer, s_date date, e_date date) returns SETOF bee_repdata24
    language plpgsql
as
$$
/*
	add ito06 2015-08-06
	ito06 2012-02-10 Ведомость по объему услуг
*/
BEGIN
RETURN QUERY(
	SELECT
	  0::integer AS grp,
	  'bold'::text AS row_style,
	   dat AS dat,
	  '0б'::text AS nn,
	  '0б'::text AS nn_tmp,
	  'Корректировка за '||to_char(dat,'YYYY-MM') AS name,
	  null::text AS doc_name,
	  null::numeric,
	  null::numeric,
	  null::numeric,
	  null::numeric,
	  null::numeric(12,6) AS tar_m_tot,
	  null::numeric(12,6) AS tar_m_vn,
	  null::numeric(12,6) AS tar_m_sn1,
	  null::numeric(12,6) AS tar_m_sn2,
	  null::numeric(12,6) AS tar_m_nn,

	  sum(CASE WHEN (nn<>'2.2.1.2') AND (nn<>'1.2.1.2')
	    THEN tot_amount
	    ELSE NULL
	  END) AS tot_amount,
	  sum(CASE WHEN (nn<>'2.2.1.2') AND (nn<>'1.2.1.2')
	    THEN vn_amount
	    ELSE NULL
	  END) AS vn_amount,
	  sum(CASE WHEN (nn<>'2.2.1.2') AND (nn<>'1.2.1.2')
	    THEN sn1_amount
	    ELSE NULL
	  END) AS sn1_amount,
	   sum(CASE WHEN (nn<>'2.2.1.2') AND (nn<>'1.2.1.2')
	    THEN sn2_amount
	    ELSE NULL
	  END) AS sn2_amount,

	  sum(CASE WHEN (nn<>'2.2.1.2') AND (nn<>'1.2.1.2')
	     THEN nn_amount
	    ELSE NULL
	  END) AS nn_amount,
	  sum(tot_sum) AS tot_sum,
	  sum(vn_sum) AS vn_sum,
	  sum(sn1_sum) AS sn1_sum,
	  sum(sn2_sum) AS sn2_sum,
	  sum(nn_sum) AS nn_sum
	FROM bee_rep_get_repdata24_cont_tmp AS a
	WHERE dat >'1999-12-31'
	GROUP BY dat);
END;
$$;

comment on function bee_rep_get_repdata24_corr_tot(integer, date, date) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24(int, date, date), bee_rep_get_repdata24_all(int, date, date), bee_rep_get_repdata24_all_cust(int, date, date), bee_rep_get_repdata24_corr_all(int, date, date), bee_rep_get_repdata24_cust(int, date, date)';

alter function bee_rep_get_repdata24_corr_tot(integer, date, date) owner to pgsql;

