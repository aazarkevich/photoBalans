create function bee_get_doc_tax(vid integer, dat date) returns double precision
    language plpgsql
as
$$
    --
  -- ЗНАЧЕНИЕ СТАВКИ НАЛОГА
  -- vid : вид налога.
  --
BEGIN
   --
   RETURN (
      select (tax_proc / 100)::numeric(4,2)  from bee_docs_tax
      where
        dat1 <= dat and
        tax_vid = vid
        order by dat1 desc limit 1
   );
   --
END;
$$;

comment on function bee_get_doc_tax(integer, date) is 'Получить ставку налога по дате';

alter function bee_get_doc_tax(integer, date) owner to postgres;

