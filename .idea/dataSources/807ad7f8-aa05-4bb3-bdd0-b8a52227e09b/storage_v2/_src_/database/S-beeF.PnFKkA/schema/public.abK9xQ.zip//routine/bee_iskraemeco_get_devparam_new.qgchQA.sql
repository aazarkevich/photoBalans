create function bee_iskraemeco_get_devparam_new()
    returns TABLE(docnum character varying, dev_num character varying, oper_val numeric, oper_date date, ok integer, ok_text character varying, prim character varying, db_tag character varying, db_name character varying, locid integer, dev_mark character varying, src character varying, pointid integer, loaddate date, locid_name character varying, tp integer, tp_name text)
    language plpgsql
as
$$
/*
	add ito06 2015-11-17 добавили расшифровку участка и ТП
	add ito06 2015-11-13 Данные о загруженных счетчиках из (искры и энергомеры)
*/
DECLARE
	ListConn  TEXT[];
	Result    TEXT;
	Rec       RECORD;
	curr_dbase varchar = 'beeU';
	res_dbase varchar = 'beeF';
	
BEGIN
	--параметры соединения
	SELECT * FROM dblink_get_connections() INTO ListConn;
	IF 'iskrconn2' = ANY (ListConn) THEN SELECT dblink_disconnect('iskrconn2') INTO Result; END IF;
	
	select * from current_database() INTO curr_dbase;

	IF (curr_dbase = 'beeF') THEN res_dbase = 'beeU'; END IF;	
	SELECT hostname,dbname,dbport FROM bee_closed_info WHERE dbname = res_dbase INTO Rec;
	--
	IF (Rec IS NOT NULL) THEN
	   SELECT dblink_connect_u('iskrconn2',
	      ' dbname   = ' || res_dbase   ||
	      ' port     = ' || Rec.dbport   ||
	      ' host     = ' || Rec.hostname ||
	      ' user     = ' || 'pgsql'      ||
	      ' password = ' || '') INTO Result;   

	RETURN QUERY(
		(SELECT t.* FROM dblink('iskrconn2',
                ' SELECT DISTINCT 
			amn.docnumber							AS docnum,
			list.prodnum							AS dev_num,			
			bes.operval 							AS oper_val,
			bes.operdate 							AS oper_date,			
			CASE
			    WHEN bes.ready AND rdo.rowid IS NOT NULL THEN 0	
			    WHEN bes.ready IS NULL THEN 1			    		    
			    ELSE bes.err
			END  								AS ok,
			CASE
			    WHEN bes.ready AND rdo.rowid IS NOT NULL THEN ''загружен''::text
			    ELSE ''ошибка загрузки''::text
			END::varchar							AS ok_text,
			
			CASE
			    WHEN bes.ready AND rdo.rowid IS NULL THEN ''Несколько счетчиков с одним номером, показания введены на другой.''
			    WHEN bes.ready IS NULL THEN ''В источнике нет счетчиков с таким номером!''			    
			    ELSE de2.element_name
			END 								AS prim,
			list.db_tag 							AS db_tag,
			CASE
			    WHEN list.db_tag::text = ''U''::text THEN ''юр лица''::text
			    WHEN list.db_tag::text = ''F''::text THEN ''физ лица''::text
			    ELSE ''отсутсвует''::text
			END::varchar							AS db_name,
			list.locid 							AS locid,
			CASE WHEN de.element_name IS NOT NULL
			  THEN  de.element_name
			  ELSE ''-''	
			  END 								AS dev_mark,
			de1.element_name::varchar					AS src, 
			list.pointid							AS pointid,
			bes.loaddate 							AS loaddate, 
			dn.nam	 							AS locid_name,
			rdc.traceid 							AS tp,
			CASE
			   WHEN regexp_replace(gis.pchain, ''\+.{1,}?\+.{1,}?\+.{1,}?\+''::text, ''''::text) IS NULL 
			     THEN ''-''::text
			   ELSE regexp_replace(gis.pchain, ''\+.{1,}?\+.{1,}?\+.{1,}?\+''::text, ''''::text)
			END 									AS tp_name
		   FROM bee_iskraemeco_get_devload_list() AS list
	      LEFT JOIN bee_external_agreepoint AS apn_ext ON apn_ext.rowid = list.pointid
	      LEFT JOIN bee_external_src AS bes ON list.prodnum = bes.dev_num AND list.src = bes.srv 
	      LEFT JOIN agreement AS amn ON amn.rowid = list.amnid
	      LEFT JOIN dic_elements AS de ON de.rowid = list.devid
	      LEFT JOIN dic_elements AS de1 ON de1.element_code = list.src AND de1.link = 176
      	      LEFT JOIN dic_elements AS de2 ON de2.element_code = bes.err AND de2.link = 177
      	      LEFT JOIN regdevoper AS rdo ON rdo.linkid = list.pointid AND rdo.operdate = bes.operdate AND rdo.paramid = 195 AND rdo.valman::numeric = bes.operval::numeric
      	           JOIN denet AS dn ON dn.rowid = list.locid
	      LEFT JOIN regdevconn AS rdc on rdc.pointid = list.pointid 
	      LEFT JOIN gis_traces AS gis On gis.rowid = rdc.traceid 
		  WHERE ''bee''||list.db_tag = '''||res_dbase||''' AND (apn_ext.rowid IS NOT NULL OR rdo.rowid IS NOT NULL)
		  ORDER BY list.prodnum' ) AS t (docnum varchar, dev_num varchar, oper_val numeric, oper_date date, ok integer, ok_text varchar, prim varchar, db_tag varchar, db_name varchar, locid integer,dev_mark varchar,src varchar, pointid int, loaddate date, locid_name varchar, tp integer, tp_name text))
	UNION (  SELECT DISTINCT 
			amn.docnumber							AS docnum,
			list.prodnum							AS dev_num,			
			bes.operval 							AS oper_val,
			bes.operdate 							AS oper_date,			
			CASE
			    WHEN bes.ready AND rdo.rowid IS NOT NULL THEN 0	
			    WHEN bes.ready IS NULL THEN 1			    		    
			    ELSE bes.err
			END  								AS ok,
			CASE
			    WHEN bes.ready AND rdo.rowid IS NOT NULL THEN 'загружен'::text
			    ELSE 'ошибка загрузки'::text
			END::varchar							AS ok_text,
			
			CASE
			    WHEN bes.ready AND rdo.rowid IS NULL THEN 'Несколько счетчиков с одним номером, показания введены на другой.'
			    WHEN bes.ready IS NULL THEN 'В источнике нет счетчиков с таким номером!'			    
			    ELSE de2.element_name
			END 								AS prim,
			list.db_tag 							AS db_tag,
			CASE
			    WHEN list.db_tag::text = 'U'::text THEN 'юр лица'::text
			    WHEN list.db_tag::text = 'F'::text THEN 'физ лица'::text
			    ELSE 'отсутсвует'::text
			END::varchar							AS db_name,
			list.locid 							AS locid,
			CASE WHEN de.element_name IS NOT NULL
			  THEN  de.element_name
			  ELSE '-' 	
			  END 								AS dev_mark,
			de1.element_name::varchar					AS src, 
			list.pointid							AS pointid,
			bes.loaddate 							AS loaddate, 
			dn.nam	 							AS locid_name,
			rdc.traceid 							AS tp,
			CASE
			   WHEN regexp_replace(gis.pchain, '\+.{1,}?\+.{1,}?\+.{1,}?\+'::text, ''::text) IS NULL 
			     THEN '-'::text
			   ELSE regexp_replace(gis.pchain, '\+.{1,}?\+.{1,}?\+.{1,}?\+'::text, ''::text)
			END 									AS tp_name
		   FROM bee_iskraemeco_get_devload_list() AS list
	      LEFT JOIN bee_external_agreepoint AS apn_ext ON apn_ext.rowid = list.pointid
	      LEFT JOIN bee_external_src AS bes ON list.prodnum = bes.dev_num AND list.src = bes.srv 
	      LEFT JOIN agreement AS amn ON amn.rowid = list.amnid
	      LEFT JOIN dic_elements AS de ON de.rowid = list.devid
	      LEFT JOIN dic_elements AS de1 ON de1.element_code = list.src AND de1.link = 176
      	      LEFT JOIN dic_elements AS de2 ON de2.element_code = bes.err AND de2.link = 177
      	      LEFT JOIN regdevoper AS rdo ON rdo.linkid = list.pointid AND rdo.operdate = bes.operdate AND rdo.paramid = 195 AND rdo.valman::numeric = bes.operval::numeric
      	           JOIN denet AS dn ON dn.rowid = list.locid
	      LEFT JOIN regdevconn AS rdc on rdc.pointid = list.pointid 
	      LEFT JOIN gis_traces AS gis On gis.rowid = rdc.traceid 
		  WHERE 'bee'||list.db_tag = curr_dbase AND (apn_ext.rowid IS NOT NULL OR rdo.rowid IS NOT NULL)
		  ORDER BY list.prodnum));
	     --удаляем соединение
	     IF 'iskrconn2' = ANY (ListConn) THEN SELECT dblink_disconnect('iskrconn2') INTO Result; END IF;	     
	   ELSE 
		RETURN QUERY
		  SELECT DISTINCT 
			amn.docnumber							AS docnum,
			list.prodnum							AS dev_num,			
			bes.operval 							AS oper_val,
			bes.operdate 							AS oper_date,			
			CASE
			    WHEN bes.ready AND rdo.rowid IS NOT NULL THEN 0	
			    WHEN bes.ready IS NULL THEN 1			    		    
			    ELSE bes.err
			END  								AS ok,
			CASE
			    WHEN bes.ready AND rdo.rowid IS NOT NULL THEN 'загружен'::text
			    ELSE 'ошибка загрузки'::text
			END::varchar							AS ok_text,
			
			CASE
			    WHEN bes.ready AND rdo.rowid IS NULL THEN 'Несколько счетчиков с одним номером, показания введены на другой.'
			    WHEN bes.ready IS NULL THEN 'В источнике нет счетчиков с таким номером!'			    
			    ELSE de2.element_name
			END 								AS prim,
			list.db_tag 							AS db_tag,
			CASE
			    WHEN list.db_tag::text = 'U'::text THEN 'юр лица'::text
			    WHEN list.db_tag::text = 'F'::text THEN 'физ лица'::text
			    ELSE 'отсутсвует'::text
			END::varchar							AS db_name,
			list.locid 							AS locid,
			CASE WHEN de.element_name IS NOT NULL
			  THEN  de.element_name
			  ELSE '-' 	
			  END 								AS dev_mark,
			de1.element_name::varchar					AS src, 
			list.pointid							AS pointid,
			bes.loaddate 							AS loaddate, 
			dn.nam	 							AS locid_name,
			rdc.traceid 							AS tp,
			CASE
			   WHEN regexp_replace(gis.pchain, '\+.{1,}?\+.{1,}?\+.{1,}?\+'::text, ''::text) IS NULL 
			     THEN '-'::text
			   ELSE regexp_replace(gis.pchain, '\+.{1,}?\+.{1,}?\+.{1,}?\+'::text, ''::text)
			END 									AS tp_name
		   FROM bee_iskraemeco_get_devload_list() AS list
	      LEFT JOIN bee_external_agreepoint AS apn_ext ON apn_ext.rowid = list.pointid
	      LEFT JOIN bee_external_src AS bes ON list.prodnum = bes.dev_num AND list.src = bes.srv 
	      LEFT JOIN agreement AS amn ON amn.rowid = list.amnid
	      LEFT JOIN dic_elements AS de ON de.rowid = list.devid
	      LEFT JOIN dic_elements AS de1 ON de1.element_code = list.src AND de1.link = 176
      	      LEFT JOIN dic_elements AS de2 ON de2.element_code = bes.err AND de2.link = 177
      	      LEFT JOIN regdevoper AS rdo ON rdo.linkid = list.pointid AND rdo.operdate = bes.operdate AND rdo.paramid = 195 AND rdo.valman::numeric = bes.operval::numeric
      	           JOIN denet AS dn ON dn.rowid = list.locid
	      LEFT JOIN regdevconn AS rdc on rdc.pointid = list.pointid 
	      LEFT JOIN gis_traces AS gis On gis.rowid = rdc.traceid 
		  WHERE 'bee'||list.db_tag = curr_dbase AND (apn_ext.rowid IS NOT NULL OR rdo.rowid IS NOT NULL)
		  ORDER BY list.prodnum;	  		  
	END IF; 
END;
$$;

comment on function bee_iskraemeco_get_devparam_new() is 'Данные о загруженных счетчиках из (искры и энергомеры). Используется в IskraEmeco.java, SessionBean1.java';

alter function bee_iskraemeco_get_devparam_new() owner to pgsql;

