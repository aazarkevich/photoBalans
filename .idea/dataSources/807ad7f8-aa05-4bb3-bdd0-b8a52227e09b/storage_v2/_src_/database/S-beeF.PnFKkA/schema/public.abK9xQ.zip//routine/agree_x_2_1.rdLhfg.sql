create function agree_x_2_1(dbn character varying, agr_num character varying, agr_rid integer, tagid integer, src_host character varying, src_port character varying) returns void
    language plpgsql
as
$$
DECLARE
/* 180210 by ito07
*/
   Agr RECORD; -- for agreement 
   Pnt RECORD; -- for agreepoint
   Rec RECORD;
   Rec1 RECORD;
   agreement_rowid INTEGER;

BEGIN
      SELECT rowid 
      from agreement 
      where docnumber = agr_num and docstatus = 79 LIMIT 1 
      INTO agreement_rowid;
      --RAISE NOTICE 'ENTRY agree_x_2_1 1 : %:%',agr_num,agreement_rowid ;  
      for Rec IN ( -- EXTERNAL POINTS
        select 
            pntid, refdoc 
        from agree_get_agreepoint_ext(dbn, agr_num, tagid, src_host, src_port) -- pntid : ext agrreepoint.rowid
      ) 
      loop
      --RAISE NOTICE 'ENTRY agree_x_2_1 2 : %:%',Rec.pntid,Rec.refdoc ;       
         for Rec1 IN ( -- EXTERNAL VALUES
             SELECT DISTINCT agreement_rowid, devid,account,prodnumber,devtype,rowid,deleted,lid -- rowid: ext agreepoint.rowid
             FROM agree_get_agreepoint(dbn,agr_num,tagid,src_host, src_port) x
             WHERE 
                 x.rowid  = Rec.pntid -- agreepoint`s
         ) 
         loop
            if exists 
               (
                select 1 from agreepoint 
                where 
                   rowid = Rec.pntid and linkid = agreement_rowid
               ) 
            THEN
               --RAISE NOTICE 'ENTRY agree_x_2_1 Upd: %:%',Rec.pntid, Rec1.rowid;          
               BEGIN -- UPDATE CHANGED IN REMOTE
                  update agreepoint set
                     devid      = Rec1.devid,
                     account    = Rec1.account,
                     prodnumber = Rec1.prodnumber,
                     devtype    = Rec1.devtype,
                     rowid      = Rec1.rowid,
                     deleted    = Rec1.deleted,
                     lid        = Rec1.lid
                  where 
                     rowid = Rec.pntid and 
                     linkid = agreement_rowid;
               EXCEPTION
                   WHEN others 
                      THEN 
                         RAISE NOTICE 'Err Exeption agree_x_2_1 Upd: %:%',Rec.pntid, Rec1.rowid; 
                         CONTINUE;
               END;
            else
               --RAISE NOTICE 'ENTRY 3 Ins: %:%:%',agreement_rowid,Rec.pntid, Rec1.rowid;      
               BEGIN --INSERT NEW FROM REMOTE
                  INSERT INTO agreepoint (linkid, devid,account,prodnumber,devtype,rowid,deleted,lid)
                  values (agreement_rowid, Rec1.devid,Rec1.account,Rec1.prodnumber,Rec1.devtype,Rec1.rowid,Rec1.deleted,Rec1.lid);
               EXCEPTION
                  WHEN others 
                     THEN 
                        RAISE NOTICE 'Err Exeption agree_x_2_1 Ins: %:%:%', agreement_rowid, Rec.pntid, Rec1.rowid;
                        CONTINUE;
               END;
            end if;
         END loop;   
      end loop;
     
END;
$$;

alter function agree_x_2_1(varchar, varchar, integer, integer, varchar, varchar) owner to pgsql;

