create function bee_rep_get_repdata25_all(loc_id integer, start_d date, end_d date) returns SETOF bee_repdata25
    language plpgsql
as
$$
/*
    ito07 2019-08-2 DB CR ->DB ->CR
    add ito06 2015-09-30 Изменили названия колонок для  разделителя
    add ito06 2015-06-23
    add ito06 2015-05-12 
    add ito06 2013-10-22
    add ito06 2012-10-02	   
    ito06 2011-07-21: Реализация эл эн

*/
BEGIN
    DROP TABLE IF EXISTS bee_rep_get_repdata25_tmp;
        CREATE TEMPORARY table bee_rep_get_repdata25_tmp AS
    (SELECT * FROM bee_rep_get_repdata25_content($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));

RETURN QUERY(          
    (SELECT 'bold'::varchar	   					AS row_style,
        null::varchar 						AS nn,
        '01'::varchar 						AS nn1,
        'ВСЕГО'::varchar					AS name,
        row.*,
        null::smallint 						AS accdir,
        null::int 						AS loc,
        'ВСЕГО'::varchar  					AS ord
    FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,0) AS row)
    UNION 
    (SELECT 'bold'::varchar	   					AS row_style,
        '1'::varchar 						AS nn,
        '10'::varchar 						AS nn1,
        'Прочие потребители'::varchar  				AS name,
        row.*,
        null::smallint 						AS accdir,
        null::int 						AS loc,
        'Прочие потребители'::varchar  				AS ord
    FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,10) AS row)
    UNION 
    (SELECT 'norm'::varchar	   					AS row_style,
        null::varchar 						AS nn,
        '100'::varchar						AS nn1,
        CASE 
            WHEN npp = 1 
	THEN  doc_num||', '||abo_num 
            WHEN npp = 2 
	THEN  'в т.ч. юр.лица'
            WHEN npp = 3 
	THEN  'в т.ч. население в пределах соц. нормы' 
            WHEN npp = 4 
	THEN  'в т.ч. население свыше соц. нормы'   
        END::varchar   						AS name, 
        d_start_sum 						AS d_start_sum, 
        k_start_sum 						AS k_start_sum,  
        amount  						AS  amount,   
        amount1 						AS amount1,  
        amount2 						AS amount2,  
        sum_with_tax  						AS sum_with_tax,
        sum_no_tax 						AS sum_no_tax,
        sum_with_tax1068 					AS sum_with_tax1068, 
        sum_no_tax1068 						AS sum_no_tax1068,
        sum_with_tax1069 					AS sum_with_tax1069,
        sum_no_tax1069 						AS sum_no_tax1069,
        tar 							AS tar, 
        fact_all_sum 						AS fact_all_sum,
        payed_sum							AS payed_sum,
        retrest_sum 						AS retrest_sum,
        disc_sum 							AS disc_sum,

        -- 190513 by ito07 
        --d_end_sum 							AS d_end_sum,
        --k_end_sum 							AS k_end_sum,
        
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN d_end_sum - k_end_sum
               ELSE 0.00    
        END AS d_end_sum,
    
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN 0.00
               ELSE k_end_sum  - d_end_sum  
        END AS k_end_sum,	
        
        pay_all_sum 						AS pay_all_sum,
        fact_adv_sum 						AS fact_adv_sum,
        ext_sum 							AS ext_sum,
        accdir 							AS accdir,
        loc 							AS loc,
        (doc_num||', '||abo_num || ', ' ||npp)::varchar		AS ord
    FROM bee_rep_get_repdata25_tmp 
    WHERE  accdir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623))
    UNION
    (SELECT 'bold'::varchar	   					AS row_style,
        '2'::varchar 						AS nn,
        '20'::varchar  						AS nn1,
        'Бюджетные потребители'::varchar			AS name,  
        row.*,
        null::smallint 						AS accdir,
        null::int 						AS loc,
        'Бюджетные потребители'::varchar  			AS ord
    FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,20) AS row)
    UNION 
    (SELECT 'bold'::varchar 					AS row_style,
        '2.1'::varchar  					AS nn,
        '21' ::varchar 						AS nn1,
        '-федеральный бюджет' ::varchar 			AS name,
        row.*,
        null::smallint 						AS accdir,
        null::int 						AS loc,
        '-областной бюджет'::varchar  				AS ord
    FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,21) AS row)
    UNION 
    (SELECT 'norm'::varchar	   					AS row_style,
        null::varchar 						AS nn,
        '210'::varchar						AS nn1,
        CASE 
            WHEN npp = 1 
	THEN  doc_num||', '||abo_num 
            WHEN npp = 2 
	THEN  'в т.ч. юр.лица'
            WHEN npp = 3 
	THEN  'в т.ч. население в пределах соц. нормы' 
            WHEN npp = 4 
	THEN  'в т.ч. население свыше соц. нормы'   
        END::varchar   						AS name,  
        d_start_sum 						AS d_start_sum, 
        k_start_sum 						AS k_start_sum,  
        amount  						AS  amount,   
        amount1 						AS amount1,  
        amount2 						AS amount2,  
        sum_with_tax  						AS sum_with_tax,
        sum_no_tax 						AS sum_no_tax,
        sum_with_tax1068 					AS sum_with_tax1068, 
        sum_no_tax1068 						AS sum_no_tax1068,
        sum_with_tax1069					AS sum_with_tax1069,
        sum_no_tax1069 						AS sum_no_tax1069,
        tar 							AS tar, 
        fact_all_sum 						AS fact_all_sum,
        payed_sum 							AS payed_sum,
        retrest_sum 						AS retrest_sum,
        disc_sum 							AS disc_sum,
        
        --d_end_sum 							AS d_end_sum,
        --k_end_sum 							AS k_end_sum,
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN d_end_sum - k_end_sum
               ELSE 0.00    
        END AS d_end_sum,
    
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN 0.00
               ELSE k_end_sum  - d_end_sum  
        END AS k_end_sum,	
        
        pay_all_sum 						AS pay_all_sum,
        fact_adv_sum 						AS fact_adv_sum,
        ext_sum 							AS ext_sum,
        accdir 							AS accdir,
        loc 							AS loc,
        (doc_num||', '||abo_num || ', ' ||npp)::varchar		AS ord
    FROM bee_rep_get_repdata25_tmp 
    WHERE  accdir  =  835)
    UNION 
    (SELECT 'bold'::varchar	   					AS row_style,
        '2.2'::varchar 						AS nn,
        '22'::varchar 						AS nn1,
        '-областной бюджет'::varchar				AS name,
        row.*,
        null::smallint 						AS accdir,
        null::int 						AS loc,
        '-областной бюджет'::varchar 				AS ord
    FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,22) AS row)
    UNION 
    (SELECT 'norm'::varchar	   					AS row_style,
        null::varchar  						AS nn,
        '220'::varchar 						AS nn1,
        CASE 
            WHEN npp = 1 
	THEN  doc_num||', '||abo_num 
            WHEN npp = 2 
	THEN  'в т.ч. юр.лица'
            WHEN npp = 3 
	THEN  'в т.ч. население в пределах соц. нормы' 
            WHEN npp = 4 
	THEN  'в т.ч. население свыше соц. нормы'   
        END::varchar						AS name,  
        d_start_sum  						AS d_start_sum, 
        k_start_sum  						AS k_start_sum,  
        amount    						AS  amount,   
        amount1   						AS amount1,  
        amount2   						AS amount2,  
        sum_with_tax   						AS sum_with_tax,
        sum_no_tax   						AS sum_no_tax,
        sum_with_tax1068  					AS sum_with_tax1068, 
        sum_no_tax1068   					AS sum_no_tax1068,
        sum_with_tax1069  					AS sum_with_tax1069,
        sum_no_tax1069  					AS sum_no_tax1069,
        tar   							AS tar, 
        fact_all_sum   						AS fact_all_sum,		
        payed_sum   						AS payed_sum,
        retrest_sum   						AS retrest_sum,
        disc_sum   							AS disc_sum,
        
        --d_end_sum   						AS d_end_sum,
        --k_end_sum   						AS k_end_sum,
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN d_end_sum - k_end_sum
               ELSE 0.00    
        END AS d_end_sum,
    
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN 0.00
               ELSE k_end_sum  - d_end_sum  
        END AS k_end_sum,	
        
        pay_all_sum   						AS pay_all_sum,
        fact_adv_sum   						AS fact_adv_sum,
        ext_sum   							AS ext_sum,
        accdir 							AS accdir,
        loc 							AS loc,
        (doc_num||', '||abo_num || ', ' ||npp)::varchar 	AS ord
    FROM bee_rep_get_repdata25_tmp 
    WHERE  accdir  =  836)
    UNION
    (SELECT 'bold'::varchar	   					AS row_style,
        '2.3'::varchar   					AS nn,
        '23'::varchar   					AS nn1,
        '-местный бюджет'::varchar    				AS name,
        row.*,
        null::smallint 						AS accdir,
        null::int 						AS loc,
        '-местный бюджет'::varchar  				AS ord
    FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,23) AS row)
    UNION	
    (SELECT 'bold'::varchar   					AS row_style,
        '2.3.1'::varchar   					AS nn,
        '231'::varchar   					AS nn1,
        '--юр. лица'::varchar    				AS name,
        row.*,
        null::smallint 						AS accdir,
        null::int 						AS loc,
        '--юр. лица'::varchar					AS order_nam
    FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,231) AS row)
    UNION 
    (SELECT 'norm'::varchar	   					AS row_style,
        null::varchar   					AS nn,
        '2310'::varchar 					AS nn1,
        CASE 
            WHEN npp = 1 
	THEN  doc_num||', '||abo_num 
            WHEN npp = 2 
	THEN  'в т.ч. юр.лица'
            WHEN npp = 3 
	THEN  'в т.ч. население в пределах соц. нормы' 
            WHEN npp = 4 
	THEN  'в т.ч. население свыше соц. нормы'   
        END::varchar						AS name,  
        d_start_sum   						AS d_start_sum, 
        k_start_sum   						AS k_start_sum,  
        amount    						AS  amount,   
        amount1   						AS amount1,  
        amount2   						AS amount2,  
        sum_with_tax    					AS sum_with_tax,
        sum_no_tax   						AS sum_no_tax,
        sum_with_tax1068   					AS sum_with_tax1068, 
        sum_no_tax1068   					AS sum_no_tax1068,
        sum_with_tax1069 					AS sum_with_tax1069,
        sum_no_tax1069 						AS sum_no_tax1069,
        tar   							AS tar, 
        fact_all_sum   						AS fact_all_sum,		
        payed_sum   						AS payed_sum,
        retrest_sum   						AS retrest_sum,
        disc_sum   							AS disc_sum,
        --d_end_sum   						AS d_end_sum,
        --k_end_sum   						AS k_end_sum,
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN d_end_sum - k_end_sum
               ELSE 0.00    
        END AS d_end_sum,
    
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN 0.00
               ELSE k_end_sum  - d_end_sum  
        END AS k_end_sum,	

        
        pay_all_sum   						AS  pay_all_sum,
        fact_adv_sum   						AS fact_adv_sum,
        ext_sum   							AS ext_sum,
        accdir   						AS accdir,
        loc   							AS loc,
        (doc_num||', '||abo_num || ', ' ||npp)::varchar		AS ord
    FROM bee_rep_get_repdata25_tmp 
    WHERE  accdir IN (832, 837, 838, 839, 840, 841, 842))
    UNION 
    (SELECT 'bold'::varchar	   					AS row_style,
        '2.3.2'::varchar   					AS nn,
        '232'::varchar   					AS nn1,
        '--уличное освещение'::varchar  			AS name,
        row.*,
        null::smallint 						AS accdir,
        null::int 						AS loc,
        '--уличное освещение'::varchar  			AS ord
    FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,232) AS row)
    UNION 
    (SELECT 'norm'::varchar	   					AS row_style,
        null::varchar 						AS nn,
        '2320'::varchar   					AS nn1,
        CASE 
            WHEN npp = 1 
	THEN  doc_num||', '||abo_num 
            WHEN npp = 2 
	THEN  'в т.ч. юр.лица'
            WHEN npp = 3 
	THEN  'в т.ч. население в пределах соц. нормы' 
            WHEN npp = 4 
	THEN  'в т.ч. население свыше соц. нормы'   
        END::varchar     					AS name, 
        d_start_sum   						AS d_start_sum, 
        k_start_sum   						AS k_start_sum,  
        amount    						AS  amount,   
        amount1   						AS amount1,  
        amount2   						AS amount2,  
        sum_with_tax    					AS sum_with_tax,
        sum_no_tax   						AS sum_no_tax,
        sum_with_tax1068   					AS sum_with_tax1068, 
        sum_no_tax1068   					AS sum_no_tax1068,
        sum_with_tax1069   					AS sum_with_tax1069,
        sum_no_tax1069   					AS sum_no_tax1069,
        tar   							AS tar, 
        fact_all_sum   						AS fact_all_sum,		
        payed_sum   						AS payed_sum,
        retrest_sum   						AS retrest_sum,
        disc_sum   						AS disc_sum,
        --d_end_sum   						AS d_end_sum,
        --k_end_sum   						AS k_end_sum,
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN d_end_sum - k_end_sum
               ELSE 0.00    
        END AS d_end_sum,
    
        CASE 
               WHEN d_end_sum >= k_end_sum
               THEN 0.00
               ELSE k_end_sum  - d_end_sum  
        END AS k_end_sum,	

        pay_all_sum   						AS  pay_all_sum,
        fact_adv_sum   						AS fact_adv_sum,
        ext_sum   						AS ext_sum,
        accdir   						AS accdir,
        loc 	  						AS loc,
        (doc_num||', '||abo_num || ', ' ||npp)::varchar		AS ord		
    FROM bee_rep_get_repdata25_tmp 
    WHERE  accdir = 1623)
    ORDER BY nn1, ord);
END;
$$;

comment on function bee_rep_get_repdata25_all(integer, date, date) is 'Реализация эл эн. развернуть по потребителям. Используется в RepCreate25.java';

alter function bee_rep_get_repdata25_all(integer, date, date) owner to pgsql;

