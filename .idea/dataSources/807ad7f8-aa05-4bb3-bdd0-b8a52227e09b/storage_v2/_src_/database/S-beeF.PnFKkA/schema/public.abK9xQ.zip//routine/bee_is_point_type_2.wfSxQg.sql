create function bee_is_point_type_2(pointid integer) returns boolean
    language plpgsql
as
$$
BEGIN
   RETURN EXISTS (SELECT 1 FROM agreeregdev WHERE linkid = $1 AND paramid = 1655 AND paramval = '1657' LIMIT 1);
   END;
$$;

comment on function bee_is_point_type_2(integer) is 'Используется в LossDistr.java, AppUtils.java';

alter function bee_is_point_type_2(integer) owner to pgsql;

