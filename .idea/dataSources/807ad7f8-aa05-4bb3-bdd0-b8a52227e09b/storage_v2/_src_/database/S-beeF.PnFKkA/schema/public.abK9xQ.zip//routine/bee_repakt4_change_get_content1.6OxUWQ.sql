create function bee_repakt4_change_get_content1(bd_rowid integer) returns SETOF bee_repakt4_tab
    language plpgsql
as
$$
/*
	ito06 2015-07-09 Акт (передача) для исправления
*/
BEGIN
	RETURN QUERY SELECT * from tmp_repakt4_change_content order by period, grp, tarname_grp;
END;
$$;

comment on function bee_repakt4_change_get_content1(integer) is 'Акт (передача). Используется в  repakt4_change.java';

alter function bee_repakt4_change_get_content1(integer) owner to pgsql;

