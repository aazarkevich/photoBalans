create function bee_fill_regdevconn_copy(pointidsrc integer, pointiddst integer) returns integer
    language plpgsql
as
$$
--
DECLARE NR INTEGER;
BEGIN
   --
   DELETE FROM regdevconn WHERE pointid = pointiddst;
   --
   BEGIN 
      INSERT INTO regdevconn 
      (traceid,pointid,   locid,kod,objtype) 
      (SELECT 
       traceid,pointiddst,locid,kod,objtype FROM regdevconn WHERE pointid = pointidsrc
      ) RETURNING rowid INTO NR;
   EXCEPTION
      WHEN UNIQUE_VIOLATION THEN
      RETURN -1;
   END;
   RETURN NR;
   --
END;
$$;

comment on function bee_fill_regdevconn_copy(integer, integer) is 'Используется в AgreeAddDev.java, AppUtils.java';

alter function bee_fill_regdevconn_copy(integer, integer) owner to pgsql;

