create function bee_get_customer_name(aboid integer) returns character varying
    language sql
as
$$
SELECT abo_name FROM customer WHERE abo_code = $1;
$$;

comment on function bee_get_customer_name(integer) is 'Используется в AgreeByDevice.java, Agreement.java, AgreeRegDev.java, Customer.java, DeviceEdit.java, DocMain.java, IskraEmeco.java, Menu.java, OperVal.java, RepAkt3.java, RepAkt6.java, RepAkt8.java, TarifPoint.java, AppUtils.java';

alter function bee_get_customer_name(integer) owner to pgsql;

