create function bee_repagreepointlist_get_agreeregdev(loc integer) returns SETOF bee_repagreepointlist_agreeregdev
    language sql
as
$$
SELECT 
	apn.rowid,
	ard153.paramval,							-- год выпуска				*kol22*
	CASE
	   WHEN is_date(ard154.paramval)
		THEN ard154.paramval
	   ELSE null
	END:: date,								-- дата установки			*kol24*
	CASE
	   WHEN is_date(ard155.paramval)
		THEN ard155.paramval
	   ELSE null
	END::date,								-- дата последней поверки 		*kol25*
	ard168.paramval,							-- значность				*kol30*
	ard189.element_name, 							-- вид учета				*kol43*
	ard410.paramval,							-- адрес запитанного объекта 		*kol12* 
	ard417.paramval,							-- адрес установки счетчика		*kol14*
	ard418.paramval,							-- запитанный объект			*kol11* 
	ard643.paramval,							-- место установки счетчика		*kol13*
	CASE
	   WHEN is_date(ard690.paramval) AND ard690.paramval IS NOT NULL
		THEN ard690.paramval
	   ELSE null
	END ::date,								-- дата снятия(замены)счетчика 		*kol44*	
	ard715.element_name,							-- тип запитанного объекта		*kol15*
	ard1469.paramval,							-- причина снятия(замены) счетчика	*kol45*
        CASE WHEN ard1641.element_name IS NULL
          THEN '-'
          ELSE ard1641.element_name	
        END,   					     				-- тип модема				*kol73*
        
        CASE
	   WHEN is_date(ard824.paramval)
		THEN ard824.paramval
	   ELSE null
	END::date,								-- дата последней проверки		*kol74*
        ard831.paramval,							-- N акта посл.пров.счетч.		*kol75*
        ard1471.paramval,							-- комментарий				*kol76*

        CASE
	   WHEN is_date(ard1445.paramval)
		THEN ard1445.paramval
	   ELSE null
	END:: date,                                                             --  дата акта раздела границ		*kol84*
	
	ard686.paramval,							-- номер ТУ				*kol85*
	CASE
	   WHEN is_date(ard687.paramval) AND ard687.paramval IS NOT NULL
		THEN 	ard687.paramval
	   ELSE null
	END ::date,								-- дата ТУ				*kol86*
	------------------------
        ard1408.paramval,							-- № акта тех.присоединения		*kol87*
	CASE
	   WHEN is_date(ard1409.paramval) AND ard1409.paramval IS NOT NULL
		THEN ard1409.paramval
	   ELSE null
	END ::date,							        -- дата акта тех.присоединения          *kol88*
        ------------------------

        ard1944.paramval,					                -- N уведомления о замене прибора учёта *kol89*
	CASE
	   WHEN is_date(ard1945.paramval) AND ard1945.paramval IS NOT NULL
		THEN ard1945.paramval
	   ELSE null
	END ::date	 					                -- Дата выдачи уведомления о замене прибора учёта *kol90*

	
  FROM agreepoint 									AS apn		
  JOIN agreement									AS amn 		ON amn.rowid = apn.linkid
--год выпуска   
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 153) 				AS ard153 	ON apn.rowid=ard153.linkid
--дата установки
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 154) 				AS ard154 	ON apn.rowid=ard154.linkid
--дата последней поверки
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 155) 				AS ard155 	ON apn.rowid=ard155.linkid
--значность
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 168) 				AS ard168 	ON apn.rowid=ard168.linkid 
--вид учета   
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 189) 				AS ard_189 	ON apn.rowid=ard_189.linkid 
   LEFT JOIN dic_elements 								AS ard189 	ON ard_189.paramval::integer=ard189.rowid 
--адрес запитанного объекта
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 410) 				AS ard410 	ON apn.rowid=ard410.linkid         
--адрес установки счетчика
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 417) 				AS ard417 	ON apn.rowid=ard417.linkid 
--запитанный объект
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 418) 				AS ard418 	ON apn.rowid=ard418.linkid 
--место установки счетчика
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 643) 				AS ard643 	ON apn.rowid=ard643.linkid 
--дата снятия(замены) счетчика
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 690) 				AS ard690 	ON apn.rowid=ard690.linkid 
--тип запитанного объекта
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 715) 				AS ard_715 	ON apn.rowid=ard_715.linkid 
   LEFT JOIN dic_elements                                 				AS ard715 	ON ard_715.paramval::integer=ard715.rowid  
--причина снятия (замены) счетчика
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1469) 				AS ard1469 	ON apn.rowid=ard1469.linkid 
--тип запитанного объекта
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1641) 				AS ard_1641 	ON apn.rowid=ard_1641.linkid 
   LEFT JOIN dic_elements                                 				AS ard1641 	ON ard_1641.paramval::integer=ard1641.rowid  
-- дата последней проверки
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 824) 				AS ard824 	ON apn.rowid=ard824.linkid 
-- N акта посл.пров.счетч.
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 831) 				AS ard831 	ON apn.rowid=ard831.linkid 
-- комментарий	
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1471) 				AS ard1471 	ON apn.rowid=ard1471.linkid 
-- дата акта раздела границ	
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1445) 				AS ard1445 	ON apn.rowid=ard1445.linkid 

    
-- нмер ТУ	
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 686) 				AS ard686 	ON apn.rowid=ard686.linkid 
-- № акта тех.присоединения	
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 687) 				AS ard687 	ON apn.rowid=ard687.linkid 
-- № акта тех.присоединения	
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1408) 				AS ard1408 	ON apn.rowid=ard1408.linkid  
-- дата акта тех.присоединения	
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1409) 				AS ard1409 	ON apn.rowid=ard1409.linkid 


-- N уведомления о замене прибора учёта	 
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1944) 				AS ard1944 	ON apn.rowid=ard1944.linkid  
-- Дата выдачи уведомления о замене прибора учёта
   LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1945) 				AS ard1945 	ON apn.rowid=ard1945.linkid 

   
WHERE amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1))

$$;

comment on function bee_repagreepointlist_get_agreeregdev(integer) is 'Список устройств, постоянные параметры. Используется в bee_repagreepointlist_get_content(int, text)';

alter function bee_repagreepointlist_get_agreeregdev(integer) owner to postgres;

