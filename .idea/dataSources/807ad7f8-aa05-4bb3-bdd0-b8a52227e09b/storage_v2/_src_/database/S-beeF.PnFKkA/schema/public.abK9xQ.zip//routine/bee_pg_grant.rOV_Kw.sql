create function bee_pg_grant(text, text, text, text) returns integer
    security definer
    language plpgsql
as
$$
DECLARE obj record;
num integer;
BEGIN
num:=0;
FOR obj IN SELECT relname FROM pg_class c
JOIN pg_namespace ns ON (c.relnamespace = ns.oid) WHERE
relkind in ('c','r','v','S','i') AND
nspname = $4 AND
relname LIKE $3
LOOP
EXECUTE 'GRANT ' || $2 || ' ON ' || obj.relname || ' TO ' || $1;
num := num + 1;
END LOOP;
RETURN num;
END;
$$;

alter function bee_pg_grant(text, text, text, text) owner to pgsql;

