create function bee_get_agreement_rskid(agreeid integer) returns integer
    language plpgsql
as
$$
    --
-- код потерь РСК 
BEGIN
   RETURN (
      select ai.paramid from agreement as ag 
          join agreement_info as ai on ag.rowid = ai.linkid
      where ai.paramid in (1914,1915)  and ag.rowid = agreeid
      LIMIT 1
   );
--
END;
$$;

comment on function bee_get_agreement_rskid(integer) is 'Код потерь РСК. Используется в CustomerForm.* ApppUtils.java';

alter function bee_get_agreement_rskid(integer) owner to pgsql;

