create function bee_get_gis_traces_not_nets(locid integer) returns SETOF gis_traces_not_nets
    language plpgsql
as
$$
DECLARE
  RowLine gis_traces_not_nets%rowtype;
  
BEGIN
  FOR RowLine IN (
       SELECT pchain, objname, objowner, objcode, objtype, ownerid, rowid FROM gis_traces
	LEFT JOIN (SELECT ownerid, linkid FROM gis_traces_owner) AS a1 ON gis_traces.rowid=a1.linkid
	WHERE objtype <> 1000
	--AND locid = locid
	ORDER BY pchain
  )
  LOOP
     RETURN NEXT RowLine;
  END LOOP;
END;
$$;

comment on function bee_get_gis_traces_not_nets(integer) is 'Используется в GisTracesOwner.java, SessionBean1.java';

alter function bee_get_gis_traces_not_nets(integer) owner to postgres;

