create function bee_get_classaccuracy() returns SETOF character varying
    language sql
as
$$
/*
	ito06 2020-11-20  Получить классточности A/R для каждого счетчика
*/
select distinct
case when de1.element_name is null  and  de2.element_name is null 
then ' '
else
case when de1.element_name is null 
then ' ' else de1.element_name end 
|| '/'||
case when de2.element_name is null 
then ' ' else  de2.element_name 
end 
end as param
from dic_elements as de
left join regdevattr as rda1 on rda1.deviceid  = de.rowid and rda1.paramid = 143
left join dic_elements as de1 on rda1.valman = de1.rowid::varchar
left join regdevattr as rda2 on rda2.deviceid  = de.rowid and rda2.paramid = 146
left join dic_elements as de2 on rda2.valman = de2.rowid::varchar
where de.link = 35
order by param;
$$;

comment on function bee_get_classaccuracy() is 'Информация об измерительном комплексе,  Получить классточности A/R для каждого счетчика. Используется в SessionBean1.java ';

alter function bee_get_classaccuracy() owner to postgres;

