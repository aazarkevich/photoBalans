create view v1s_exp_abo
            (abo_code, dog_id, consum_name, inn, kpp, dog_num, dog_dat, accdir, acc_dir, urstatus, ur_status) as
SELECT customer.abo_code,
       agreement.rowid                                                        AS dog_id,
       btrim(((replace(regexp_replace(btrim(array_to_string(
               regexp_split_to_array((customer.consum_name)::text, '\s+'::text), ' '::text)), ',$'::text, '.'::text),
                       '"'::text, ' '::text))::character varying(350))::text) AS consum_name,
       customer.consum_inn                                                    AS inn,
       customer_info.item                                                     AS kpp,
       agreement.docnumber                                                    AS dog_num,
       agreement.docdate                                                      AS dog_dat,
       agreement.accdir,
       (SELECT dic_elements_1.element_name
        FROM dic_elements dic_elements_1
        WHERE (dic_elements_1.rowid = agreement.accdir))                      AS acc_dir,
       customer.urstatus,
       (SELECT dic_elements_2.element_name
        FROM dic_elements dic_elements_2
        WHERE (dic_elements_2.rowid = customer.urstatus))                     AS ur_status
FROM (((customer
    JOIN customer_info ON ((customer.abo_code = customer_info.abo)))
    JOIN agreement ON ((customer.abo_code = agreement.abo_code)))
         JOIN dic_elements ON ((customer_info.elrowid = dic_elements.rowid)))
WHERE (((agreement.closedate IS NULL) AND (dic_elements.link = 26) AND (dic_elements.rowid = 84)) OR
       (dic_elements.rowid = agreement.accdir))
ORDER BY customer.consum_name;

alter table v1s_exp_abo
    owner to postgres;

