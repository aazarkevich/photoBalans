create function bee_rep_get_repdata24_tmp3_norm_cust(loc_id integer, s_date date, e_date date, t_vn integer, t_sn1 integer, t_sn2 integer, t_nn integer) returns SETOF bee_repdata24_cust
    language plpgsql
as
$$
/*
	add ito06 2016-03-03 добавляем параметр тип договора amntyp
	add ito06 2015-06-30
	add ito06 2013-12-11
	ito06 2013-10-21: Ведомость по объему услуг
*/
DECLARE
	RowLine bee_repdata24_cust%rowtype;
	tmp_kod character varying;

BEGIN
	SELECT into tmp_kod  kod from denet AS de1 where de1.rowid = loc_id limit 1;
	FOR RowLine IN (
		SELECT	
			'1999-12-02'::date AS dat,	
			am.docnumber ||', '|| cust.abo_name::text		AS "name",		/*наименование потребителя и номер договора*/
			CASE
			    WHEN (SELECT sum(a) from unnest(ARRAY[sum(res_vn.sum_no_tax),sum(res_sn1.sum_no_tax),sum(res_sn2.sum_no_tax),sum(res_nn.sum_no_tax)]) as a)<>0
				THEN (SELECT sum(c) from unnest(ARRAY[sum(res_vn.sum_no_tax),sum(res_sn1.sum_no_tax),sum(res_sn2.sum_no_tax),sum(res_nn.sum_no_tax)]) as c)
				    /(SELECT sum(b) from unnest(ARRAY[sum(res_vn.amount),sum(res_sn1.amount),sum(res_sn2.amount),sum(res_nn.amount)]) as b)
				ELSE null
			END::numeric(12,6)					AS total,	/*7*/
			CASE
			    WHEN sum(res_vn.amount)<>0
				THEN (sum(res_vn.sum_no_tax))/(sum(res_vn.amount))
			    ELSE null
			END::numeric(12,6)					AS total_vn,	/*8*/

			CASE
			    WHEN sum(res_sn1.amount)<>0
				THEN (sum(res_sn1.sum_no_tax))/(sum(res_sn1.amount))
			    ELSE null
			END::numeric(12,6)					AS total_sn1,	/*9*/
			CASE
			    WHEN sum(res_sn2.amount)<>0
				THEN (sum(res_sn2.sum_no_tax))/(sum(res_sn2.amount))
			    ELSE null
			END::numeric(12,6)					AS total_sn2,	/*10*/
			CASE
			    WHEN sum(res_nn.amount)<>0
				THEN (sum(res_nn.sum_no_tax))/(sum(res_nn.amount))
			    ELSE null
			END::numeric(12,6)					AS total_nn,	/*11*/

			(SELECT sum(a) FROM unnest(ARRAY[sum(res_vn.amount),sum(res_sn1.amount),sum(res_sn2.amount),sum(res_nn.amount)]) AS a )	
										AS am_summ,	/*12*/
			sum(res_vn.amount)					AS am_vn,	/*13*/
			sum(res_sn1.amount)					AS am_sn1,	/*14*/
			sum(res_sn2.amount)					AS am_sn2,	/*15*/
			sum(res_nn.amount)					AS am_nn,	/*16*/

			(SELECT sum(b) FROM unnest(ARRAY[sum(res_vn.sum_no_tax),sum(res_sn1.sum_no_tax),sum(res_sn2.sum_no_tax),sum(res_nn.sum_no_tax)]) AS b )
										AS s_summ,	/*17*/
			sum(res_vn.sum_no_tax)					AS s_vn,	/*18*/
			sum(res_sn1.sum_no_tax)					AS s_sn1,	/*19*/
			sum(res_sn2.sum_no_tax)					AS s_sn2,	/*20*/
			sum(res_nn.sum_no_tax)					AS s_nn		/*21*/
		   FROM 
			agreement AS am 
		   JOIN customer  AS cust ON (cust.abo_code=am.abo_code)	
		   JOIN bee_docs AS doc ON (doc.linkid=am.rowid) AND (doc.docdat BETWEEN $2 AND $3)	
		   JOIN bee_docs_result  AS doc_res ON(doc_res.linkid = doc.rowid) AND doc_res.tar_typ = 1068   
	     LEFT JOIN bee_docs_result  AS res_vn  ON (res_vn.rowid=doc_res.rowid) AND res_vn.tar_grp = $4 AND res_vn.tar_typ = 1068 AND res_vn.row_typ = 1070
	     LEFT JOIN bee_docs_result  AS res_sn1 ON (res_sn1.rowid=doc_res.rowid) AND res_sn1.tar_grp = $5 AND res_sn1.tar_typ = 1068 AND res_sn1.row_typ = 1070
	     LEFT JOIN bee_docs_result  AS res_sn2 ON (res_sn2.rowid=doc_res.rowid) AND res_sn2.tar_grp = $6 AND res_sn2.tar_typ = 1068 AND res_sn2.row_typ = 1070
	     LEFT JOIN bee_docs_result  AS res_nn  ON (res_nn.rowid=doc_res.rowid) AND res_nn.tar_grp = $7 AND res_nn.tar_typ = 1068 AND res_nn.row_typ = 1070
		 WHERE true 
		   --AND am.docstatus = '79'			/*действующий договор*/
		   --AND (am.docstatus = 79 OR am.docstatus = 77 AND am.closedate >= s_date ) --2015-06-30
		   AND am.doctype = 1910 --2016-03-03
		   AND bee_is_agreement_get_to_report(am.rowid, s_date) -- 2015-07-14
		   AND (res_vn.sum_no_tax IS NOT NULL OR res_sn1.sum_no_tax IS NOT NULL OR res_sn2.sum_no_tax IS NOT NULL OR res_nn.sum_no_tax IS NOT NULL
		    OR res_vn.amount IS NOT NULL OR res_sn2.amount IS NOT NULL OR res_sn1.amount IS NOT NULL OR res_nn.amount IS NOT NULL)
		   AND am.locid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
		 GROUP BY  am.rowid, cust.abo_name, am.docnumber
		 ORDER BY am.docnumber)
	LOOP
		RETURN NEXT RowLine;
	END LOOP;								
END;

$$;

comment on function bee_rep_get_repdata24_tmp3_norm_cust(integer, date, date, integer, integer, integer, integer) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24_cont_cust1(int, date, date)';

alter function bee_rep_get_repdata24_tmp3_norm_cust(integer, date, date, integer, integer, integer, integer) owner to pgsql;

