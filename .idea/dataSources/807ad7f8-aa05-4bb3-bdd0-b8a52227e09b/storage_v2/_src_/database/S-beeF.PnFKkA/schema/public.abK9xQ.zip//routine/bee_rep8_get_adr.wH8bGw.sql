create function bee_rep8_get_adr(objname character varying, lname character varying, city character varying, street character varying, house character varying, corpus character varying) returns character varying
    language plpgsql
as
$$
DECLARE
  result character varying;
BEGIN
  result='';
  IF objname IS NULL OR objname='?' OR objname='_' THEN
  ELSE
     result=result || objname || ' ';
  END IF;
  IF lname IS NULL OR lname='?' THEN
  ELSE
     result=result ||lname;
  END IF;
  IF city IS NULL OR city='?' THEN
  ELSE
     result=result ||', ' ||city;
  END IF;
  IF street IS NULL OR street='?' THEN
  ELSE
     result=result ||', ' ||street;
  END IF;
  IF house IS NULL OR house='?' THEN
  ELSE
     result=result ||', ' ||house;
  END IF;
  IF corpus IS NULL OR corpus='?' THEN
  ELSE
     result=result ||'/' ||corpus;
  END IF;
  RETURN result;
END
$$;

comment on function bee_rep8_get_adr(varchar, varchar, varchar, varchar, varchar, varchar) is 'Используется в bee_rep10_get_adrfio(varchar, int), bee_rep_get_repdata8_0(int, varchar, varchar, varchar, varchar), bee_rep_get_repdata8_1(int, varchar, varchar, varchar, varchar), bee_rep_get_repdata8_2(int, varchar, varchar, varchar, varchar)';

alter function bee_rep8_get_adr(varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

