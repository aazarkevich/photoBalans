create function bee_get_customer_info(custid integer, catid integer, sparams character varying) returns character varying
    language plpgsql
as
$$
DECLARE
   Rec    RECORD;
   Result VARCHAR   := '';
   Idx    INTEGER   := 1;
   Upr    INTEGER ;  
   params INTEGER[] :=  regexp_split_to_array(sparams,E'\\|');
BEGIN
   Upr := array_upper(params,1);  
--- 
   WHILE Idx <= Upr LOOP
      SELECT INTO Rec dic_elements.element_name AS lab,customer_info.item AS val 
      FROM customer_info
      LEFT JOIN dic_elements ON customer_info.elrowid = dic_elements.rowid
      WHERE
         dic_elements.link  = catid       AND
         dic_elements.rowid = params[Idx] AND 
         customer_info.abo  = custid; 
      Result := Result || '|' || COALESCE(Rec.lab,'-') || ' : ' || COALESCE(Rec.val,'-');
      Idx := Idx + 1;    
   END LOOP;
---    
   RETURN Result;   
---
END;
$$;

comment on function bee_get_customer_info(integer, integer, varchar) is 'Используется в RepAkt3.java, RepAkt6.java, RepAkt8.java, AppUtils.java';

alter function bee_get_customer_info(integer, integer, varchar) owner to pgsql;

