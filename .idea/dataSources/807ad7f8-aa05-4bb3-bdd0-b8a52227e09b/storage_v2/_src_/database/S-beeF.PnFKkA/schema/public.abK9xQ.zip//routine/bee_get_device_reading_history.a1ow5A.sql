create function bee_get_device_reading_history(agree_id integer) returns SETOF device_reading_history
    language plpgsql
as
$$
/*
	add ito06 2014-03-07
	add ito06 2013-11-28
	ito06 2011-12-06:История на договор

*/
DECLARE
  Rec RECORD;
  Rec1 RECORD;
  Rec2 RECORD;
  Rec3 RECORD;
  Rec4 RECORD;
  f1 FLOAT;
  f2 FLOAT;
---  
BEGIN
---
  FOR Rec IN (   
	     select
		a1.operdate           as operdate,
		agreepoint.rowid      as ap_rowid,
		customer.consum_name  as cons_name,
		agreement.docnumber   as dnum,
		agreepoint.account    as acc,
		agreepoint.prodnumber as pnum,
		
		a1.valman   as c1,  -- колонка 1 (дата снятия показаний)
		a2.valman   as c2,  -- колонка 2 (текущие показания)
		a3.valman   as c3,  -- колонка 3 (предыдущие показания)
		a4.valman   as c4,  -- колонка 4 (разность показаний)
		a5.valman   as c5,  -- колонка 5 (потери в линиях)
		a6.valman   as c6,  -- колонка 6 (потери холостого хода)
		a7.valman   as c7,  -- колонка 7 (нагрузочные потери)
		a8.valman   as c8,  -- колонка 8 (доп. сумма)
		a12.valman  as cn1, -- кол-во рабочих дней в отчетном периоде
		0 AS c9,            -- колонка 9 (мощность)
		0 AS cn2,
		0 AS c10,
		a9.valman   as c11, -- колонка 11 ( количество эл. эн.)
		a10.valman  as c12, -- колонка 12 (потреблено субабонентами)
		a11.valman  as c13, -- колонка 13 (потреблено без субабонентов)
		a13.valman  as c14, -- колонка 14 (примечание)
		b3.valman   as b3valman,
		null::text as c15,
		null::text as c16		
		
		from agreepoint
		join agreement on agreepoint.linkid=agreement.rowid
		join customer on agreement.abo_code=customer.abo_code
		join (select valman, linkid, operdate from regdevoper where paramid=194) as a1 on agreepoint.rowid=a1.linkid
		left join (select valman, linkid, operdate from regdevoper where paramid=195) as a2 on a1.linkid=a2.linkid and a1.operdate=a2.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=196) as a3 on a1.linkid=a3.linkid and a1.operdate=a3.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=198) as a4 on a1.linkid=a4.linkid and a1.operdate=a4.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=919) as a5 on a1.linkid=a5.linkid and a1.operdate=a5.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=918) as a6 on a1.linkid=a6.linkid and a1.operdate=a6.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=917) as a7 on a1.linkid=a7.linkid and a1.operdate=a7.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=199) as a8 on a1.linkid=a8.linkid and a1.operdate=a8.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=407) as a9 on a1.linkid=a9.linkid and a1.operdate=a9.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=849) as a10 on a1.linkid=a10.linkid and a1.operdate=a10.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=850) as a11 on a1.linkid=a11.linkid and a1.operdate=a11.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=200) as a12 on a1.linkid=a12.linkid and a1.operdate=a12.operdate
		left join (select valman, linkid, operdate from regdevoper where paramid=1005) as a13 on a1.linkid=a13.linkid and a1.operdate=a13.operdate
		left join (select valman, operdate, linkid from regdevoper where paramid = 200) as b3 on agreepoint.rowid=b3.linkid and b3.operdate = a1.operdate
		where agreepoint.rowid = agree_id
		--ito06 2011-12-05
		and agreepoint.devtype = 644
		order by agreepoint.rowid, a1.valman desc
  ) 
  LOOP 
     select into Rec1 max(period) AS period, paramval from agreeregdev_period where paramid = 424 and period <= Rec.operdate and linkid = Rec.ap_rowid 
 group by paramval order by period DESC;
     select into Rec2 max(period) AS period, paramval from agreeregdev_period where paramid = 425 and period <= Rec.operdate and linkid = Rec.ap_rowid 
 group by paramval order by period DESC;
     select into Rec3 max(period) AS period, paramval from agreeregdev_period where paramid = 356 and period <= Rec.operdate and linkid = Rec.ap_rowid 
 group by paramval order by period DESC;
     select into Rec4 max(period) AS period, paramval from agreeregdev_period where paramid = 408 and period <= Rec.operdate and linkid = Rec.ap_rowid 
 group by paramval order by period DESC;


     
    
     f1 = (CASE Rec.b3valman
		      WHEN '?' THEN '0'
		      WHEN '-' THEN '0'
		      WHEN ''  THEN '0'
		      ELSE Rec.b3valman::float * (
				CASE Rec2.paramval
				      WHEN '?' THEN '0'
				      WHEN '-' THEN '0'
				      WHEN ''  THEN '0'
				      ELSE Rec2.paramval::float END)
		 END);

		 
     f2 = (CASE Rec.cn1
		      WHEN '?' THEN '0'
		      WHEN '-' THEN '0'
		      WHEN ''  THEN '0'
		      ELSE Rec.cn1::float * (
				CASE Rec2.paramval
				      WHEN '?' THEN '0'
				      WHEN '-' THEN '0'
				      WHEN ''  THEN '0'
				      ELSE rec2.paramval::float END)
		 END);
     
     IF Rec1.paramval IN  ('?', '-', '') THEN Rec1.paramval = '0'; END IF;
         
     Rec.c9 = to_number(Rec1.paramval::text, '99999999');    
     Rec.cn2 = f1;
     Rec.c10 = f2;
 
     return query
	select Rec.ap_rowid::text as ap_rowid,
	       Rec.cons_name::text as cons_name,
               Rec.dnum::text as dnum,
               Rec.acc::text as acc,
               Rec.pnum::text as pnum,
               Rec.c1::text as c1,
               Rec.c2::text as c2,
               Rec.c3::text as c3,
               Rec.c4::text as c4,
               Rec.c5::text as c5,
               Rec.c6::text as c6,
               Rec.c7::text as c7,
               Rec.c8::text as c8,
               Rec.cn1::text as cn1,
               Rec1.paramval::text as c9,
               f1::text as cn2,
               f2::text as c10,
               Rec.c11::text as c11,
               Rec.c12::text as c12,
               Rec.c13::text as c13,
               Rec.c14::text as c14,
               Rec3.paramval::text as c15,
               Rec4.paramval::text as c16;
  END LOOP;
---
RETURN;
--
END;

$$;

comment on function bee_get_device_reading_history(integer) is 'История на договор. Используется в RepAktHistory.java';

alter function bee_get_device_reading_history(integer) owner to bee;

