create function bee_get_feeder(_lid integer, pid integer) returns character varying
    language plpgsql
as
$$
/*
    add ito06 2015-03-20 Хотим учитывать и субабонентов, находящихся в других участках
    ito07: Получить значение параметра 644(счётчик головного абонента) для устройства pid 
    ito07 190109 без учёта участка
*/
DECLARE 
    Rec RECORD;
BEGIN
    SELECT INTO Rec 
	customer.abo_code                   AS abo,
	agreement.rowid                     AS agr,
	COALESCE(customer.code_des,'?')     AS cde, 
	COALESCE(agreement.docnumber,'?')   AS doc, 
	COALESCE(agreepoint.account,'?')    AS acc,
	COALESCE(agreepoint.prodnumber,'?') AS num 
       FROM agreepoint
     INNER JOIN agreement ON agreepoint.linkid  = agreement.rowid
     INNER JOIN customer  ON agreement.abo_code = customer.abo_code
      -- WHERE agreement.locid  IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = _lid)) --2015-03-20
     -- WHERE  agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE length(kod)=6))      
      --AND 
      where agreepoint.rowid = pid;             
    
    RETURN Rec.abo|| '|' || Rec.agr || '|' || Rec.cde || '|' || Rec.doc || '|' || Rec.acc || '|' || Rec.num;
END;
$$;

comment on function bee_get_feeder(integer, integer) is 'Используется в AgreeRegDev.java, DeviceParamP.java, AppUtils.java';

alter function bee_get_feeder(integer, integer) owner to pgsql;

