create function bee_rep28_get_consum(amnid integer, strdat date, tarval integer) returns SETOF bee_rep_tab28_en
    language sql
as
$$
/*
ito06 2013-01-18  Приложение 1а, договорные данные
*/
  SELECT 
	  apn.linkid			AS amnid,
	  apn.rowid 			AS pointid,
	  ard.paramval::integer		AS ul,
	  null::varchar 		AS ulev,
	  (select sum(a) from  unnest(ARRAY[m01,m02,m03,m04,m05,m06,m07,m08,m09,m10,m11,m12]) As a)	AS summ,
	  sum(m01) AS m01,  
          sum(m02) AS m02,
          sum(m03) AS m03,
          sum(m04) AS m04,
          sum(m05) AS m05,
          sum(m06) AS m06,
          sum(m07) AS m07,
          sum(m08) AS m08,
          sum(m09) AS m09,
          sum(m10) AS m10,
          sum(m11) AS m11,
          sum(m12) AS m12
     FROM bee_points_consum AS bb
     JOIN  agreepoint  AS apn  ON  apn.rowid = bb.linkid AND apn.devtype = 644
     JOIN bee_rep_get_ard_per_max(439) AS ard  ON apn.rowid = ard.linkid
    WHERE tarif_val = $3
      AND period = to_char($2,'YYYY-01-01')::date 
      AND apn.linkid = $1
    GROUP BY amnid,pointid, ul,summ


$$;

comment on function bee_rep28_get_consum(integer, date, integer) is 'Приложение 1а, договорные данные. Используется в bee_rep_get_repdata28_get_en_4(int, date), bee_rep_get_repdata28_get_en_5(int, date), bee_rep_get_repdata28_get_pow_4(int, date), bee_rep_get_repdata28_get_pow_5(int, date)';

alter function bee_rep28_get_consum(integer, date, integer) owner to pgsql;

