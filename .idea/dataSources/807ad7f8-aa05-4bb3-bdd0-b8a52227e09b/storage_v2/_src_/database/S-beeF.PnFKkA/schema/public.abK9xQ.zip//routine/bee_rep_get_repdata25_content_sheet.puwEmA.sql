create function bee_rep_get_repdata25_content_sheet(agreenum character varying, param integer, sdate date) returns numeric
    language plpgsql
as
$$
begin
   if param IN (0,2) THEN	
     RETURN  (
         select distinct 
	     (final_debit + final_kredit) as v
         from  bee_docs_sheet  
         join  bee_docs         as bd  on  bee_docs_sheet.linkid2 = bd.rowid 
         join  bee_docs_result  as br  on  bd.rowid               = br.linkid
         join  agreement        as agr on  bd.linkid              = agr.rowid
         where
	        --param IN (0,2) and
	        agr.docnumber  = agreenum     and
            bd.doctyp      = 1618         and	
	        bd.docdat     >= sdate        and	
	        br.tar_typ IN (1069,1159, 1707,1142) and 
	        final_debit   <> 0.00 
	        group by v
            limit 1);
   ELSE 
       RETURN null;
   end IF;  
	
END;
$$;

alter function bee_rep_get_repdata25_content_sheet(varchar, integer, date) owner to postgres;

