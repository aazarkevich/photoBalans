create function bee_has_agreement(custid integer) returns boolean
    language plpgsql
as
$$
BEGIN
RETURN EXISTS(SELECT 1 FROM agreement WHERE abo_code = custid LIMIT 1);
END;
$$;

comment on function bee_has_agreement(integer) is 'Используется в Customer.java, DeviceEdit.java, AppUtils.java';

alter function bee_has_agreement(integer) owner to pgsql;

