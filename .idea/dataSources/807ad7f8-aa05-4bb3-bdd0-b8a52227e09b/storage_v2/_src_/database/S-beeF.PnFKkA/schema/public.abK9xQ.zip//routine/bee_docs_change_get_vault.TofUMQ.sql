create function bee_docs_change_get_vault(_linkid integer) returns SETOF docs_adjustment_vault
    language plpgsql
as
$$
/*
ito06 2012-03-26 Исправления счетов-фактур
*/
DECLARE
  rec docs_adjustment_vault%rowtype;

BEGIN
   FOR rec IN (
      SELECT
	   dic.element_name,
	   doc.docnum,
	   bds.operdate,
	   bds.start_debit,
	   bds.start_kredit,
	   bds.oper_debit,
	   bds.oper_kredit,
	   bds.final_debit,
	   bds.final_kredit

	  FROM 
		bee_docs_sheet AS bds
		JOIN bee_docs AS doc ON doc.rowid=bds.linkid2
		JOIN dic_elements AS dic ON doc.doctyp=dic.rowid  
		JOIN agreement ON agreement.rowid=doc.linkid 
	  WHERE doc.linkid=_linkid 
	  ORDER BY bds.operdate DESC
   )
   LOOP
	RETURN NEXT rec;
   END LOOP;
   --
END;
--
$$;

comment on function bee_docs_change_get_vault(integer) is 'Исправления счетов-фактур. Используется в DocsChange.java, SessionBean1.java';

alter function bee_docs_change_get_vault(integer) owner to pgsql;

