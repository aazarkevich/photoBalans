create function bee_add_newtarif(point integer, tarif integer, per date) returns integer
    language plpgsql
as
$$
/*
ito07 2019-05-16 RETURNING NR 
ito06 2012-08-27 Добавление тарифа на точку учета
*/
DECLARE NR INTEGER =-1;
BEGIN
    INSERT INTO agreepoint_tarif
       (pointid,tarifid, period) VALUES
       (point, tarif, per) ;   --RETURNING NR;
       select currval('agreepoint_tarif_rowid_seq') INTO NR;

    IF NR IS NOT NULL  THEN  RETURN 1;
          ELSE RETURN -1;
    END IF;

END;
$$;

comment on function bee_add_newtarif(integer, integer, date) is 'Добавление тарифа на точку учета. Используется в TarifPoint.java, AppUtils.java';

alter function bee_add_newtarif(integer, integer, date) owner to pgsql;

