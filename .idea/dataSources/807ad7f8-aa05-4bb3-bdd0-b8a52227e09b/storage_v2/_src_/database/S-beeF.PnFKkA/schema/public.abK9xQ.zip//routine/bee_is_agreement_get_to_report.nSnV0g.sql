create function bee_is_agreement_get_to_report(_amnid integer, d_start date) returns boolean
    language plpgsql
as
$$
/*
  	add ito06 2021-02-15 должны попадать расторгнутые
 	add ito06 2020-07-14 Расторгнуты договор должен попапать если есть сальдо на начало или конец
	add ito06 2015-10-15
	add ito06 2015-08-24
	ito06 2015-07-14 Должен ли договор попадать в очет 
*/
DECLARE
	rid int;
	last_day_of_year DATE := (SELECT (date_trunc('year', d_start) + INTERVAL '1 year' - INTERVAL '1 day'))::DATE; -- 2015-10-15
BEGIN
	select amn.rowid  
	  from agreement AS amn
     left join (select * from bee_docs_sheet where linkid1=_amnid AND operdate<=d_start order by operdate desc, npp desc limit 1) AS bds1 ON bds1.linkid1 = amn.rowid	
     left join (select * from bee_docs_sheet where linkid1=_amnid AND operdate<=last_day_of_year and npp = 0 limit 1) AS bds2 ON bds2.linkid1 = amn.rowid	  
         where amn.rowid = _amnid
           -- and amn.docstatus = 79 OR amn.docstatus = 77 AND amn.closedate IS NOT NULL AND (amn.closedate >= d_start OR bds1.final_debit<>0 OR bds1.final_kredit<>0 ) --2020-07-14
           -- and amn.docstatus = 79 OR amn.docstatus = 77 AND amn.closedate IS NOT NULL AND (amn.closedate >= d_start OR bds1.final_debit<>0 OR bds1.final_kredit<>0 OR bds1.start_debit<>0 OR bds1.start_kredit<>0) 
              and (amn.docstatus = 79 OR amn.docstatus = 77 AND amn.closedate IS NOT NULL AND (amn.closedate >= d_start OR bds1.final_debit<>0 OR bds1.final_kredit<>0 OR bds1.start_debit<>0 OR bds1.start_kredit<>0)) 
 
	   and bds2.rowid IS NOT NULL

           INTO rid;

         if rid IS NOT NULL 
             then return true;
             else return false;            
         end if;
               
END;
$$;

comment on function bee_is_agreement_get_to_report(integer, date) is ' Должен ли договор попадать в очет. Используется в bee_rep_get_repdata24_corr1(int,date, date, int), 
bee_rep_get_repdata24_corr1_cust(int,date, date, int),bee_rep_get_repdata24_corr2(int,date, date, int),bee_rep_get_repdata24_corr2_cust(int,date, date, int),bee_rep_get_repdata24_corr3(int,date, date, int),bee_rep_get_repdata24_corr3_cust(int,date, date, int), bee_rep_get_repdata24_corr3_norm(int, date, date, int), bee_rep_get_repdata24_corr3_norm_cust(int, date, date, int), bee_rep_get_repdata24_corr3_snorm(int, date, date, int), bee_rep_get_repdata24_corr3_snorm_cust(int, date, date, int), bee_rep_get_repdata24_tmp1(int, date, date, int), bee_rep_get_repdata24_tmp1_cust(int, date, date, int), bee_rep_get_repdata24_tmp2(int, date, date, int), bee_rep_get_repdata24_tmp2_cust(int, date, date, int), bee_rep_get_repdata24_tmp3(int, date, date, int), bee_rep_get_repdata24_tmp3_cust(int, date, date, int), bee_rep_get_repdata24_tmp3_norm(int, date, date, int),bee_rep_get_repdata24_tmp3_norm_cust(int, date, date, int),bee_rep_get_repdata24_tmp3_snorm(int, date, date, int),bee_rep_get_repdata24_tmp3_snorm_cust(int, date, date, int), bee_rep_get_repdata25_content(integer, date, date)';

alter function bee_is_agreement_get_to_report(integer, date) owner to pgsql;

