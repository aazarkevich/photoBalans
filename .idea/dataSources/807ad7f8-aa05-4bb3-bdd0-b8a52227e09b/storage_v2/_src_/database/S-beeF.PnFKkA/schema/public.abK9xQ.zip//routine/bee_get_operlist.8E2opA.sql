create function bee_get_operlist(pnt integer, per character varying) returns character varying
    language plpgsql
as
$$
    --
-- ПОЛУЧИТЬ СПИСОК
--
DECLARE
  Rec     RECORD;
  DatList varchar := '';
---  
BEGIN
---  
  FOR Rec IN (
	SELECT DISTINCT operdate::varchar AS dat FROM regdevoper
	WHERE linkid =  pnt AND operdate::varchar LIKE per || '-__'
	ORDER BY dat
  ) 	    
  LOOP
     DatList = DatList || '|' || Rec.dat; 
  END LOOP;
---
RETURN DatList;
---
END;
$$;

comment on function bee_get_operlist(integer, varchar) is 'Используется в RepAkt.java, RepAkt1.java, AppUtils.java';

alter function bee_get_operlist(integer, varchar) owner to pgsql;

