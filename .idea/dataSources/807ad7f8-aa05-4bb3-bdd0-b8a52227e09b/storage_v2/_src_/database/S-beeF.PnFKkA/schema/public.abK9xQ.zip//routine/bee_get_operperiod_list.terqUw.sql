create function bee_get_operperiod_list(xlid integer) returns character varying
    language plpgsql
as
$$
/*
	 add ito06 2014-06-24
*/
DECLARE
	Rec RECORD;
	PList varchar := '';

BEGIN
  
	FOR Rec IN (
		SELECT substring(regdevoper.operdate::text from 1 for 7) AS dat 
		  FROM regdevoper
	    INNER JOIN agreepoint ON regdevoper.linkid = agreepoint.rowid
	    INNER JOIN agreement  ON agreepoint.linkid = agreement.rowid
		 WHERE agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = xlid))
		 GROUP BY substring(regdevoper.operdate::text from 1 for 7)   
		 ORDER BY substring(regdevoper.operdate::text from 1 for 7)  DESC
		  ) 	    
	LOOP
		PList = PList  || Rec.dat || '|'; 
	END LOOP;
	RETURN PList;
END;
$$;

comment on function bee_get_operperiod_list(integer) is 'Используется в AgreeByDevice.java, RepAkt3.java, RepAkt6.java, RepAkt8.java, RepAkt9.java, AppUtils.java';

alter function bee_get_operperiod_list(integer) owner to pgsql;

