create function bee_add_new_bee_doc(doc_date text, ava_text text, loc_id integer, agreeid integer, doc_type integer, ava_type integer, ava_num integer) returns character varying
    language plpgsql
as
$$
/*
	add ito06 2014-12-01
	Создание документа "счет на предоплату"
*/
DECLARE
	ava_date          DATE := (SELECT (ava_text || '-01')::DATE);
	first_day_of_year DATE := (SELECT (date_trunc('year', ava_date::TIMESTAMP)::DATE));
BEGIN
	
	IF ( first_day_of_year >= '2015-01-01'::date )
	   THEN
	      RETURN bee_add_new_bee_doc_new(doc_date, ava_text, loc_id, agreeid, doc_type, ava_type, ava_num);
	   ELSE 
	      RETURN bee_add_new_bee_doc_old(doc_date, ava_text, loc_id, agreeid, doc_type, ava_type, ava_num);
	END IF;   
	
END;
$$;

comment on function bee_add_new_bee_doc(text, text, integer, integer, integer, integer, integer) is 'Используется в AdvanceDocs.java, AppUtils.java';

alter function bee_add_new_bee_doc(text, text, integer, integer, integer, integer, integer) owner to pgsql;

