create function bee_fill_agreeregdev_copy(pointidsrc integer, pointiddst integer) returns integer
    language plpgsql
as
$$
    --
-- 
-- КОПИРОВАНИЕ ПАРАМЕТРОВ ОДНОГО УСТРОЙСТВА В ДРУГОЕ
--
DECLARE
   rec RECORD;
BEGIN
   --
   DELETE FROM agreeregdev WHERE linkid = pointidDST;
   --
   FOR rec in (SELECT paramid,paramval FROM agreeregdev WHERE linkid = pointidSRC AND paramid NOT IN (154,690))
   LOOP
      BEGIN
	INSERT INTO agreeregdev (linkid,paramid,paramval) VALUES (pointidDST,rec.paramid,rec.paramval);
      EXCEPTION
      WHEN UNIQUE_VIOLATION THEN
         CONTINUE;
      END;
   END LOOP;
   --
   RETURN 0;
   --
END;
$$;

comment on function bee_fill_agreeregdev_copy(integer, integer) is 'Копировнаие параметров одного устройства в другое. Используется в AgreeAddDev.java, AppUtils.java';

alter function bee_fill_agreeregdev_copy(integer, integer) owner to pgsql;

