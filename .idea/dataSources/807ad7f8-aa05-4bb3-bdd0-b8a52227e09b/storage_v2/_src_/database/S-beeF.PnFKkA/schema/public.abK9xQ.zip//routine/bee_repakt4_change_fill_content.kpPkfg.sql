create function bee_repakt4_change_fill_content(bd_rowid integer, diff boolean, _doctyp integer) returns SETOF integer[]
    language plpgsql
as
$$
/*
	add ito06 2015-12-10  добавили входной параметр _doctyp
	ito06 2015-07-09 Акт(передача) 
       для исправления или корректировки, заполнение временной таблицы
*/
DECLARE
  _tartyp      int = 0;
  _tartyp_corr int = 0;
BEGIN
  IF _doctyp  = 1 
     THEN
	--исправление
        _tartyp = 1707;
        _tartyp_corr = -1;
  ELSIF _doctyp  = 2
     THEN 	
	--корректировка 
	_tartyp = 1069;  
	-- корректировка сверх сверх соц.нормы
	_tartyp_corr = 1159;         
		
  END IF;   
  DROP TABLE IF EXISTS tmp_repakt4_change_content;
  CREATE TEMPORARY table tmp_repakt4_change_content AS 
    (SELECT * FROM 
	(
	 (SELECT
           0::integer		 as grp,
	   tarname_grp::integer	 as tarname_grp,
	   '1000-1-1'::date 	 as period,
	   CASE 
	      WHEN tarname_grp = 0 THEN 'Электрическая энергия (пром)'
	      WHEN tarname_grp = 1 THEN 'Электрическая энергия (2 став)'
	      WHEN tarname_grp = 2 THEN 'Электрическая энергия (мощность 2 став)'
	      WHEN tarname_grp = 3 THEN E'\rЭлектрическая энергия (население газ)'
	      WHEN tarname_grp = 4 THEN 'Электрическая энергия (население эл.плиты)'
	      WHEN tarname_grp = 5 THEN 'Электрическая энергия (население село)'
              WHEN tarname_grp = 6 THEN 'Электрическая энергия (население газ) сверх соц.нормы'
	      WHEN tarname_grp = 7 THEN 'Электрическая энергия (население эл.плиты) сверх соц.нормы'
	      WHEN tarname_grp = 8 THEN 'Электрическая энергия (население село) сверх соц.нормы'
              
  	   END::varchar	as tar_name,
	   (select a[1] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp) AS a)::numeric	as vn_amount,
	   (select a[2] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp) AS a)::numeric	as vn_sum,
	   (select a[3] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp) AS a)::numeric	as vn_price,
	   (select a[4] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp) AS a)::numeric	as vn_tax_sum,
	   (select a[5] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp) AS a)::numeric	as vn_sum_w_tax,
		 
	   (select a[1] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp) AS a)::numeric	as sn1_amount,
	   (select a[2] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp) AS a)::numeric	as sn1_sum,
	   (select a[3] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp) AS a)::numeric	as sn1_price,
	   (select a[4] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp) AS a)::numeric	as sn1_tax_sum,
	   (select a[5] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp) AS a)::numeric	as sn1_sum_w_tax,
			 
   	   (select a[1] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp) AS a)::numeric	as sn2_amount,
	   (select a[2] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp) AS a)::numeric	as sn2_sum,
	   (select a[3] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp) AS a)::numeric	as sn2_price,
	   (select a[4] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp) AS a)::numeric	as sn2_tax_sum,
	   (select a[5] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp) AS a)::numeric	as sn2_sum_w_tax,
				 
	   (select a[1] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp) AS a)::numeric	as nn_amount,
	   (select a[2] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp) AS a)::numeric	as nn_sum,
	   (select a[3] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp) AS a)::numeric	as nn_price,
	   (select a[4] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp) AS a)::numeric	as nn_tax_sum,
	   (select a[5] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp) AS a)::numeric	as nn_sum_w_tax,
		 
	   (select sum (a) from unnest(ARRAY[
		(select a[2] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp) AS a),
		(select a[2] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff,_tartyp) AS a),
		(select a[2] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff,_tartyp) AS a),
		(select a[2] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp) AS a)
		]) AS a) ::numeric as tot_sum,
	   (select sum (a) from unnest(ARRAY[
		(select a[1] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp) AS a),
		(select a[1] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff,_tartyp) AS a),
		(select a[1] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff,_tartyp) AS a),
		(select a[1] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp) AS a)
		]) AS a)::numeric as tot_amount,
   	   (select sum (a) from unnest(ARRAY[
		(select a[4] from bee_repakt4_change_get_tmp($1,dtg.vn_code,  diff, _tartyp) AS a),
		(select a[4] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff,_tartyp) AS a),
		(select a[4] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff,_tartyp) AS a),
		(select a[4] from bee_repakt4_change_get_tmp($1,dtg.nn_code,  diff, _tartyp) AS a)
		]) AS a)::numeric as tot_tax_sum,
	    (select sum (a) from unnest(ARRAY[
		(select a[5] from bee_repakt4_change_get_tmp($1,dtg.vn_code,  diff, _tartyp) AS a),
		(select a[5] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp) AS a),
		(select a[5] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff,_tartyp) AS a),
		(select a[5] from bee_repakt4_change_get_tmp($1,dtg.nn_code,  diff, _tartyp) AS a)
		]) AS a)::numeric as tot_sum_w_tax
            FROM bee_rep_dtg_rebuilt() AS dtg
            ORDER BY tarname_grp	
           )
           union 
           (
           SELECT
           0::integer		 as grp,
	   tarname_grp::integer	 as tarname_grp,
	   '1000-1-1'::date 	 as period,
	   CASE
	          
	      WHEN tarname_grp = 0 THEN 'Электрическая энергия (пром) сверх соц.нормы'
              WHEN tarname_grp = 1 THEN 'Электрическая энергия (2 став) сверх соц.нормы'
	      WHEN tarname_grp = 2 THEN 'Электрическая энергия (мощность 2 став) сверх соц.нормы'
	      WHEN tarname_grp = 3 THEN 'Электрическая энергия (население газ) сверх соц.нормы'
	      WHEN tarname_grp = 4 THEN 'Электрическая энергия (население эл.плиты) сверх соц.нормы'
	      WHEN tarname_grp = 5 THEN 'Электрическая энергия (население село) сверх соц.нормы'
              WHEN tarname_grp = 6 THEN 'Электрическая энергия (население газ) сверх соц.нормы'
	      WHEN tarname_grp = 7 THEN 'Электрическая энергия (население эл.плиты) сверх соц.нормы'
	      WHEN tarname_grp = 8 THEN 'Электрическая энергия (население село) сверх соц.нормы'	      
  	   END::varchar	as tar_name,
	   (select a[1] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp_corr) AS a)::numeric	as vn_amount,
	   (select a[2] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp_corr) AS a)::numeric	as vn_sum,
	   (select a[3] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp_corr) AS a)::numeric	as vn_price,
	   (select a[4] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp_corr) AS a)::numeric	as vn_tax_sum,
	   (select a[5] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff, _tartyp_corr) AS a)::numeric	as vn_sum_w_tax,
		 
	   (select a[1] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp_corr) AS a)::numeric	as sn1_amount,
	   (select a[2] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp_corr) AS a)::numeric	as sn1_sum,
	   (select a[3] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp_corr) AS a)::numeric	as sn1_price,
	   (select a[4] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp_corr) AS a)::numeric	as sn1_tax_sum,
	   (select a[5] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp_corr) AS a)::numeric	as sn1_sum_w_tax,
			 
   	   (select a[1] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp_corr) AS a)::numeric	as sn2_amount,
	   (select a[2] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp_corr) AS a)::numeric	as sn2_sum,
	   (select a[3] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp_corr) AS a)::numeric	as sn2_price,
	   (select a[4] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp_corr) AS a)::numeric	as sn2_tax_sum,
	   (select a[5] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp_corr) AS a)::numeric	as sn2_sum_w_tax,
				 
	   (select a[1] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp_corr) AS a)::numeric	as nn_amount,
	   (select a[2] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp_corr) AS a)::numeric	as nn_sum,
	   (select a[3] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp_corr) AS a)::numeric	as nn_price,
	   (select a[4] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp_corr) AS a)::numeric	as nn_tax_sum,
	   (select a[5] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff, _tartyp_corr) AS a)::numeric	as nn_sum_w_tax,
		 
	   (select sum (a) from unnest(ARRAY[
		(select a[2] from bee_repakt4_change_get_tmp($1,dtg.vn_code,  diff,  _tartyp_corr) AS a),
		(select a[2] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp_corr) AS a),
		(select a[2] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp_corr) AS a),
		(select a[2] from bee_repakt4_change_get_tmp($1,dtg.nn_code,  diff,  _tartyp_corr) AS a)
		]) AS a) ::numeric as tot_sum,

	   (select sum (a) from unnest(ARRAY[
		(select a[1] from bee_repakt4_change_get_tmp($1,dtg.vn_code,  diff, _tartyp_corr) AS a),
		(select a[1] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp_corr) AS a),
		(select a[1] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp_corr) AS a),
		(select a[1] from bee_repakt4_change_get_tmp($1,dtg.nn_code,  diff, _tartyp_corr) AS a)
		]) AS a)::numeric 
		as tot_amount, -- SEE WHERE SELECTOR

   	   (select sum (a) from unnest(ARRAY[
		(select a[4] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff,  _tartyp_corr) AS a),
		(select a[4] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp_corr) AS a),
		(select a[4] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp_corr) AS a),
		(select a[4] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff,  _tartyp_corr) AS a)
		]) AS a)::numeric as tot_tax_sum,
	    (select sum (a) from unnest(ARRAY[
		(select a[5] from bee_repakt4_change_get_tmp($1,dtg.vn_code, diff,  _tartyp_corr) AS a),
		(select a[5] from bee_repakt4_change_get_tmp($1,dtg.sn1_code, diff, _tartyp_corr) AS a),
		(select a[5] from bee_repakt4_change_get_tmp($1,dtg.sn2_code, diff, _tartyp_corr) AS a),
		(select a[5] from bee_repakt4_change_get_tmp($1,dtg.nn_code, diff,  _tartyp_corr) AS a)
		]) AS a)::numeric as tot_sum_w_tax

            FROM bee_rep_dtg_rebuilt() AS dtg
            ORDER BY tarname_grp
           )
          ) 
          AS tabl
          WHERE tot_amount IS NOT NULL
      ORDER BY 
          period, grp, tarname_grp
      );
END;
$$;

comment on function bee_repakt4_change_fill_content(integer, boolean, integer) is 'Акт (передача) для исправления. Используется в bee_repakt4_change_get_content1(int)';

alter function bee_repakt4_change_fill_content(integer, boolean, integer) owner to pgsql;

