create function bee_rep_get_repdata29_content(_fil character varying, sdate date) returns SETOF bee_repdata29
    language plpgsql
as
$$
DECLARE rec bee_repdata29%rowtype;
	rec1 record;
/*
	ito06 2015-01-21 Сводная ведомость по объему услуг 
*/
BEGIN	
	FOR rec IN (SELECT * FROM bee_rep_get_repdata29_tot($1, $2)  order by sort1, sort, doc_name)
	LOOP	
		IF (rec.sort not in ('31', '32', '33', '421', '422', '423') AND substring(rec.sort from length(rec.sort) for 1)<>'b') 
		   THEN
			IF  rec.tot_amount IS NOT NULL AND rec.tot_sum IS NOT NULL AND rec.tot_amount<>0 THEN rec.tar_m_tot=(rec.tot_sum/rec.tot_amount)::numeric(20,6);END IF;
			IF  rec.vn_amount IS NOT NULL AND rec.vn_sum  IS NOT NULL AND rec.vn_amount<>0 THEN rec.tar_m_vn=(rec.vn_sum/rec.vn_amount)::numeric(20,6);END IF;
			IF  rec.sn1_amount IS NOT NULL AND rec.sn1_sum IS NOT NULL AND rec.sn1_amount<>0 THEN rec.tar_m_sn1=(rec.sn1_sum/rec.sn1_amount)::numeric(20,6);END IF;
			IF  rec.sn2_amount IS NOT NULL AND rec.sn2_sum IS NOT NULL AND rec.sn2_amount<>0 THEN rec.tar_m_sn2=(rec.sn2_sum/rec.sn2_amount)::numeric(20,6);END IF;
			IF  rec.nn_amount IS NOT NULL AND rec.nn_sum  IS NOT NULL AND rec.nn_amount<>0 THEN rec.tar_m_nn=(rec.nn_sum/rec.nn_amount)::numeric(20,6);END IF; 
		END IF;
		rec.fil =  $1;

		RETURN NEXT rec;		
	END LOOP;

END;
$$;

comment on function bee_rep_get_repdata29_content(varchar, date) is 'Сводная ведомость по объему услуг. Используется в bee_rep_get_repdata29_all(int, date, date, boolean, boolean, boolean)';

alter function bee_rep_get_repdata29_content(varchar, date) owner to pgsql;

