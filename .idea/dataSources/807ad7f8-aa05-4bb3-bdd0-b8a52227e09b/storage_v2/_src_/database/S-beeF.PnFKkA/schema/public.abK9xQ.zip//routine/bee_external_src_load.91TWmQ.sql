create function bee_external_src_load() returns trigger
    language plpgsql
as
$$
/*
	ito06 2015-11-13 Проверка нужно ли сохранять данные в regdevoper	

КОД ОШИБКИ
при вставке в regdevoper 
-7: Расход субабонента превышает расход головного абонента
-6: Потребление без субабонентов не может быть < 0 для прямых договоров!
-5: Проверьте правильность вводимых данных (доп. суммы, соц. норма, сверх соц нормы)
-4: Период закрыт!
-3: Проверить : показания при восстановлени работы счётчика
-2: Проверить :  дата восстановления работы счётчика
-1: Проверить : значность (разрядность)*
 0: Нет ошибки
при вставке в bee_external_src
 1: Общая ошибка
 2: Cчетчик не отмечен для загрузки
 3: Дата ввода не попадает в разрешенный период
 4: Для данного счетчика на эту дату из внешенго источника введены другие показания
 5: Счетчика с таким номером нет в БЭЭ
 6: Показания были загружены, но удалены пользователем
 7: Марка счетчика не подходит
 8: Счетчик снят
 9: Договор растогрнут
*/
DECLARE
	per_start date;
	per_end date;
	DbLoc    VARCHAR; --текущая база
	DbRem    VARCHAR; --смежная база
	DbLocTag VARCHAR; --tag текущей базы
	DbRemTag VARCHAR; --tag смежной базы
	res      text;
	listconn text[];
	_rid integer;
	_dbtag varchar;	
	_err integer = 0;

	_is_corrmark boolean = false; 
	_is_working boolean = false; 
	_is_currdog boolean = false;
	_src int = 0;
BEGIN
	SELECT min(period_start), max(period_end) FROM bee_external_sql  INTO per_start, per_end;
	
	-- current db name
	DbLoc = (SELECT current_database() LIMIT 1);
	--
	IF DbLoc = 'beeU' 
	   THEN
		DbLocTag = 'U';
		DbRemTag = 'F';
		DbRem = 'beeF';
	   ELSE 
		DbLocTag = 'F';
		DbRemTag = 'U';
		DbRem = 'beeU';
	END IF;
	

	-- Проверка только для юриков, в базу физиков все записывается автоматически!	
	IF DbLoc = 'beeU'  
	   THEN
		-- create connection
		SELECT * FROM dblink_get_connections() INTO listconn; 
		IF 'deconn_src' = ANY (listconn) 
		   THEN -- удаляем соединение
			SELECT dblink_disconnect('deconn_src') INTO res;
		END IF;
		SELECT dblink_connect_u('deconn_src', 
			' dbname ='   || DbRem ||
			' port = 5432 ' ||
			' host = localhost ' ||
			' user = pgsql ' ||
			' password = ') INTO res;

		IF TG_OP = 'INSERT'
		   THEN 
		     
		     select pointid, is_corrmark, is_working, is_currdog, src from bee_iskraemeco_get_devload_list_new(NEW.dev_num) 
		     order by is_corrmark desc, is_working desc, is_currdog desc limit 1 
		     INTO _rid, _is_corrmark,_is_working, _is_currdog, _src;
		     
		     IF (_rid IS NOT NULL AND _is_corrmark AND _is_working AND _is_currdog AND _src = NEW.srv) 
			THEN --не снятый счетчик (в действующем договоре) с таким номером и нужной маркой есть в бээ (в какой-то из баз)
			select rowid, db_tag from bee_external_agreepoint WHERE prodnumber = NEW.dev_num AND src = NEW.srv limit 1 INTO _rid, _dbtag;

			IF (_rid IS NOT NULL AND NOT NEW.ready AND NEW.operdate BETWEEN per_start AND per_end)
			   THEN --запись подходит для записи в regdevoper

				IF _dbtag = DbLocTag 
				   THEN --вставляем в текущую базу 
					SELECT bee_add_regdevoper_registered_435(_rid, NEW.operdate,  NEW.operval::varchar, '-') INTO _err;
					UPDATE regdevoper SET val = '161', valman = '1729' WHERE linkid = _rid AND paramid = 1451 AND operdate = NEW.operdate;  
				   ELSE  --вставляем в смежную базу
				        SELECT t.* FROM dblink('deconn_src','SELECT bee_add_regdevoper_registered_435('||_rid||', '''||NEW.operdate||''', '''||
				                        NEW.operval||'''::varchar, '''||'-'||''')') AS t (addres int) INTO _err;
                                        PERFORM dblink('deconn_src','UPDATE regdevoper SET val = '||161||', valman = '||1729||' WHERE linkid = '||_rid||' 
                                                    AND paramid = 1451 AND operdate = '''||NEW.operdate||'''');  
				END IF;
				
				NEW.err = _err;
				IF  NEW.err = 0 
				  THEN NEW.ready = true; 
				       update bee_external_src set ready = false, err = 4
				        where dev_num = NEW.dev_num AND operdate = NEW.operdate AND srv = NEW.srv AND ready = true AND err = 0;
				END IF;
								
			   ELSE --запись не подходит для записи в regdevoper				
				if (_rid IS NULL) then NEW.err = 2; 
				  elsif (NEW.operdate NOT BETWEEN per_start AND per_end) then NEW.err = 3; 
				  else NEW.err = 1; 
				end if;				
			END IF;
			PERFORM dblink('deconn_src', 'insert into  bee_external_src (dev_num, operdate, operval, srv, loaddate, ready, err) 
			   values ('''||NEW.dev_num||''','''||NEW.operdate||''', '||NEW.operval||', '||NEW.srv||', '''||NEW.loaddate||''', '||NEW.ready||','||NEW.err||');');

			-- удаляем соединение
			SELECT dblink_disconnect('deconn_src') INTO res;   
			RETURN NEW;
		   
		      ELSE -- не снятого счетчика (из действующего договора) с таким номером и нужной маркой  нет в бээ
		        if _rid IS NULL 
			   THEN NEW.err = 5; 
			   ELSIF NOT _is_corrmark THEN NEW.err = 7; 
			   ELSIF NOT _is_working  THEN NEW.err = 8; 
			   ELSIF NOT _is_currdog THEN NEW.err = 9; 
			   ELSE  NEW.err = 1; 
		        END IF;
			
			PERFORM dblink('deconn_src', 'insert into  bee_external_src (dev_num, operdate, operval, srv, loaddate, ready, err) 
			   values ('''||NEW.dev_num||''','''||NEW.operdate||''', '||NEW.operval||', '||NEW.srv||', '''||NEW.loaddate||''', '||NEW.ready||','||NEW.err||');');

			-- удаляем соединение
			SELECT dblink_disconnect('deconn_src') INTO res;   
			RETURN NEW;
		     END IF;
			
		   ELSIF (TG_OP = 'UPDATE') 
		      THEN 
		           PERFORM dblink(' dbname ='|| DbRem ||' port = 5432 ' || ' host = localhost ' || ' user = pgsql ' || ' password = ', 
		                                        'UPDATE bee_external_src 
		                                            set dev_num = '''||NEW.dev_num||''', operdate  = '''||NEW.operdate||''', 
		                                                operval = '||NEW.operval||', srv ='||NEW.srv||', 
		                                                loaddate ='''||NEW.loaddate||''', ready = '||NEW.ready||', err = '||NEW.err||'
		                                          WHERE dev_num = '''||OLD.dev_num||''' AND operdate  = '''||OLD.operdate||''' AND 
		                                                operval = '||OLD.operval||' AND srv ='||OLD.srv||' AND
		                                                loaddate ='''||OLD.loaddate||''' AND ready = '||OLD.ready||' AND err = '||OLD.err||'');			  		
			   RETURN NEW;
		   ELSIF (TG_OP = 'DELETE') 
		      THEN 
		          PERFORM dblink(' dbname ='|| DbRem ||' port = 5432 ' || ' host = localhost ' || ' user = pgsql ' || ' password = ', 
		                                        'delete from bee_external_src 		                                           
		                                          WHERE dev_num = '''||OLD.dev_num||''' AND operdate  = '''||OLD.operdate||''' AND 
		                                                operval = '||OLD.operval||' AND srv ='||OLD.srv||' AND 
		                                                loaddate ='''||OLD.loaddate||''' AND ready = '||OLD.ready||' AND err = '||OLD.err||'');
		           
		           RETURN OLD;
		      ELSE RETURN NULL;
		END IF;	
	   ELSE  -- без проверки
		IF (TG_OP = 'DELETE') THEN RETURN OLD;
		  ELSIF (TG_OP = 'UPDATE') THEN RETURN NEW;
		  ELSIF (TG_OP = 'INSERT') THEN RETURN NEW;
		  ELSE RETURN NULL;
		END IF;	
	END IF;	
	RETURN NULL;
	   
END;
$$;

alter function bee_external_src_load() owner to pgsql;

