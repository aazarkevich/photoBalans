create function bee_repact_sver_get_head(_rid integer) returns bee_repact_sver_head
    language sql
as
$$
/*
	add ito06 2016-06-03
	add ito06 2016-04-14
	add ito06 2016-02-26 добавили столбец с датой печати акта
	add ito06 2016-02-05 добавили слово "действующего"
	add ito06 2016-01-20 добавили fil_dir_param "ФИО руководителя" (должность+филиал+ФИО+основание), если заполнен параметр "ФИО уполномоченного лица", то берем его!
	add ito06 2015-03-18
	ito16 10.11.29 Акт сверки - шапка.
*/
	SELECT 
		amn.docnumber 																AS doc_num,
		to_char(amn.docdate,'DD-MM-YYYY') 													AS doc_date,
		dinf1085.paramval 															AS fil_name,
		dinf1093.paramval 															AS fil_buh,
		dic.element_name ||' '||cst.consum_name 												AS cst_name,
		cst_dir.item 																AS cst_dir_name,
		dinf1098.paramval															AS fil_dir_name,
		cst_buh.item 																AS cst_buh,
		dinf1155.paramval 															AS fil_buh,
		CASE WHEN dinf1815.paramval IN('0','?','-','') OR dinf1815.paramval IS NULL
		       OR dinf1816.paramval IN('0','?','-','') OR dinf1816.paramval IS NULL
		       OR dinf1817.paramval IN('0','?','-','') OR dinf1817.paramval IS NULL
		        --** 2016-04-14
		       OR dinf1916.paramval IN('0','?','-','') OR dinf1916.paramval IS NULL
			THEN dinf1098.paramval
		    ELSE dinf1815.paramval
		END::varchar 																AS sign_ryk_fio,
		CASE WHEN dinf1818.paramval IN('0','?','-','') OR dinf1818.paramval IS NULL
		       OR dinf1819.paramval IN('0','?','-','') OR dinf1819.paramval IS NULL
		       OR dinf1820.paramval IN('0','?','-','') OR dinf1820.paramval IS NULL
			THEN dinf1093.paramval
		    ELSE dinf1818.paramval
		END::varchar::varchar 															AS sign_byh_fio,
		CASE WHEN dinf1815.paramval IN('0','?','-','') OR dinf1815.paramval IS NULL
		       OR dinf1816.paramval IN('0','?','-','') OR dinf1816.paramval IS NULL
		       OR dinf1817.paramval IN('0','?','-','') OR dinf1817.paramval IS NULL
		        --** 2016-04-14
		       OR dinf1916.paramval IN('0','?','-','') OR dinf1916.paramval IS NULL
		     --**  2016-06-03 THEN dinf1823.paramval||' '|| dinf1155.paramval ||' '|| dinf1098.paramval ||', действующий на основании доверенности '|| dinf1158.paramval
		       THEN dinf1823.paramval||' '|| dinf1155.paramval ||' '|| dinf1098.paramval ||', действующий на основании '|| dinf1158.paramval
		     --** 2016-04-14
		     --ELSE dinf1817.paramval||' '|| dinf1155.paramval ||' '|| dinf1815.paramval ||', действующий на основании приказа '|| dinf1816.paramval
		     ELSE   dinf1817.paramval||' '|| dinf1155.paramval ||' '|| dinf1815.paramval 
		          ||', действующий на основании '||dinf1916.paramval|| ' ' || dinf1816.paramval
		END        																AS fil_dir_param,

		CASE WHEN dinf1902.paramval IN('0','?','-','') OR dinf1902.paramval IS NULL
		   THEN '_______________'
		   ELSE dinf1902.paramval
		END 																	AS perfom_name,
		dinf1903.paramval															AS perfom_tel,
		dinf1904.paramval															AS perfom_adr, 
		CASE WHEN dinf1903.paramval NOT IN ('0','?','-','') AND  dinf1903.paramval IS NOT NULL 
		      AND dinf1904.paramval NOT IN ('0','?','-','') AND  dinf1904.paramval IS NOT NULL
		          THEN  'тел: '||dinf1903.paramval ||', '||dinf1904.paramval
		   WHEN dinf1903.paramval NOT IN ('0','?','-','') AND  dinf1903.paramval IS NOT NULL 
		          THEN 'тел: '|| dinf1903.paramval 
		   WHEN dinf1904.paramval NOT IN ('0','?','-','') AND  dinf1904.paramval IS NOT NULL 
		          THEN 'эл. адрес:'||dinf1904.paramval 
		   ELSE ''		  
		END 																	AS perfom_param,
		(now()::date)::varchar																AS print_date

		
	   FROM dic_elements AS dic
	   JOIN customer AS cst ON cst.urstatus=dic.rowid
	   JOIN agreement AS amn ON amn.abo_code=cst.abo_code
      LEFT JOIN customer_info AS cst_buh ON cst_buh.elrowid=1470 AND cst_buh.abo = amn.abo_code
      LEFT JOIN customer_info AS cst_dir ON cst_dir.elrowid=83 AND cst_dir.abo = amn.abo_code

      LEFT JOIN denet AS d ON d.rowid=cst.locid 
      LEFT JOIN denet AS d1 ON  d1.kod=substring((d.kod) FROM 1 FOR 6)
      LEFT JOIN denet_info AS dinf1085 ON dinf1085.linkid= d1.rowid AND dinf1085.paramid=1085  		--"наименование филиала (в им. падеже)"
      LEFT JOIN denet_info AS dinf1093 ON dinf1093.linkid= d1.rowid AND dinf1093.paramid=1093  		--"ФИО гл. бухгалтера"
      LEFT JOIN denet_info AS dinf1098 ON dinf1098.linkid= d1.rowid AND dinf1098.paramid=1098  		--"ФИО руководителя"
      LEFT JOIN denet_info AS dinf1155 ON dinf1155.linkid= d1.rowid AND dinf1155.paramid=1155  		--"наименование филиала (в род. падеже)"

      LEFT JOIN denet_info AS dinf1815 ON dinf1815.linkid= cst.locid AND dinf1815.paramid=1815 		--"ФИО уполномоченного лица (руководителя)"
      LEFT JOIN denet_info AS dinf1816 ON dinf1816.linkid= cst.locid AND dinf1816.paramid=1816 		--"приказ уполномоченного лица (руководителя)"
      LEFT JOIN denet_info AS dinf1817 ON dinf1817.linkid= cst.locid AND dinf1817.paramid=1817 		--"должность уполномоченного лица (руководителя)"
      LEFT JOIN denet_info AS dinf1818 ON dinf1818.linkid= cst.locid AND dinf1818.paramid=1818 		--"ФИО уполномоченного лица (гл.бух)"
      LEFT JOIN denet_info AS dinf1819 ON dinf1819.linkid= cst.locid AND dinf1819.paramid=1819 		--"приказ уполномоченного лица (гл.бух)"
      LEFT JOIN denet_info AS dinf1820 ON dinf1820.linkid= cst.locid AND dinf1820.paramid=1820 		--"должность уполномоченного лица (гл.бух)"


      LEFT JOIN denet_info AS dinf1823 ON dinf1823.linkid= d1.rowid AND dinf1823.paramid=1823 		--"должность руководителя (в им. падеже)" 2016-01-20
      LEFT JOIN denet_info AS dinf1158 ON dinf1158.linkid= d1.rowid AND dinf1158.paramid=1158 		--"Доверенность №" 2016-01-20

      LEFT JOIN denet_info AS dinf1902 ON dinf1902.linkid= cst.locid AND dinf1902.paramid=1902		--"ФИО исполнителя в (им. падеже)" 2016-01-20
      LEFT JOIN denet_info AS dinf1903 ON dinf1903.linkid= cst.locid AND dinf1903.paramid=1903 		--"телефон исполнителя" 2016-01-20
      LEFT JOIN denet_info AS dinf1904 ON dinf1904.linkid= cst.locid AND dinf1904.paramid=1904 		--"электронный адрес исполнителя" 2016-01-20

      --** 2016-04-14
      LEFT JOIN denet_info AS dinf1916 ON dinf1916.linkid= cst.locid AND dinf1916.paramid=1916		--основание подписи уполномоч. лица (рук) (род. пад)

          WHERE amn.rowid=$1;
$$;

comment on function bee_repact_sver_get_head(integer) is 'Акт сверки: шапка. Используется в RepActSver.java';

alter function bee_repact_sver_get_head(integer) owner to pgsql;

