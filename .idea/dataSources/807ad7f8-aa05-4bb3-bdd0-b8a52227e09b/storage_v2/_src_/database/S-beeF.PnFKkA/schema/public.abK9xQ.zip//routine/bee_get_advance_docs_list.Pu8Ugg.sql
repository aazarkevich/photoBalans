create function bee_get_advance_docs_list(date_from text, date_to text, _locid integer, el_type integer) returns SETOF advance_docs_list
    language plpgsql
as
$$
/*
	add ito06 2015-02-03
	add ito06 2014-12-01
	Список документов: "счет на предоплату"
*/
DECLARE
  RowLine advance_docs_list%rowtype;
---  
BEGIN
---  
  FOR RowLine IN ((SELECT
			cust.consum_inn,                       --колонка 2 (ИНН)
			d.item,                                --колонка 3 (КПП)
			cust.abo_name,                         --колонка 4 (Наименование потребителя)
			amn.docnumber,                         --колонка 5 (номер договора )
			a1.paramval,                           --колонка 6 (ФИО ответственного договорника)
			bd.docnum,                             --колонка 7 (номер документа)
			bd.docdat,
			ROUND((select sum(cost_with_tax) from bee_docs_advance where linkid1 = bd.rowid), 2) AS cost_with_tax,
			bda.date_ava  AS date_ava,
			bd.rowid,
			bd.linkid
		   FROM bee_docs  AS bd
		   JOIN agreement AS amn ON bd.linkid = amn.rowid
	           JOIN bee_docs_advance AS bda ON bda.linkid1 = bd.rowid
	      LEFT JOIN (select ai.linkid, ai.paramval 
	                  from agreement_info  AS ai
                          join (SELECT linkid, max(period)  AS period 
                                  FROM agreement_info where paramid = 1149 group by linkid
                               ) As c ON ai.linkid = c.linkid AND ai.period = c.period AND ai.paramid = 1149
                        ) AS a1 ON amn.rowid = a1.linkid
		   JOIN customer AS cust ON amn.abo_code = cust.abo_code
	      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 84) AS d ON cust.abo_code = d.abo
		  WHERE amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = _locid)) 
		    AND bd.docdat BETWEEN date_from::date AND date_to::date
		    AND bd.doctyp = el_type
		  GROUP BY cust.consum_inn, d.item, cust.abo_name, amn.docnumber, a1.paramval, bd.docnum, bd.docdat, bda.date_ava, bd.rowid, bd.linkid
	          ORDER BY docnumber)
	UNION (
	          SELECT
			cust.consum_inn,                       --колонка 2 (ИНН)
			d.item,                                --колонка 3 (КПП)
			cust.abo_name,                         --колонка 4 (Наименование потребителя)
			amn.docnumber,                         --колонка 5 (номер договора )
			a1.paramval,                           --колонка 6 (ФИО ответственного договорника)
			bd.docnum,                             --колонка 7 (номер документа)
			bd.docdat,
			ROUND((select sum(cost_with_tax) from bee_docs_advance_t where linkid1 = bd.rowid), 2) AS cost_with_tax,
			bdat.date_ava  AS date_ava,
			bd.rowid,
			bd.linkid
		   FROM bee_docs  AS bd
		   JOIN agreement AS amn ON bd.linkid = amn.rowid
	           JOIN bee_docs_advance_t AS bdat ON bdat.linkid1 = bd.rowid
	      LEFT JOIN (select ai.linkid, ai.paramval 
	                  from agreement_info  AS ai
                          join (SELECT linkid, max(period)  AS period 
                                  FROM agreement_info where paramid = 1149 group by linkid
                               ) As c ON ai.linkid = c.linkid AND ai.period = c.period AND ai.paramid = 1149
                        ) AS a1 ON amn.rowid = a1.linkid
		   JOIN customer AS cust ON amn.abo_code = cust.abo_code
	      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 84) AS d ON cust.abo_code = d.abo
		   WHERE amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = _locid)) 
		    AND bd.docdat BETWEEN date_from::date AND date_to::date
		    AND bd.doctyp = el_type
		  GROUP BY cust.consum_inn, d.item, cust.abo_name, amn.docnumber, a1.paramval, bd.docnum, bd.docdat, bdat.date_ava, bd.rowid, bd.linkid
	          ORDER BY docnumber))
  LOOP
     RETURN NEXT RowLine; 
  END LOOP;
---
RETURN;
--
END;

$$;

comment on function bee_get_advance_docs_list(text, text, integer, integer) is 'Используется в AdvanceDocs.java, SessionBean1.java';

alter function bee_get_advance_docs_list(text, text, integer, integer) owner to pgsql;

