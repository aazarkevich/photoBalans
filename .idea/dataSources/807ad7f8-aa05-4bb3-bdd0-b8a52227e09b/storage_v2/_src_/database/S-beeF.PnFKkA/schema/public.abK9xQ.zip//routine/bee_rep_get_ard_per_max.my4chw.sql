create function bee_rep_get_ard_per_max(param_id integer) returns SETOF bee_ard_tab
    language plpgsql
as
$$
/*
ito7 2018-02-08
ito06 2012-01-10
add ito06 2012-05-24
*/
DECLARE 
RowLine bee_ard_tab%RowType;
filt varchar;
BEGIN

IF param_id NOT IN (439,689,664,1015)
 THEN 
   filt =' AND paramval IS NOT NULL 
              AND paramval <> '||quote_literal('-')||'
              AND paramval <> '||quote_literal('')||'
              AND paramval <> '||quote_literal('0')||'
              AND paramval <> '||quote_literal('?')||' ';

   ELSE
 IF param_id  = 664 THEN filt = ' AND ((is_numeric(paramval) AND length(paramval)>7) OR (paramval = '||quote_literal('0')||'))';
      ELSE filt = ' AND is_numeric(paramval)';
    END IF;
 
END IF;


RETURN QUERY EXECUTE 
'SELECT
    ard.linkid,
    paramval
 FROM agreeregdev_period AS ard 
 JOIN (SELECT  linkid,  max(period) AS period
       FROM agreeregdev_period
       WHERE paramid='||$1||'
         '||filt||'
       GROUP BY linkid
      ) AS per ON per.linkid = ard.linkid AND per.period = ard.period
      
 WHERE paramid ='||$1||' GROUP BY ard.linkid, paramval;';
 
 END;
$$;

comment on function bee_rep_get_ard_per_max(integer) is 'Используется в bee_get_agreepoint_with_subabo(int), bee_get_child_chained_devices(int), bee_get_child_chained_devices(int, int), bee_get_child_chained_devices_no690(int, int), bee_get_parent_counter(int), bee_has_subabo_agreepoint(int, int), bee_is_counter_chained(int, int), bee_rep10_month_en(int, date, date, varchar), bee_rep10_ulev_1(int, date, varchar, varchar, varchar, varchar, varchar), bee_rep10_ulev_3(int, date, varchar, varchar, varchar, varchar, varchar), bee_rep10_ulev_4(int, date, varchar, varchar, varchar, varchar, varchar), bee_rep10_ulev_5(int, date, varchar, varchar, varchar, varchar, varchar), bee_rep10_ulev_en_mix(int, date, varchar, varchar, varchar, varchar, varchar), bee_rep10_ulev_en_real(int, date, varchar, varchar, varchar, varchar, varchar), bee_rep28_get_consum(int, date, int), bee_rep28_get_consum_f(int, date, int), bee_rep28_get_en_real(int, date), bee_rep28_get_month_en(int, date, date), bee_rep_annex4_get_en_real(int, date), bee_rep_annex4_get_month_en(int, date, date), bee_rep_get_repdata28_get_en_4(int, date), bee_rep_get_repdata28_get_en_5(int, date), bee_rep_get_repdata28_get_pow_1(int, date), bee_rep_get_repdata28_get_pow_2(int, date), bee_rep_get_repdata28_get_pow_3(int, date), bee_rep_get_repdata28_get_pow_4(int, date), bee_rep_get_repdata28_get_pow_5(int, date), bee_rep_get_repdata8_0(int, varchar, varchar, varchar, varchar), bee_rep_get_repdata8_1(int,varchar, varchar,  varchar,  varchar), bee_rep_get_repdata8_2(int, varchar, varchar, varchar, varchar), bee_rep_get_repdata9(int), bee_repagreepointlist_get_agreeregdev_period(int), bee_repakt8_get_content(text, date, date, int), bee_repreestr_get_vals(int)';

alter function bee_rep_get_ard_per_max(integer) owner to pgsql;

