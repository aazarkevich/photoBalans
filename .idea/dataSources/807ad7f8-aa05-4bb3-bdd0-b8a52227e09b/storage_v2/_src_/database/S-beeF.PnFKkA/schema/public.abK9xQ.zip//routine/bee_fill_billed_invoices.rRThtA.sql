create function bee_fill_billed_invoices(_top_locid integer, _df text, _dt text) returns SETOF integer[]
    language plpgsql
as
$$
DECLARE
/*
	add ito06 2020-03-19 берем % НДС из таблицы  + если есть расчитанный sum_wiht_tax в result берем от туда, если нет расчитываем
	Выставленные счет-фактуры
*/
    _date_from date = _df::date;
    _date_to date = _dt::date;
    _dat date := '2014-09-30';
  
BEGIN
       DROP TABLE IF EXISTS tmp_rep_billed_invoices;
      CREATE TEMPORARY table tmp_rep_billed_invoices  AS 
       (SELECT
	    dic_elements.element_name::text 	                						AS c1,  	--направление учета
	    agreement.docnumber::text  	                        						AS c2,  	--номер договора
	    e3.element_name || ' ' || customer.consum_name ::text						AS c3,  	--наименование контрагента 
	    bee_docs.docnum::text                           							AS c4,  	--номер документа
                        bee_docs.docdat::text                                		AS c5,  	--дата документа
	    SUM(vn.amount)::numeric                       								AS c6,  	--сумма кВт по вн 
	    SUM(sn1.amount)::numeric                                					AS c7,  	--сумма кВт по сн-1  
	    SUM(sn2.amount)::numeric                                					AS c8,  	--сумма кВт по сн-2 
	    SUM(nn.amount)::numeric                                 					AS c9,  	--сумма кВт по нн
	    
	    SUM(vn_1.sum_no_tax)::numeric												AS c10, 	--сумма без НДС по вн 
	    SUM(sn1_1.sum_no_tax)::numeric												AS c11, 	--сумма без НДС по cн-1       
	    SUM(sn2_1.sum_no_tax)::numeric												AS c12, 	--сумма без НДС по cн-2
	    SUM(nn_1.sum_no_tax)::numeric												AS c13, 	--сумма без НДС по нн 
	    /* 2020-03-19 
	    CASE WHEN SUM(vn_1.sum_with_tax) <> 0 AND  _date_from <= _dat
		THEN SUM(vn_1.sum_with_tax)::numeric
	         ELSE (SUM(vn_1.sum_no_tax) * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)	
	    END 																		AS c14, 	--сумма с НДС по вн 						
	    CASE WHEN SUM(sn1_1.sum_with_tax) <> 0 AND  _date_from <= _dat
		THEN SUM(sn1_1.sum_with_tax)::numeric	
	         ELSE (SUM(sn1_1.sum_no_tax) * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)
	    END 																		AS c15, 	--сумма с НДС по сн-1
	    CASE WHEN SUM(sn2_1.sum_with_tax) <> 0 AND  _date_from <= _dat
		THEN SUM(sn2_1.sum_with_tax)::numeric	 
	         ELSE (SUM(sn2_1.sum_no_tax)* (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)
	    END 																		AS c16, 	--сумма с НДС по сн-2
	    CASE WHEN SUM(nn_1.sum_with_tax) <> 0 AND  _date_from <= _dat
		THEN SUM(nn_1.sum_with_tax)::numeric
	         ELSE (SUM(nn_1.sum_no_tax) * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)	
	    END       																	AS c17, 	--сумма с НДС по нн                   
		*/
		CASE WHEN SUM(vn_1.sum_with_tax) = 0 
		THEN   (SUM(vn_1.sum_no_tax) * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)	
		ELSE 
			CASE WHEN   _date_from >= _dat
				THEN SUM(vn_1.sum_with_tax)::numeric
					 ELSE (SUM(vn_1.sum_no_tax) * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)	
				END 
		END 																		AS c14, 	--сумма с НДС по вн 						
		CASE WHEN SUM(sn1_1.sum_with_tax) = 0 
		  THEN (SUM(sn1_1.sum_no_tax) * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)
		ELSE 		
			CASE WHEN  _date_from >= _dat
			THEN SUM(sn1_1.sum_with_tax)::numeric	
				 ELSE (SUM(sn1_1.sum_no_tax) * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)
			END 
		END 																		AS c15, 	--сумма с НДС по сн-1
	    CASE WHEN SUM(sn2_1.sum_with_tax) = 0 
		   THEN (SUM(sn2_1.sum_no_tax)* (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)
		ELSE
			CASE WHEN  _date_from >= _dat
			THEN SUM(sn2_1.sum_with_tax)::numeric	 
				 ELSE (SUM(sn2_1.sum_no_tax)* (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)
			END
		END 																		AS c16, 	--сумма с НДС по сн-2
		CASE WHEN SUM(nn_1.sum_with_tax) = 0 
		  THEN (SUM(nn_1.sum_no_tax) * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)
		  ELSE
			CASE WHEN  _date_from >= _dat
			THEN SUM(nn_1.sum_with_tax)::numeric
				 ELSE (SUM(nn_1.sum_no_tax) * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::numeric(20,2)	
		   END
		END  																		AS c17, 	--сумма с НДС по нн
		--**
	    bee_docs.rowid::integer                                 					AS c18, 	--внутренний код документа по нем нужно сгруппировать записи
	    agreement.locid::integer													AS c19, 	--locid
	    agreement.accdir::integer			        								AS c20, 	--направление учёта
	    '/'||e1.element_name||'/40'::text                       					AS pref,	--префикс документа
	    
	    CASE WHEN SUM(res.sum_with_tax) = 0 
				--** 2020-03-19
	            --THEN (SELECT sum(a)*1.18 from unnest(ARRAY[SUM(vn_1.sum_no_tax),SUM(sn1_1.sum_no_tax),SUM(sn2_1.sum_no_tax),SUM(nn_1.sum_no_tax)]) as a)	        	     
		     THEN (SELECT sum(a)*(1 + bee_get_doc_tax(1163,bee_docs.rowid)) from unnest(ARRAY[SUM(vn_1.sum_no_tax),SUM(sn1_1.sum_no_tax),SUM(sn2_1.sum_no_tax),SUM(nn_1.sum_no_tax)]) as a)	        	     
			 ELSE CASE WHEN  _date_from >= _dat
	                      THEN  SUM(res.sum_with_tax)
	                   ELSE  (SELECT sum(a) from unnest(ARRAY[SUM(vn_1.sum_with_tax),SUM(sn1_1.sum_with_tax),SUM(sn2_1.sum_with_tax),SUM(nn_1.sum_with_tax)]) as a)
	              END        
	    END::numeric																AS allsumm	--сумма всего с НДС
	    
	    
	  FROM  bee_docs
	  -- киловаты
         LEFT JOIN (SELECT bdr.linkid, sum(bdr.amount) AS amount
	          FROM bee_docs_result  AS bdr
	      JOIN dic_tarif_group ON bdr.tar_grp = dic_tarif_group.rowid
	      JOIN bee_docs as bd ON bdr.linkid= bd.rowid
	     WHERE dic_tarif_group.voltage_level=306
	       AND ((bdr.tar_typ IN (1068,1168) AND bd.doctyp = 1065) OR (bd.doctyp  = 1618 AND bdr.tar_typ=1069))
	     GROUP BY bdr.linkid
	        ) AS nn ON bee_docs.rowid = nn.linkid

         LEFT JOIN (SELECT bdr.linkid, sum(bdr.amount) AS amount
	      FROM bee_docs_result  AS bdr
	      JOIN dic_tarif_group ON bdr.tar_grp = dic_tarif_group.rowid
	      JOIN bee_docs as bd ON bdr.linkid= bd.rowid
	     WHERE dic_tarif_group.voltage_level=310
	       AND ((bdr.tar_typ IN (1068,1168) AND bd.doctyp = 1065) OR (bd.doctyp  = 1618 AND  bdr.tar_typ=1069))
	     GROUP BY bdr.linkid
	       ) AS sn2 ON bee_docs.rowid = sn2.linkid

         LEFT JOIN (SELECT bdr.linkid, sum(bdr.amount) AS amount
	      FROM bee_docs_result  AS bdr
	      JOIN dic_tarif_group ON bdr.tar_grp = dic_tarif_group.rowid
	      JOIN bee_docs as bd ON bdr.linkid= bd.rowid
	     WHERE dic_tarif_group.voltage_level=308
	       AND ((bdr.tar_typ IN (1068,1168) AND bd.doctyp = 1065) OR (bd.doctyp  = 1618 AND  bdr.tar_typ=1069))
	     GROUP BY bdr.linkid
	       ) AS sn1 ON bee_docs.rowid = sn1.linkid

         LEFT JOIN (SELECT bdr.linkid, sum(bdr.amount) AS amount
	          FROM bee_docs_result  AS bdr
	      JOIN dic_tarif_group ON bdr.tar_grp = dic_tarif_group.rowid
	      JOIN bee_docs as bd ON bdr.linkid= bd.rowid
	         WHERE dic_tarif_group.voltage_level=311
	       AND ((bdr.tar_typ IN (1068,1168) AND bd.doctyp = 1065) OR (bd.doctyp  = 1618 AND  bdr.tar_typ=1069))
	     GROUP BY bdr.linkid
	    ) AS vn ON bee_docs.rowid = vn.linkid
	    -------------------
         -- денги
         LEFT JOIN (SELECT bdr.linkid, sum(sum_no_tax) AS sum_no_tax, sum(sum_with_tax) AS sum_with_tax
	      FROM bee_docs_result  AS bdr
	      JOIN dic_tarif_group ON bdr.tar_grp = dic_tarif_group.rowid
	      JOIN bee_docs as bd ON bdr.linkid= bd.rowid
	     WHERE dic_tarif_group.voltage_level=306
	       AND ((bdr.tar_typ IN (1068,1168) AND bd.doctyp = 1065) OR (bd.doctyp  = 1618))
	     GROUP BY bdr.linkid
	    ) AS nn_1 ON bee_docs.rowid = nn_1.linkid

         LEFT JOIN (SELECT bdr.linkid, sum(sum_no_tax) AS sum_no_tax, sum(sum_with_tax) AS sum_with_tax
	      FROM bee_docs_result  AS bdr
	      JOIN dic_tarif_group ON bdr.tar_grp = dic_tarif_group.rowid
	      JOIN bee_docs as bd ON bdr.linkid= bd.rowid
	     WHERE dic_tarif_group.voltage_level=310
	       AND ((bdr.tar_typ IN (1068,1168) AND bd.doctyp = 1065) OR (bd.doctyp  = 1618))
	     GROUP BY bdr.linkid
	    ) AS sn2_1 ON bee_docs.rowid = sn2_1.linkid

         LEFT JOIN (SELECT bdr.linkid, sum(sum_no_tax) AS sum_no_tax, sum(sum_with_tax) AS sum_with_tax
	          FROM bee_docs_result  AS bdr
	      JOIN dic_tarif_group ON bdr.tar_grp = dic_tarif_group.rowid
	      JOIN bee_docs as bd ON bdr.linkid= bd.rowid
	     WHERE dic_tarif_group.voltage_level=308
	       AND ((bdr.tar_typ IN (1068,1168) AND bd.doctyp = 1065) OR (bd.doctyp  = 1618))
	     GROUP BY bdr.linkid
	       ) AS sn1_1 ON bee_docs.rowid = sn1_1.linkid

         LEFT JOIN (SELECT bdr.linkid, sum(sum_no_tax) AS sum_no_tax, sum(sum_with_tax) AS sum_with_tax
	      FROM bee_docs_result  AS bdr
	      JOIN dic_tarif_group ON bdr.tar_grp = dic_tarif_group.rowid
	      JOIN bee_docs as bd ON bdr.linkid= bd.rowid
	     WHERE dic_tarif_group.voltage_level=311
	       AND ((bdr.tar_typ IN (1068,1168) AND bd.doctyp = 1065) OR (bd.doctyp  = 1618))
	     GROUP BY bdr.linkid
	       ) AS vn_1 ON bee_docs.rowid = vn_1.linkid

         LEFT JOIN (SELECT bdr.linkid, sum(sum_no_tax) AS sum_no_tax, sum(sum_with_tax) AS sum_with_tax
	      FROM bee_docs_result  AS bdr
	      JOIN dic_tarif_group ON bdr.tar_grp = dic_tarif_group.rowid
	      JOIN bee_docs as bd ON bdr.linkid= bd.rowid
	     WHERE ((bdr.tar_typ IN (1068,1168) AND bd.doctyp = 1065) OR (bd.doctyp  = 1618))
	     GROUP BY bdr.linkid
	       ) AS res ON bee_docs.rowid = res.linkid

	       
	    -------------------	
		    
			
	  JOIN dic_elements AS e1 ON bee_docs.pref = e1.rowid
	  JOIN agreement ON bee_docs.linkid = agreement.rowid
         LEFT JOIN dic_elements ON agreement.accdir=dic_elements.rowid
	  JOIN customer ON agreement.abo_code = customer.abo_code
	  JOIN dic_elements AS e3 ON customer.urstatus = e3.rowid
	
	 WHERE bee_docs.doctyp IN (1065, 1618)                   -- документ выставления (акт приема-передачи и корректировка)
	   AND bee_docs.docdat BETWEEN _date_from AND _date_to   -- период выгрузки документов
	   -- 79- действующий 77- расторгнутый
	   AND ((agreement.docstatus = 79) or ( agreement.docstatus = 77 and agreement.closedate BETWEEN _date_from AND _date_to))

	   AND agreement.doctype = 1910 --** 2016-04-25		   
	   AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
	   AND agreement.valid=true
                 GROUP BY c4, c5, c20, c1, c3, c2, c18, c19, e1.element_name,agreement.docnumber
	 ORDER BY c19, c3,  case when regexp_replace(agreement.docnumber, E'[^\\d*]', E'\\1','g') = '' 
	                            then 0 else regexp_replace(agreement.docnumber, E'[^\\d*]', E'\\1','g')::bigint 
	                       end);
    END;
$$;

comment on function bee_fill_billed_invoices(integer, text, text) is 'Финансовый отчет: выставление счета-фактуры. Используется в BilledInvoices.java';

alter function bee_fill_billed_invoices(integer, text, text) owner to pgsql;

