create function bee_is_devices_oneplace(agreeid integer) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN EXISTS (SELECT 1  FROM agreepoint WHERE linkid = agreeid GROUP BY linkid HAVING COUNT(distinct lid) = 1);
END;
$$;

comment on function bee_is_devices_oneplace(integer) is 'Проверка на привязку по разным участкам. Используется в DeviceEdit.java, AppUtils.java';

alter function bee_is_devices_oneplace(integer) owner to pgsql;

