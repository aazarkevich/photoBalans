create function bee_rep_get_repdata(locid integer, strdate date, enddate date) returns SETOF bee_rep_tab
    language sql
as
$$
/*
	add ito06 2021-02-15 должны попадать расторгнутые
	ito16 Формирование сравнительной ведомости по показаниям АО Донэнерго и ПАО ТНС энерго Ростов-на-Дону
*/
SELECT DISTINCT
	apn.rowid			      AS ardlink,
	replace((ard.paramval || ', '|| cst.abo_name), E'\\','/' ) AS adrfio, 
	apn.account                           AS accoun, 
	bee_get_oper_regdevval(apn.rowid,715) AS grp,
          ---------- 
--        bee_get_oper_repval975(apn.rowid, 196, $2,$3+'1 month'::interval - '1 day'::interval) AS strval, 
--	  bee_get_oper_repval975(apn.rowid, 195, $2,$3+'1 month'::interval - '1 day'::interval) AS endval, 
--        bee_get_oper_repval(apn.rowid, 196, $2,$3+'1 month'::interval - '1 day'::interval) AS strval, 
--        bee_get_oper_repval(apn.rowid, 195, $2,$3+'1 month'::interval - '1 day'::interval) AS endval, 
        bee_get_oper_repval1(apn.rowid, 993, rdo.operdate) AS strval, 
        bee_get_oper_repval1(apn.rowid, 992, rdo.operdate) AS endval, 
        bee_get_oper_repval1(apn.rowid, 991, rdo.operdate) AS contval, 
        bee_get_oper_repval1(apn.rowid, 990, rdo.operdate) AS accval, 
        bee_get_oper_repval1(apn.rowid, 199, rdo.operdate) AS dopval,
        to_char(rdo.operdate,'DD.MM.YYYY') AS dat
          
FROM customer            as cst
        JOIN agreement   as amn ON cst.abo_code = amn.abo_code
        JOIN agreepoint  as apn ON amn.rowid    = apn.linkid 
        JOIN agreeregdev as ard ON apn.rowid    = ard.linkid
        JOIN regdevoper977  as rdo ON apn.rowid = rdo.linkid
WHERE 
        ard.paramid = 417 AND
        cst.locid   = $1  AND
        rdo.operdate BETWEEN $2 AND $3+'1 month'::interval - '1 day'::interval AND 
        --ito06 2021-02-15 amn.docstatus = 79 AND	 amn.docstatus in (77, 79) AND
	
        rdo.paramid IN (195,196,199) AND
        (bee_get_oper_regdevval_date(apn.rowid,690) IS NULL OR
         bee_get_oper_regdevval_date(apn.rowid,690) > $2)
GROUP BY apn.linkid, ard.paramval, cst.abo_name, apn.account,apn.rowid,rdo.operdate
ORDER BY adrfio, accoun;
$$;

comment on function bee_rep_get_repdata(integer, date, date) is 'Формирование сравнительной ведомости по показаниям ОАО Донэнерго и ООО Донэнергосбыт. Используется в RepCreate.java';

alter function bee_rep_get_repdata(integer, date, date) owner to pgsql;

