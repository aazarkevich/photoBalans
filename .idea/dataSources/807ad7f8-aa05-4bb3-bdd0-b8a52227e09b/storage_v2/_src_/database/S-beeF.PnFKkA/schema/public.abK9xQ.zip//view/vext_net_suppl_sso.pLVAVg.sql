create view vext_net_suppl_sso(supplier, period, lid) as
SELECT (((agreepoint.prodnumber)::text || '_'::text) || (agreepoint.lid)::text) AS supplier,
       agreeregdev_period.period,
       agreepoint.lid
FROM (agreepoint
         JOIN agreeregdev_period ON ((agreepoint.rowid = agreeregdev_period.linkid)))
WHERE ((agreeregdev_period.paramid = 2041) AND (agreepoint.deleted = false))
ORDER BY agreepoint.lid, agreepoint.prodnumber, agreeregdev_period.period DESC;

alter table vext_net_suppl_sso
    owner to postgres;

