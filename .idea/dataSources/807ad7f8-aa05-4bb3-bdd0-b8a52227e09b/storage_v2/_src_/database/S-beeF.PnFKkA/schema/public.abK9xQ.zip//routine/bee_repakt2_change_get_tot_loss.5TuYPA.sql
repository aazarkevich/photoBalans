create function bee_repakt2_change_get_tot_loss(bd_rowid integer, diff boolean, _doctyp integer) returns bee_repakt2_tot_tab1
    language plpgsql
as
$$
/*
	add ito06 2015-12-10  добавили входной параметр _doctyp
	ito06 2015-07-09: Акт (соц. норма) для исправления или корректировки	
*/
DECLARE _tartyp text = '0';
	
BEGIN 
	IF _doctyp  = 1 
           THEN	--исправление
		_tartyp = '1707,1142';
	   ELSIF _doctyp  = 2
	      THEN 	
		--корректировка 
		_tartyp = '1069,1159';           		
        END IF;
SELECT (select sum (a) from unnest (ARRAY[cont.vn_sum_fsk,cont.vn_sum_rsk]) AS a)   AS vn_tot_sum, 
       (select sum (a) from unnest (ARRAY[cont.sn1_sum_fsk,cont.sn1_sum_rsk]) AS a) AS sn1_tot_sum, 
       (select sum (a) from unnest (ARRAY[cont.sn2_sum_fsk,cont.sn2_sum_rsk]) AS a) AS sn2_tot_sum,
       (select sum (a) from unnest (ARRAY[cont.nn_sum_fsk,cont.nn_sum_rsk]) AS a)   AS  nn_tot_sum,
       (select sum (a) from unnest (ARRAY[cont.tot_sum_fsk, cont.tot_sum_rsk]) AS a)  AS tot_sum,
       (select sum (a) from unnest (ARRAY[vn.vn[1],  -cont.vn_sum_fsk, -cont.vn_sum_rsk]) AS a)  AS itog_sum_vn,
       (select sum (a) from unnest (ARRAY[sn1.sn1[1],-cont.sn1_sum_fsk,-cont.sn1_sum_rsk]) AS a)  AS itog_sum_sn1,
       (select sum (a) from unnest (ARRAY[sn2.sn2[1],-cont.sn2_sum_fsk,-cont.sn2_sum_rsk]) AS a)  AS itog_sum_sn2,
       (select sum (a) from unnest (ARRAY[nn.nn[1],  -cont.nn_sum_fsk,-cont.nn_sum_rsk]) AS a)  AS itog_sum_nn,
       (select sum (a) from unnest (ARRAY[vn.vn[1],sn1.sn1[1],sn2.sn2[1],nn.nn[1],
                                        -cont.tot_sum_fsk, -cont.tot_sum_rsk]) AS a)  AS itog_sum
FROM bee_repakt2_change_get_content_loss($1)  As cont,
     bee_repakt2_change_get_tot_vn($1,diff,_tartyp) AS vn,
     bee_repakt2_change_get_tot_sn1($1,diff, _tartyp) AS sn1,
     bee_repakt2_change_get_tot_sn2($1,diff, _tartyp) AS sn2,
     bee_repakt2_change_get_tot_nn($1,diff, _tartyp) AS nn;
    
END;
$$;

comment on function bee_repakt2_change_get_tot_loss(integer, boolean, integer) is 'Акт (соц. норма) для исправления или корректировки. Используется в repakt2_change.java';

alter function bee_repakt2_change_get_tot_loss(integer, boolean, integer) owner to pgsql;

