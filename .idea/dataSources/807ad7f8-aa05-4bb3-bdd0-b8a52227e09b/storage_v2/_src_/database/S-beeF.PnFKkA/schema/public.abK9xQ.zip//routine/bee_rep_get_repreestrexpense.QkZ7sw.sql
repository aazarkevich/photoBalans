create function bee_rep_get_repreestrexpense(loc integer, start_date date, end_date date, reptype character varying) returns SETOF bee_repreestrexpense
    language plpgsql
as
$$
/*
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2012-08-21
	ito06 2011-12-05 Реестр по расходу
*/
DECLARE 
	RowLine bee_repreestrexpense%RowType;
	param character varying;
BEGIN
	IF reptype = 'reestExpense' THEN param = ' NOT ';
	END IF;
	IF reptype = 'reestExpenseCD' THEN param = ' ';
	END IF;

RETURN QUERY EXECUTE'
 SELECT distinct
	cust.consum_name 							AS cust,	-- потребитель
	amn.docnumber::varchar(20)						AS docnum,	-- № договора
	apn.account 								AS account, 	-- лицевой счет
	apn.prodnumber 								AS prodnum,	-- № СЧЁТЧИКА
	rdo.valman::numeric(12,2)						AS expense,	-- расход 	
	doc_calc.quantity_amo::numeric(12,2) 					AS finexpense,	-- расход финансы
	(rdo.valman::numeric(12,2)-doc_calc.quantity_amo)::numeric(12,2)	AS difference	-- разница

     FROM agreement 								AS amn
     JOIN agreepoint 								AS apn  	ON apn.linkid = amn.rowid
     JOIN customer 								AS cust		ON cust.abo_code = amn.abo_code
     
     JOIN (select linkid , sum(valman ::numeric(12,2)) AS valman 
             from regdevoper 
             where  paramid='||quote_literal(850)||' AND operdate between '||quote_literal($2)||' AND '||quote_literal($3)||'
             group by linkid 
          ) AS    rdo  	ON rdo.linkid = apn.rowid
     JOIN regdevoper 								AS rdo1  	ON rdo1.linkid = apn.rowid
     JOIN agreeregdev_period 							AS arp  	ON arp.linkid = apn.rowid
LEFT JOIN bee_docs_calc 							AS doc_calc  	ON rdo1.rowid=doc_calc.quantity_id
LEFT JOIN bee_docs 								AS bds 		ON bds.rowid = doc_calc.linkid1
    WHERE docstatus = 79									-- действующий договор
	  AND amn.doctype = 1910								-- прямой договор
	  AND rdo1.paramid='||quote_literal(850)||'						-- потреблено без субабанентов
	  AND bds.docdat between '||quote_literal($2)||' AND '||quote_literal($3)||'						-- дата выбранного периода 
	  AND rdo1.operdate between '||quote_literal($2)||' AND '||quote_literal($3)||'					-- дата выбранного периода
	  AND apn.rowid '|| param ||' IN (SELECT linkid from agreeregdev_period WHERE paramid  IN (1614,1535) AND paramval <> '||quote_literal('0')||')
	  AND amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = '||$1||'))

ORDER BY docnum, account, prodnum;';
END;
$$;

comment on function bee_rep_get_repreestrexpense(integer, date, date, varchar) is 'Реестр по расходу. Используется в RepReestExpense.java';

alter function bee_rep_get_repreestrexpense(integer, date, date, varchar) owner to pgsql;

