create function bee_is_counter_chained(_lid integer, pointid integer) returns boolean
    language plpgsql
as
$$
BEGIN
/*
	add ito06 201-11-14 Запитано ли устройство от другого.

*/
   RETURN EXISTS(
	   select 1 from (select paramval from agreeregdev_period where linkid = pointid and paramid = 664 order by period desc limit 1) AS a 
	where a.paramval NOT IN ('?','-','0') AND a.paramval ~ E'^\\d{1,}' 
      /*SELECT 1 FROM agreepoint
      JOIN bee_rep_get_ard_per_max(664)  AS ard 
         ON ard.linkid = agreepoint.rowid AND paramval NOT IN ('?','-','0') AND paramval ~ E'^\\d{1,}'   
      JOIN agreement  ON agreepoint.linkid  = agreement.rowid 
      WHERE 
         TRUE
         --agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = _lid))  
	    AND agreepoint.rowid = pointid*/
   ); 
END;

$$;

comment on function bee_is_counter_chained(integer, integer) is 'Запитано ли устройство от другого. Используется в AgreeByDevice.java, AgreeRegDev.java, OperVal.java, AppUtils.java';

alter function bee_is_counter_chained(integer, integer) owner to pgsql;

