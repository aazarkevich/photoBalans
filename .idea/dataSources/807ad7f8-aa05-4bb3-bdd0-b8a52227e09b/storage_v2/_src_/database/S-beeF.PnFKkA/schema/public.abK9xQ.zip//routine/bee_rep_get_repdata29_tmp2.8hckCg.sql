create function bee_rep_get_repdata29_tmp2(loc_id integer, d_start date, d_end date, fil character varying) returns SETOF bee_repdata29_tmp
    language plpgsql
as
$$
/*
	add ito06 2021-06-15 проверяем, если в середине месяца перестал быть смешанным, то не учитываем
	add ito06 2016-03-03 добавляем параметр тип договора amntyp
	add ito06 2015-06-30
	ito06 2015-01-21 Сводная ведомость по объему услуг,
	выводит потребеление для всех групп (смешанные договоры) с разбиением по тарифам	
*/
DECLARE 
	tmp_kod VARCHAR;
	Hname_mix varchar; 
	RowLine bee_repdata29_tmp%rowtype;
	ListConn TEXT[];
	Result TEXT;

BEGIN
	SELECT hostname FROM bee_closed_info WHERE dbstatus = 'X' LIMIT 1 INTO Hname_mix;
	SELECT * FROM dblink_get_connections() INTO ListConn;
	IF 'deconnMix' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconnMix') INTO Result ; END IF;  
	SELECT dblink_connect_u('deconnMix','dbname=beeX  port=5432  host='''|| Hname_mix ||''' user=pgsql') INTO Result;
	
	
	
	SELECT into tmp_kod  kod from denet AS de1 where de1.rowid = loc_id limit 1;
	RETURN QUERY(
	SELECT $4										AS fil,
	       '1900-01-01'::date	 				AS dat,
	       amnid 									AS amnid,	       
       	       doc_name						AS doc_name, 

	       CASE WHEN adir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp  IN (139,140,141,138)
			THEN 11 --прочие потребители одноставочный
	            WHEN adir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp  IN (142,144,147,148)
			THEN 121 --прочие потребители двуставочный мощность
		    WHEN adir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp  IN (143,145,146,149)
			THEN 122 --прочие потребители двуставочный эл.эн

		    WHEN adir  IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp  IN (139,140,141,138)
			THEN 21 --бюджетные потребители одноставочный
		    WHEN adir IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp  IN (142,144,147,148)
			THEN 221 --бюджетные  потребители двуставочный мощность
		    WHEN adir  IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp  IN (143,145,146,149) 
			THEN 222 --бюджетные потребители двуставочный эл.эн	

		    WHEN bdc.tar_grp  IN (150,156,154,155) AND con_sum = 850
			THEN 311 --население и потребители приравненниые к населению
		    WHEN bdc.tar_grp  IN (150,156,154,155) AND con_sum = 1446
			THEN 312 --население и потребители приравненниые к населению норма
		    WHEN bdc.tar_grp  IN (150,156,154,155) AND con_sum = 1174
			THEN 313 --население и потребители приравненниые к населению сверх нормы
			
		    WHEN bdc.tar_grp  IN (152,159,157,158) AND con_sum = 850  	           
			THEN 321 --городское население эл. плиты
		    WHEN bdc.tar_grp  IN (152,159,157,158) AND con_sum = 1446  	           
			THEN 322 --городское население эл. плиты норма
		    WHEN bdc.tar_grp  IN (152,159,157,158) AND con_sum = 1174	           
			THEN 323 --городское население эл. плиты сверх нормы

		    WHEN bdc.tar_grp  IN (153,162,160,161) AND con_sum = 850
			THEN 331 -- население проживающее в сельских населенных пунктах
		    WHEN bdc.tar_grp  IN (153,162,160,161) AND con_sum = 1446 
			THEN 332 -- население проживающее в сельских населенных пунктах норма
		    WHEN bdc.tar_grp  IN (153,162,160,161) AND con_sum = 1174
			THEN 333 -- население проживающее в сельских населенных пунктах сверх нормы
		   ELSE 5
		   
		END											AS grp,
		
		---
		null::numeric 										AS tot_amount,
                SUM(CASE WHEN bdc.tar_grp IN (139,142,143,150,152,153)
			   THEN bdc.quantity_amo
			 ELSE NULL
		    END) 										AS vn_amount,    
	        SUM(CASE WHEN bdc.tar_grp IN (140,144,145,156,159,162)
			   THEN bdc.quantity_amo
			 ELSE NULL
		    END)   										AS sn1_amount,
		SUM(CASE WHEN bdc.tar_grp IN (141,147,146,154,157,160)
			   THEN bdc.quantity_amo
			 ELSE NULL
		    END)   										AS sn2_amount,
		SUM(CASE WHEN bdc.tar_grp IN (138,148,149,155,158,161)
			   THEN bdc.quantity_amo
			 ELSE NULL
		    END)   										AS nn_amount,
		----     
		null::numeric 										AS tot_sum,   
		SUM(CASE WHEN bdc.tar_grp IN (139,142,143,150,152,153)
			   THEN bdc.cost_no_tax
			 ELSE NULL
		    END) 										AS vn_sum,    
	        SUM(CASE WHEN bdc.tar_grp IN (140,144,145,156,159,162)
			   THEN bdc.cost_no_tax
			 ELSE NULL
		    END)   										AS sn1_sum,
		SUM(CASE WHEN bdc.tar_grp IN (141,147,146,154,157,160)
			   THEN bdc.cost_no_tax
			 ELSE NULL
		    END)   										AS sn2_sum,
		SUM(CASE WHEN bdc.tar_grp IN (138,148,149,155,158,161)
			   THEN bdc.cost_no_tax
			 ELSE NULL
		    END)   										AS nn_sum   		    		      

	  FROM agreement AS amn
	  JOIN agreepoint AS apn ON 
	         apn.linkid = amn.rowid 
				AND apn.lid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
      JOIN (SELECT linkid, paramval FROM agreeregdev_period AS ardp1
			  JOIN (SELECT linkid, max(period) AS period , paramid
				  FROM agreeregdev_period 
				 -- 2021-06-15  WHERE period <=$3 AND paramid = 1614  GROUP BY linkid, paramid
					WHERE period <=$3 AND paramid = 1614 and paramval <> '*' GROUP BY linkid, paramid
				) AS ardp2 USING (linkid, period, paramid) WHERE ardp1.paramid = 1614
		) AS ardp_mix ON ardp_mix.linkid = apn.rowid 
     JOIN (SELECT DISTINCT points.* 
            FROM dblink('deconnMix',
			      'select  
			          bdc.linkid2, 
			          bdc.tar_grp, 
			          sum(bdc.quantity_amo), 
			          price, sum(cost_no_tax), 
			          con_sum, 
			          amn.rowid, 
				       amn.docnumber '||'||'||''', '''||'||'||  'cust.abo_name, amn.accdir 
				  from bee_docs_calc AS bdc 
				  join bee_docs AS bd ON bd.rowid = bdc.linkid1 AND bd.docdat BETWEEN '''||$2||''' AND '''||$3||'''
				  join agreement AS amn ON amn.rowid = bd.linkid
				  join customer AS cust On cust.abo_code = amn.abo_code
				  WHERE (amn.docstatus = 79 OR amn.docstatus = 77 AND amn.closedate >= '''||$2||''') AND amn.doctype = 1910 
				  group by bdc.linkid2, bdc.tar_grp, price, con_sum, amn.rowid, amn.docnumber,cust.abo_name, amn.accdir'
            ) AS points(linkid2 int, tar_grp int, quantity_amo numeric, price numeric, cost_no_tax numeric, con_sum int, amnid int, doc_name text, adir int)  
	       ) AS  bdc ON bdc.linkid2 = apn.rowid 
      WHERE 
         (amn.docstatus = 79) -- OR amn.docstatus = 77 AND amn.closedate >= d_start)--2015-06-30
          AND amn.doctype = 1910 --2016-03-03
	   GROUP BY grp, bdc.tar_grp ,bdc.price, amnid, doc_name,con_sum
         ORDER BY grp, doc_name);

      SELECT dblink_disconnect('deconnMix') INTO Result;
        
END;
$$;

comment on function bee_rep_get_repdata29_tmp2(integer, date, date, varchar) is 'Сводная ведомость по объему услуг. Используется в bee_rep_get_repdata29_tmpMix(integer, date, date)';

alter function bee_rep_get_repdata29_tmp2(integer, date, date, varchar) owner to postgres;

