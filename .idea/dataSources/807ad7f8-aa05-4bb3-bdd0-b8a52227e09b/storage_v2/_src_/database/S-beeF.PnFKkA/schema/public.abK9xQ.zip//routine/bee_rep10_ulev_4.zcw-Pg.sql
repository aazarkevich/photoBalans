create function bee_rep10_ulev_4(locid integer, strdate date, ulev character varying, trm_filter character varying, accdir_filter character varying, cd_filter character varying, sd_filter character varying) returns SETOF bee_rep_tab10
    language plpgsql
as
$$
/*
  	add ito06 2021-02-15 должны попадать расторгнутые
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2012-12-18
	ito06 2012-05-15 Приложение 1 Договорные данные
*/
DECLARE
	tmp_kod varchar;
	rec bee_rep_tab10%rowtype;
BEGIN 
 select kod from denet where rowid=$1 into tmp_kod;
 FOR rec IN (
  SELECT dn.nam 		AS fil,     
	  denet.nam 		AS loc,  
	  amn.docnumber 	AS docnumber,
          apn.account || ', ' || apn.prodnumber || ', ' || ard3.paramval || ', ' || ard4.paramval 		AS account,
	  de.element_name  AS ulev,
          CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN  (select sum(a) from  unnest(ARRAY[pcef.m01,pcef.m02,pcef.m03,pcef.m04,pcef.m05,pcef.m06,pcef.m07,pcef.m08,pcef.m09,pcef.m10,pcef.m11,pcef.m12]) AS a)
	       ELSE  (select sum(a) from  unnest(ARRAY[pce.m01,pce.m02,pce.m03,pce.m04,pce.m05,pce.m06,pce.m07,pce.m08,pce.m09,pce.m10,pce.m11,pce.m12]) AS a)	END AS summ,
  
	  CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcef.m01
	       ELSE pce.m01	END	AS summ1,
	   CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcef.m02
	       ELSE pce.m02	END	AS summ2,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcef.m03
	       ELSE pce.m03	END	AS summ3,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcef.m04
	       ELSE pce.m04	END	AS summ4,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcef.m05
	       ELSE pce.m05	END	AS summ5,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcef.m06
	       ELSE pce.m06	END	AS summ6,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m07
	       ELSE pce.m07	END	AS summ7,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m08
	       ELSE pce.m08	END	AS summ8,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m09
	       ELSE pce.m09	END	AS summ9,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m10
	       ELSE pce.m10	END	AS summ10,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m11
	       ELSE pce.m11	END	AS summ11,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m12
	       ELSE pce.m12	END	AS summ12,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN  (select sum(a) from  unnest(ARRAY[pcmf.m01,pcmf.m02,pcmf.m03,pcmf.m04,pcmf.m05,pcmf.m06,pcmf.m07,pcmf.m08,pcmf.m09,pcmf.m10,pcmf.m11,pcmf.m12]) AS a)
	       ELSE  (select sum(a) from  unnest(ARRAY[pcm.m01,pcm.m02,pcm.m03,pcm.m04,pcm.m05,pcm.m06,pcm.m07,pcm.m08,pcm.m09,pcm.m10,pcm.m11,pcm.m12]) AS a)	END AS summ_p,
        
	  CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcmf.m01
	       ELSE pcm.m01	END	AS summ1_,
	   CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m02
	       ELSE pcm.m02	END	AS summ2_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcmf.m03
	       ELSE pcm.m03	END	AS summ3_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcmf.m04
	       ELSE pcm.m04	END	AS summ4_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcmf.m05
	       ELSE pcm.m05	END	AS summ5_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m06
	       ELSE pcm.m06	END	AS summ6_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m07
	       ELSE pcm.m07	END	AS summ7_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m08
	       ELSE pcm.m08	END	AS summ8_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m09
	       ELSE pcm.m09	END	AS summ9_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcmf.m10
	       ELSE pcm.m10	END	AS summ10_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcmf.m11
	       ELSE pcm.m11	END	AS summ11_,
	       CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25 
	       THEN pcmf.m12
	       ELSE pcm.m12	END	AS summ12_,
	  replace(ard6.paramval,',','.') AS maxpow,
	  replace(ard5.paramval,',','.') AS prispow,
	  char_length(amn.docnumber) AS dl,
	  char_length(apn.account) AS al
      FROM customer AS cust 	
	 --ito06 2021-02-15 JOIN agreement   AS amn  ON amn.abo_code = cust.abo_code  AND amn.docstatus = 79  AND amn.accdir NOT IN (319,538,1110,1476) 
     JOIN agreement   AS amn  ON amn.abo_code = cust.abo_code  AND amn.docstatus in (77, 79)  AND amn.accdir NOT IN (319,538,1110,1476) 
                             AND amn.locid IN (select rowid from denet where (kod ~ tmp_kod and length(tmp_kod)<=6)
                                                                          or (kod = tmp_kod and length(tmp_kod)>6)
                                               )
                           --AND amn.locid IN (select rowid from denet where kod ~ (select kod from denet where rowid=$1))
     JOIN agreepoint  AS apn  ON amn.rowid = apn.linkid AND apn.devtype = 644
     JOIN bee_rep_get_ard_per_max(439) AS ard  ON apn.rowid = ard.linkid   AND ard.paramval=$3 
     JOIN denet  ON apn.lid=denet.rowid
     JOIN (SELECT nam, kod FROM denet WHERE length(kod)=6) AS dn ON substring(denet.kod, 0, 7) = dn.kod
   
     JOIN dic_elements AS de ON de.rowid = ard.paramval::numeric(3)
     JOIN agreeregdev  AS ard1 ON apn.rowid = ard1.linkid AND ard1.paramid=189 AND ard1.paramval='432'
LEFT JOIN agreeregdev  AS ard2 ON apn.rowid = ard2.linkid AND ard2.paramid=690 AND is_date(ard2.paramval)
     JOIN agreeregdev AS ard3 ON ard3.linkid=apn.rowid AND ard3.paramid=418 
     JOIN agreeregdev AS ard4 ON ard4.linkid=apn.rowid AND ard4.paramid=410
LEFT JOIN agreeregdev AS ard5 ON ard5.linkid = apn.rowid AND ard5.paramid = 685 AND ard5.paramval~E'^\\d{1,}' 
LEFT JOIN agreeregdev AS ard6 ON ard6.linkid = apn.rowid AND ard6.paramid = 426 AND ard6.paramval~E'^\\d{1,}' 

LEFT JOIN bee_points_consum AS pce ON pce.linkid = apn.rowid AND pce.period = to_char($2,'YYYY-01-01')::date AND pce.tarif_val = 1042
LEFT JOIN bee_points_consum AS pcm ON pcm.linkid = apn.rowid AND pcm.period = to_char($2,'YYYY-01-01')::date AND pcm.tarif_val = 1043
LEFT JOIN bee_points_consum_f AS pcef ON pcef.linkid2 = apn.rowid AND pcef.period = to_char($2,'YYYY-01-01')::date AND pcef.tarif_val = 1042
LEFT JOIN bee_points_consum_f AS pcmf ON pcmf.linkid2 = apn.rowid AND pcmf.period = to_char($2,'YYYY-01-01')::date AND pcmf.tarif_val = 1043

LEFT JOIN (SELECT ap.rowid AS rowid,
                  CASE WHEN a.paramid = 1535     
                      THEN true ELSE false
                 END AS cd
            FROM agreepoint as ap 
       LEFT JOIN (SELECT linkid,    
                         max(period) AS period   
	            FROM agreeregdev_period  
	           WHERE paramid = 1535  
	           GROUP BY linkid
	         ) AS max_per_cd  ON max_per_cd.linkid = ap.rowid   
       LEFT JOIN agreeregdev_period AS a ON ap.rowid = a.linkid AND a.paramid = 1535 AND max_per_cd.period = a.period 

           GROUP BY ap.rowid, a.paramid
           ORDER BY ap.rowid
           ) AS cd_filter ON cd_filter.rowid = apn.rowid
 LEFT JOIN (SELECT ap.rowid AS rowid,
                   CASE WHEN b.paramid = 1614     
                      THEN true ELSE false
                 END AS sd
            FROM agreepoint as ap 
       LEFT JOIN (SELECT linkid,    
                         max(period) AS period   
	            FROM agreeregdev_period  
	           WHERE paramid = 1614  
	           GROUP BY linkid
	         ) AS max_per_sd  ON max_per_sd.linkid = ap.rowid   
       LEFT JOIN agreeregdev_period AS b ON ap.rowid = b.linkid AND b.paramid = 1614 AND max_per_sd.period = b.period 
           GROUP BY ap.rowid,  b.paramid
           ORDER BY ap.rowid
           ) AS sd_filter ON sd_filter.rowid = apn.rowid
     
   
    WHERE (ard2.paramval IS NULL OR ard2.paramval::date >= to_char($2,'YYYY-mm-01')::date - '11 month'::interval) 
     AND (amn.accdir = 317) IN
            (CASE WHEN $5 = 'a' 
                THEN 'f'::boolean ELSE $5::boolean
             END,
             CASE WHEN $5 = 'a' 
               THEN 't'::boolean  ELSE $5::boolean
             END)       
        AND (amn.doctype = 1910) IN --** 2016-04-25 
            (CASE WHEN $4 = 'a' 
                THEN 'f'::boolean ELSE $4::boolean
             END,
             CASE WHEN $4 = 'a' 
               THEN 't'::boolean ELSE $4::boolean
             END)
     AND cd_filter.cd  IN
           (CASE  WHEN $6 = 'a' 
              THEN 'f'::boolean ELSE $6::boolean
            END,
            CASE  WHEN $6 = 'a' 
              THEN 't'::boolean  ELSE $6::boolean
            END) 
     AND sd_filter.sd  IN
           (CASE WHEN $7 = 'a' 
              THEN 'f'::boolean ELSE $7::boolean
            END,
            CASE WHEN $7 = 'a' 
              THEN 't'::boolean ELSE $7::boolean
             END)  
ORDER BY dl, docnumber, fil, loc, al,account
) LOOP 
RETURN NEXT rec;

END LOOP;
END;
$$;

comment on function bee_rep10_ulev_4(integer, date, varchar, varchar, varchar, varchar, varchar) is 'Приложение 1 Договорные данные. Используется в bee_rep_get_repdata10(int, date, varchar, varchar, varchar, varchar, int)';

alter function bee_rep10_ulev_4(integer, date, varchar, varchar, varchar, varchar, varchar) owner to pgsql;

