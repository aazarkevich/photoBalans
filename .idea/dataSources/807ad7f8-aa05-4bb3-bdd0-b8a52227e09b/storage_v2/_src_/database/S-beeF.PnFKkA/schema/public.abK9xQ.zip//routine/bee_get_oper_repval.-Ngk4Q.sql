create function bee_get_oper_repval(integer, integer, date) returns numeric
    language sql
as
$$
    -- 1 - pointid
  -- 2 - paramid
  -- 3 - operdate
  --
  --SELECT valman::numeric(12,3) FROM regdevoper
  SELECT round(valman::numeric,0) FROM regdevoper
  WHERE 
     linkid   = $1 AND
     paramid  = $2 AND 
     operdate = $3 AND
     valman   ~ E'^\\d{1,}'
  ;
$$;

comment on function bee_get_oper_repval(integer, integer, date) is 'Используется в RepCreate5.java';

alter function bee_get_oper_repval(integer, integer, date) owner to pgsql;

