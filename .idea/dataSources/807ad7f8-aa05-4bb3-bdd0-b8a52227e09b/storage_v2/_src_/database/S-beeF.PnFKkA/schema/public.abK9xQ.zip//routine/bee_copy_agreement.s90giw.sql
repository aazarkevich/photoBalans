create function bee_copy_agreement(lid integer, tag boolean, docstat integer, docnum character varying, docdat character varying, accd integer, doctyp integer, aboco integer, amnid integer, closedat character varying) returns character varying
    language plpgsql
as
$$
/*
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2016-04-20 добавили заполнение параметров "дата установки*", "показания при установке*", (закрытый период)
	add ito06 2016-03-02 вместо transmit новый параметр doctyp
	add ito06 2015-06-30
	ito06 2014-12-15: Копирование договора (amnid) со всеми точками учета и их пост, прериод, параметрами, подключениями и тарифами.
*/
DECLARE
	ridAmn int := -1;
	ridApn int := -1;
	ridParam int := -1;
	apnType int := 0;
	open_period date = now() ;
	recA record;
	recP record;
	errApn varchar = '';
	errParamC varchar = '';
	errParamP varchar = '';
	errParamT varchar = '';
	errParamR varchar = '';
	rdo194 varchar = ''; -- 2016-04-20 "дата снятия показаний"
	rdo195 varchar = ''; -- 2016-04-20 "текущие показания"
	per_all date;
	per_uni date;
	per_mix date;
	per_dir date;	
BEGIN
	 
	--добавляем договор
	INSERT INTO agreement 
		(locid, valid, docstatus, docnumber, docdate,      accdir, abo_code, closedate,      doctype) VALUES
		(lid,   tag,   docstat,   docnum,    docdat::date, accd,   aboco,    closedat::date, doctyp) RETURNING rowid INTO ridAmn;
	IF ridAmn IS NULL THEN ridAmn := -1; END IF;	
		
	IF ridAmn > 0 --договор добавлен
	   THEN
		--цикл по точкам учета договора, который копируем
		FOR recA IN (  SELECT apn.rowid, apn.linkid, apn.devid, apn.account, apn.prodnumber,  apn.devtype, apn.deleted, apn.lid 
		                 FROM agreepoint AS apn
		            LEFT JOIN agreeregdev AS ard  ON apn.rowid = ard.linkid AND ard.paramid = 690
				WHERE apn.linkid = amnid AND (length(ard.paramval)<2 or ard.paramval IS null))
		LOOP
			
		    BEGIN
			--вставляем т.у.
			INSERT INTO agreepoint 
			(linkid,        devid,         account,         prodnumber,         devtype,        deleted,         lid) VALUES
			(ridAmn, recA.devid,  recA.account,  recA.prodnumber,  recA.devtype, recA.deleted,  recA.lid) RETURNING rowid INTO ridApn;

			IF ridApn IS NULL THEN ridApn := -1; END IF;

			IF ridApn > 0 --точка добавлена в новый договор
			   
			    THEN  			    
				-- смотрим какая точка (простая, смешанная...) и находим первое число открытого периода
				select * from bee_get_point_agree_type(recA.rowid,'agreeregdev_period') INTO apnType;
				IF apnType IS NULL THEN apnType := 0; END IF;
				--** 2016-04-20
				SELECT period + 1 FROM  bee_closed_period_uni where filloc = recA.lid  LIMIT 1 INTO per_uni;
				SELECT period + 1 FROM  bee_closed_period_mix where filloc = recA.lid  LIMIT 1 INTO per_mix;
				SELECT period + 1 FROM  bee_closed_period_dir where filloc = recA.lid  LIMIT 1 INTO per_dir;
				SELECT period + 1 FROM  bee_closed_period where filloc = recA.lid  LIMIT 1 INTO per_all; 
				
				IF (apnType = 1) --централизованная
					THEN SELECT GREATEST(per_uni, per_dir, per_all) INTO open_period;
				    ELSIF (apnType = 2) --смешенная
					THEN SELECT GREATEST(per_mix, per_dir, per_all) INTO open_period;
				    ELSIF (apnType = 4)  -- прямой
					THEN SELECT GREATEST(per_dir, per_all) INTO open_period;
				    ELSE open_period = per_all;
				END IF;
				--**
				IF  open_period IS NULL THEN  open_period:= now(); END IF;
				
				-- цикл по постоянным параметрам устройства
				FOR recP IN (select * from agreeregdev where linkid = recA.rowid AND paramid not in (154,192))
				LOOP				
				   BEGIN
					INSERT INTO agreeregdev 
					(         paramid,          paramval,linkid) VALUES
					(recP.paramid, recP.paramval,ridApn);					
				   EXCEPTION
					WHEN others THEN errParamC = errParamC|| ','|| recA.prodnumber; CONTINUE;					
				   END;
				END LOOP;
				--** 2016-04-20 
				BEGIN
					select operdate::varchar, valman from regdevoper 
					 where linkid = recA.rowid and paramid = 195 order by operdate desc limit 1 INTO rdo194, rdo195;						
					INSERT INTO agreeregdev (paramid,paramval,linkid) VALUES (154, rdo194,ridApn); -- дата установки
					INSERT INTO agreeregdev (paramid,paramval,linkid) VALUES (192, rdo195,ridApn); -- показания при установке
				   EXCEPTION
					WHEN others THEN errParamC = errParamC|| ','|| recA.prodnumber; CONTINUE;					
				   END;
				--**
				
				-- цикл по периодическим параметрам устройства
				FOR recP IN (SELECT ardp.linkid,
							ardp.paramid, 
							ardp.paramval, 
							GREATEST(open_period, a1.period) AS period							 
						   FROM agreeregdev_period AS ardp
						   JOIN (SELECT paramid, MAX(period) AS period, linkid 
							   FROM agreeregdev_period 
						          WHERE linkid =   recA.rowid
							  GROUP BY paramid, linkid
							) AS a1 ON ardp.linkid = a1.linkid AND ardp.paramid = a1.paramid AND ardp.period = a1.period 
						  WHERE ardp.linkid = recA.rowid
                                                  ORDER BY paramid)
				LOOP
				   BEGIN
					 INSERT INTO agreeregdev_period
					              (linkid,          paramid,          period,          paramval) VALUES
                                                      (ridApn, recP.paramid, recP.period, recP.paramval);				
				   EXCEPTION
					WHEN others THEN errParamP = errParamP|| ', '||recA.prodnumber; CONTINUE;					
				   END;
				END LOOP;
				
				-- цикл по тарифам устройства
				FOR recP IN (SELECT apnt.pointid,
							apnt.tarifid, 
							GREATEST(open_period, a1.period) AS period							 
						   FROM agreepoint_tarif AS apnt
						   JOIN (SELECT tarifid, MAX(period) AS period, pointid 
							   FROM agreepoint_tarif 
						          WHERE pointid = recA.rowid
							  GROUP BY tarifid, pointid
							) AS a1 ON  apnt.pointid  = a1.pointid  AND  apnt.tarifid = a1.tarifid AND  apnt.period = a1.period 
						  WHERE  apnt.pointid = recA.rowid)
				LOOP
				   BEGIN
					INSERT INTO agreepoint_tarif 
						(pointid, tarifid, period)VALUES
						(ridApn, recP.tarifid, recP.period);
					
				   EXCEPTION
					WHEN others  THEN errParamT = errParamT|| ', '||recA.prodnumber; CONTINUE;
				   END;
				END LOOP;
				
				-- цикл по подключениям устройства
				FOR recP IN (select * from regdevconn where pointid = recA.rowid)
				LOOP
				   BEGIN	
					INSERT INTO regdevconn
						(         traceid, pointid,         locid,          kod,          objtype)VALUES 
						(recP.traceid, ridApn, recP.locid, recP.kod, recP.objtype);
				   EXCEPTION
					WHEN others  THEN errParamR = errParamR|| ','|| recA.prodnumber; CONTINUE;					
				   END;
				END LOOP;
			   ELSE --точка не добавлена				
				errApn = errApn|| ', recA.prodnumber';
			END IF;   
			   
		    EXCEPTION
			WHEN others THEN errApn = errApn || ','||recA.prodnumber; CONTINUE;
			
		    END;
		END LOOP;
	END IF;	

	RETURN ridAmn||':'||errApn||':'||errParamC||':'||errParamP||':'||errParamT||':'||errParamR;

END;
$$;

comment on function bee_copy_agreement(integer, boolean, integer, varchar, varchar, integer, integer, integer, integer, varchar) is 'Добавление копирование договора. Используется CustomerForm.java, AppUtils.java';

alter function bee_copy_agreement(integer, boolean, integer, varchar, varchar, integer, integer, integer, integer, varchar) owner to pgsql;

