create function bee_rep_get_repdata30_all(loc_id integer, sdate date, edate date, allcust boolean, alluni boolean, allfil boolean) returns SETOF bee_repdata30
    language plpgsql
as
$$
/*
    ito07 2019-06-24 drop moved to top 
    add ito06 2015-09-30 Изменили названия колонок для  разделителя
    add ito06 2015-05-12
    ito06 2015-02-02 Сводная реализация электроэнергии
    allcust = true - развернуть по потребителям
    alluni = true  - развернуть по централизованным
    allfil = true  - развернуть по филиалам
*/
DECLARE rec bee_repdata30%rowtype;
    rec1 record;
    func varchar =  'bee_rep_get_repdata30';
    func1 varchar =  'bee_rep_get_repdata30';
    fil varchar = '%';
    host varchar = 'f66apps0';
    host1 varchar = 'f66apps1';
    host2 varchar = 'f66apps2';
    host3 varchar = 'f66apps3';

BEGIN
    DROP TABLE IF EXISTS bee_rep_get_repdata30_tmp; 
    DROP TABLE IF EXISTS bee_rep_get_repdata30_period_tmp; 
    
    PERFORM bee_rep_get_repdata30_create_tmp_table($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date);

    IF alluni   THEN func = 'bee_rep_get_repdata30_uni';  func1 = 'bee_rep_get_repdata30_uni'; END IF;		
    IF allcust  THEN func = 'bee_rep_get_repdata30_cust'; func1 = 'bee_rep_get_repdata30'; END IF;

    IF loc_id = 693 AND allfil  
          THEN --РГЭС
            SELECT distinct hostname FROM bee_closed_info WHERE dbstatus = 'U' limit 1 INTO host;
            IF    host ='f66apps1' THEN host1 = 'f66apps0';
            ELSIF host ='f66apps2' THEN host2 = 'f66apps0';
            ELSIF host ='f66apps3' THEN host3 = 'f66apps0';
            END IF;   
            
            RETURN QUERY EXECUTE '      SELECT * FROM '||func||'('''||fil  ||''')
                                  UNION SELECT * FROM '||func||'('''||host ||''')
                                  UNION SELECT * FROM '||func||'('''||host1||''')
                                  UNION SELECT * FROM '||func||'('''||host2||''')
                                  UNION SELECT * FROM '||func||'('''||host3||''')
                                  ORDER BY host, nn1, ord; ';
	         
       ELSIF loc_id = 644 AND allfil  
         THEN 
            RETURN QUERY EXECUTE 'SELECT * FROM '||func1||'('''||fil||''') ORDER BY host, nn1, ord;';
           
            FOR rec1 IN (SELECT distinct hostname FROM bee_closed_info WHERE dbstatus = 'U' AND hostname NOT IN ('f66apps1', 'f66apps2', 'f66apps3') ORDER BY hostname)
	   LOOP
	        IF rec1.hostname = 'f66apps0' 
	            THEN RETURN QUERY EXECUTE 'SELECT * FROM '||func||'('''||'f66apps%'||''') ORDER BY host, nn1, ord;'; 
	        ELSE RETURN QUERY EXECUTE 'SELECT * FROM '||func||'('''||rec1.hostname||''') ORDER BY host, nn1, ord;';
	    END IF;
	   END LOOP;	
       ELSE 
	RETURN QUERY EXECUTE 'SELECT * FROM '||func||'('''||fil||''') ORDER BY host, nn1, ord;';
    END IF;	
    
--	DROP TABLE IF EXISTS bee_rep_get_repdata30_tmp; 
--  DROP TABLE IF EXISTS bee_rep_get_repdata30_period_tmp; 

END;
$$;

comment on function bee_rep_get_repdata30_all(integer, date, date, boolean, boolean, boolean) is 'Сводная реализация. Используется в RepCreate.java';

alter function bee_rep_get_repdata30_all(integer, date, date, boolean, boolean, boolean) owner to pgsql;

