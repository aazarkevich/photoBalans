create function agree_get_ext_docnumbers(paramid character varying) returns SETOF character varying
    language plpgsql
as
$$
/*
  added 2013-02-19 by ito07
  Получить список номеров смешанных или централизованных договоров 
  из внешней базы данных beeX 
*/

DECLARE
   ListConn  TEXT[];
   Result    TEXT;
   r         VARCHAR;
   DbTag     VARCHAR = '*';
   Rec       RECORD;
   LabLength VARCHAR;
BEGIN

   SELECT * FROM dblink_get_connections() INTO ListConn;
   IF 'deconn2' = ANY (ListConn) THEN    
        SELECT dblink_disconnect('deconn2') INTO Result;
   END IF;
  
   IF paramid = '1614' THEN      -- смешанные
      DbTag = 'X';
      LabLength = '6';           -- length(denet.kod)
   ELSEIF paramid = '1535' THEN  -- централизованные
         DbTag = 'Z';
         LabLength = '3'; -- length(denet.kod)
   ELSE
       --    
   END IF;

   SELECT hostname,dbname,dbport FROM bee_closed_info WHERE dbstatus = DbTag INTO Rec;

   IF (Rec IS NOT NULL) THEN
   SELECT dblink_connect_u('deconn2',
      ' dbname   = ' || Rec.dbname   ||
      ' port     = ' || Rec.dbport   ||
      ' host     = ' || Rec.hostname ||
      ' user     = ' || 'pgsql'      ||
      ' password = ' || '') INTO Result;

     

     FOR r IN (
       SELECT t.* FROM dblink(
         'deconn2',
         '(SELECT docnumber FROM agreement 
            WHERE 
               locid = (select rowid from denet 
                        where length(kod) = ' || LabLength || ' limit 1
               )
          ) 
          UNION (
            SELECT ' || quote_literal('*') || '
          ) ORDER BY docnumber '
         ) AS t (docnumber varchar)
     )
     LOOP       
        RETURN NEXT r;
     END LOOP;
     
     IF 'deconn2' = ANY (ListConn) THEN    
        SELECT dblink_disconnect('deconn2') INTO Result;
     END IF;
     END IF;

END;
$$;

comment on function agree_get_ext_docnumbers(varchar) is 'Получить список номеров смешанных или централизованных договоров из внешней базы данных beeX. Используется в DeviceParamP.java, SessionBean.java';

alter function agree_get_ext_docnumbers(varchar) owner to pgsql;

