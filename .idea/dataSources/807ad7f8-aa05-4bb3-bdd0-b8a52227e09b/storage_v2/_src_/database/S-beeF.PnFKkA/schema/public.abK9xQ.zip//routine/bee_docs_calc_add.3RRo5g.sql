create function bee_docs_calc_add(docid integer, pid integer) returns numeric
    language plpgsql
as
$$
/*
	add ito06 2014-11-11
	add ito06 2014-11-11
	add ito06 2013-10-04 
*/
DECLARE
	E_NO_TARIF INTEGER := -1;
	LastDate DATE;
	FirstDate DATE;
	QUANTITY_AMO_CURRENT NUMERIC := 0;
	QUANTITY_AMO_TOTAL NUMERIC := 0;
	Rec RECORD;
BEGIN
	--
	LastDate  = (SELECT docdat FROM bee_docs WHERE rowid = docid ORDER BY docdat DESC LIMIT 1);
	FirstDate = (SUBSTRING(LastDate::VARCHAR,1,7) || '-01')::DATE;
   
	IF (SELECT period FROM dic_tarif_sum WHERE period BETWEEN  FirstDate AND LastDate LIMIT 1) IS NULL 
	   THEN RETURN E_NO_TARIF;
	END IF;

	FOR Rec IN (--если тариф в точке учета "Прочие потребители" или "Бюджетные потребители", то создается 1 запись в calc по regdevoper.paramid = 850   
		(SELECT 
			docid 											AS r1, 		-- 1
			pointid 										AS r2, 		-- 2 
			agreepoint_tarif.tarifid 								AS r3, 		-- 3
			regdevoper.rowid 									AS r4, 		-- 4  
			regdevoper.valman::NUMERIC 								AS r5, 		-- 5
														       
			(CASE 
			    WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
			    WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 /
								     (100 + (SELECT tax_proc FROM bee_docs_tax 
		                                                              WHERE dat1 <= LastDate 
		                                                               ORDER BY dat1 DESC LIMIT 1))
			END) 											AS r6, 		-- 6
														
			(regdevoper.valman::NUMERIC *  
			    CASE 
				WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
		                WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 /
								         (100 + (SELECT tax_proc FROM bee_docs_tax 
		                                                                  WHERE dat1 <= LastDate
		                                                                  ORDER BY dat1 DESC LIMIT 1))
		            END) ::NUMERIC(11,2) 								AS r7, 		-- 7

													
			(SELECT tax_proc FROM bee_docs_tax 
			  WHERE  dat1 <= LastDate 
			  ORDER BY dat1 DESC LIMIT 1)								AS r8,		-- 8
														
			((regdevoper.valman::NUMERIC *  
			   CASE 
			       WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
		               WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 /
							                (100 + (SELECT tax_proc FROM bee_docs_tax 
		                                                                 WHERE dat1 <= LastDate 
		                                                                 ORDER BY dat1 DESC LIMIT 1))
		           END) ::NUMERIC(11,2)
		        * (SELECT tax_proc FROM bee_docs_tax 
		            WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1) / 100
			)::NUMERIC(11,2) 									AS r9,		-- 9
	       											
			(regdevoper.valman::NUMERIC *  
			    CASE 
		                WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
				WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 /
									 (100 + (SELECT tax_proc FROM bee_docs_tax 
										  WHERE dat1 <= LastDate 
										  ORDER BY dat1 DESC LIMIT 1))
			     END 
			) ::NUMERIC(11,2) 
			+
			((regdevoper.valman::NUMERIC *
			    CASE 
				WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
				WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 /
				                                         (100 + (SELECT tax_proc FROM bee_docs_tax 
		                                                                  WHERE dat1 <= LastDate 
		                                                                  ORDER BY dat1 DESC LIMIT 1))
			    END) ::NUMERIC(11,2)
			* (SELECT tax_proc FROM bee_docs_tax 
	                    WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1) / 100) ::NUMERIC(11,2) 		AS r10, 	-- 10 (7+9)
			regdevoper.paramid AS r11
	           FROM bee_docs
	           JOIN agreement ON bee_docs.linkid = agreement.rowid
	           JOIN agreepoint ON agreement.rowid = agreepoint.linkid
	           JOIN agreepoint_tarif ON agreepoint.rowid = agreepoint_tarif.pointid AND tarifid not in (150,156,154,155,152,159,157,158,153,162,160,161)
		   JOIN regdevoper ON agreepoint.rowid = regdevoper.linkid
		   JOIN dic_tarif_group ON agreepoint_tarif.tarifid = dic_tarif_group.rowid
		   JOIN dic_tarif_sum ON dic_tarif_group.rowid = dic_tarif_sum.tarifid
	          WHERE bee_docs.rowid = docid
		    AND agreepoint_tarif.pointid = pid
	            AND agreepoint_tarif.period = (SELECT period FROM agreepoint_tarif WHERE pointid = pid AND period <= LastDate ORDER BY period DESC LIMIT 1) 
	            AND dic_tarif_sum.period BETWEEN  FirstDate AND LastDate 
	            AND regdevoper.paramid = 850       
	            AND regdevoper.operdate  BETWEEN FirstDate AND LastDate
	            AND regdevoper.rowid NOT IN (SELECT quantity_id FROM bee_docs_calc)	      
	          ORDER BY regdevoper.operdate DESC)

	UNION(-- если тариф в точке учета "Население" , то создается 2 записи в calc по regdevoper.paramid in (1446, 1174) 
		SELECT 
			docid 											AS r1,		-- 1
			pointid 										AS r2,		-- 2 
			agreepoint_tarif.tarifid 								AS r3,		-- 3
			rdo1446.rowid 										AS r4,		-- 4  
			rdo1446.valman::NUMERIC 								AS r5, 		-- 5
														     
			(CASE 
			     WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
			     WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 / 
			                                              (100 + (SELECT tax_proc FROM bee_docs_tax 
		                                                                WHERE dat1 <= LastDate 
		                                                                ORDER BY dat1 DESC LIMIT 1))
			END) 											AS r6,		-- 6  
														
			(rdo1446.valman::NUMERIC *  
			   CASE 
			      WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
			      WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 / 
			                                               (100 + (SELECT tax_proc FROM bee_docs_tax 
										WHERE dat1 <= LastDate 
										ORDER BY dat1 DESC LIMIT 1))
			   END) ::NUMERIC(11,2) 								AS r7, 		-- 7
														
			(SELECT tax_proc FROM bee_docs_tax 
			  WHERE dat1 <= LastDate 
			  ORDER BY dat1 DESC LIMIT 1) 								AS r8,		-- 8
														
			((rdo1446.valman::NUMERIC *  
			   CASE 
			      WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
			      WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 /
								       (100 + (SELECT tax_proc FROM bee_docs_tax 
		                                                                WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1))
			   END)::NUMERIC(11,2) 
			*  
			(SELECT tax_proc FROM bee_docs_tax 
			  WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1) / 100)::NUMERIC(11,2) 		AS r9,		-- 9
	       											
			(rdo1446.valman::NUMERIC *  
			   CASE 
			      WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
			      WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 / 
							               (100 + (SELECT tax_proc FROM bee_docs_tax 
										WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1))
			   END)::NUMERIC(11,2) 
			+
			((rdo1446.valman::NUMERIC *
			   CASE 
			      WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ
			      WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ * 100 / 
								       (100 + (SELECT tax_proc FROM bee_docs_tax 
										WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1))
			   END) ::NUMERIC(11,2)
			* (SELECT tax_proc FROM bee_docs_tax 
			    WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1) / 100) ::NUMERIC(11,2)		AS r10, 	-- 10 (7+9)
			rdo1446.paramid
	       
		   FROM bee_docs
		   JOIN agreement ON bee_docs.linkid = agreement.rowid
		   JOIN agreepoint ON agreement.rowid = agreepoint.linkid
		   JOIN agreepoint_tarif ON agreepoint.rowid = agreepoint_tarif.pointid AND tarifid in (150,156,154,155,152,159,157,158,153,162,160,161)
		   JOIN regdevoper AS rdo1446 	ON agreepoint.rowid = rdo1446.linkid
		   JOIN dic_tarif_group ON agreepoint_tarif.tarifid = dic_tarif_group.rowid
		   JOIN dic_tarif_sum ON dic_tarif_group.rowid = dic_tarif_sum.tarifid
		  WHERE bee_docs.rowid             = docid
		    AND agreepoint_tarif.pointid = pid
		    AND agreepoint_tarif.period = (SELECT period FROM agreepoint_tarif WHERE pointid = pid AND period <= LastDate ORDER BY period DESC LIMIT 1)
		    AND dic_tarif_sum.period BETWEEN  FirstDate AND LastDate 
		    AND rdo1446.paramid = 1446      
		    AND rdo1446.operdate  BETWEEN FirstDate AND LastDate
		    AND rdo1446.rowid NOT IN (SELECT quantity_id FROM bee_docs_calc)	      
	          ORDER BY rdo1446.operdate DESC) 
	UNION(
		SELECT  docid 												AS r1,		-- 1
			pointid 											AS r2,  	-- 2 
			agreepoint_tarif.tarifid 									AS r3,	 	-- 3
			rdo1174.rowid 											AS r4, 		-- 4  
			rdo1174.valman::NUMERIC 									AS r5,		-- 5
																     
			(CASE 
			    WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
			    WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
								     (100 + (SELECT tax_proc FROM bee_docs_tax 
									      WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1))
			END)	 											AS r6,		-- 6  
												
			(rdo1174.valman::NUMERIC *  
			   CASE 
			      WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
			      WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
								       (100 + (SELECT tax_proc FROM bee_docs_tax 
										WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1))
			   END) ::NUMERIC(11,2) 									AS r7, 		-- 7
															
			(SELECT tax_proc FROM bee_docs_tax 
			  WHERE  dat1 <= LastDate 
			  ORDER BY dat1 DESC LIMIT 1)									AS r8,		-- 8
															
			((rdo1174.valman::NUMERIC *  
			  CASE 
			     WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
			     WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
								      (100 + (SELECT tax_proc FROM bee_docs_tax 
									       WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1))
			  END) ::NUMERIC(11,2)
			*  
			(SELECT tax_proc FROM bee_docs_tax 
			  WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1) / 100)::NUMERIC(11,2) 			AS r9,		-- 9
	       															
			(rdo1174.valman::NUMERIC *  
			   CASE 
			      WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
			      WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
								       (100 + (SELECT tax_proc FROM bee_docs_tax 
										WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1))
			   END)::NUMERIC(11,2)
			+
			((rdo1174.valman::NUMERIC *
			   CASE 
			      WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
			      WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
								       (100 + (SELECT tax_proc FROM bee_docs_tax 
										WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1))
			   END)::NUMERIC(11,2)
			* 
			(SELECT tax_proc FROM bee_docs_tax 
			  WHERE dat1 <= LastDate ORDER BY dat1 DESC LIMIT 1) / 100) ::NUMERIC(11,2) 			AS r10, 	-- 10 (7+9)

			rdo1174.paramid
	       
		   FROM bee_docs
		   JOIN agreement ON bee_docs.linkid = agreement.rowid
		   JOIN agreepoint ON agreement.rowid = agreepoint.linkid
		   JOIN agreepoint_tarif ON agreepoint.rowid = agreepoint_tarif.pointid AND tarifid in (150,156,154,155,152,159,157,158,153,162,160,161)      
		   JOIN regdevoper AS rdo1174 ON agreepoint.rowid = rdo1174.linkid
	           JOIN dic_tarif_group ON agreepoint_tarif.tarifid = dic_tarif_group.rowid
		   JOIN dic_tarif_sum ON dic_tarif_group.rowid = dic_tarif_sum.tarifid
		  WHERE bee_docs.rowid = docid
	            AND agreepoint_tarif.pointid = pid
	            AND agreepoint_tarif.period = (SELECT period FROM agreepoint_tarif WHERE pointid = pid AND period <= LastDate ORDER BY period DESC LIMIT 1) 
	            AND dic_tarif_sum.period BETWEEN  FirstDate AND LastDate 
	            AND rdo1174.paramid = 1174       
	            AND rdo1174.operdate  BETWEEN FirstDate AND LastDate
	            AND rdo1174.rowid NOT IN (SELECT quantity_id FROM bee_docs_calc)	      
	          ORDER BY rdo1174.operdate DESC)) 
	LOOP 
		IF (Rec.r1 IS NULL OR Rec.r2 IS NULL) THEN QUANTITY_AMO_CURRENT := 0;
		   ELSE QUANTITY_AMO_CURRENT := Rec.r5;
			IF (QUANTITY_AMO_CURRENT IS NULL) THEN QUANTITY_AMO_CURRENT := 0;
		        END IF;
			IF (QUANTITY_AMO_CURRENT != 0) 
			   THEN 
				IF (LastDate>'2014-09-30') THEN Rec.r9 = 0; Rec.r10 = 0; END IF;   -- 2014-11-11  
				
				INSERT INTO bee_docs_calc (
					linkid1,      -- 1 bee_bocs.rowid
					linkid2,      -- 2 agreepoint.rowid
					tar_grp,      -- 3 dic_tarif_group.rowid
					quantity_id,  -- 4 regdevoper.rowid
					quantity_amo, -- 5 regdevoper.valman
					price,        -- 6 dic_tarif_sum.summ * 
					cost_no_tax,  -- 7 regdevoper.valman * bee_docs_tax
					tax_rate,     -- 8 bee_docs_tax.tax_proc 
					tax_sum,      -- 9 dic_tarif_sum...
					cost_with_tax,-- 10
					con_sum       -- 11 regdevoper.paramid
				) VALUES (
					Rec.r1,
					Rec.r2,
					Rec.r3,
					Rec.r4,
					Rec.r5,
					Rec.r6,
					Rec.r7,
					Rec.r8,
					Rec.r9,
					Rec.r10,
					Rec.r11);
			END IF;
		END IF;
		QUANTITY_AMO_TOTAL := QUANTITY_AMO_TOTAL + QUANTITY_AMO_CURRENT;
	   
	END LOOP;
	RETURN QUANTITY_AMO_TOTAL;
END;
$$;

comment on function bee_docs_calc_add(integer, integer) is 'Используется в DocMain.java, GroupDocsProcessing.java, AppUtils.java';

alter function bee_docs_calc_add(integer, integer) owner to pgsql;

