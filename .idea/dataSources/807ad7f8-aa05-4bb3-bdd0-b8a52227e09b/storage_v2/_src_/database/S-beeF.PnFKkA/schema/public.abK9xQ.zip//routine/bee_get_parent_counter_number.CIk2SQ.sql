create function bee_get_parent_counter_number(pointid integer) returns character varying
    language plpgsql
as
$$
    --
-- Получить номер родительского () усторойства
-- pointid -- код устройства
-- возврат -- номер родительского устройства
--
DECLARE
   DeviceNum character varying;
BEGIN
   SELECT INTO DeviceNum prodnumber FROM agreepoint 
          WHERE  (rowid = pointid) LIMIT 1;
  --IF DeviceNum IS NULL THEN 
  --   DeviceNum = 0;
  --END IF; 
--
--
RETURN DeviceNum;
--
--
END;
--
--
$$;

comment on function bee_get_parent_counter_number(integer) is 'Получить номер родительского усторойства. Используется в AgreeByDevice.java, AppUtils.java';

alter function bee_get_parent_counter_number(integer) owner to pgsql;

