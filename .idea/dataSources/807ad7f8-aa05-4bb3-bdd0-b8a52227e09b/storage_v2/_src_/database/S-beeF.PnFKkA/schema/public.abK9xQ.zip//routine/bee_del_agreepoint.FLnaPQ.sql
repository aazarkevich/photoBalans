create function bee_del_agreepoint(locid integer, rid integer) returns integer
    language plpgsql
as
$$
/*
ito06 2012-08-27 Удаление точки учета
*/
DECLARE NR INTEGER =-1;

 BEGIN
 NR = -1; 
 DELETE FROM agreepoint WHERE lid = locid AND rowid = rid RETURNING 1 INTO NR;
 IF NR IS NOT NULL
    THEN  RETURN 1;
 ELSE RETURN -1;
 END IF;

END;
$$;

comment on function bee_del_agreepoint(integer, integer) is 'Удаление точки учета. Используется в AgreeRegDev.java, AppUtils.java';

alter function bee_del_agreepoint(integer, integer) owner to pgsql;

