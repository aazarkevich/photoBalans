create function bee_repakt2_get_content(bd_rowid integer) returns SETOF bee_repakt2_tab
    language plpgsql
as
$$
/*
	add ito06 2015-06-17 
	add ito06 2015-06-05 изменен тип
	ito06 2013-09-25: Акт (соц. норма)	
*/
BEGIN
	RETURN QUERY SELECT * from tmp_repakt2_content;
END;
$$;

comment on function bee_repakt2_get_content(integer) is 'Акт (соц. норма). Используется в RepAkt2.java; bee_repakt2_get_tot_grp(int, varchar), bee_repakt2_get_tot_grp_sum(int, varchar)';

alter function bee_repakt2_get_content(integer) owner to pgsql;

