create view vbee_get_opervalues_buf
            (loc, per, abo, agr, pid, nam, doc, acc, num, adr, pdat, pdopsumm, prep, pamo, cdat, crep, camo, prim,
             snorm, oversnorm, rdo850, pchain)
as
(SELECT cust.locid                                                                                                                                           AS loc,
        COALESCE(rdo.operdate, '2000-01-01'::date)                                                                                                           AS per,
        cust.abo_code                                                                                                                                        AS abo,
        amn.rowid                                                                                                                                            AS agr,
        apn.rowid                                                                                                                                            AS pid,
        cust.abo_name                                                                                                                                        AS nam,
        amn.docnumber                                                                                                                                        AS doc,
        apn.account                                                                                                                                          AS acc,
        apn.prodnumber                                                                                                                                       AS num,
        COALESCE(ard.paramval, '-'::character varying(150))                                                                                                  AS adr,
        COALESCE(bee_get_oper_date_prev(apn.rowid, rdo.operdate), ((SELECT agreeregdev.paramval
                                                                    FROM agreeregdev
                                                                    WHERE ((agreeregdev.linkid = apn.rowid) AND (agreeregdev.paramid = 154))))::date)        AS pdat,
        ((COALESCE(rdo199.valman, '0'::character varying))::character varying(32))::numeric                                                                  AS pdopsumm,
        COALESCE(bee_get_oper_val_prev(apn.rowid, 407, rdo.operdate),
                 (0)::numeric)                                                                                                                               AS prep,
        COALESCE(bee_get_oper_val_prev(apn.rowid, 195, rdo.operdate), ((SELECT agreeregdev.paramval
                                                                        FROM agreeregdev
                                                                        WHERE ((agreeregdev.linkid = apn.rowid) AND (agreeregdev.paramid = 192))))::numeric) AS pamo,
        COALESCE(rdo.operdate, ((SELECT agreeregdev.paramval
                                 FROM agreeregdev
                                 WHERE ((agreeregdev.linkid = apn.rowid) AND (agreeregdev.paramid = 154))))::date)                                           AS cdat,
        COALESCE(bee_get_oper_val(apn.rowid, 407, rdo.operdate),
                 (0)::numeric)                                                                                                                               AS crep,
        ((COALESCE(rdo.valman, '0'::character varying))::character varying(32))::numeric                                                                     AS camo,
        COALESCE(bee_get_regdevoper_valman(apn.rowid, rdo.operdate, 1005),
                 '-'::character varying)                                                                                                                     AS prim,
        ((COALESCE(rdo1446.valman, '0'::character varying))::character varying(32))::numeric                                                                 AS snorm,
        ((COALESCE(rdo1174.valman, '0'::character varying))::character varying(32))::numeric                                                                 AS oversnorm,
        ((COALESCE(rdo850.valman, '0'::character varying))::character varying(32))::numeric                                                                  AS rdo850,
        CASE
            WHEN (regexp_replace(gt.pchain, '\+.{1,}?\+.{1,}?\+.{1,}?\+'::text, ''::text) IS NULL) THEN '-'::text
            ELSE regexp_replace(gt.pchain, '\+.{1,}?\+.{1,}?\+.{1,}?\+'::text, ''::text)
            END                                                                                                                                              AS pchain
 FROM ((((((((((customer cust
     JOIN agreement amn ON ((cust.abo_code = amn.abo_code)))
     JOIN agreepoint apn ON ((amn.rowid = apn.linkid)))
     LEFT JOIN agreeregdev ard ON (((apn.rowid = ard.linkid) AND (ard.paramid = 417))))
     LEFT JOIN regdevoper rdo ON (((apn.rowid = rdo.linkid) AND (rdo.paramid = 195))))
     LEFT JOIN regdevoper rdo199 ON (((rdo199.linkid = rdo.linkid) AND (rdo199.operdate = rdo.operdate) AND
                                      (rdo199.paramid = 199) AND
                                      ((rdo199.valman)::text ~ '^[-+]?[0-9]*.?[0-9]+([eE][-+]?[0-9]+)?$'::text))))
     LEFT JOIN regdevoper rdo1446 ON (((rdo1446.linkid = rdo.linkid) AND (rdo1446.operdate = rdo.operdate) AND
                                       (rdo1446.paramid = 1446) AND
                                       ((rdo1446.valman)::text ~ '^[-+]?[0-9]*.?[0-9]+([eE][-+]?[0-9]+)?$'::text))))
     LEFT JOIN regdevoper rdo1174 ON (((rdo1174.linkid = rdo.linkid) AND (rdo1174.operdate = rdo.operdate) AND
                                       (rdo1174.paramid = 1174) AND
                                       ((rdo1174.valman)::text ~ '^[-+]?[0-9]*.?[0-9]+([eE][-+]?[0-9]+)?$'::text))))
     LEFT JOIN regdevoper rdo850 ON (((rdo850.linkid = rdo.linkid) AND (rdo850.operdate = rdo.operdate) AND
                                      (rdo850.paramid = 850) AND
                                      ((rdo850.valman)::text ~ '^[-+]?[0-9]*.?[0-9]+([eE][-+]?[0-9]+)?$'::text))))
     LEFT JOIN regdevconn rdc ON ((rdc.pointid = apn.rowid)))
          LEFT JOIN gis_traces gt ON ((gt.rowid = rdc.traceid)))
 WHERE ((COALESCE(rdo.operdate, bee_get_oper_date_last(apn.rowid)) = bee_get_oper_date_last(apn.rowid)) AND
        (amn.docstatus = 79) AND (NOT (apn.rowid IN (SELECT agreeregdev.linkid
                                                     FROM agreeregdev
                                                     WHERE ((agreeregdev.paramid = 690) AND
                                                            (char_length((agreeregdev.paramval)::text) > 2))))) AND
        (NOT (ard.linkid IN (SELECT agreeregdev.linkid
                             FROM agreeregdev
                             WHERE (agreeregdev.paramid = 1900)))))
 ORDER BY cust.locid, amn.docnumber, apn.account, apn.prodnumber, rdo.operdate DESC)
UNION
(SELECT cust.locid                                                                                                                                    AS loc,
        COALESCE(rdo.operdate, '2000-01-01'::date)                                                                                                    AS per,
        cust.abo_code                                                                                                                                 AS abo,
        amn.rowid                                                                                                                                     AS agr,
        apn.rowid                                                                                                                                     AS pid,
        cust.abo_name                                                                                                                                 AS nam,
        amn.docnumber                                                                                                                                 AS doc,
        apn.account                                                                                                                                   AS acc,
        apn.prodnumber                                                                                                                                AS num,
        COALESCE(ard.paramval, '-'::character varying(150))                                                                                           AS adr,
        COALESCE(bee_get_oper_date_prev(apn.rowid, rdo.operdate), ((SELECT agreeregdev.paramval
                                                                    FROM agreeregdev
                                                                    WHERE ((agreeregdev.linkid = apn.rowid) AND (agreeregdev.paramid = 154))))::date) AS pdat,
        NULL::numeric                                                                                                                                 AS pdopsumm,
        NULL::numeric                                                                                                                                 AS prep,
        NULL::numeric                                                                                                                                 AS pamo,
        COALESCE(rdo.operdate, ((SELECT agreeregdev.paramval
                                 FROM agreeregdev
                                 WHERE ((agreeregdev.linkid = apn.rowid) AND (agreeregdev.paramid = 154))))::date)                                    AS cdat,
        COALESCE(bee_get_oper_val(apn.rowid, 407, rdo.operdate),
                 (0)::numeric)                                                                                                                        AS crep,
        NULL::numeric                                                                                                                                 AS camo,
        '-'::character varying                                                                                                                        AS prim,
        NULL::numeric                                                                                                                                 AS snorm,
        NULL::numeric                                                                                                                                 AS oversnorm,
        NULL::numeric                                                                                                                                 AS rdo850,
        CASE
            WHEN (regexp_replace(gt.pchain, '\+.{1,}?\+.{1,}?\+.{1,}?\+'::text, ''::text) IS NULL) THEN '-'::text
            ELSE regexp_replace(gt.pchain, '\+.{1,}?\+.{1,}?\+.{1,}?\+'::text, ''::text)
            END                                                                                                                                       AS pchain
 FROM (((((((customer cust
     JOIN agreement amn ON ((cust.abo_code = amn.abo_code)))
     JOIN agreepoint apn ON ((amn.rowid = apn.linkid)))
     JOIN agreeregdev ard ON (((apn.rowid = ard.linkid) AND (ard.paramid = 417))))
     JOIN agreeregdev ard2 ON ((apn.rowid = ard2.linkid)))
     LEFT JOIN regdevoper rdo ON ((apn.rowid = rdo.linkid)))
     LEFT JOIN regdevconn rdc ON ((rdc.pointid = apn.rowid)))
          LEFT JOIN gis_traces gt ON ((gt.rowid = rdc.traceid)))
 WHERE ((COALESCE(rdo.operdate, bee_get_oper_date_last(apn.rowid)) = bee_get_oper_date_last(apn.rowid)) AND
        (amn.docstatus = 79) AND (NOT (apn.rowid IN (SELECT agreeregdev.linkid
                                                     FROM agreeregdev
                                                     WHERE (agreeregdev.paramid = 690)))) AND (rdo.linkid IS NULL) AND
        (NOT (ard.linkid IN (SELECT agreeregdev.linkid
                             FROM agreeregdev
                             WHERE (agreeregdev.paramid = 1900)))))
 ORDER BY cust.locid, amn.docnumber, apn.account, apn.prodnumber, rdo.operdate DESC)
ORDER BY 1, 7, 8, 9, 2 DESC;

comment on view vbee_get_opervalues_buf is 'Используется в bee_get_opervalues_buf(int, varchar, varchar, varchar, varchar, varchar, varchar)';

alter table vbee_get_opervalues_buf
    owner to pgsql;

