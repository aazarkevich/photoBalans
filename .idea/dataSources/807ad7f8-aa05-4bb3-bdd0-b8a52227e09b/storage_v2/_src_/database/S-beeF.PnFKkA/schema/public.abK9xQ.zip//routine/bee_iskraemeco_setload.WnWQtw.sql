create function bee_iskraemeco_setload(_perstart date, _perend date, _loadstart date, _loadend date) returns boolean
    language plpgsql
as
$$
/*
	ito06 2015-11-20 устанавливаем период разрешенной автаматической загрузки (load_start, load_end) из таблицы bee_external_src (внешние данные)
	и период разрешенный для ввода показаний (period_start, period_end)
*/
DECLARE 
	result boolean = false;
        dbname_conn varchar; 
	listconn text[];
	TagRecord Record;
        res record;
        r record;	
BEGIN

	IF       current_database() = 'beeU' THEN  dbname_conn = 'beeF';
	  ELSEIF current_database() = 'beeF' THEN  dbname_conn = 'beeU';
	  ELSE RETURN false;
	END IF;

	-- получить параметры подключеия
	SELECT * FROM dblink_get_connections() INTO listconn; 

	IF 'deload' = ANY (listconn) 
	   THEN -- удаляем соединение
		SELECT dblink_disconnect('deload') INTO res;
	END IF;
			
	EXECUTE 'SELECT * FROM bee_closed_info WHERE dbname ='''||dbname_conn||''' LIMIT 1'  INTO TagRecord;
	SELECT dblink_connect_u('deload', 'dbname = ' || TagRecord.dbname ||
				   ' port = '|| TagRecord.dbport || 
				   ' host = ' || TagRecord.hostname ||
				   ' user = pgsql') into res;
	
        FOR r in EXECUTE 'select * from bee_external_sql;'
        LOOP		 
		UPDATE bee_external_sql 
		   SET period_start = _perStart,
		       period_end = _perEnd,
		       load_start = _loadStart,
		       load_end = _loadEnd
		   WHERE rowid = r.rowid;

		--получить тип возвращаемы данных из базы bee_audit
		PERFORM  dblink('deload','UPDATE bee_external_sql set period_start = '''||_perStart||''', period_end = '''||_perEnd||''',
		                           load_start = '''||_loadStart||''', load_end = '''||_loadEnd||''' WHERE rowid = '||r.rowid||';');   	
		result =  true;		
	END LOOP;
	
	-- удаляем соединение
	SELECT dblink_disconnect('deload') INTO res;		
	RETURN result;
END;
$$;

comment on function bee_iskraemeco_setload(date, date, date, date) is 'устанавливаем период автаматической загрузки из таблицы bee_external_src (внешние данные). Используется в IskraEmeco.java, AppUtils.java';

alter function bee_iskraemeco_setload(date, date, date, date) owner to pgsql;

