create function bee_is_calc_vid(pointid integer, vid integer, dat date) returns boolean
    language plpgsql
as
$$
BEGIN
   -- 2016-06-28 by ito07 for new device
   if NOT EXISTS (select 1 from regdevoper where linkid = pointid limit 1) then
       RETURN TRUE;
   end if;
   RETURN (   
      SELECT valman =  vid::text FROM regdevoper 
      WHERE 
             linkid    = pointid 
         AND paramid   = 193 
         AND operdate <= dat 
       ORDER BY  operdate desc LIMIT 1
   );

END;
$$;

comment on function bee_is_calc_vid(integer, integer, date) is 'Используется в bee_get_opervalues_buf(int, varchar, varchar, varchar, varchar, varchar, varchar)';

alter function bee_is_calc_vid(integer, integer, date) owner to pgsql;

