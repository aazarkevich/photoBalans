create function bee_iskraemeco_get_devload_list_new(_prodnum character varying)
    returns TABLE(pointid integer, prodnum character varying, devid integer, amnid integer, docnumber character varying, src integer, db_tag character varying, is_corrmark boolean, is_working boolean, is_currdog boolean)
    language plpgsql
as
$$
/*
	ito06 2015-11-13 Получить список счетчиков подходящих для загрузки из других источников для всех баз
*/
DECLARE
	ListConn  TEXT[];
	Result    TEXT;
	Rec       RECORD;
	curr_dbase varchar = 'beeU';
	res_dbase varchar = 'beeF';
	
BEGIN
	--параметры соединения
	SELECT * FROM dblink_get_connections() INTO ListConn;
	IF 'iskrconn3' = ANY (ListConn) THEN SELECT dblink_disconnect('iskrconn3') INTO Result; END IF;
	
	select * from current_database() INTO curr_dbase;
	IF (curr_dbase = 'beeF') THEN res_dbase = 'beeU'; END IF;
		
	SELECT hostname,dbname,dbport FROM bee_closed_info WHERE dbname = res_dbase INTO Rec;
	--
	IF (Rec IS NOT NULL) THEN
	   SELECT dblink_connect_u('iskrconn3',
	      ' dbname   = ' || res_dbase   ||
	      ' port     = ' || Rec.dbport   ||
	      ' host     = ' || Rec.hostname ||
	      ' user     = ' || 'pgsql'      ||
	      ' password = ' || '') INTO Result;   

	RETURN QUERY( select a.pointid, a.prodnum, a.devid, a.amnid, a.docnumber, a.src, a.db_tag, 
	                     case when b.rowid IS NOT NULL  then true else false end AS is_corrmark, 
	                     a.is_working, a.is_currdog  from (
	
		(SELECT t.* FROM dblink('iskrconn3', 
		'select a.pointid, a.prodnum, a.devid, a.amnid, a.docnumber, sum(a.src)::int,  a.db_tag, a.is_corrmark, a.is_working, a.is_currdog 
		from bee_iskraemeco_get_devload_list_tmp_new('''||_prodnum||''') AS a
		GROUP BY a.pointid, a.prodnum, a.devid, a.amnid, a.docnumber,  a.db_tag, a.is_corrmark, a.is_working, a.is_currdog') 
		AS t (pointid integer, prodnum character varying, devid integer, amnid integer, docnumber character varying,  
		      src integer, db_tag character varying,is_corrmark boolean, is_working boolean, is_currdog boolean))
	  UNION (SELECT a.pointid, a.prodnum, a.devid, a.amnid, a.docnumber, sum(a.src)::int, a.db_tag, a.is_corrmark, a.is_working, a.is_currdog 
	           FROM bee_iskraemeco_get_devload_list_tmp_new(_prodnum) AS a
	          GROUP BY a.pointid, a.prodnum, a.devid, a.amnid, a.docnumber, a.db_tag, a.is_corrmark, a.is_working, a.is_currdog )
	  ORDER BY prodnum) AS a 
	  LEFT JOIN  bee_external_sql AS b ON b.rowid = a.src) ;
	
	     --удаляем соединение
	     IF 'iskrconn3' = ANY (ListConn) THEN SELECT dblink_disconnect('iskrconn3') INTO Result; END IF;	     
	   ELSE    
		SELECT * from bee_iskraemeco_get_devload_list_tmp_new(_prodnum) ORDER BY prodnum;		
	END IF; 

END;
$$;

comment on function bee_iskraemeco_get_devload_list_new(varchar) is 'Получить список счетчиков подходящих для загрузки из других источников для всех баз. Используется в  тригере bee_external_src_load()';

alter function bee_iskraemeco_get_devload_list_new(varchar) owner to pgsql;

