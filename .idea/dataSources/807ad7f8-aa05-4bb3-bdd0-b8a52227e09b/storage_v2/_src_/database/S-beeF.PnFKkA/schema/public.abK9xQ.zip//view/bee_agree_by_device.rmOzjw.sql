create view bee_agree_by_device
            (loc, agr, acc, num, doc, abo, subject, nam, typ, dev, mark, pnt, tra, pch, devadr, ds975, ds976, ds977,
             locnam_apn, locnam_amn, fotofix)
as
SELECT DISTINCT agreement.locid                                          AS loc,
                agreement.rowid                                          AS agr,
                agreepoint.account                                       AS acc,
                agreepoint.prodnumber                                    AS num,
                agreement.docnumber                                      AS doc,
                agreement.abo_code                                       AS abo,
                customer.abo_vid                                         AS subject,
                customer.abo_name                                        AS nam,
                agreepoint.devtype                                       AS typ,
                agreepoint.devid                                         AS dev,
                dic_elements.element_name                                AS mark,
                agreepoint.rowid                                         AS pnt,
                (bee_is_point_connected(agreepoint.rowid))::integer      AS tra,
                (bee_get_point_trace_path(agreepoint.rowid))::text       AS pch,
                (bee_get_agreeregdev_value(agreepoint.rowid, 417))::text AS devadr,
                false                                                    AS ds975,
                false                                                    AS ds976,
                false                                                    AS ds977,
                deapn.nam                                                AS locnam_apn,
                deamn.nam                                                AS locnam_amn,
                CASE
                    WHEN (rdo.rowid IS NULL) THEN 0
                    ELSE 1
                    END                                                  AS fotofix
FROM ((((((agreement
    LEFT JOIN customer ON ((agreement.abo_code = customer.abo_code)))
    LEFT JOIN agreepoint ON ((agreement.rowid = agreepoint.linkid)))
    LEFT JOIN regdevoper rdo ON (((agreepoint.rowid = rdo.linkid) AND (rdo.paramid = 2024) AND
                                  (length((rdo.valman)::text) > 1))))
    LEFT JOIN dic_elements ON ((agreepoint.devid = dic_elements.rowid)))
    LEFT JOIN denet deapn ON ((deapn.rowid = agreepoint.lid)))
         LEFT JOIN denet deamn ON ((deamn.rowid = agreement.locid)))
WHERE ((customer.valid = true) AND (agreepoint.prodnumber IS NOT NULL) AND (agreement.abo_code IS NOT NULL) AND
       (agreement.locid IS NOT NULL))
ORDER BY agreement.locid, agreepoint.prodnumber;

alter table bee_agree_by_device
    owner to postgres;

