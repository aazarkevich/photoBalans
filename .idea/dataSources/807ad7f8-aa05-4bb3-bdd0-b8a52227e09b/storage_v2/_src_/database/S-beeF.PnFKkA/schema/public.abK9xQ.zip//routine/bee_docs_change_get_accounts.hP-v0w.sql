create function bee_docs_change_get_accounts(agreeid integer) returns SETOF bdc_accounts
    language plpgsql
as
$$
    /*
    ito06 2012-03-26 Исправление в счете-фактуре
    */
	--
	DECLARE
	        Rec RECORD;
		RowLine bdc_accounts%rowtype;
	---  
	BEGIN
	---  
		FOR RowLine IN (
			select agreepoint.account,
				agreepoint.prodnumber,
				NULL as tar_grp_new_lab,
				agreepoint_tarif.pointid,
				NULL as isremoved,
				max(agreepoint_tarif.period) as period,
				agreepoint.rowid from agreepoint
				
				join agreement on agreepoint.linkid = agreement.rowid
				join agreepoint_tarif on agreepoint.rowid = agreepoint_tarif.pointid
				where agreement.rowid = agreeid
				group by agreepoint.account, agreepoint.prodnumber, agreepoint_tarif.pointid, agreepoint.rowid
				order by pointid asc
		)
		LOOP
			BEGIN
				SELECT INTO Rec name FROM dic_tarif_group WHERE rowid = (SELECT tarifid FROM agreepoint_tarif where period = RowLine.period and pointid = RowLine.pointid limit 1);
				RowLine.tar_grp_new_lab = coalesce(Rec.name, '');

				SELECT INTO Rec (octet_length(coalesce(paramval, '')) > 3) as c1 FROM agreeregdev WHERE paramid = 690 and linkid = RowLine.pointid;
				RowLine.isremoved = Rec.c1;
				
				RETURN NEXT RowLine; 
			END;
		END LOOP;
	--
	END;


$$;

comment on function bee_docs_change_get_accounts(integer) is 'Исправление в счете-фактуре. Используется в DocsChange.java, SessionBean1.java';

alter function bee_docs_change_get_accounts(integer) owner to pgsql;

