create function bee_iskraemeco_get_countersrc_list(sdat date, edat date)
    returns TABLE(amnid integer, docnumber character varying, pointid integer, mark character varying, devid integer, prodnum character varying, operdate date, operval numeric, err integer, ok_text character varying, prim character varying, src_name character varying, src integer, base character varying, db_tag character varying, locid integer, loaddate date)
    language plpgsql
as
$$
/*
	ito06 2015-11-13 Получить список счетчиков незагруженных из bee_external_src (либо не отмечены, либо не подходящие по периоду) для всех баз
*/
DECLARE
	ListConn  TEXT[];
	Result    TEXT;
	Rec       RECORD;
	curr_dbase varchar = 'beeU';
	res_dbase varchar = 'beeF';
	
BEGIN
	--параметры соединения
	SELECT * FROM dblink_get_connections() INTO ListConn;
	IF 'iskrconn3' = ANY (ListConn) THEN SELECT dblink_disconnect('iskrconn3') INTO Result; END IF;
	
	select * from current_database() INTO curr_dbase;
	IF (curr_dbase = 'beeF') THEN res_dbase = 'beeU'; END IF;
		
	SELECT hostname,dbname,dbport FROM bee_closed_info WHERE dbname = res_dbase INTO Rec;
	--
	IF (Rec IS NOT NULL) THEN
	   SELECT dblink_connect_u('iskrconn3',
	      ' dbname   = ' || res_dbase   ||
	      ' port     = ' || Rec.dbport   ||
	      ' host     = ' || Rec.hostname ||
	      ' user     = ' || 'pgsql'      ||
	      ' password = ' || '') INTO Result;   

	RETURN QUERY(select distinct
				     a.amnid 				AS amnid, 
				     a.docnumber 			AS docnumber,
				     a.pointid 				AS pointid, 
	                             a.mark 				AS mark, 
	                             a.devid 				AS devid,	                            
	                             bes.dev_num 			AS prodnum, 
	                             bes.operdate 			AS operdate, 
	                             bes.operval 			AS operval,
	                             bes.err 				AS err, 
	                             CASE
					WHEN bes.ready THEN 'загружен'
					ELSE 'ошибка загрузки'
				     END::varchar			AS ok_text,
	                             de2.element_name 			AS prim,
	                             de1.element_name			AS src_name,
	                             bes.srv 				AS src, 
	                             a.base 				AS base, 
	                             a.db_tag 				AS db_tag, 
	                             a.locid 				AS locid, 
	                             bes.loaddate 			AS loaddate
	               from bee_external_src AS bes
            	  LEFT JOIN dic_elements AS de1 ON de1.element_code = bes.srv AND de1.link = 176
	          LEFT JOIN dic_elements AS de2 ON de2.element_code = bes.err AND de2.link = 177
                  left join ((SELECT t.* FROM dblink('iskrconn3', 'select * from bee_iskraemeco_get_countersrc_list_tmp('''||$1||''','''||$2||''')') 
		                  AS t (amnid int, docnumber varchar, pointid int, mark varchar, devid int, prodnum varchar,operdate date, operval numeric, err integer,
		                   ok_text varchar, prim varchar,  src_name varchar, src int, base varchar, db_tag varchar, locid int, loaddate date))
	                       UNION (SELECT * from bee_iskraemeco_get_countersrc_list_tmp($1, $2))) AS a 
	                       on a.prodnum = bes.dev_num 
	                       and a.operdate = bes.operdate
	                       and  a.operval::varchar = bes.operval::varchar
	   WHERE bes.operdate between $1 and $2 AND bes.ready = false
	  ORDER BY bes.dev_num);
	
	     --удаляем соединение
	     IF 'iskrconn3' = ANY (ListConn) THEN SELECT dblink_disconnect('iskrconn3') INTO Result; END IF;	     
	   ELSE    
		SELECT * from bee_iskraemeco_get_countersrc_list_tmp() ORDER BY prodnum;		
	END IF; 

END;
$$;

comment on function bee_iskraemeco_get_countersrc_list(date, date) is 'Получить список счетчиков незагруженных из bee_external_src (либо не отмечены, либо не подходящие по периоду) для всех баз. Используется в IskraEmeco.java, SessionBean1.java';

alter function bee_iskraemeco_get_countersrc_list(date, date) owner to pgsql;

