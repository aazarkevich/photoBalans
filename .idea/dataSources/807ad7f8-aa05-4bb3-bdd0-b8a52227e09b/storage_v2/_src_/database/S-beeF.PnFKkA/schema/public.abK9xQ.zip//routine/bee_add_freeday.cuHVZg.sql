create function bee_add_freeday(aday character varying, ainfo character varying) returns integer
    language plpgsql
as
$$
    --
--
DECLARE 
  Result integer;
BEGIN
  IF aday IS NOT NULL THEN
     INSERT INTO bee_calendar (dat,info) VALUES
     (to_date(aday,'YYYY-MM-DD'),ainfo);
     Result = 0;
  ELSE 
     Result = -1;  
  END if;
--
RETURN Result;
--
END;
--
$$;

comment on function bee_add_freeday(varchar, varchar) is 'Используется в OffDays.java, AppUtils.java';

alter function bee_add_freeday(varchar, varchar) owner to pgsql;

