create function bee_get_requisites_represent(_locid integer) returns character varying
    language sql
as
$$
/*
	ito06 2015-03-26 Получение реквизитов представителей для печати "актов снятия показаний"
*/
	
        select DISTINCT 'fioext^'||
                CASE WHEN di_fioext.paramval IS NULL OR di_fioext.paramval IN ('','?','0',' ')
			THEN ' '::varchar
			ELSE di_fioext.paramval
		END ||'|posext^'
		|| CASE WHEN di_posext.paramval IS NULL OR di_posext.paramval IN ('','?','0',' ')
			  THEN ' '::varchar
			  ELSE di_posext.paramval 
		   END ||'|fioown^'
		|| CASE WHEN di_fioown.paramval IS NULL OR di_fioown.paramval IN ('','?','0',' ')
			  THEN ' '::varchar
			  ELSE di_fioown.paramval
		   END ||'|posown^'		
		|| CASE WHEN di_posown.paramval IS NULL OR di_posown.paramval IN ('','?','0',' ')
			THEN ' '::varchar
			ELSE di_posown.paramval
		END
        
          from denet_info AS di
     left join denet_info AS  di_fioext ON  di.linkid = di_fioext.linkid AND di_fioext.paramid = 1849
     left join denet_info AS  di_posext ON  di.linkid = di_posext.linkid AND di_posext.paramid = 1850
     left join denet_info AS  di_fioown ON  di.linkid = di_fioown.linkid AND di_fioown.paramid = 1851
     left join denet_info AS  di_posown ON  di.linkid = di_posown.linkid AND di_posown.paramid = 1852
         where di.linkid = _locid

$$;

comment on function bee_get_requisites_represent(integer) is 'Получение реквизитов представителей для печати актов снятия показаний. Используется в RepAkt8.java; AppUtils.java';

alter function bee_get_requisites_represent(integer) owner to pgsql;

