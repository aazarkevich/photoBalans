create function agree_x_2(dbn character varying, agr_num character varying, agr_rid integer, tagid integer, src_host character varying, src_port character varying) returns void
    language plpgsql
as
$$
/* 
	add ito06 2016-02-25 поменяла местами пункты 2 и 3 (сначала добавление, потом исправление)
	180213 DISABLED by ito07 REPLACED by agree_x_2_1 
 */
DECLARE
   Agr RECORD; -- for agreement 
   Pnt RECORD; -- for agreepoint
   Rec RECORD;
BEGIN
      BEGIN
      -- scan agreements in this database
      INSERT INTO agreepoint  
      (linkid,    devid,account,prodnumber,devtype,rowid,deleted,lid)
      (SELECT DISTINCT 
         agr_rid AS ooo, devid,account,prodnumber,devtype,rowid,deleted,lid
         FROM agree_get_agreepoint(dbn,agr_num,tagid,src_host, src_port) x
         WHERE 
            x.rowid NOT IN (SELECT DISTINCT rowid FROM agreepoint WHERE linkid = agr_rid)
            AND  (prodnumber,account,devtype,devid,lid) != (x.prodnumber,x.account,x.devtype,x.devid,x.lid)
      );
      EXCEPTION
         WHEN others THEN RAISE NOTICE 'UUU 1';
         --
      END;

       -- ADD NEW POINTS
      RAISE NOTICE '*** 2 ***';
      BEGIN
      INSERT INTO agreepoint
         (linkid, devid,account,prodnumber,devtype,rowid,deleted,lid)
      (SELECT DISTINCT
         agr_rid AS ooo, devid,account,prodnumber,devtype,rowid,deleted,lid
         FROM agree_get_agreepoint(dbn,agr_num,tagid,src_host, src_port) x
         WHERE
            x.rowid NOT IN (SELECT rowid FROM agreepoint)
      );
      EXCEPTION
         WHEN others THEN RAISE NOTICE 'UUU 3';
         --    
      END;
      
      FOR Rec IN (
         SELECT DISTINCT 
            agr_rid AS ooo, devid,account,prodnumber,devtype,rowid,deleted,lid
         FROM agree_get_agreepoint(dbn,agr_num,tagid,src_host, src_port) x
         WHERE 
            x.rowid NOT IN (SELECT DISTINCT rowid FROM agreepoint WHERE linkid = agr_rid)
      )
      LOOP  
         UPDATE agreepoint
         SET
            linkid  = agr_rid,
            rowid   = Rec.rowid,
            deleted = Rec.deleted
         WHERE -- uniq constraint
             TRUE
                 --linkid     = agr_rid 
             AND prodnumber = Rec.prodnumber
             AND account    = Rec.account
             AND devtype    = Rec.devtype
             AND devid      = Rec.devid
             AND lid        = Rec.lid;
      END LOOP;     
END;
$$;

comment on function agree_x_2(varchar, varchar, integer, integer, varchar, varchar) is 'Добавление/изменение точек учета из указанного филиала в базу централизованных/смешнных для указанного договора. Используется в agree_w(int, varchar, varchar), agree_x(varchar, int, varchar)';

alter function agree_x_2(varchar, varchar, integer, integer, varchar, varchar) owner to pgsql;

