create function bee_get_agreepoint_with_subabo(xloc integer) returns character varying
    language plpgsql
as
$$
/* 
	ПОЛУЧИТЬ СПИСОК УСТРОЙСТВ ИМЕЮЩИХ ПОДКЛЮЧЕНИЯ СУБАБОНЕНТОВ
	счётчик головного абонента dic_elements.rowid = 664
	RETURN {agreepoint.rowid}
	    ito07 2011-01-14, 
	add ito06 2012-06-28
	add ito06 2014-06-24
*/
DECLARE
	Rec    RECORD;
	Points VARCHAR := '';
	tmpVal INTEGER;
BEGIN
	FOR Rec IN (   
		SELECT ard.paramval FROM agreepoint
             LEFT JOIN agreement ON agreepoint.linkid = agreement.rowid
                  JOIN  bee_rep_get_ard_per_max(664) AS ard ON ard.linkid = agreepoint.rowid 
                   AND paramval IS NOT NULL AND paramval NOT IN ('?','-','0') AND paramval ~ E'^\\d{1,}'   
                   AND length(ard.paramval) > 7
                 WHERE
		       agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = xloc))      
		   AND agreepoint.prodnumber       IS NOT NULL      
		    )
	LOOP
		Points = Points || Rec.paramval || '|';
	END LOOP;   
   
	IF (Points <> '') AND (Points <> '|')  
	   THEN
		tmpVal := char_length(Points);
		Points := substring(Points from 1 for tmpVal-1);
	   ELSE
		Points := '';
	END IF; 

	RETURN Points; 
END;
$$;

comment on function bee_get_agreepoint_with_subabo(integer) is 'Получить список устройств имеющих подключения субабонентов. Используется в AgreeByDevice.java, AppUtils.java';

alter function bee_get_agreepoint_with_subabo(integer) owner to pgsql;

