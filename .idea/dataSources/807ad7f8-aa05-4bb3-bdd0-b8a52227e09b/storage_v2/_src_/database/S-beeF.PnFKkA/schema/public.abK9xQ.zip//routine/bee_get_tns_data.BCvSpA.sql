create function bee_get_tns_data(_kod character varying, _df character varying, _dt character varying) returns SETOF character varying[]
    language plpgsql
as
$$
/*
	add ito06 2020-08-12 в колонку 14 для двуставочников должны попадать только показания за день
   180509 by ito07
   TNS DATA 
*/
DECLARE
_date_from date = _df::date;
_date_to date = _dt::date;

BEGIN
DROP TABLE IF EXISTS tmp_bee_get_tns_data;
CREATE TEMPORARY table tmp_bee_get_tns_data  AS 
  (
    (select
     '1-Лицевой счет потребителя'                    as c1,
     '2-Лицевой счёт до конвертациии данных в СТЕК'  as c2,
     '3-Фамилия имя отчество абонента'               as c3,
     '4-Населенный пункт'                            as c4,
     '5-Район города'                                AS c5,
     '6-Улица'                                       as c6,
     '7-Номер дома'                                  as c7,
     '8-Номер корпуса'                               as c8,
     '9-Номер квартиры'                              as c9,
     '10-Номер комнаты'                              as c10,
     '11-Тип счетчика'                               as c11,
     '12-Номер счетчика'                             as c12,
     '13-Количество зон счётчика'                    as c13,
     '14-Показания текущие (день /пик для 3-х зонных
      ПУ) (в случае одной зоны текущие показания 
      заносятся в эту колонку)'                      as c14,
     '15-Показания текущие (ночь)'                   as c15,
     '16-Показания текущие (полупик) 
      – для трехзонных ПУ'                           as c16,
     '17-Дата съема показаний'                       as c17,
     '18-Номер лицевого в сетевой организации'       as c18,
     '19-Место установки ПУ'                         as c19,
     '20-потреблено без субабонентов'                AS c20
    from customer limit 1
    )

    union

    (select
      (select
       case when position('56' in _kod) > 0
          then agreement.docnumber || agreepoint.account
          else agreement.docnumber
       end
      )::text                                     as c1,
      agreement.docnumber                         as c2,
      customer.abo_name                           as c3,
      upper(
        case 
           when   a720.paramval is not null and 
               a720.paramval <> '' and 
               a720.paramval <> '0'  
           then a720.paramval 

           when  (
               a720.paramval IS NULL OR 
               a720.paramval = '' OR 
               a720.paramval = '0'
              ) and 
              (a723.paramval is NOT null and
               a723.paramval <> '' and
               a723.paramval <> '0' 
              )  
           then a723.paramval 
        
           when 
            length(a720.paramval) > 2 and 
            length(a723.paramval) > 2 
           then a720.paramval || ' , ' || a723.paramval 
        
           when a720.paramval = '0' 
           then ''
        
           else  '-' 
        end 
      )                                           as c4,

      upper(
        case 
          when a641.paramval  like '_'  then ''
          when a641.paramval  is null   then ''
          else a641.paramval
        end
      )                                           AS c5,

      upper(
        case when a642.paramval = '0'     then  ''
          when a642.paramval  is null  then ''
          else a642.paramval
        END     
      )                                           as c6,

      replace(upper(
        case 
           when a640.paramval = '0'     then  ''
           when a640.paramval  is null  then ''
           else a640.paramval
        END
      ),'?','')                                   as c7,

     upper(
        case 
          when a721.paramval = '0'     then ''
          when a721.paramval  is null  then ''
          when a721.paramval = '?'     then ''
          else a721.paramval
        END     
     )                                           as c8,
     ''                                          as c9,
     ''                                          as c10,
     (
      select element_name from dic_elements 
      where rowid = agreepoint.devid
     )                                           as c11,
     agreepoint.prodnumber                       as c12,
     (select
        case 
          when count(agreeregdev.paramval) = 0 then 1
          else count(agreeregdev.paramval)
        end
      from agreeregdev
      where
         agreeregdev.linkid = agreepoint.rowid and
         agreeregdev.paramid in (1971,1972,1973,1974,1975,1976)
     )::text                                    as c13,

     /*2020-08-12 case 
        when  position ('.' in rdo195.valman) > 0 
        then rdo195.valman
        else rdo195.valman || '.0'
     end                                         as c14,*/
	 (select
        case 
          when count(agreeregdev.paramval) = 0   then 
			  case 
				when  position ('.' in rdo195.valman) > 0 
				then rdo195.valman
				else rdo195.valman || '.0'
			 end
	      else rdo1972.valman 
        end
      from agreeregdev
      where
         agreeregdev.linkid = agreepoint.rowid and
         agreeregdev.paramid in (1972,1973,1974,1975,1976)
     )                                          as c14,
	 
     rdonit.valman                               as c15,
     rdo1975.valman                              as c16,
     rdo195.operdate::text                       as c17,
     agreepoint.account                          as c18,

     upper(
       case 
         when a643.paramval = '0'     then ''
         when a643.paramval  is null  then ''
         when a643.paramval = '?'     then ''
         else a643.paramval
       END
     )                                           as c19,

    --rdo850.valman                              AS c20 
    ( select
       sum(valman::NUMERIC) 
       from regdevoper 
       where 
         linkid = rdo195.linkid  and 
         paramid = 850 and
         operdate between _date_from and _date_to   and
         valman  is not null and
         valman <> '-' and
         valman <> ''  
     )::text as                                  c20    

     from customer

     join agreement  on
     customer.abo_code = agreement.abo_code

     join agreepoint on
     agreement.rowid = agreepoint.linkid and
     agreement.closedate  is null and
     agreepoint.prodnumber is not null and
     agreepoint.prodnumber <> ''

     join agreeregdev a417 on
     agreepoint.rowid = a417.linkid and
     a417.paramid = 417

     left join agreeregdev a720 on
     agreepoint.rowid = a720.linkid and
     a720.paramid = 720

     left join agreeregdev a723 on
     agreepoint.rowid = a723.linkid and
     a723.paramid = 723

     left join agreeregdev a641 on
     agreepoint.rowid = a641.linkid and
     a641.paramid = 641

     left join agreeregdev a642 on
     agreepoint.rowid = a642.linkid and
     a642.paramid = 642

     left join agreeregdev a640 on
     agreepoint.rowid = a640.linkid and
     a640.paramid = 640

     left join agreeregdev a721 on
     agreepoint.rowid = a721.linkid and
     a721.paramid = 721

     join regdevoper rdo195 on
     agreepoint.rowid  = rdo195.linkid and
     rdo195.paramid = 195
	 
	 left join regdevoper rdo1972 on
     agreepoint.rowid = rdo1972.linkid   and
     rdo1972.paramid in (1972) --2020-08-12

     left join regdevoper rdonit on
     agreepoint.rowid = rdonit.linkid   and
     rdonit.paramid in (1973,1976)

     left join regdevoper rdo1975 on
     agreepoint.rowid = rdo1975.linkid   and
     rdo1975.paramid = 1975

     left join regdevoper rdo850 on
     agreepoint.rowid = rdo850.linkid   and
     rdo850.paramid = 850 

     left join agreeregdev a643 on
     agreepoint.rowid = a643.linkid and
     a643.paramid = 643

     where
        agreement.docnumber like '61%' and
        (agreepoint.lid in (select rowid from denet where kod like _kod || '%' )) and
        (rdo195.valman   is not null) and
        (rdo195.operdate = (select operdate from regdevoper where linkid = rdo195.linkid  and rdo195.operdate between  _date_from and _date_to  order by operdate desc limit 1)) and      
        (rdo850.operdate = (select operdate from regdevoper where linkid = rdo850.linkid  and rdo850.operdate between  _date_from and _date_to  order by operdate desc limit 1)) 
     )

order by 1,2,3,4,6

);
 END;
$$;

alter function bee_get_tns_data(varchar, varchar, varchar) owner to postgres;

