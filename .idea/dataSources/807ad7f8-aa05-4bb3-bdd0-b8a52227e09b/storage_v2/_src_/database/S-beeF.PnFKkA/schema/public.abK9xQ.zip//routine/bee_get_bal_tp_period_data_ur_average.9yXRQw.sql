create function bee_get_bal_tp_period_data_ur_average(date_from text, date_to text, locid integer, uselocid text, short_name text, tp_not_exist text) returns SETOF bal_tp_period_data_ur_average
    language plpgsql
as
$$
/*
	add ito06 2015-06-30
	add ito06 2015-05-12 Учитывать, только последние трассы
	ito06 2011-12-20 Свод по ТП
	add ito06 2012-08-06
	
	-- uselocid (true -сформировать c делением на участки)
	-- short_name (true - сформировать с сокращенным названием ТП)
	-- tp_not_exist (true - сформировать по отключенным трассам)
*/
DECLARE
	RowLine bal_tp_period_data_ur_average%rowtype;
	_locid VARCHAR;
	param character varying;
BEGIN
---
	IF  tp_not_exist = 'false'
		THEN  param = ' NOT '; ELSE param =' ';
	END IF;   
	EXECUTE 'create TEMPORARY table  temp_gis_traces_for_bal_tp_period  AS
		(select gt.locid, gt.period, gt.pchain, gt.objowner, gt.objname, gt.objcode,  gt.objtype, gt.rowid, gt.kod  
		   from gis_traces as gt
		left join gis_traces_tmp as gtt USING (kod, locid,pchain, objowner, objname, objcode, objtype) where gtt.period is '|| param ||' NULL);';

	EXECUTE 'create TEMPORARY table temp_gis_traces_bal  AS
		(select gt.locid, gt.period, gt.pchain, gt.objowner,  gt.objname, gt.objcode, gt.objtype, gt.kod from gis_traces AS gt 
                   join (select  max(period) AS period, locid, objcode, objtype from gis_traces  group by locid, objcode, objtype) AS gt1
                  using (period, locid, objcode, objtype));';        
---
	IF useLocid = 'true' THEN _locid = locid::text;
	  ELSE _locid = '%';
	END IF;  

  FOR RowLine IN (SELECT 
			 tab2.tpname							AS tp, --колонка 2
			 tab1.obj_code,							-- obj_code,		
			 1 								AS objowner_code, 
			 SUM(tab1.average_value)::numeric(15,3)				-- SUM(average_value)
	            FROM 
			(SELECT 
				CASE 
				   WHEN  gt.objtype=11 
				      THEN family.son_code
				   WHEN  gt.objtype=10 OR  gt.objtype=9 OR  gt.objtype=8 
				      THEN family.father_code
	                        END AS obj_code,			 
				CASE 
				   WHEN maxdate - mindate <> 0
				      THEN (a2.valman / (maxdate::date - mindate::date)) * ((date_to::date - date_from::date)+1)
				END 											AS average_value
			   FROM regdevconn AS rdc
			   JOIN agreepoint AS apn ON rdc.pointid=apn.rowid
			   JOIN agreement AS amn ON apn.linkid=amn.rowid
			   JOIN temp_gis_traces_for_bal_tp_period AS gt on rdc.traceid =  gt.rowid
			   JOIN ( SELECT 
					 apn.rowid 	AS r1, 
					 t1.objcode 		AS son_code, 
					 t2.objcode 		AS father_code
				    FROM agreepoint AS apn 
				    JOIN regdevconn AS rdc ON apn.rowid=rdc.pointid 
				    JOIN temp_gis_traces_for_bal_tp_period AS t1 ON rdc.traceid=t1.rowid 
			       LEFT JOIN temp_gis_traces_for_bal_tp_period AS t2 ON t2.objcode=t1.objowner 
				    GROUP BY apn.rowid, t1.objname, t1.objcode, t1.objowner, t2.objname, t2.objcode
				) AS family ON rdc.pointid=family.r1 
		      LEFT JOIN ( SELECT SUM(valman::float) AS valman, 
					 linkid 
				    FROM regdevoper 
				   WHERE paramid=850
				     AND valman <> '-'  AND valman <> '' 
				     AND operdate BETWEEN (SELECT (date_trunc('month', date_from::date) - INTERVAL '1 year')::date) AND 
							  (SELECT(date_from::date - INTERVAL '1 day')::date)
				   GROUP BY linkid
				) AS a2 ON rdc.pointid=a2.linkid
		      LEFT JOIN ( SELECT MAX(valman::date) AS maxdate,  
					 linkid 
				    FROM regdevoper 
                                   WHERE paramid=194 
				     AND valman <> '-' 
				     AND valman <> '' 
				     AND valman <> '0'
				     AND valman IS NOT NULL
				     AND operdate BETWEEN (SELECT (date_trunc('month', date_from::date) - INTERVAL '1 year')::date) AND 
							  (SELECT(date_from::date - INTERVAL '1 day'))
				   GROUP BY linkid) AS a3 ON a2.linkid=a3.linkid    
		      LEFT JOIN (SELECT MIN(valman::date) AS mindate, 
				        linkid 
				   FROM regdevoper
				  WHERE paramid=197 
				    AND valman <> '-' 
				    AND valman <> '' 
				    AND valman <> '0'
				    AND valman IS NOT NULL
				    AND operdate BETWEEN (SELECT (date_trunc('month', date_from::date) - INTERVAL '1 year')::date) AND 
							 (SELECT(date_from::date - INTERVAL '1 day')::date)
				  GROUP BY linkid
				) AS a4 on a2.linkid=a4.linkid   
		      LEFT JOIN ( SELECT linkid, 
					 paramval 
				   FROM agreeregdev WHERE paramid = 690
				) AS a5 on apn.rowid=a5.linkid
			  WHERE amn.locid::text like _locid
			    AND (a5.paramval IS NULL OR length(trim(a5.paramval)) < 4)
			    and (amn.docstatus=79 or amn.docstatus=77 and amn.closedate >= date_from::date) -- 2015-06-30
			    AND apn.rowid NOT IN (SELECT linkid 
							   FROM regdevoper 
							  WHERE paramid=850 
							    AND operdate BETWEEN date_from::date AND date_to::date
							)
			 
		) AS tab1
		JOIN ( SELECT 
		             CASE 
		                WHEN short_name = 'false'		            
                                   THEN(
   		         	        CASE 
					   WHEN a6.objname IS NOT NULL 
                                              THEN a6.objname
                                           ELSE ''
                                        END  || CASE 
                                              WHEN a5.objname IS NOT NULL 
                                                 THEN ' ' || a5.objname
                                              ELSE ''
                                        END || CASE 
                                              WHEN a4.objname IS NOT NULL 
                                                 THEN ' ' || a4.objname
                                              ELSE ''
                                        END || CASE 
                                              WHEN a3.objname IS NOT NULL 
                                                 THEN ' ' || a3.objname
                                              ELSE ''
                                        END || CASE 
                                             WHEN a2.objname IS NOT NULL 
                                                THEN ' ' || a2.objname
                                             ELSE ''
                                       END || CASE 
                                             WHEN a1.objname IS NOT NULL 
                                                THEN ' ' || a1.objname
                                             ELSE ''
                                       END || CASE 
                                             WHEN tmp_gt.objname IS NOT NULL 
                                                THEN ' ' || tmp_gt.objname
                                             ELSE ''
                                       END 
                                      ) ELSE tmp_gt.objname
                                 END 					        AS tpname,
                                 tmp_gt.objcode                                 AS objcode
                            FROM temp_gis_traces_for_bal_tp_period AS tmp_gt 
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a1 ON tmp_gt.objowner=a1.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a2 ON a1.objowner=a2.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a3 ON a2.objowner=a3.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a4 ON a3.objowner=a4.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a5 ON a4.objowner=a5.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a6 ON a5.objowner=a6.objcode
                           WHERE tmp_gt.objtype=11
                           ORDER BY tpname
		     ) AS tab2 ON tab2.objcode = tab1.obj_code
                GROUP BY tab2.tpname, tab1.obj_code
                ORDER BY tab2.tpname
               )
	LOOP
		RETURN NEXT RowLine; 
	END LOOP;
---
	DROP TABLE IF EXISTS temp_gis_traces_for_bal_tp_period;
	DROP TABLE IF EXISTS temp_gis_traces_bal;	
	RETURN;
--
END;
$$;

comment on function bee_get_bal_tp_period_data_ur_average(text, text, integer, text, text, text) is 'Свод по ТП перерасчет по юр. Используется в RepBal6.java';

alter function bee_get_bal_tp_period_data_ur_average(text, text, integer, text, text, text) owner to pgsql;

