create function bee_rep_get_repdata23_tmp1(loc integer, str_d date, end_d date) returns SETOF bee_reptab23
    language plpgsql
as
$$
/*
ito06 2011-06-17
ito06 2012-02-10
Сводный акт учета эл.эн. по договорам купли продажи
*/
DECLARE
	s_date date;
	e_date date;
	RowLine bee_reptab23%rowtype;
BEGIN
 s_date  = (SELECT (date_trunc('month', str_d))::DATE);
 e_date = (SELECT (date_trunc('month', end_d) +  INTERVAL '1 month' - INTERVAL '1 day' )::DATE);
 
FOR RowLine IN ( 
SELECT 	
DISTINCT
  'norm' :: text AS style,	
  res.kod AS kod,

  amn.docnumber AS doc_nam,
  res.nam AS fil_name,
  amn.docnumber  || ', ' || cst.consum_name AS cst_name,
  ard418.paramval ||', '|| ard410.paramval AS cst_adr,
  apn.prodnumber AS prodnumber,
  rdo196.v AS v196,
  rdo195.v AS v195,
  rdo198.v AS v198,
  ard321.paramval AS koef_i,
  ard286.paramval AS koef_u,
  ard_p356.paramval AS koef,
  rdo850.v - rdo919.v AS dev,
  rdo919.v as v919,   
  func.vn AS vn,
  func.sn1 AS sn1,
  func.sn2 AS sn2,
  func.nn AS nn
		
FROM
  agreement AS amn
  JOIN customer AS cst ON amn.abo_code = cst.abo_code
  JOIN agreepoint AS apn ON amn.rowid = apn.linkid
  LEFT JOIN agreeregdev AS ard690 ON ard690.paramid = 690 AND ard690.paramval LIKE '____-__-__' AND apn.rowid = ard690.linkid
  LEFT JOIN agreeregdev AS ard690_1 ON ard690_1.paramid = 690 AND ard690_1.paramval NOT LIKE '____-__-__' AND CHAR_LENGTH(ard690_1.paramval) > 2 AND apn.rowid = ard690_1.linkid
  JOIN denet AS res ON res.rowid=cst.locid
  JOIN denet AS mes ON mes.kod = substring(res.kod from 1 for 6)

  LEFT JOIN agreeregdev AS ard418 ON ard418.linkid = apn.rowid AND ard418.paramid = 418
  LEFT JOIN agreeregdev AS ard410 ON ard410.linkid = apn.rowid AND ard410.paramid = 410
  LEFT JOIN agreeregdev AS ard321 ON ard321.linkid = apn.rowid AND ard321.paramid = 321
  LEFT JOIN agreeregdev AS ard286 ON ard286.linkid = apn.rowid AND ard286.paramid = 286
  JOIN bee_docs_sheet AS bds ON bds.linkid1 = amn.rowid AND bds.operdate BETWEEN s_date AND e_date AND npp=1
  LEFT JOIN(
    SELECT
      linkid,
      max(period) AS period 
    FROM 
      agreeregdev_period
      WHERE paramid = 356
    GROUP BY
      linkid) AS ard_p_d ON ard_p_d.linkid = apn.rowid
  LEFT JOIN agreeregdev_period AS ard_p356 ON ard_p_d.period = ard_p356.period AND ard_p356.linkid = apn.rowid and ard_p356.paramid = 356
  LEFT JOIN (
    SELECT
      sum(valman::numeric) AS v,
      linkid 
    FROM 
      regdevoper 
	 WHERE 
      paramid = 196 AND
      operdate BETWEEN $2 AND $3 + '1 month'::interval - '1 day'::interval AND
      valman ~ E'^[\\d{1,}\\-]' AND
      valman<>'-'
    GROUP BY
      linkid) AS rdo196 ON rdo196.linkid = apn.rowid
  LEFT JOIN (
    SELECT
      sum(valman::numeric) AS v,
      linkid 
    FROM 
      regdevoper 
	 WHERE 
      paramid = 195 AND
      operdate BETWEEN $2 AND $3 + '1 month'::interval - '1 day'::interval AND
      valman ~ E'^[\\d{1,}\\-]' AND
      valman<>'-'
    GROUP BY
      linkid) AS rdo195 ON rdo195.linkid = apn.rowid
  LEFT JOIN (
    SELECT
      sum(valman::numeric) AS v,
      linkid 
    FROM 
      regdevoper 
	 WHERE 
      paramid = 198 AND
      operdate BETWEEN $2 AND $3 + '1 month'::interval - '1 day'::interval AND
      valman ~ E'^[\\d{1,}\\-]' AND
      valman<>'-'
    GROUP BY
      linkid) AS rdo198 ON rdo198.linkid = apn.rowid
  LEFT JOIN (
    SELECT
      sum(valman::numeric) AS v,
      linkid 
    FROM 
      regdevoper 
	 WHERE 
      paramid = 850 AND
      operdate BETWEEN $2 AND $3 + '1 month'::interval - '1 day'::interval AND
      valman ~ E'^[\\d{1,}\\-]' AND
      valman<>'-'
    GROUP BY
      linkid) AS rdo850 ON rdo850.linkid = apn.rowid
  LEFT JOIN (
    SELECT
      sum(valman::numeric) AS v,
      linkid 
    FROM 
      regdevoper 
	 WHERE 
      paramid = 919 AND
      operdate BETWEEN $2 AND $3 + '1 month'::interval - '1 day'::interval AND
      valman ~ E'^[\\d{1,}\\-]' AND
      valman<>'-'
    GROUP BY
      linkid) AS rdo919 ON rdo919.linkid = apn.rowid
  LEFT JOIN bee_rep_get_repdata3($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date) AS func ON apn.rowid = func.apn_rowid
WHERE
--ito06 2012-02-10 amn.transmit=true AND
  cst.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1)) AND
  (ard690.paramval::date >= $2 OR ard690.paramval IS NULL) AND
  ard690_1.paramval IS NULL AND
  func.total >= 0
ORDER BY
   res.kod, amn.docnumber,cst_name, prodnumber
)
LOOP RETURN NEXT RowLine; 
END LOOP;
   RETURN;
end
$$;

comment on function bee_rep_get_repdata23_tmp1(integer, date, date) is 'Сводный акт учета эл.эн. по договорам купли продажи. Используется в bee_rep_get_repdata23(int, date, date), bee_rep_get_repdata23_tmp2(int, date, date)';

alter function bee_rep_get_repdata23_tmp1(integer, date, date) owner to pgsql;

