create view vbee_gis_pathes(locid, rowid, path, objname) as
SELECT gis_traces.locid,
       gis_traces.rowid,
       "substring"(gis_traces.pchain,
                   strpos(gis_traces.pchain, (string_to_array(gis_traces.pchain, '+'::text))[4])) AS path,
       gis_traces.objname
FROM gis_traces
WHERE (gis_traces.objtype = 11)
ORDER BY gis_traces.pchain;

comment on view vbee_gis_pathes is 'Гис. Используется в скриптах';

alter table vbee_gis_pathes
    owner to pgsql;

