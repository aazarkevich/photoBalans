create function bee_rep_annex1_get_en(amn_rowid integer, year1 character varying) returns SETOF bee_rep_annex1_en_tab
    language sql
as
$$
/*
	ito16 Приложение1 (прямые) из формы "договоры" строки по эл.эн
*/
SELECT 
	amn.docnumber AS docnum,
	to_char(amn.docdate,'DD.MM.YYYY') AS docdat,
	urs.element_name || ' ' || cst.consum_name AS nam,
	    CASE 
	       WHEN ard_ul.paramval = '311'
	       THEN 0
	       WHEN ard_ul.paramval = '308'
	       THEN 1
	       WHEN ard_ul.paramval = '310'
	       THEN 2
	       WHEN ard_ul.paramval = '306'
	       THEN 3
	    END AS ul,
	    sum(bpc.m01)+sum(bpc.m02)+sum(bpc.m03)+sum(bpc.m04)+sum(bpc.m05)+sum(bpc.m06)+sum(bpc.m07)+sum(bpc.m08)+sum(bpc.m09)+sum(bpc.m10)+sum(bpc.m11)+sum(bpc.m12) AS tot,
	    sum(bpc.m01) AS m01,
	    sum(bpc.m02) AS m02,
	    sum(bpc.m03) AS m03,
	    sum(bpc.m04) AS m04,
	    sum(bpc.m05) AS m05,
	    sum(bpc.m06) AS m06,
	    sum(bpc.m07) AS m07,
	    sum(bpc.m08) AS m08,
	    sum(bpc.m09) AS m09,	
	    sum(bpc.m10) AS m10,
	    sum(bpc.m11) AS m11,
	    sum(bpc.m12) AS m12
       FROM agreement AS amn 
       JOIN customer AS cst ON amn.abo_code = cst.abo_code
       JOIN agreepoint AS apn ON apn.linkid = amn.rowid
       JOIN bee_points_consum AS bpc ON bpc.linkid = apn.rowid AND bpc.tarif_val=1043
       JOIN agreeregdev AS ard_nam ON ard_nam.linkid = apn.rowid AND ard_nam.paramid = 418
       JOIN (SELECT linkid AS linkid, max(period) 
               FROM agreeregdev_period 
              WHERE period <= ($2 || '-12-31')::date AND paramid = 439
              GROUP BY linkid) AS ard_ul_dat ON ard_ul_dat.linkid = apn.rowid
       JOIN agreeregdev_period AS ard_ul ON ard_ul.linkid = ard_ul_dat.linkid AND ard_ul.paramid = 439
  LEFT JOIN (SELECT linkid AS linkid, max(period)
               FROM agreeregdev_period 
              WHERE period <= ($2 || '-12-31')::date AND paramid = 426
              GROUP BY linkid) AS ard_maxpow_dat ON ard_maxpow_dat.linkid = apn.rowid
  LEFT JOIN agreeregdev_period AS ard_maxpow ON ard_maxpow.linkid = apn.rowid AND ard_maxpow.paramid = 426 AND ard_maxpow.linkid = ard_maxpow_dat.linkid
  LEFT JOIN(SELECT linkid AS linkid, max(period)
              FROM agreeregdev_period 
             WHERE period <= ($2 || '-12-31')::date AND paramid = 685
             GROUP BY linkid) AS ard_addpow_dat ON ard_addpow_dat.linkid = apn.rowid
  LEFT JOIN agreeregdev_period AS ard_addpow ON ard_addpow.linkid = apn.rowid AND ard_addpow.paramid = 685 AND ard_addpow.linkid = ard_addpow_dat.linkid
  LEFT JOIN agreeregdev AS ard_okved ON ard_okved.linkid = apn.rowid AND ard_okved.paramid = 1030
  LEFT JOIN dic_elements AS urs ON urs.rowid = cst.urstatus
      WHERE amn.rowid=$1 AND to_char(bpc.period,'YYYY')=$2
      GROUP BY docnum,docdat,nam,ul
      ORDER BY ul;
$$;

comment on function bee_rep_annex1_get_en(integer, varchar) is 'Приложение1 (прямые) из формы "договоры" строки по эл.эн. Используется в RepAnnex1.java';

alter function bee_rep_annex1_get_en(integer, varchar) owner to postgres;

