create function bee_get_item_list(catcod integer) returns text
    language plpgsql
as
$$
    --
--
-- СПИСОК ЭЛЕМЕНТОВ ПО КАТЕГОРИИ
-- 
DECLARE
  Rec      RECORD;
  ItemList TEXT := '';
--
BEGIN
  FOR Rec IN (   
      SELECT   rowid::text || '^' || element_name AS par 
      FROM     dic_elements  
      WHERE    link = catcod 
      ORDER BY element_code 
  ) 
  LOOP 
     --
     IF Rec.par IS NOT NULL THEN
	 ItemList = ItemList || Rec.par || '|';
     END IF;
     -- 
  END LOOP;
  --
RETURN ItemList;
  --
END;
$$;

comment on function bee_get_item_list(integer) is 'Список элементов по категории. Используется в Agreement.java, AgreeRegDev.java, AppUtils.java';

alter function bee_get_item_list(integer) owner to pgsql;

