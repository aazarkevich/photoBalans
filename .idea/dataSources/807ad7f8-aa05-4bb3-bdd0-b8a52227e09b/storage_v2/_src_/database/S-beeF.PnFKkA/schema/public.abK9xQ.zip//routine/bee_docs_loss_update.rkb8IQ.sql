create function bee_docs_loss_update(agreeid integer, docid integer, docnumber integer, docperiod date, docdate date, k_ens integer, k_rsk integer, k_all integer, t_ens character varying, t_rsk character varying, t_all character varying, s_ens character varying, s_rsk character varying, s_all character varying, usr character varying, _locid integer) returns integer
    language plpgsql
as
$$
/*
	add ito06 2016-04-20 добавили колонку locid
	Изменение записи в таблице bee_docs_loss (потери РСК)
*/
DECLARE
   NR int = - 1;
BEGIN
   BEGIN
         UPDATE bee_docs 
            SET docnum = docnumber,    
                docdat = docperiod
          WHERE rowid  = docid RETURNING rowid INTO NR;

         IF NR IS NOT NULL 
            THEN 
                 UPDATE bee_docs_loss 
                    SET docnum     = docnumber,
                        period     = docperiod,      
                        docdat     = docdate,
                        loss_kvt   = k_ens, 
                        loss_tarif = t_ens::numeric(13,11),          
                        loss_sum   = s_ens::numeric(12,2),
                        userid     = usr, 
                        locid 	   = _locid -- 2016-04-20                           
                  WHERE loss_typ   = 1731
                    AND linkid1      = agreeid
                    AND linkid2      =  docid; 

                 UPDATE bee_docs_loss
                    SET docnum     = docnumber,
                        period     = docperiod,      
                        docdat     = docdate,
                        loss_kvt   = k_rsk, 
                        loss_tarif = t_rsk::numeric(13,11),          
                        loss_sum   = s_rsk::numeric(12,2),
                        userid       = usr, 
                        locid 	   = _locid -- 2016-04-20                             
                  WHERE loss_typ = 1732
                    AND linkid1      = agreeid
                    AND linkid2      =  docid;
 
                 UPDATE bee_docs_loss
                    SET docnum      = docnumber,
                        period     = docperiod,      
                        docdat     = docdate,
                        loss_kvt   = k_all, 
                        loss_tarif = t_all::numeric(13,11),          
                        loss_sum   = s_all::numeric(12,2),
                        userid       = usr, 
                        locid 	   = _locid -- 2016-04-20                             
                  WHERE loss_typ = 1733
                    AND linkid1      = agreeid
                    AND linkid2      =  docid;                        
            ELSE NR = -2;
        END IF;   
   EXCEPTION
            WHEN UNIQUE_VIOLATION THEN
            RETURN -1;
   END;
RETURN NR;
END;
$$;

comment on function bee_docs_loss_update(integer, integer, integer, date, date, integer, integer, integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer) is 'Изменение нагрузочных потерь. Используется в LossRSK.java, AppUtils.java';

alter function bee_docs_loss_update(integer, integer, integer, date, date, integer, integer, integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer) owner to pgsql;

