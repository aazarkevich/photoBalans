create function bee_get_close_user(tabl character varying) returns character varying
    language plpgsql
as
$$
/*
	ito06 2013-11-21
        add itio06 2014-04-10
*/
DECLARE
	usr varchar;
	RES varchar; 
BEGIN 
	IF tabl  = 'bee_closed_period_mix' THEN usr = 'mix____';
		ELSE usr = 'uni____';
	END IF;
	
	EXECUTE 'SELECT usr FROM '||$1||' where usr LIKE '||quote_literal(usr)||' LIMIT 1;' INTO RES;
	IF RES IS NULL THEN RES =''; END IF;
	RETURN RES;
END;

$$;

comment on function bee_get_close_user(varchar) is 'Получить пользователя закрывшего период. Используется в Menu.java, AgreeJoinUni.java, AgreeJoinMix.java, AppUtils.java';

alter function bee_get_close_user(varchar) owner to pgsql;

