create function bee_aktpartbord_select_akts_type(_locid integer, _df text, _dt text)
    returns TABLE(akts_total integer)
    language plpgsql
as
$$
/*
	ito06 2015-07-28: Акт раздела границ, итоговое кол-во
*/
DECLARE
	_datef date = _df::date;
	_datet date = _dt::date;
BEGIN
	return query
	select
		(select count(paramval) from agreepoint left join agreeregdev_period on agreeregdev_period.linkid = agreepoint.rowid where period between _datef and _datet and paramid=1865 and agreepoint.lid in (select rowid from denet where kod like ((select kod from denet where rowid = _locid) || '%')))::integer;

END;
$$;

comment on function bee_aktpartbord_select_akts_type(integer, text, text) is 'Используется в AktPartitionBorders.java, SessionBean1.java';

alter function bee_aktpartbord_select_akts_type(integer, text, text) owner to pgsql;

