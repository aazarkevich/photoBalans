create function bee_rep_get_repdata6_get_legal(digits character varying, code integer, date_start date, date_end date, filter1 integer, filter2 integer) returns SETOF bee_repdata6
    language plpgsql
as
$$
/*
ito06 2011-12-02
Баланс по ТП, юр лица
*/
DECLARE 
	RowLine bee_repdata6%RowType;
	filter_add text;
   BEGIN
	filter_add = bee_rep_get_repdata6_get_legal_filters($5,$6);
RETURN QUERY 
EXECUTE 'SELECT adr.paramval || '||quote_literal(',')|| ' || cst.consum_name || '||quote_literal(',')||
		' || amn.docnumber || '||quote_literal(',')|| ' || apn.account || '||quote_literal(',')|| ' || apn.prodnumber AS name, 
		null::numeric AS control, 
		sum(legal_all.v) AS legal_all, 
		sum(legal11.v) + sum(legal12.v) AS legal1, 
		sum(legal2.v) AS legal2, 
		null::numeric AS natural, 
		null::numeric AS all, 
		null::numeric AS not_balance, 
		null::numeric AS not_balance_perc 
           FROM gis_traces AS gis 
           JOIN regdevconn  AS rdc ON rdc.traceid=gis.rowid 
	   JOIN agreepoint  AS apn ON apn.rowid=rdc.pointid 
	   JOIN agreement   AS amn ON amn.rowid=apn.linkid 
	   JOIN customer    AS cst ON cst.abo_code=amn.abo_code 
	   JOIN agreeregdev AS ard ON ard.linkid=rdc.pointid AND ard.paramid=189 AND ard.paramval='||quote_literal(432)||' 
      LEFT JOIN agreeregdev AS adr ON adr.linkid=rdc.pointid AND adr.paramid=417 
      LEFT JOIN agreeregdev AS ard1 ON ard1.linkid=rdc.pointid AND ard1.paramid=715 
      LEFT JOIN (select linkid, sum(valman::numeric('||$1||')) as v from regdevoper 
                  where operdate BETWEEN '||quote_literal($3)||' AND ('||quote_literal($4)||')::date - '||quote_literal('1 day')||'::interval AND paramid = 850 AND is_pokazania(valman) group by linkid
                ) AS legal_all ON legal_all.linkid = apn.rowid  
      LEFT JOIN (select linkid, sum(valman::numeric('||$1||')) as v from regdevoper 
                  where operdate BETWEEN '||quote_literal($3)||' AND ('||quote_literal($4)||')::date - '||quote_literal('1 day')||'::interval AND paramid = 917 AND is_pokazania(valman) group by linkid
                ) AS legal11 ON legal11.linkid = apn.rowid  
      LEFT JOIN (select linkid, sum(valman::numeric('||$1||')) as v from regdevoper 
                  where operdate BETWEEN '||quote_literal($3)||' AND ('||quote_literal($4)||')::date - '||quote_literal('1 day')||'::interval AND paramid = 918 AND is_pokazania(valman) group by linkid
                ) AS legal12 ON legal12.linkid = apn.rowid  
      LEFT JOIN (select linkid, sum(valman::numeric('||$1||')) as v from regdevoper 
                  where operdate BETWEEN '||quote_literal($3)||' AND ('||quote_literal($4)||')::date - '||quote_literal('1 day')||'::interval AND paramid = 919 AND is_pokazania(valman) group by linkid
                ) AS legal2 ON legal2.linkid = apn.rowid  
      LEFT JOIN agreeregdev AS ard690 ON ard690.linkid = apn.rowid AND ard690.paramid=690 
   WHERE  
     ( gis.objcode =   '||$2||' '|| filter_add ||')  AND  ((length(ard690.paramval) <> 10 OR ard690.paramval IS NULL)OR (ard690.paramval::date > '||quote_literal($3)||'))
   GROUP BY name,rdc.pointid 
   ORDER by name;';
END;
$$;

comment on function bee_rep_get_repdata6_get_legal(varchar, integer, date, date, integer, integer) is 'Баланс по ТП, юр лица. Используется в RepCreate6.java';

alter function bee_rep_get_repdata6_get_legal(varchar, integer, date, date, integer, integer) owner to postgres;

