create function bee_get_dic_elements(catid integer) returns refcursor
    language plpgsql
as
$$
    --
  -- catid dic_category.rowid
  --
 DECLARE
     rf REFCURSOR;
 BEGIN
    OPEN rf FOR 
    SELECT rowid,element_name FROM dic_elements 
    WHERE link = catid ORDER BY element_code;
    RETURN rf; 
   END;
 --
 --
$$;

comment on function bee_get_dic_elements(integer) is 'Используется в CustomerForm.java, AppUtils.java';

alter function bee_get_dic_elements(integer) owner to pgsql;

