create function audit_process() returns trigger
    language plpgsql
as
$$
    --
-- use of dblink and hstore extensions
--
/*
ПЕРЕНОС ЗАПИСЕЙ АУДИТА В СТОРОННЮЮ БАЗУ 
ito07 2012-08-27
add ito07 2012-08-29
add ito07 2012-09-03
add ito06 2012-09-25
add ito07 2012-10-08
add ito06 2013-03-12 пререименование connection
*/

DECLARE
   XLocID    INTEGER := 0;
   TagRecord RECORD;
   AudiTab   VARCHAR;
   Opr       VARCHAR;
   --
   res       text;
   listconn  text[];
   --

   ColumnInfo RECORD;
   --
   ColNames  VARCHAR;
   ColValues VARCHAR;

   hRec     hstore;
   Val      VARCHAR;
  
BEGIN


   -- fetch connection parameters for remote base
   EXECUTE 'SELECT * FROM bee_external WHERE tag =''audit'' LIMIT 1' 
      INTO TagRecord;



   -- create connection
   SELECT * FROM dblink_get_connections() 
      INTO listconn; 
   IF 'deconn_audit' = ANY (listconn) THEN 
      res = 'ok';
   ELSE 
      SELECT dblink_connect_u('deconn_audit', 
      ' dbname = '   || TagRecord.dbname ||
      ' port = '     || TagRecord.port ||
      ' host = '     || TagRecord.host ||
      ' user = '     || TagRecord.usr ||
      ' password = ' || TagRecord.pwd) into res;
   END IF;

   ------------------------------------
   AudiTab = TG_TABLE_NAME || '_audit';
   ------------------------------------
   IF TG_OP = 'UPDATE' THEN
      Opr = 'U';
      IF Old = New THEN 
         RETURN null;
      END IF;
   ELSEIF TG_OP = 'INSERT' THEN
      Opr = 'I'; 
   ELSEIF TG_OP = 'DELETE' THEN
      Opr = 'D';
   END IF;

   
   -- prepaire header for audit record
   ColNames  = ' (xlocid,dbase,operation,stamp,xuid,userip,';
   ColValues = ' (' || XLocID || ',' || quote_literal((select current_database())) || ',' ||
                       quote_literal(Opr)   || ',' || 
                       quote_literal(now()) || ',' || 
                       quote_literal(user)  || ',' ||
                       quote_literal((select get_usrvar('userip')))  || ',' ;

   

   -- convert OLD or NEW into hash
   IF Opr = 'U' THEN
      hRec = hstore(OLD.*);
   ELSIF Opr = 'I' THEN
      hRec = hstore(NEW.*);
   ELSEIF Opr = 'D' THEN
     hRec = hstore(OLD.*);
   END IF;
   

   -- check only rows if these tables   
   IF (TG_TABLE_NAME = 'regdevoper') OR
      (TG_TABLE_NAME = 'agreeregdev') OR   
      (TG_TABLE_NAME = 'agreeregdev_period') THEN

      
      IF NOT EXISTS ( SELECT t.* FROM dblink('deconn_audit',
       'SELECT paramid FROM audit_paramid WHERE ' || 
       'tabname = ''' || TG_TABLE_NAME || ''' AND '
       'paramid = '   || (hRec -> 'paramid')
         ) AS t (paramid integer)
      ) THEN
       IF Opr = 'U' THEN
	RETURN OLD;
       ELSIF Opr = 'I' THEN
	RETURN NEW;
           ELSEIF Opr = 'D' THEN
	RETURN OLD;
       END IF;
      END IF;   

   END IF;

   ---
   --- select table name and types
   ---
   FOR ColumnInfo IN 
     SELECT DISTINCT
        column_name AS nam, 
        data_type AS typ
     FROM information_schema.columns  
     WHERE table_name = TG_TABLE_NAME
   LOOP
       
       -- fetch field value by column name from NEW or OLD 
       Val = hRec -> ColumnInfo.nam;

        
       -- concat column names
       ColNames = ColNames ||  ColumnInfo.nam || ',' ;
       -- quote text values, concat string values
       IF (   ColumnInfo.typ ILIKE 'character%')
          OR (ColumnInfo.typ ILIKE 'time%') 
          OR (ColumnInfo.typ    = 'boolean') 
          OR (ColumnInfo.typ    = 'text') 
          OR (ColumnInfo.typ    = 'date') THEN  
          -- for quoted types

          IF (ColumnInfo.typ ILIKE 'time%' OR ColumnInfo.typ    = 'boolean' OR ColumnInfo.typ ILIKE 'character%' ) AND Val IS NULL
             THEN  ColValues = ColValues || 'NULL' || ',';              
               ELSE  ColValues = ColValues || quote_literal(Val) || ',';
          END IF;
       ELSE
          -- for other  
          IF Val IS NULL 
             THEN colValues = ColValues ||'NULL' || ',';
               ELSE colValues = ColValues || Val || ',';
          END IF;
       END IF;
   END LOOP;
  
   -- remove last character (comma)

--   ColNames  = left(ColNames,  length(ColNames) -1) || ')';
--   ColValues = left(ColValues, length(ColValues)-1) || ')';
     ColNames  = substring(ColNames  from 1 for length(ColNames) -1) || ')';
     ColValues = substring(ColValues from 1 for length(ColValues)-1) || ')';


   ----------------------------------
   -- insert audit record
   


   PERFORM  dblink('deconn_audit',
      'INSERT INTO ' || AudiTab || ColNames || ' VALUES ' || ColValues);
   ----------------------------------
   IF (TG_OP = 'DELETE') THEN
      RETURN OLD;
   ELSIF (TG_OP = 'UPDATE') THEN       
      RETURN NEW;
   ELSIF (TG_OP = 'INSERT') THEN
      RETURN NEW;
   END IF;
   ----
   SELECT dblink_disconnect('deconn_audit') 
      INTO res;
   ---
   RETURN NULL;
   ---
END;
$$;

alter function audit_process() owner to pgsql;

