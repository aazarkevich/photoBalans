create function bee_rep_get_repdata24_tmp2(tar_id integer, d_start date, d_end date, loc_id integer) returns numeric[]
    language plpgsql
as
$$
/*
	add ito06 2016-03-03 добавляем параметр тип договора amntyp
	add ito06 2015-06-30
	ito06 2012-02-10 Ведомость по объему услуг
*/
DECLARE
     tmp_kod character varying;
BEGIN
 
  SELECT into tmp_kod  kod from denet AS de1 where de1.rowid = loc_id limit 1;
  
  RETURN ( SELECT
       ARRAY[sum(bdr.amount), sum(bdr.sum_no_tax) ,sum(bdr.sum_no_tax)/sum(bdr.amount)] AS m_tar
  FROM
       denet AS de
       JOIN agreement AS amn on amn.locid = de.rowid AND amn.accdir IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) 
						     AND amn.locid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
                                                     --AND (amn.docstatus = 79 OR amn.docstatus  = 77 AND amn.closedate  >= d_start )--2015-06-30
                                                     AND amn.doctype = 1910 --2016-03-03
                                                     AND bee_is_agreement_get_to_report(amn.rowid, d_start) -- 2015-07-14
       LEFT JOIN bee_docs AS bd ON bd.linkid = amn.rowid AND bd.docdat BETWEEN $2 AND $3
       LEFT JOIN bee_docs_result AS bdr ON bdr.linkid = bd.rowid AND bdr.tar_typ = 1068 AND bdr.row_typ = 1070 AND bdr.tar_grp = $1);
END;
$$;

comment on function bee_rep_get_repdata24_tmp2(integer, date, date, integer) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24_cont(int, date, date)';

alter function bee_rep_get_repdata24_tmp2(integer, date, date, integer) owner to postgres;

