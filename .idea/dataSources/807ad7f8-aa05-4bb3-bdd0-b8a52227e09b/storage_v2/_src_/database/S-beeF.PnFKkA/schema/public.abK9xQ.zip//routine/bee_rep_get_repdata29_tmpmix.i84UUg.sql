create function bee_rep_get_repdata29_tmpmix(loc_id integer, d_start date, d_end date) returns SETOF bee_repdata29_tmp
    language plpgsql
as
$$
/*
	ito06 2015-01-21 Сводная ведомость по объему услуг, выводит потребеление для всех групп для смешаных с разбиением по тарифам
	
*/
DECLARE rec record;
	host varchar = 'f66apps0';
	host1 varchar = 'f66apps1';
	host2 varchar = 'f66apps2';
	host3 varchar = 'f66apps3';
	ListConn TEXT[];
	Result TEXT;

BEGIN
	IF loc_id = 693	   
	      THEN --РГЭС
	        SELECT distinct hostname FROM bee_closed_info WHERE dbstatus = 'U' limit 1 INTO host;
	        IF       host ='f66apps1' THEN host1 = 'f66apps0';
	           ELSIF host ='f66apps2' THEN host2 = 'f66apps0';
	           ELSIF host ='f66apps3' THEN host3 = 'f66apps0';
	        END IF;  
	        
	        SELECT * FROM dblink_get_connections() INTO ListConn;
		IF 'deconn1' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn1') INTO Result; END IF;  
		IF 'deconn2' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn2') INTO Result; END IF;  
		IF 'deconn3' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn3') INTO Result; END IF; 	
		
		SELECT dblink_connect_u('deconn1',' dbname = beeU port = 5432 host = '||host1||' user = pgsql') INTO Result;
		SELECT dblink_connect_u('deconn2',' dbname = beeU port = 5432 host = '||host2||' user = pgsql') INTO Result;
		SELECT dblink_connect_u('deconn3',' dbname = beeU port = 5432 host = '||host3||' user = pgsql') INTO Result;
 
	        
	        RETURN QUERY( SELECT * from bee_rep_get_repdata29_tmp2($1,$2,$3, host) 
	                UNION SELECT * from bee_rep_get_repdata29_tmp2_corr($1,$2,$3, host)
			UNION SELECT DISTINCT points.* 
                               FROM dblink('deconn1','select * from bee_rep_get_repdata29_tmp2('||$1||', '''||$2||''','''||$3||''','''||host1||''') '
                                           ) AS points(fil varchar, dat date, amnid int, doc_name text, grp int, tot_amount numeric, vn_amount numeric, sn1_amount numeric, 
                                           sn2_amount numeric, nn_amount numeric, tot_sum numeric, vn_sum numeric, sn1_sum numeric, sn2_sum numeric, nn_sum numeric)
                        UNION SELECT DISTINCT points.* 
                               FROM dblink('deconn1','select * from bee_rep_get_repdata29_tmp2_corr('||$1||', '''||$2||''','''||$3||''','''||host1||''') '
                                           ) AS points(fil varchar,dat date, amnid int, doc_name text, grp int, tot_amount numeric, vn_amount numeric, sn1_amount numeric, 
                                           sn2_amount numeric, nn_amount numeric, tot_sum numeric, vn_sum numeric, sn1_sum numeric, sn2_sum numeric, nn_sum numeric)
			UNION SELECT DISTINCT points.* 
                               FROM dblink('deconn2','select * from bee_rep_get_repdata29_tmp2('||$1||', '''||$2||''','''||$3||''','''||host2||''') '
					  ) AS points(fil varchar,dat date, amnid int, doc_name text, grp int, tot_amount numeric, vn_amount numeric, sn1_amount numeric, 
					sn2_amount numeric, nn_amount numeric, tot_sum numeric, vn_sum numeric, sn1_sum numeric, sn2_sum numeric, nn_sum numeric)
			UNION SELECT DISTINCT points.* 
                               FROM dblink('deconn2','select * from bee_rep_get_repdata29_tmp2_corr('||$1||', '''||$2||''','''||$3||''','''||host2||''') '
					  ) AS points(fil varchar,dat date, amnid int, doc_name text, grp int, tot_amount numeric, vn_amount numeric, sn1_amount numeric, 
					sn2_amount numeric, nn_amount numeric, tot_sum numeric, vn_sum numeric, sn1_sum numeric, sn2_sum numeric, nn_sum numeric)
			UNION SELECT DISTINCT points.* 
                               FROM dblink('deconn3','select * from bee_rep_get_repdata29_tmp2('||$1||', '''||$2||''','''||$3||''','''||host3||''') '
                                           ) AS points(fil varchar,dat date, amnid int, doc_name text, grp int, tot_amount numeric, vn_amount numeric, sn1_amount numeric, 
                                           sn2_amount numeric, nn_amount numeric, tot_sum numeric, vn_sum numeric, sn1_sum numeric, sn2_sum numeric, nn_sum numeric)
			UNION SELECT DISTINCT points.* 
                               FROM dblink('deconn3','select * from bee_rep_get_repdata29_tmp2_corr('||$1||', '''||$2||''','''||$3||''','''||host3||''') '
                                           ) AS points(fil varchar,dat date, amnid int, doc_name text, grp int, tot_amount numeric, vn_amount numeric, sn1_amount numeric, 
                                           sn2_amount numeric, nn_amount numeric, tot_sum numeric, vn_sum numeric, sn1_sum numeric, sn2_sum numeric, nn_sum numeric)
			);
	        SELECT dblink_disconnect('deconn1') INTO Result;
	        SELECT dblink_disconnect('deconn2') INTO Result;
	        SELECT dblink_disconnect('deconn3') INTO Result;			
	   ELSIF loc_id = 644
	     THEN 
	        FOR rec IN (SELECT distinct hostname FROM bee_closed_info WHERE dbstatus = 'U')
		 LOOP
			SELECT * FROM dblink_get_connections() INTO ListConn;
			IF 'deconn0' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn0') INTO Result; END IF;  
			SELECT dblink_connect_u('deconn0',' dbname = beeU port = 5432 host = '||rec.hostname||' user = pgsql') INTO Result;
			
			RETURN QUERY(SELECT DISTINCT points.* 
                                       FROM dblink('deconn0','select * from bee_rep_get_repdata29_tmp2('||$1||', '''||$2||''','''||$3||''','''||rec.hostname||''')'
                                               ) AS points(fil varchar,dat date, amnid int, doc_name text, grp int, tot_amount numeric, vn_amount numeric, sn1_amount numeric,
                                                   sn2_amount numeric, nn_amount numeric, tot_sum numeric, vn_sum numeric, sn1_sum numeric, sn2_sum numeric, nn_sum numeric)
                               UNION SELECT DISTINCT points.* 
                                       FROM dblink('deconn0','select * from bee_rep_get_repdata29_tmp2_corr('||$1||', '''||$2||''','''||$3||''','''||rec.hostname||''')'
                                               ) AS points(fil varchar, dat date, amnid int, doc_name text, grp int, tot_amount numeric, vn_amount numeric, sn1_amount numeric,
                                                   sn2_amount numeric, nn_amount numeric, tot_sum numeric, vn_sum numeric, sn1_sum numeric, sn2_sum numeric, nn_sum numeric)                              	    );
		 END LOOP;
		 SELECT dblink_disconnect('deconn0') INTO Result;
	
	   ELSE 
		SELECT distinct hostname FROM bee_closed_info WHERE dbstatus = 'U' limit 1 INTO host;
		RETURN QUERY(select * from bee_rep_get_repdata29_tmp2($1,$2,$3, host)
		       UNION select * from bee_rep_get_repdata29_tmp2_corr($1,$2,$3, host));	   
	END IF; 
		
END;
$$;

comment on function bee_rep_get_repdata29_tmpmix(integer, date, date) is 'Сводная ведомость по объему услуг. Используется в bee_rep_get_repdata29_create_tmp_table(lint, date, date)';

alter function bee_rep_get_repdata29_tmpmix(integer, date, date) owner to postgres;

