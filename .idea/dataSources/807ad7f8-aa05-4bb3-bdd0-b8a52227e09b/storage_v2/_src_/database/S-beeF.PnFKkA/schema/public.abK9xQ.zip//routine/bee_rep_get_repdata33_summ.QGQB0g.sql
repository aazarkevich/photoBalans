create function bee_rep_get_repdata33_summ(pp integer, _host character varying) returns SETOF bee_repdata33_sum
    language plpgsql
as
$$
/*
	ito06 2016-04-26 Сводный журнал задолжненников (репс), суммарные строки по группе потребителя
*/
DECLARE 	
	RowLine bee_repdata33_sum%rowtype;

BEGIN     
    FOR RowLine IN (
		 SELECT 
			(select sum (a)  from unnest(ARRAY[ sum(row.sum_debit), sum(row.sum_debit20), sum(row.sum_debit45), 
							    sum(row.sum_debit90), sum(row.sum_debit365)]) AS a) 
									AS all_sum_debit,
			null::date 					AS dat_debit,
			sum(row.sum_debit) 				AS sum_debit,
			null::date 					AS dat_debit20,
			sum(row.sum_debit20)				AS sum_debit20,
			null::date 					AS dat_debit45,
			sum(row.sum_debit45)  				AS sum_debit45,
			null::date 					AS dat_debit90,
			sum(row.sum_debit90) 				AS sum_debit90,
			null::date 					AS dat_debit365,		 
			sum(row.sum_debit365)  				AS sum_debit365,
			null::varchar					AS dat_measure,
			null::varchar 					AS meas_measure,
			null::varchar					AS comm_measure,		
			null::varchar					AS dat_collecting,			
			sum(row.sum_collecting)				AS sum_collecting,			
			null::varchar					AS meas_collecting,
			null::varchar					AS comm_collecting,			
			$2 						AS host 
		FROM bee_rep_get_repdata33_tmp AS row
		
		WHERE ((accdir NOT IN ( 835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND row.host NOT IN ('beex', 'localhost') AND pp=10)	-- прочие потребители 
			OR (accdir IN ( 835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND row.host NOT IN ('beex', 'localhost') AND pp=20)	-- бюджетные потребиели
			OR (accdir = 835 						  AND row.host NOT IN ('beex', 'localhost') AND pp=21)	-- федеральный бюджет 
			OR (accdir = 836 						  AND row.host NOT IN ('beex', 'localhost') AND pp=22)	-- областной бюджет
			OR (accdir IN (832, 837, 838, 839, 840, 841, 842,1623) 		  AND row.host NOT IN ('beex', 'localhost') AND pp=23)	-- местный бюджет
			OR (accdir IN (832, 837, 838, 839, 840, 841, 842) 		  AND row.host NOT IN ('beex', 'localhost') AND pp=231)	-- юр. лица
			OR (accdir = 1623 						  AND row.host NOT IN ('beex', 'localhost') AND pp=232)	-- уличное освещение
			OR (pp=0)                                                                       -- ВСЕГО
			OR (row.host IN ('beex', 'localhost')				  AND pp=3))    -- централизованные
		    AND row.host like $2)
	LOOP
		IF RowLine.sum_collecting = '0' THEN RowLine.sum_collecting = null; END IF;
		RETURN  NEXT RowLine;        
	END LOOP;
	    
	    
END;
$$;

comment on function bee_rep_get_repdata33_summ(integer, varchar) is 'Сводный журнал задолжненников (репс). Используется в bee_rep_get_repdata33(varchar),bee_rep_get_repdata33_uni(varchar bee_rep_get_repdata33_cust(varchar), bee_rep_get_repdata33_all(int, date, varchar, boolean, boolean, boolean, varchar)';

alter function bee_rep_get_repdata33_summ(integer, varchar) owner to pgsql;

