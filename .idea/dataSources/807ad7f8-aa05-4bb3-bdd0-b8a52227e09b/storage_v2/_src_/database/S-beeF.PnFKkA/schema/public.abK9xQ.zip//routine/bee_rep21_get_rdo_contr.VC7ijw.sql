create function bee_rep21_get_rdo_contr(locid integer, start_date date, end_date date, n integer) returns SETOF bee_repakt7_rdo
    language plpgsql
as
$$
/*
    add ito06 2020-07-16 Добавили параметр виду учета "технический"
  	add ito06 2012-08-02
	ito06 2012-02-02 Сводный баланс за период

*/
DECLARE 
RowLine bee_repakt7_rdo%RowType;
param varchar;
tabl varchar;
BEGIN
param = quote_literal('^[\d{1,},\-]');
tabl = 'temp_gis_traces_for_rep21';

RETURN QUERY EXECUTE'
SELECT 
  gis.objcode AS code,
  sum(rdo.valman::numeric) AS valman
FROM
  bee_rep_get_dats_for13('||quote_literal($2)||','||quote_literal($3)||') AS dats 
  JOIN '||tabl||' AS gis ON dats IS NOT NULL
 
  JOIN regdevconn AS rdc ON rdc.traceid = gis.rowid
  JOIN agreeregdev AS ard ON ard.linkid = rdc.pointid AND ard.paramid=189 AND ard.paramval in ( '||quote_literal('434')||', '||quote_literal('2287')||' )
  JOIN regdevoper  AS rdo ON rdo.linkid = ard.linkid
  JOIN agreepoint AS apn ON apn.rowid = ard.linkid
  JOIN agreement AS amn ON amn.rowid = apn.linkid
  WHERE
    amn.locid IN(SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = '||$1||')) AND
    gis.objtype = 11 AND 

    gis.objowner IN(select objcode FROM  gis_traces WHERE objtype IN(9,8,1000)) AND
    rdo.operdate BETWEEN dats.dats['||$4||'][1] AND dats.dats['||$4||'][2] AND
    rdo.paramid = 850 AND
    rdo.valman ~ '||param||' AND
    rdo.valman <> '||quote_literal('-')||'
    and amn.accdir = 538 --- ito02 2011-11-23 08-30  контроль
   GROUP BY code';
  END;
$$;

comment on function bee_rep21_get_rdo_contr(integer, date, date, integer) is 'Сводный баланс за период. Используется в bee_rep_get_repdata21_leg(int, date, date, boolean, boolean)';

alter function bee_rep21_get_rdo_contr(integer, date, date, integer) owner to pgsql;

