create view vbee_agreeregdev_tn(element_code, element_name, link, rowid, refs, element_type) as
SELECT dic_elements.element_code,
       dic_elements.element_name,
       dic_elements.link,
       dic_elements.rowid,
       dic_elements.refs,
       dic_elements.element_type
FROM dic_elements
WHERE ((dic_elements.link = 61) AND ((dic_elements.element_code)::text ~~ '2__'::text))
ORDER BY dic_elements.element_code;

comment on view vbee_agreeregdev_tn is 'Используется в DeviceParamTN.java, SessionBean1.java, AppUtils.java';

alter table vbee_agreeregdev_tn
    owner to pgsql;

