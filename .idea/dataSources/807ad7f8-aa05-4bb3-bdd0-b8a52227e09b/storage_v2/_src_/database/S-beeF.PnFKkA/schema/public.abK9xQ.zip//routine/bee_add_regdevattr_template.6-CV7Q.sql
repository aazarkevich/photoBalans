create function bee_add_regdevattr_template(devidsrc integer, deviddst integer) returns integer
    language plpgsql
as
$$
begin
--
insert into regdevattr (
 deviceid,
 paramid,
 ed,
 val,
 timeperiod 
) 
(select 
  deviddst,  
  paramid,
  ed,
  val,
  timeperiod 
from 
  regdevattr 
where 
 deviceid = devidsrc
);
return 0;
--
end;
$$;

comment on function bee_add_regdevattr_template(integer, integer) is 'Используется в RegDevAttr.java, AppUtils.java';

alter function bee_add_regdevattr_template(integer, integer) owner to pgsql;

