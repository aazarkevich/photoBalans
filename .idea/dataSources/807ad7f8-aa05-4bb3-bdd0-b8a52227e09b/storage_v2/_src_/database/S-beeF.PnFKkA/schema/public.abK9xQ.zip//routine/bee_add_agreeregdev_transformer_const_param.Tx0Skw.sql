create function bee_add_agreeregdev_transformer_const_param(pid integer, trid integer, typ integer) returns integer
    language plpgsql
as
$$
/*	
	ito06 2020-05-25 Ввод пост параметров ("коэфициента трансформации", "класс точности", "на границе раздела", "место установки", "балансовая принадлежность") для ТТ/ТН лько что введенного для фаз А В С, если на какой-то фазе есть (А В С).
*/
DECLARE
	 NR INTEGER;	 	
	_paramval varchar;
	_param int;
	_paramid1 int;
	_paramid2 int;
	_paramid3 int;
	_paramid4 int;
	_paramid5 int;
    _period date;
    _count1 int; --количество
     
begin
	BEGIN
   		select paramid, period from agreeregdev_period where rowid = trid into _param, _period; --определяем фазу период введенного трансформатора
   		
   		if typ = 56 --1 TT 
		   then		
	     		if (_param = 2203) --фаза А
		     		 then       _paramid1 = 2209; _paramid2  = 2210; _paramid3 = 2211; _paramid4 = 2212; _paramid5 = 2213; 
		     		 else if (_param = 2204) --фаза В 
		     			   then _paramid1 = 2222; _paramid2  = 2223; _paramid3 = 2224; _paramid4 = 2225; _paramid5 = 2226;
		     		 	   else _paramid1 = 2235; _paramid2  = 2236; _paramid3 = 2237; _paramid4 = 2238; _paramid5 = 2239; --фаза С
		     		 	  end if;
		     		end if; 
	    else  --1 TH
			     if (_param = 2206) --фаза А
			     	then        _paramid1 = 2248; _paramid2  = 2249; _paramid3 = 2250; _paramid4 = 2251; _paramid5 = 2252; 
			     	 else if (_param = 2207) --фаза В 
			     		   then _paramid1 = 2261; _paramid2  = 2262; _paramid3 = 2263; _paramid4 = 2264; _paramid5 = 2265; 
			     		   else _paramid1 = 2274; _paramid2  = 2275; _paramid3 = 2276; _paramid4 = 2277; _paramid5 = 2278; --фаза С
			     		  end if;
			     end if;
	     end if; --1
   		
	   
		     --ищем для даннного устройства введен ли параметр "коэфициент трансформации" хотя быдля одной фазы
	   		select ardtr.paramval from agreeregdev_period as ardp
	   	        left join agreeregdev_transformer as ardtr on ardtr.linkid1 = ardp.linkid and ardtr.linkid2 = ardp.rowid and ((ardtr.paramid in (2209, 2222, 2235) and typ = 56) or (ardtr.paramid in (2248, 2261, 2274) and typ = 61))
	   		 where ardp.linkid = pid and ardp.period <= _period and ((ardp.paramid in (2203, 2204, 2205) and typ = 56) or (ardp.paramid in (2206, 2207, 2208) and typ = 61))  and ardtr.paramval is not null order by period desc into _paramval; 			
	    
		    if (_paramval is not null)  --2 
		      then 	        
		           insert into agreeregdev_transformer(linkid1, linkid2, paramid, paramval) values (pid,trid,_paramid1,_paramval) RETURNING rowid INTO NR;
		           
                  if typ = 56 
                  then
                  	 select count(ardp.rowid) from agreeregdev_period as ardp where ardp.linkid = pid and ardp.period = _period and (ardp.paramid in (2203,  2205) and _param in (2203, 2205)) into _count1; 
                  else
		          	 select count(ardp.rowid) from agreeregdev_period as ardp where ardp.linkid = pid and ardp.period = _period and (ardp.paramid in (2206, 2207, 2208) and _param in (2206, 2207, 2208)) into _count1;
		          end if;	
	 	                          
		          if ((typ = 56 and _count1 >= 2) or (typ = 61  and _count1 = 3)) then PERFORM public.bee_set_rasch_koef(pid,_period); end if;
		          
		    end if; --2
		    
		     --ищем для даннного устройства введен ли параметр "класс точности" хотя быдля одной фазы
	   		select ardtr.paramval from agreeregdev_period as ardp
	   	        left join agreeregdev_transformer as ardtr on ardtr.linkid1 = ardp.linkid and ardtr.linkid2 = ardp.rowid and ((ardtr.paramid in (2210, 2223, 2236) and typ = 56) or (ardtr.paramid in (2249, 2262, 2275) and typ = 61))
	   		 where ardp.linkid = pid and ardp.period <= _period and ((ardp.paramid in (2203, 2204, 2205) and typ = 56) or (ardp.paramid in (2206, 2207, 2208) and typ = 61))  and ardtr.paramval is not null order by period desc into _paramval;
	    
		    if (_paramval is not null)  --2 
		      then 	        
		           insert into agreeregdev_transformer(linkid1, linkid2, paramid, paramval) values (pid,trid,_paramid2,_paramval) RETURNING rowid INTO NR;
		    end if; --2
		    
		    
		     --ищем для даннного устройства введен ли параметр "на границе раздела" хотя быдля одной фазы
	   		select ardtr.paramval from agreeregdev_period as ardp
	   	        left join agreeregdev_transformer as ardtr on ardtr.linkid1 = ardp.linkid and ardtr.linkid2 = ardp.rowid and ((ardtr.paramid in (2211, 2224, 2237) and typ = 56) or (ardtr.paramid in (2250, 2263, 2276) and typ = 61))
	   		 where ardp.linkid = pid and ardp.period <= _period and ((ardp.paramid in (2203, 2204, 2205) and typ = 56) or (ardp.paramid in (2206, 2207, 2208) and typ = 61))  and ardtr.paramval is not null order by period desc into _paramval;
	    
		    if (_paramval is not null)  --2 
		      then 	        
		           insert into agreeregdev_transformer(linkid1, linkid2, paramid, paramval) values (pid,trid,_paramid3,_paramval) RETURNING rowid INTO NR;
		    end if; --2
		    
		    
		     --ищем для даннного устройства введен ли параметр "место установки" хотя быдля одной фазы
	   		select ardtr.paramval from agreeregdev_period as ardp
	   	        left join agreeregdev_transformer as ardtr on ardtr.linkid1 = ardp.linkid and ardtr.linkid2 = ardp.rowid and ((ardtr.paramid in (2212, 2225, 2238) and typ = 56) or (ardtr.paramid in (2251, 2264, 2277) and typ = 61))
	   		 where ardp.linkid = pid and ardp.period <= _period and ((ardp.paramid in (2203, 2204, 2205) and typ = 56) or (ardp.paramid in (2206, 2207, 2208) and typ = 61))  and ardtr.paramval is not null order by period desc into _paramval;
	 			
	    
		    if (_paramval is not null)  --2 
		      then 	        
		           insert into agreeregdev_transformer(linkid1, linkid2, paramid, paramval) values (pid,trid,_paramid4,_paramval) RETURNING rowid INTO NR;
		     end if; --2

		    
		    
		     --ищем для даннного устройства введен ли параметр "балансовая принадлежность" хотя быдля одной фазы
	   		select ardtr.paramval from agreeregdev_period as ardp
	   	        left join agreeregdev_transformer as ardtr on ardtr.linkid1 = ardp.linkid and ardtr.linkid2 = ardp.rowid and ((ardtr.paramid in (2213, 2226, 2239) and typ = 56) or (ardtr.paramid in (2252, 2265, 2278) and typ = 61))
	   		 where ardp.linkid = pid and ardp.period <= _period and ((ardp.paramid in (2203, 2204, 2205) and typ = 56) or (ardp.paramid in (2206, 2207, 2208) and typ = 61))  and ardtr.paramval is not null order by period desc into _paramval;
	    
		    if (_paramval is not null)  --2 
		      then 	        
		           insert into agreeregdev_transformer(linkid1, linkid2, paramid, paramval) values (pid,trid,_paramid5,_paramval) RETURNING rowid INTO NR;
		    end if; --2

		
   EXCEPTION
	WHEN UNIQUE_VIOLATION THEN
	RETURN -1;
   END;
   RETURN NR;
END;
$$;

comment on function bee_add_agreeregdev_transformer_const_param(integer, integer, integer) is 'Ввод пост параметров ("коэфициента трансформации", "класс точности", "на границе раздела", "место установки", "балансовая принадлежность") для ТТ/ТН лько что введенного для фаз А В С, если на какой-то фазе есть (А В С). Используется в DevParamTT.java, DevParamTN.java, AppUtils.java';

alter function bee_add_agreeregdev_transformer_const_param(integer, integer, integer) owner to pgsql;

