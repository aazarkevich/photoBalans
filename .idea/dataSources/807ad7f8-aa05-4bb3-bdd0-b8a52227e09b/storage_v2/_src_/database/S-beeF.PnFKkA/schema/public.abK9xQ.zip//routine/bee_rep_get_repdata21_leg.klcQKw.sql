create function bee_rep_get_repdata21_leg(locid integer, start_date date, end_date date, full_name boolean, tp_is_exists boolean) returns SETOF bee_repdata21_leg
    language plpgsql
as
$$
/*
	add ito06 2015-05-12 Учитывать, только последние трассы
	add ito06 2012-08-02
	ito06 2012-02-02 Сводный баланс за период
*/
DECLARE
	RowLine bee_repdata21_leg%rowtype;
	count_c bigint;
	count_l bigint;
	param character varying;
BEGIN
	IF  tp_is_exists = true
		THEN  param = ' NOT '; ELSE param =' ';
	END IF;   
	EXECUTE 'create TEMPORARY table  temp_gis_traces_for_rep21 AS
		(select gt.locid, gt.period, gt.pchain, gt.objowner, gt.objname, gt.objcode,  gt.objtype, gt.rowid, gt.kod  
		   from gis_traces as gt
		left join gis_traces_tmp as gtt USING (kod, locid,pchain, objowner, objname, objcode, objtype) where gtt.period is '|| param ||' NULL);';

	EXECUTE 'create TEMPORARY table temp_gis_traces21  AS
		(select gt.locid, gt.period, gt.pchain, gt.objowner,  gt.objname, gt.objcode, gt.objtype, gt.kod from gis_traces AS gt 
                   join (select  max(period) AS period, locid, objcode, objtype from gis_traces  group by locid, objcode, objtype) AS gt1
                  using (period, locid, objcode, objtype));';	  

FOR RowLine IN (
	SELECT 
		gis.objcode 			AS code,
		CASE WHEN $4 
		   THEN CASE WHEN gis.objname IS NOT NULL
			    THEN gis.objname || ' '
			   ELSE ''
			END
		   ELSE CASE WHEN a6.objname IS NOT NULL
			   THEN a6.objname || ' '
			   ELSE ''
			END 
			||CASE WHEN a5.objname IS NOT NULL
			    THEN a5.objname || ' '
			    ELSE ''
			  END 
			||CASE WHEN a4.objname IS NOT NULL
			    THEN a4.objname || ' '
			    ELSE ''
			  END 
			||CASE WHEN a3.objname IS NOT NULL
			    THEN a3.objname || ' '
			    ELSE ''
			  END 
			||CASE WHEN a2.objname IS NOT NULL
			     THEN a2.objname || ' '
			     ELSE ''
			END 
			||CASE WHEN a1.objname IS NOT NULL
			     THEN a1.objname || ' '
			     ELSE ''
			END 
			||CASE WHEN gis.objname IS NOT NULL
			     THEN gis.objname || ' '
			     ELSE ''
			  END 
		END 						AS pch,
		CASE WHEN leg_count_off IS NOT NULL
		    THEN leg_count_off
		    ELSE 0
		END  						AS n_off,
		CASE WHEN leg_count  IS NOT NULL
		   THEN  leg_count 
		   ELSE 0
		END  						AS n,
		0::bigint As count_leg,
		0::bigint As count_contr,
		ARRAY[
		    rdo1_contr.valman,
		    rdo2_contr.valman,
		    rdo3_contr.valman,
		    rdo4_contr.valman,
		    rdo5_contr.valman,
		    rdo6_contr.valman,
		    rdo7_contr.valman,
		    rdo8_contr.valman,
		    rdo9_contr.valman,
		    rdo10_contr.valman,
		    rdo11_contr.valman,
		    rdo12_contr.valman,
		    rdo13_contr.valman
		  ] 						AS subst_contr,
		  ARRAY[
		    rdo1_contr2.valman,
		    rdo2_contr2.valman,
		    rdo3_contr2.valman,
		    rdo4_contr2.valman,
		    rdo5_contr2.valman,
		    rdo6_contr2.valman,
		    rdo7_contr2.valman,
		    rdo8_contr2.valman,
		    rdo9_contr2.valman,
		    rdo10_contr2.valman,
		    rdo11_contr2.valman,
		    rdo12_contr2.valman,
		    rdo13_contr2.valman
		  ] 						AS subst_contr2,
		  ARRAY[
		    rdo1.valman,
		    rdo2.valman,
		    rdo3.valman,
		    rdo4.valman,
		    rdo5.valman,
		    rdo6.valman,
		    rdo7.valman,
		    rdo8.valman,
		    rdo9.valman,
		    rdo10.valman,
		    rdo11.valman,
		    rdo12.valman,
		    rdo13.valman
		  ] 						AS v850,
		ARRAY [
		    CASE WHEN rtp1.loss_val IS NULL
		      THEN 0 ELSE rtp1.loss_val
		    END,
		    CASE WHEN rtp2.loss_val IS NULL
		      THEN 0 ELSE rtp2.loss_val
		    END,
		    CASE WHEN rtp3.loss_val IS NULL
		      THEN 0 ELSE rtp3.loss_val
		    END,
		    CASE WHEN rtp4.loss_val IS NULL
		      THEN 0 ELSE rtp4.loss_val
		    END,
		    CASE WHEN rtp5.loss_val IS NULL
		      THEN 0 ELSE rtp5.loss_val
		    END,
		    CASE WHEN rtp6.loss_val IS NULL
		      THEN 0 ELSE rtp6.loss_val
		    END,
		    CASE WHEN rtp7.loss_val IS NULL
		      THEN 0 ELSE rtp7.loss_val
		    END,
		    CASE WHEN rtp8.loss_val IS NULL
		      THEN 0 ELSE rtp8.loss_val
		    END,
		    CASE WHEN rtp9.loss_val IS NULL
		      THEN 0 ELSE rtp9.loss_val
		    END,
		    CASE WHEN rtp10.loss_val IS NULL
		      THEN 0 ELSE rtp10.loss_val
		    END,
		    CASE WHEN rtp11.loss_val IS NULL
		      THEN 0 ELSE rtp11.loss_val
		    END,
		    CASE WHEN rtp12.loss_val IS NULL
		      THEN 0 ELSE rtp12.loss_val
		    END,
		    CASE WHEN rtp13.loss_val IS NULL
		      THEN 0 ELSE rtp13.loss_val
		    END
		  ] 						AS loss,
		gto.ownerid 					AS subst_type
		
	   FROM bee_rep_get_dats_for13($2,$3) AS dats
           JOIN temp_gis_traces_for_rep21  AS gis ON dats IS NOT NULL
      LEFT JOIN gis_traces_owner AS gto ON gis.rowid = gto.linkid
	   JOIN temp_gis_traces_for_rep21 AS gis_child ON gis.objcode = gis_child.objowner OR gis.objcode = gis_child.objcode
	   JOIN regdevconn AS rdc ON rdc.traceid = gis_child.rowid
	   JOIN agreepoint AS apn ON apn.rowid = rdc.pointid
	   JOIN agreement AS amn ON amn.rowid = apn.linkid
      LEFT JOIN (SELECT gis.objcode AS code1,
			count(ard.linkid) AS leg_count
		   FROM temp_gis_traces_for_rep21 AS gis
		   JOIN temp_gis_traces_for_rep21 AS gis_child ON gis.objcode = gis_child.objowner OR gis.objcode = gis_child.objcode
		   JOIN regdevconn AS rdc ON rdc.traceid = gis_child.rowid
	      LEFT JOIN agreeregdev AS ard ON ard.linkid = rdc.pointid AND ard.paramid=189 AND ard.paramval='432'
		  WHERE ard.linkid NOT IN (select linkid from agreeregdev 
                                            where paramid = 690 and length(paramval) = 10
			                      and is_date(paramval) and paramval::date < $3)
                  GROUP BY code1
               ) AS rdo ON gis.objcode = rdo.code1
      LEFT JOIN (SELECT gis.objcode AS code1,
			count(ard.linkid) AS leg_count_off
		   FROM temp_gis_traces_for_rep21 AS gis
		   JOIN temp_gis_traces_for_rep21 AS gis_child ON gis.objcode = gis_child.objowner OR gis.objcode = gis_child.objcode
		   JOIN regdevconn AS rdc ON rdc.traceid = gis_child.rowid
	      LEFT JOIN agreeregdev AS ard ON ard.linkid = rdc.pointid AND ard.paramid=189 AND ard.paramval='432'
                  WHERE ard.linkid IN (select linkid from agreeregdev 
                                        where paramid = 690 and length(paramval) = 10
			                  and is_date(paramval) and paramval::date < $3)
		  GROUP BY code1
		) AS rdo_off ON gis.objcode = rdo_off.code1
		
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,1) AS rdo1 ON rdo1.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,2) AS rdo2 ON rdo2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,3) AS rdo3 ON rdo3.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,4) AS rdo4 ON rdo4.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,5) AS rdo5 ON rdo5.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,6) AS rdo6 ON rdo6.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,7) AS rdo7 ON rdo7.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,8) AS rdo8 ON rdo8.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,9) AS rdo9 ON rdo9.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,10) AS rdo10 ON rdo10.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,11) AS rdo11 ON rdo11.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,12) AS rdo12 ON rdo12.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo($1,$2,$3,13) AS rdo13 ON rdo13.linkid = gis.objcode

      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,1) AS rdo1_contr ON rdo1_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,2) AS rdo2_contr ON rdo2_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,3) AS rdo3_contr ON rdo3_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,4) AS rdo4_contr ON rdo4_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,5) AS rdo5_contr ON rdo5_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,6) AS rdo6_contr ON rdo6_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,7) AS rdo7_contr ON rdo7_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,8) AS rdo8_contr ON rdo8_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,9) AS rdo9_contr ON rdo9_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,10) AS rdo10_contr ON rdo10_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,11) AS rdo11_contr ON rdo11_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,12) AS rdo12_contr ON rdo12_contr.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr($1,$2,$3,13) AS rdo13_contr ON rdo13_contr.linkid = gis.objcode

      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,1) AS rdo1_contr2 ON rdo1_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,2) AS rdo2_contr2 ON rdo2_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,3) AS rdo3_contr2 ON rdo3_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,4) AS rdo4_contr2 ON rdo4_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,5) AS rdo5_contr2 ON rdo5_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,6) AS rdo6_contr2 ON rdo6_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,7) AS rdo7_contr2 ON rdo7_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,8) AS rdo8_contr2 ON rdo8_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,9) AS rdo9_contr2 ON rdo9_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,10) AS rdo10_contr2 ON rdo10_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,11) AS rdo11_contr2 ON rdo11_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,12) AS rdo12_contr2 ON rdo12_contr2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo_contr2($1,$2,$3,13) AS rdo13_contr2 ON rdo13_contr2.linkid = gis.objcode

      LEFT JOIN gis_rtp AS rtp1 ON rtp1.traceid = gis.rowid AND rtp1.period = dats.dats[1][2]
      LEFT JOIN gis_rtp AS rtp2 ON rtp2.traceid = gis.rowid AND rtp2.period = dats.dats[2][2]
      LEFT JOIN gis_rtp AS rtp3 ON rtp3.traceid = gis.rowid AND rtp3.period = dats.dats[3][2]
      LEFT JOIN gis_rtp AS rtp4 ON rtp4.traceid = gis.rowid AND rtp4.period = dats.dats[4][2]
      LEFT JOIN gis_rtp AS rtp5 ON rtp5.traceid = gis.rowid AND rtp5.period = dats.dats[5][2]
      LEFT JOIN gis_rtp AS rtp6 ON rtp6.traceid = gis.rowid AND rtp6.period = dats.dats[6][2]
      LEFT JOIN gis_rtp AS rtp7 ON rtp7.traceid = gis.rowid AND rtp7.period = dats.dats[7][2]
      LEFT JOIN gis_rtp AS rtp8 ON rtp8.traceid = gis.rowid AND rtp8.period = dats.dats[8][2]
      LEFT JOIN gis_rtp AS rtp9 ON rtp9.traceid = gis.rowid AND rtp9.period = dats.dats[9][2]
      LEFT JOIN gis_rtp AS rtp10 ON rtp10.traceid = gis.rowid AND rtp10.period = dats.dats[10][2]
      LEFT JOIN gis_rtp AS rtp11 ON rtp11.traceid = gis.rowid AND rtp11.period = dats.dats[11][2]
      LEFT JOIN gis_rtp AS rtp12 ON rtp12.traceid = gis.rowid AND rtp12.period = dats.dats[12][2]
     LEFT JOIN gis_rtp AS rtp13 ON rtp13.traceid = gis.rowid AND rtp13.period = dats.dats[13][2]

      LEFT JOIN temp_gis_traces21 AS a1 ON a1.objcode = gis.objowner AND a1.objtype<>1000
      LEFT JOIN temp_gis_traces21 AS a2 ON a2.objcode = a1.objowner  AND a2.objtype<>1000    
      LEFT JOIN temp_gis_traces21 AS a3 ON a3.objcode = a2.objowner  AND a3.objtype<>1000    
      LEFT JOIN temp_gis_traces21 AS a4 ON a4.objcode = a3.objowner  AND a4.objtype<>1000    
      LEFT JOIN temp_gis_traces21 AS a5 ON a5.objcode = a4.objowner  AND a5.objtype<>1000    
      LEFT JOIN temp_gis_traces21 AS a6 ON a6.objcode = a5.objowner  AND a6.objtype<>1000    
	  WHERE 
		amn.locid IN(SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1)) AND
		gis.objtype = 11 AND gis.objowner IN (select objcode FROM temp_gis_traces21 WHERE objtype IN(9,8,1000)) 
	  GROUP BY code, pch, loss, subst_type, n, subst_contr, v850, n_off, gis.objname,subst_contr2
	 ORDER BY pch )
       LOOP
		count_c =0;
		count_l =0;

		IF RowLine.subst_contr[1] IS NOT NULL  THEN count_c = count_c + 1; END IF;
		IF RowLine.subst_contr[2] IS NOT NULL  THEN count_c = count_c + 1; END IF;
		IF RowLine.subst_contr[3] IS NOT NULL  THEN count_c = count_c + 1; END IF;
		IF RowLine.subst_contr[4] IS NOT NULL  THEN count_c = count_c + 1; END IF;
		IF RowLine.subst_contr[5] IS NOT NULL  THEN count_c = count_c + 1; END IF;
		IF RowLine.subst_contr[6] IS NOT NULL  THEN count_c = count_c + 1; END IF;
		IF RowLine.subst_contr[7] IS NOT NULL  THEN count_c = count_c + 1; END IF;
		IF RowLine.subst_contr[8] IS NOT NULL  THEN count_c = count_c + 1; END IF;
		IF RowLine.subst_contr[9] IS NOT NULL  THEN count_c = count_c + 1; END IF;   
		IF RowLine.subst_contr[10] IS NOT NULL  THEN count_c = count_c + 1; END IF;   
		IF RowLine.subst_contr[11] IS NOT NULL  THEN count_c = count_c + 1; END IF;   
		IF RowLine.subst_contr[12] IS NOT NULL  THEN count_c = count_c + 1; END IF;  
		IF RowLine.subst_contr[13] IS NOT NULL  THEN count_c = count_c + 1; END IF;  
		IF RowLine.subst_leg[1] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[2] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[3] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[4] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[5] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[6] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[7] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[8] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[9] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[10] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[11] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[12] IS NOT NULL  THEN count_l = count_l + 1; END IF; 
		IF RowLine.subst_leg[13] IS NOT NULL  THEN count_l = count_l + 1; END IF; 

		RowLine.count_contr = count_c;
		RowLine.count_leg = count_l;

		RETURN NEXT RowLine;
	END LOOP;								

	DROP TABLE IF EXISTS temp_gis_traces_for_rep21;
	DROP TABLE IF EXISTS temp_gis_traces21;
END ;

$$;

comment on function bee_rep_get_repdata21_leg(integer, date, date, boolean, boolean) is 'Cводный баланс по ТП за период. Используется в RepCreate21.java';

alter function bee_rep_get_repdata21_leg(integer, date, date, boolean, boolean) owner to pgsql;

