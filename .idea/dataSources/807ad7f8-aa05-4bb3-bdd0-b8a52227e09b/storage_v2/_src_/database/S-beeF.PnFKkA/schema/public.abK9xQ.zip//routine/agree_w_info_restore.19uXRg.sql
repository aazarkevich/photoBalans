create function agree_w_info_restore() returns void
    language plpgsql
as
$$
declare
   R RECORD;	
BEGIN
   ---
   ALTER TABLE bee_closed_period         DISABLE TRIGGER bee_closed_period_trig;
   delete from bee_closed_period;
   insert into bee_closed_period  (select * from bee_closed_period_tmp); 
   drop table if exists bee_closed_period_tmp;
   ALTER TABLE bee_closed_period         ENABLE TRIGGER bee_closed_period_trig;
   ---
   ALTER TABLE bee_closed_period_uni     DISABLE TRIGGER bee_closed_period_uni_trig;
   delete from bee_closed_period_uni;
   insert into bee_closed_period_uni  (select * from bee_closed_period_uni_tmp); 
   drop table if exists bee_closed_period_uni_tmp;
   ALTER TABLE bee_closed_period_uni     ENABLE TRIGGER bee_closed_period_uni_trig;
   ---
   ALTER TABLE bee_closed_period_dir     DISABLE TRIGGER bee_closed_period_dir_trig;
   delete from bee_closed_period_dir;
   insert into bee_closed_period_dir  (select * from bee_closed_period_dir_tmp); 
   drop table if exists bee_closed_period_dir_tmp;
   ALTER TABLE bee_closed_period_dir     ENABLE TRIGGER bee_closed_period_dir_trig;
   ---
   ALTER TABLE bee_closed_period_mix     DISABLE TRIGGER bee_closed_period_mix_trig;
   delete from bee_closed_period_mix;
   insert into bee_closed_period_mix  (select * from bee_closed_period_mix_tmp); 
   drop table if exists bee_closed_period_mix_tmp;
   ALTER TABLE bee_closed_period_mix     ENABLE TRIGGER bee_closed_period_mix_trig;
   ---
END;
$$;

alter function agree_w_info_restore() owner to postgres;

