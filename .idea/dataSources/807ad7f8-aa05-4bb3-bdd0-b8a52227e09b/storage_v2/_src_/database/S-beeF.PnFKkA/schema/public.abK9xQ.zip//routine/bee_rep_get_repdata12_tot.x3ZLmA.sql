create function bee_rep_get_repdata12_tot(loc integer, str_date date, end_date date) returns bee_rep_tab12_new
    language plpgsql
as
$$
/*
   ito06 2011-06-02
   Движение остатков по потребителю
*/
DECLARE
     result bee_rep_tab12_new%ROWTYPE;
     n integer;
     tmp_kod character varying;
     kol integer;
     loc11 integer; 
     i integer;
     sd_tmp numeric(12,2);
     sk_tmp numeric(12,2);
     sd_tmp2 numeric(12,2);
     sk_tmp2 numeric(12,2);
     od_tmp numeric(12,2);
     ok_tmp numeric(12,2);
     od_tmp2 numeric(12,2);
     ok_tmp2 numeric(12,2);
     fd_tmp numeric(12,2);
     fk_tmp numeric(12,2);
     fd_tmp2 numeric(12,2);
     fk_tmp2 numeric(12,2);

BEGIN
i=0;
sd_tmp = 0;
sk_tmp = 0;
sd_tmp2 = 0;
sk_tmp2 = 0;
od_tmp = 0;
ok_tmp = 0;
od_tmp2 = 0;
ok_tmp2 = 0;
fd_tmp = 0;
fk_tmp = 0;
fd_tmp2 = 0;
fk_tmp2 = 0;

SELECT into tmp_kod  kod   from denet AS de1 where de1.rowid = $1 limit 1;
SELECT count(de.rowid) into kol  from denet AS de where de.kod ~ tmp_kod;
SELECT into loc11 de.rowid from denet AS de where de.kod ~ tmp_kod limit 1;

WHILE i < kol LOOP

SELECT sum(sd),sum(sk), sum(od), sum(ok), sum(fd), sum(fk) INTO sd_tmp, sk_tmp, od_tmp, ok_tmp, fd_tmp, fk_tmp             
  FROM bee_rep_get_repdata12(loc11,$2,$3);
 
  IF sd_tmp IS NOT NULL THEN sd_tmp2 = sd_tmp2+sd_tmp; END IF;
  IF sk_tmp IS NOT NULL THEN sk_tmp2 = sk_tmp2+sk_tmp; END IF;
  IF od_tmp IS NOT NULL THEN od_tmp2 = od_tmp2+od_tmp; END IF;
  IF ok_tmp IS NOT NULL THEN ok_tmp2 = ok_tmp2+ok_tmp; END IF;
  IF fd_tmp IS NOT NULL THEN fd_tmp2 = fd_tmp2+fd_tmp; END IF; 
  IF fk_tmp IS NOT NULL THEN fk_tmp2 = fk_tmp2+fk_tmp; END IF;
  

i=i+1;
SELECT de.rowid into loc11  from denet AS de where de.kod ~ tmp_kod ORDER BY de.kod limit i+1 OFFSET i;
END LOOP;

SELECT 
    null::character varying,
    null::character varying,
    null::character varying,
    null::integer,
    sd_tmp2 AS sum_sd, 
    sk_tmp2 AS sum_sk, 
    od_tmp2 AS sum_od, 
    ok_tmp2 AS sum_ok, 
    fd_tmp2 AS sum_fd, 
    fk_tmp2 AS sum_fk,
    'ВСЕГО' AS grp
    INTO result;
     RETURN result;
END;
$$;

comment on function bee_rep_get_repdata12_tot(integer, date, date) is 'Движение остатков по потребителю. Используется в RepCreate12.java, bee_rep_get_repdata12_tot(int, date, date)';

alter function bee_rep_get_repdata12_tot(integer, date, date) owner to pgsql;

