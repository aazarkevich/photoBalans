create function bee_rep_get_repdata24_corr1_cust(loc_id integer, s_date date, e_date date, t_vn integer, t_sn1 integer, t_sn2 integer, t_nn integer) returns SETOF bee_repdata24_cust
    language plpgsql
as
$$
/*
	add ito06 2016-03-03 добавляем параметр тип договора amntyp
	add ito06 2015-07-14
	add ito06 2015-06-30
	ito06 2012-02-10 Ведомость по объему услуг
*/
DECLARE
     RowLine bee_repdata24_cust%rowtype;
     tmp_kod character varying;

BEGIN
SELECT into tmp_kod  kod from denet AS de1 where de1.rowid = loc_id limit 1;
FOR RowLine IN (
		SELECT  doc_corr.period			AS data,
			am.docnumber ||', '|| cust.abo_name	 ::text	AS "name",		/*наименование потребителя и номер договора*/
			

			CASE
			  WHEN (SELECT sum(a) FROM unnest(ARRAY[-sum(corr_vn_old.quantity_old),sum(corr_vn_new.quantity_new),
							 -sum(corr_sn1_old.quantity_old),sum(corr_sn1_new.quantity_new),
							 -sum(corr_sn2_old.quantity_old),sum(corr_sn2_new.quantity_new),
							 -sum(corr_nn_old.quantity_old),sum(corr_nn_new.quantity_new)]) AS a)<>0
			    THEN (SELECT sum(b) FROM unnest(ARRAY[-sum(corr_vn_old.cost_old),sum(corr_vn_new.cost_new),
							 -sum(corr_sn1_old.cost_old),sum(corr_sn1_new.cost_new),
							 -sum(corr_sn2_old.cost_old),sum(corr_sn2_new.cost_new),
							 -sum(corr_nn_old.cost_old),sum(corr_nn_new.cost_new)]) AS b )
				 /(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_vn_old.quantity_old),sum(corr_vn_new.quantity_new),
							 -sum(corr_sn1_old.quantity_old),sum(corr_sn1_new.quantity_new),
							 -sum(corr_sn2_old.quantity_old),sum(corr_sn2_new.quantity_new),
							 -sum(corr_nn_old.quantity_old),sum(corr_nn_new.quantity_new)]) AS a)
			  ELSE null
			END::numeric(12,6)												AS total,	/*7*/  
			
			CASE
			  WHEN (SELECT sum(a) FROM unnest(ARRAY[-sum(corr_vn_old.cost_old),sum(corr_vn_new.cost_new)]) AS a)<>0
			    THEN (SELECT sum(b) FROM unnest(ARRAY[-sum(corr_vn_old.cost_old),sum(corr_vn_new.cost_new)]) AS b )
				 /(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_vn_old.quantity_old),sum(corr_vn_new.quantity_new)]) AS a )
				 
			  ELSE null
			END::numeric(12,6)												AS total_vn,	/*8*/

			CASE
			  WHEN (SELECT sum(a) FROM unnest(ARRAY[-sum(corr_sn1_old.quantity_old),sum(corr_sn1_new.quantity_new)]) AS a)<>0
			    THEN (SELECT sum(b) FROM unnest(ARRAY[-sum(corr_sn1_old.cost_old),sum(corr_sn1_new.cost_new)]) AS b)
				/(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_sn1_old.quantity_old),sum(corr_sn1_new.quantity_new)]) AS a) 
			  ELSE null
			END::numeric(12,6)												AS total_sn1,	/*9*/

			CASE
			  WHEN (SELECT sum(a) FROM unnest(ARRAY[-sum(corr_sn2_old.quantity_old),sum(corr_sn2_new.quantity_new)]) AS a)<>0
			    THEN (SELECT sum(b) FROM unnest(ARRAY[-sum(corr_sn2_old.cost_old),sum(corr_sn2_new.cost_new)]) AS b)
				 /(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_sn2_old.quantity_old),sum(corr_sn2_new.quantity_new)]) AS a)
			  ELSE null
			END::numeric(12,6)												AS total_sn2,	/*10*/

			CASE
			  WHEN (SELECT sum(a) FROM unnest(ARRAY[-sum(corr_nn_old.quantity_old),sum(corr_nn_new.quantity_new)]) AS a)<>0
			    THEN (SELECT sum(b) FROM unnest(ARRAY[-sum(corr_nn_old.cost_old),sum(corr_nn_new.cost_new)]) AS b)
				/(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_nn_old.quantity_old),sum(corr_nn_new.quantity_new)]) AS a)
			  ELSE null
			END::numeric(12,6)												AS total_nn,	/*11*/
		       

			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_vn_old.quantity_old),sum(corr_vn_new.quantity_new),
							 -sum(corr_sn1_old.quantity_old),sum(corr_sn1_new.quantity_new),
							 -sum(corr_sn2_old.quantity_old),sum(corr_sn2_new.quantity_new),
							 -sum(corr_nn_old.quantity_old),sum(corr_nn_new.quantity_new)]) AS a)		AS am_summ,	/*12*/

			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_vn_old.quantity_old),sum(corr_vn_new.quantity_new)]) AS a)		AS am_vn,	/*13*/
			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_sn1_old.quantity_old),sum(corr_sn1_new.quantity_new)]) AS a)		AS am_sn1,	/*14*/
			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_sn2_old.quantity_old),sum(corr_sn2_new.quantity_new)]) AS a)		AS am_sn2,	/*15*/
			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_nn_old.quantity_old),sum(corr_nn_new.quantity_new)]) AS a)		AS am_nn,	/*16*/

			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_vn_old.cost_old),sum(corr_vn_new.cost_new),
							 -sum(corr_sn1_old.cost_old),sum(corr_sn1_new.cost_new),
							 -sum(corr_sn2_old.cost_old),sum(corr_sn2_new.cost_new),
							 -sum(corr_nn_old.cost_old),sum(corr_nn_new.cost_new)]) AS a )			AS s_summ, 	/*17*/


			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_vn_old.cost_old),sum(corr_vn_new.cost_new)]) AS a )			AS s_vn,	/*18*/
			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_sn1_old.cost_old),sum(corr_sn1_new.cost_new)]) AS a )		AS s_sn1,	/*19*/
			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_sn2_old.cost_old),sum(corr_sn2_new.cost_new)]) AS a )		AS s_sn2,	/*20*/
			(SELECT sum(a) FROM unnest(ARRAY[-sum(corr_nn_old.cost_old),sum(corr_nn_new.cost_new)]) AS a )			AS s_nn	/*21*/
				
		     FROM agreement AS am 
		     JOIN customer  AS cust ON (cust.abo_code=am.abo_code)
		     JOIN bee_docs AS doc ON (doc.linkid=am.rowid) AND doc.docdat BETWEEN $2 AND $3
		     JOIN bee_docs_corr  AS doc_corr ON(doc_corr.linkid2 = doc.rowid)  
		LEFT JOIN bee_docs_corr  AS corr_vn_new ON (corr_vn_new.rowid=doc_corr.rowid) AND corr_vn_new.tar_grp_new = $4 
		LEFT JOIN bee_docs_corr  AS corr_vn_old ON (corr_vn_old.rowid=doc_corr.rowid) AND corr_vn_old.tar_grp_old = $4
		LEFT JOIN bee_docs_corr  AS corr_sn1_new ON (corr_sn1_new.rowid=doc_corr.rowid) AND corr_sn1_new.tar_grp_new = $5  
		LEFT JOIN bee_docs_corr  AS corr_sn1_old ON (corr_sn1_old.rowid=doc_corr.rowid) AND corr_sn1_old.tar_grp_old = $5 
		LEFT JOIN bee_docs_corr  AS corr_sn2_new ON (corr_sn2_new.rowid=doc_corr.rowid) AND corr_sn2_new.tar_grp_new = $6 
		LEFT JOIN bee_docs_corr  AS corr_sn2_old ON (corr_sn2_old.rowid=doc_corr.rowid) AND corr_sn2_old.tar_grp_old = $6
		LEFT JOIN bee_docs_corr  AS corr_nn_new ON (corr_nn_new.rowid=doc_corr.rowid) AND corr_nn_new.tar_grp_new = $7
		LEFT JOIN bee_docs_corr  AS corr_nn_old ON (corr_nn_old.rowid=doc_corr.rowid) AND corr_nn_old.tar_grp_old = $7
		    WHERE true 
			--AND am.docstatus = '79'			/*действующий договор*/
		      --AND (am.docstatus = 79 OR am.docstatus = 77 AND am.closedate >= s_date ) --2015-06-30
		      AND am.doctype = 1910 --2016-03-03
		      AND bee_is_agreement_get_to_report(am.rowid, s_date) -- 2015-07-14
		      AND am.accdir NOT IN ( 835, 836, 832, 837, 838, 839, 840, 841, 842,1623) 
		      AND am.locid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)	
		    GROUP BY  data,am.rowid, cust.abo_name, am.docnumber 
		   ORDER BY data, am.docnumber)
	LOOP
		RETURN NEXT RowLine;
	END LOOP;								
END;
$$;

comment on function bee_rep_get_repdata24_corr1_cust(integer, date, date, integer, integer, integer, integer) is 'Ведомость по объему услуг. Используется bee_rep_get_repdata24_cont_cust1(int, date, date)';

alter function bee_rep_get_repdata24_corr1_cust(integer, date, date, integer, integer, integer, integer) owner to pgsql;

