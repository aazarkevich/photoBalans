create function bee_get_docs_adjustment_docs_list(_linkid integer) returns SETOF docs_adjustment_docs_list
    language plpgsql
as
$$
DECLARE
  rec docs_adjustment_docs_list%rowtype;
  
 BEGIN
   /*
    add ito06 2019-10-03 добавили поле дата корректируемого документа
    * */
  FOR rec IN (
		select DISTINCT
			dic.element_name ||' '||cst.consum_name,
			amn.docnumber,
			dic_doc.element_name,
			doc.docnum,
			doc.docdat,
			doc.rowid,
			doc.linkid, 
			bdc.period --2019-10-03
			
		   FROM dic_elements AS dic
		JOIN customer AS cst ON cst.urstatus=dic.rowid
		JOIN agreement AS amn ON amn.abo_code=cst.abo_code
		JOIN bee_docs AS doc ON doc.linkid=amn.rowid
		JOIN dic_prefix AS pref ON pref.locid = cst.locid
		JOIN dic_elements AS dic_doc ON pref.prefix=dic_doc.rowid
		join bee_docs_corr as bdc on bdc.linkid2 = doc.rowid --2019-10-03
		WHERE doc.linkid=_linkid
			AND doc.doctyp=1618
                ORDER BY doc.linkid ASC, doc.docdat DESC
	)
	LOOP
		RETURN NEXT rec;
	END LOOP;
	
END;
$$;

comment on function bee_get_docs_adjustment_docs_list(integer) is 'Используется в DocsAdjustment.java, SessionBean1.java';

alter function bee_get_docs_adjustment_docs_list(integer) owner to postgres;

