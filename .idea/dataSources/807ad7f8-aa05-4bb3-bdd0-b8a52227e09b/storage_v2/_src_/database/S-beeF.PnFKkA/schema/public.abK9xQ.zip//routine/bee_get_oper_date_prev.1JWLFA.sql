create function bee_get_oper_date_prev(integer, date) returns date
    language sql
as
$$
SELECT MAX(operdate) FROM regdevoper WHERE linkid = $1 AND operdate < $2;
$$;

comment on function bee_get_oper_date_prev(integer, date) is 'Используется в OperVal.java, AppUtils.java; vbee_oper_values, vbee_get_opervalues_buf';

alter function bee_get_oper_date_prev(integer, date) owner to pgsql;

