create function bee_rep_get_repdata30_create_tmp_table(loc_id integer, d_start date, d_end date) returns integer
    language plpgsql
as
$$
/*
   ito07 2019-02-28 
	ito06 2015-02-02 Сводная реализация электроэнергии, создает временную таблицу.
*/
	
BEGIN
	EXECUTE 
	 'create TEMPORARY table bee_rep_get_repdata30_tmp AS
	 SELECT U.*
	   FROM	(
         (SELECT * FROM bee_rep_get_repdata30_tmpUr('||$1||','''||$2||''','''||$3||'''))
          union 
         (SELECT * FROM bee_rep_get_repdata30_tmpMix('||$1||','''||$2||''','''||$3||'''))  
          union 
         (SELECT * FROM bee_rep_get_repdata30_tmpUni('||$1||','''||$2||''','''||$3||'''))                                
      ) AS U;';
    EXECUTE  
     'CREATE TEMPORARY TABLE bee_rep_get_repdata30_period_tmp AS 
      SELECT U.*
      FROM 
      (SELECT ' || $1 || ' as loc_id' || ','''||$2||''' as dat1 ,'''||$3||''' as dat2) AS U;';
 
	RETURN 0;
END;
$$;

comment on function bee_rep_get_repdata30_create_tmp_table(integer, date, date) is 'Сводная реализация по объему услуг. Используется в bee_rep_get_repdata30_all(int, date, date, boolean, boolean, boolean)';

alter function bee_rep_get_repdata30_create_tmp_table(integer, date, date) owner to postgres;

