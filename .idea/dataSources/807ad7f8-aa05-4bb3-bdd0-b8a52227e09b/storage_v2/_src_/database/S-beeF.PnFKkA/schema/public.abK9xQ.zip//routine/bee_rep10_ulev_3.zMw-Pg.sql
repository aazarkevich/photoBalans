create function bee_rep10_ulev_3(locid integer, strdate date, ulev character varying, trm_filter character varying, accdir_filter character varying, cd_filter character varying, sd_filter character varying) returns SETOF bee_rep_tab10
    language plpgsql
as
$$
/*
  	add ito06 2021-02-15 должны попадать расторгнутые
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2012-12-18
	ito06 2012-05-15 Приложение 1 Пустая таблица
*/
DECLARE
 tmp_kod varchar;
 rec bee_rep_tab10%rowtype;

BEGIN 
 select kod from denet where rowid=$1 into tmp_kod;

FOR rec IN (
   SELECT dn.nam AS fil,   		    -- филиал
          denet.nam AS loc,  		-- участок
	  amn.docnumber AS docnumber,
	  apn.account || ', '|| apn.prodnumber || ', ' || ard3.paramval || ', ' || ard4.paramval AS account,
          de.element_name AS ulev,
	  null::numeric (10,4) AS summ_el,
          null::numeric (10,4) AS summ1,
	  null::numeric (10,4) AS summ2,
	  null::numeric (10,4) AS summ3,
	  null::numeric (10,4) AS summ4,
	  null::numeric (10,4) AS summ5,
	  null::numeric (10,4) AS summ6,
	  null::numeric (10,4) AS summ7,
	  null::numeric (10,4) AS summ8,
	  null::numeric (10,4) AS summ9,
	  null::numeric (10,4) AS summ10,
	  null::numeric (10,4) AS summ11,
	  null::numeric (10,4) AS summ12,
	  null::numeric (10,4) AS summ_pow,
	  null::numeric (10,4) AS summ1_,
	  null::numeric (10,4) AS summ2_,
	  null::numeric (10,4) AS summ3_,
	  null::numeric (10,4)  AS summ4_,
	  null::numeric (10,4)  AS summ5_,
	  null::numeric (10,4)  AS summ6_,
	  null::numeric (10,4)  AS summ7_,
	  null::numeric (10,4)  AS summ8_,
	  null::numeric (10,4)  AS summ9_,
	  null::numeric (10,4)  AS summ10_,
	  null::numeric (10,4)  AS summ11_,
	  null::numeric (10,4)  AS summ12_,
	  replace(ard6.paramval,',','.') AS max,
	  replace(ard5.paramval,',','.') AS pris,
          char_length(docnumber) AS dl,
	  char_length(account) AS al
     FROM customer AS cust 	  
	 --ito06 2021-02-15      JOIN agreement   AS amn  ON amn.abo_code = cust.abo_code  AND amn.docstatus = 79  AND amn.accdir NOT IN (319,538,1110,1476) 
     JOIN agreement   AS amn  ON amn.abo_code = cust.abo_code  AND amn.docstatus in (77, 79)  AND amn.accdir NOT IN (319,538,1110,1476) 
                             AND amn.locid IN (select rowid from denet where (kod ~ tmp_kod and length(tmp_kod)<=6)
                                                                           or (kod = tmp_kod and length(tmp_kod)>6)) 
                           --AND amn.locid IN (select rowid from denet where kod ~ (select kod from denet where rowid=$1)) 
     JOIN agreepoint  AS apn  ON amn.rowid = apn.linkid AND apn.devtype=644
     JOIN denet ON apn.lid=denet.rowid
LEFT JOIN (SELECT nam, kod FROM denet WHERE length(kod)=6) as dn ON substring(denet.kod, 0, 7)=dn.kod
     JOIN bee_rep_get_ard_per_max(439) AS ard  ON apn.rowid = ard.linkid  AND ard.paramval=$3  -- уровень напряжения
     JOIN dic_elements as de on de.rowid = ard.paramval::numeric(3)
     JOIN agreeregdev AS ard1 ON apn.rowid = ard1.linkid AND ard1.paramid=189 AND ard1.paramval='432' -- вид учёта*
LEFT JOIN agreeregdev AS ard2 ON apn.rowid = ard2.linkid AND ard2.paramid=690 AND is_date(ard2.paramval)
     JOIN agreeregdev AS ard3 ON ard3.linkid=apn.rowid AND ard3.paramid=418 -- запитанный объект*
     JOIN agreeregdev AS ard4 ON ard4.linkid=apn.rowid AND ard4.paramid=410 -- адрес запитанного объекта*
LEFT JOIN agreeregdev AS ard5 ON ard5.linkid=apn.rowid AND ard5.paramid=685 AND ard5.paramval~E'^\\d{1,}' -- присоединенная мощность
LEFT JOIN agreeregdev AS ard6 ON ard6.linkid=apn.rowid AND ard6.paramid=426 AND ard6.paramval~E'^\\d{1,}' -- макс. мощность (по договору)
    
    
LEFT JOIN (SELECT ap.rowid AS rowid,
                  CASE WHEN a.paramid = 1535     
                         THEN true ELSE false
                  END AS cd
            FROM agreepoint as ap 
       LEFT JOIN (SELECT linkid,    
                          max(period) AS period   
	             FROM agreeregdev_period  
	            WHERE paramid = 1535  
	            GROUP BY linkid
	         ) AS max_per_cd  ON max_per_cd.linkid = ap.rowid   
       LEFT JOIN agreeregdev_period AS a ON ap.rowid = a.linkid AND a.paramid = 1535 AND max_per_cd.period = a.period 
           GROUP BY ap.rowid, a.paramid
           ORDER BY ap.rowid
           ) AS cd_filter ON cd_filter.rowid = apn.rowid
LEFT JOIN ( SELECT ap.rowid AS rowid,
                   CASE WHEN b.paramid = 1614     
                      THEN true ELSE false
                   END AS sd
              FROM agreepoint as ap 
         LEFT JOIN ( SELECT linkid,    
                            max(period) AS period   
	               FROM agreeregdev_period  
	              WHERE paramid = 1614  
	              GROUP BY linkid
	           ) AS max_per_sd  ON max_per_sd.linkid = ap.rowid   
         LEFT JOIN agreeregdev_period AS b ON ap.rowid = b.linkid AND b.paramid = 1614 AND max_per_sd.period = b.period 
             GROUP BY ap.rowid,  b.paramid
             ORDER BY ap.rowid
          ) AS sd_filter ON sd_filter.rowid = apn.rowid
   WHERE  (ard2.paramval IS NULL OR ard2.paramval::date >= to_char($2,'YYYY-mm-01')::date - '11 month'::interval) 
      AND (amn.accdir = 317) IN
            (CASE WHEN $5 = 'a' 
                THEN 'f'::boolean ELSE $5::boolean
             END,
             CASE WHEN $5 = 'a' 
               THEN 't'::boolean  ELSE $5::boolean
             END) 
        AND (amn.doctype = 1910) IN --** 2016-04-25
            (CASE WHEN $4 = 'a' 
                THEN 'f'::boolean ELSE $4::boolean
             END,
             CASE WHEN $4 = 'a' 
               THEN 't'::boolean ELSE $4::boolean
             END)
     AND cd_filter.cd  IN
           (CASE  WHEN $6 = 'a' 
              THEN 'f'::boolean ELSE $6::boolean
            END,
            CASE  WHEN $6 = 'a' 
              THEN 't'::boolean  ELSE $6::boolean
            END) 
     AND sd_filter.sd  IN
           (CASE WHEN $7 = 'a' 
              THEN 'f'::boolean ELSE $7::boolean
            END,
            CASE WHEN $7 = 'a' 
              THEN 't'::boolean ELSE $7::boolean
             END) 
ORDER BY dl, docnumber, fil, loc, al,account
) LOOP 
RETURN NEXT rec;

END LOOP; 
END;
$$;

comment on function bee_rep10_ulev_3(integer, date, varchar, varchar, varchar, varchar, varchar) is 'Приложение 1 Пустая таблица. Используется в bee_rep_get_repdata10(int, date, varchar, varchar, varchar, varchar, int)';

alter function bee_rep10_ulev_3(integer, date, varchar, varchar, varchar, varchar, varchar) owner to pgsql;

