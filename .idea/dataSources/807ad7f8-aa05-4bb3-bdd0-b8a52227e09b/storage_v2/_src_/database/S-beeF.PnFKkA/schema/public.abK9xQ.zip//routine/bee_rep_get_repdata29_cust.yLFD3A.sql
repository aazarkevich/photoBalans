create function bee_rep_get_repdata29_cust(locid character varying, sdate date) returns SETOF bee_repdata29
    language plpgsql
as
$$
DECLARE rec bee_repdata29%rowtype;
/*
	ito06 2015-01-21 Сводная ведомость по объему услуг развернутая по потребителям
*/
BEGIN
	FOR rec IN (
		       (SELECT * FROM bee_rep_get_repdata29_tot($1,$2))	  
		UNION  (SELECT 	CASE 
				   WHEN grp IN (312,322,332,313,323,333)				   
				      THEN substring(grp::varchar from 1 for 2)||'40'
				   ELSE  (grp*10)::varchar
				END	 						AS sort1,
				CASE 
				   WHEN grp IN (312,322,332,313,323,333)				   
				      THEN substring(grp::varchar from 1 for 2)||'40'
				   ELSE  (grp*10)::varchar
				END	 						AS sort,
				'norm'::text 						AS row_style,
				null::varchar						AS fil,
				amnid 							AS amnid,
				CASE 
				   WHEN grp IN (312,322,332)
				      THEN 'потреблено в пределах социальной нормы'
				   WHEN grp IN (313,323,333)
				      THEN 'потреблено сверх социальной нормы'
				   ELSE  doc_name
				END	 						AS doc_name,
				doc_name						AS docsort,
				null::text						AS npp,
				null::numeric 						AS tar_vn,
				null::numeric 						AS tar_sn1,
				null::numeric 						AS tar_sn2,
				null::numeric 						AS tar_nn,
				null::numeric 						AS tar_m_tot,
				null::numeric 						AS tar_m_vn,
				null::numeric 						AS tar_m_sn1,
				null::numeric 						AS tar_m_sn2,
				null::numeric 						AS tar_m_nn,
				tot_amount 						AS tot_amount,		
				vn_amount						AS vn_amount,
				sn1_amount						AS sn1_amount,
				sn2_amount						AS sn2_amount,
				nn_amount						AS nn_amount,
				tot_sum							AS tot_sum,
				vn_sum							AS vn_sum,
				sn1_sum							AS sn1_sum,
				sn2_sum							AS sn2_sum,
				nn_sum							AS nn_sum
			  from bee_rep_get_repdata29_tmp WHERE fil like $1)
		UNION  (SELECT 	'3140' 							AS sort1,
				'3140' 							AS sort,
				'norm'::text 						AS row_style,
				null::varchar						AS fil,
				amnid 							AS amnid,
				doc_name						AS doc_name,
				doc_name	 					AS docsort,
				null::text						AS npp,
				null::numeric 						AS tar_vn,
				null::numeric 						AS tar_sn1,
				null::numeric 						AS tar_sn2,
				null::numeric 						AS tar_nn,
				null::numeric 						AS tar_m_tot,
				null::numeric 						AS tar_m_vn,
				null::numeric 						AS tar_m_sn1,
				null::numeric 						AS tar_m_sn2,
				null::numeric 						AS tar_m_nn,
				sum(tot_amount) 					AS tot_amount,		
				sum(vn_amount)						AS vn_amount,
				sum(sn1_amount)						AS sn1_amount,
				sum(sn2_amount)						AS sn2_amount,
				sum(nn_amount)						AS nn_amount,
				sum(tot_sum)						AS tot_sum,
				sum(vn_sum)						AS vn_sum,
				sum(sn1_sum)						AS sn1_sum,
				sum(sn2_sum)						AS sn2_sum,
				sum(nn_sum)						AS nn_sum
			  from bee_rep_get_repdata29_tmp where grp IN (311,312,313) AND fil like $1
			  group by doc_name,amnid )
		UNION  (SELECT 	'3240' 							AS sort1,
				'3240' 							AS sort,
				'norm'::text 						AS row_style,
				null::varchar						AS fil,
				amnid 							AS amnid,
				doc_name						AS doc_name,
				doc_name	 					AS docsort,
				null::text						AS npp,
				null::numeric 						AS tar_vn,
				null::numeric 						AS tar_sn1,
				null::numeric 						AS tar_sn2,
				null::numeric 						AS tar_nn,
				null::numeric 						AS tar_m_tot,
				null::numeric 						AS tar_m_vn,
				null::numeric 						AS tar_m_sn1,
				null::numeric 						AS tar_m_sn2,
				null::numeric 						AS tar_m_nn,
				sum(tot_amount) 					AS tot_amount,		
				sum(vn_amount)						AS vn_amount,
				sum(sn1_amount)						AS sn1_amount,
				sum(sn2_amount)						AS sn2_amount,
				sum(nn_amount)						AS nn_amount,
				sum(tot_sum)						AS tot_sum,
				sum(vn_sum)						AS vn_sum,
				sum(sn1_sum)						AS sn1_sum,
				sum(sn2_sum)						AS sn2_sum,
				sum(nn_sum)						AS nn_sum
			  from bee_rep_get_repdata29_tmp where grp IN (321,322,323) AND fil like $1
			  group by doc_name,amnid )
		UNION  (SELECT 	'3340' 							AS sort1,
				'3340' 							AS sort,
				'norm'::text 						AS row_style,
				null::varchar						AS fil,
				amnid 							AS amnid,
				doc_name						AS doc_name,
				doc_name	 					AS docsort,
				null::text						AS npp,
				null::numeric 						AS tar_vn,
				null::numeric 						AS tar_sn1,
				null::numeric 						AS tar_sn2,
				null::numeric 						AS tar_nn,
				null::numeric 						AS tar_m_tot,
				null::numeric 						AS tar_m_vn,
				null::numeric 						AS tar_m_sn1,
				null::numeric 						AS tar_m_sn2,
				null::numeric 						AS tar_m_nn,
				sum(tot_amount) 					AS tot_amount,		
				sum(vn_amount)						AS vn_amount,
				sum(sn1_amount)						AS sn1_amount,
				sum(sn2_amount)						AS sn2_amount,
				sum(nn_amount)						AS nn_amount,
				sum(tot_sum)						AS tot_sum,
				sum(vn_sum)						AS vn_sum,
				sum(sn1_sum)						AS sn1_sum,
				sum(sn2_sum)						AS sn2_sum,
				sum(nn_sum)						AS nn_sum
			  from bee_rep_get_repdata29_tmp where grp IN (331,332,333) AND fil like $1
			  group by doc_name,amnid )			  			  	
								    
		order by sort1,  sort, docsort,doc_name )
	LOOP	
		IF (rec.sort not in ('31', '32', '33', '421', '422', '423') AND substring(rec.sort from length(rec.sort) for 1)<>'b') 
		   THEN
		      IF  rec.tot_amount IS NOT NULL AND rec.tot_sum IS NOT NULL AND rec.tot_amount<>0 THEN rec.tar_m_tot=(rec.tot_sum/rec.tot_amount)::numeric(20,6); END IF;
		      IF  rec.vn_amount  IS NOT NULL AND rec.vn_sum  IS NOT NULL AND rec.vn_amount<>0  THEN rec.tar_m_vn =(rec.vn_sum/rec.vn_amount)::numeric(20,6);   END IF;
		      IF  rec.sn1_amount IS NOT NULL AND rec.sn1_sum IS NOT NULL AND rec.sn1_amount<>0 THEN rec.tar_m_sn1=(rec.sn1_sum/rec.sn1_amount)::numeric(20,6); END IF;
		      IF  rec.sn2_amount IS NOT NULL AND rec.sn2_sum IS NOT NULL AND rec.sn2_amount<>0 THEN rec.tar_m_sn2=(rec.sn2_sum/rec.sn2_amount)::numeric(20,6); END IF;
		      IF  rec.nn_amount  IS NOT NULL AND rec.nn_sum  IS NOT NULL AND rec.nn_amount<>0  THEN rec.tar_m_nn =(rec.nn_sum/rec.nn_amount)::numeric(20,6);   END IF;
		END IF;	
		rec.fil =  $1;
		RETURN NEXT rec;		
	END LOOP;
END;
$$;

comment on function bee_rep_get_repdata29_cust(varchar, date) is 'Сводная ведомость по объему услуг развернутая по потребителям. Используется в bee_rep_get_repdata29_all(int, date, date, boolean, boolean, boolean)';

alter function bee_rep_get_repdata29_cust(varchar, date) owner to pgsql;

