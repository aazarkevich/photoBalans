create function aaa_restore() returns void
    language plpgsql
as
$$
DECLARE
    R RECORD;
    R29 RECORD;
    CurRef  integer;
    ParRowId integer;
BEGIN
    FOR R IN (
       -- select refs  
       select distinct  
            P.paramval::integer as oldref
      from agreeregdev_period as P  
      where
           P.paramid = 664 and 
           length(P.paramval) > 9 
      order by P.paramval::integer  
    )
    LOOP
      -- select from old by ref 
      select B.linkid,B.devid,B.account,B.prodnumber,B.devtype,B.deleted,B.lid 
      from agreepoint29 as B
      where 
         B.rowid = R.oldref 
      into R29;

      if R29 is null then continue; end if;

      if R29 is not null then 
        select distinct A.rowid 
        from agreepoint as A
        where 
           R29.linkid     = A.linkid     and  
           R29.devid      = A.devid      AND
           R29.account    = A.account    And
           R29.prodnumber = A.prodnumber and
           R29.devtype    = A.devtype    and
           R29.deleted    = A.deleted    and
           R29.lid        = A.lid limit 1        
        into CurRef; -- current point id agreepoint.rowid
        
        if (CurRef is NOT null) and ( CurRef <> R.oldref) then        
           --raise notice '%:%',CurRef,R.oldref;
        else
           continue;
        end if;    

        select distinct rowid from agreeregdev_period
        where 
           paramid  = 664 
           and length(paramval) > 9
           and paramval::integer = R.oldref 
           limit 1
        into ParRowId;

        update agreeregdev_period set paramval = CurRef::varchar where rowid = ParRowId and paramid = 664;
        ---
        raise notice '******** : %:%===%',CurRef,R.oldref,ParRowId;

      end if;  
       
    END LOOP;
END;
$$;

alter function aaa_restore() owner to pgsql;

