create function bee_get_billadvance_rowid(bdrowid integer) returns integer
    language plpgsql
as
$$
/*
	ito06 2015-04-29
	Получить rowid документа "счет на предоплату" по rowid документа выставления, на месяц следующий за месяцем в котором было выставление
*/
DECLARE
	rowidavd int;
	bddat date;
	amnid int;
	next_month_first_day DATE;
	next_month_last_day DATE;
BEGIN
	SELECT docdat, linkid FROM bee_docs WHERE rowid = bdrowid LIMIT 1 INTO bddat, amnid;
	
	SELECT (date_trunc('month', bddat) +  INTERVAL '1 month'  )::DATE INTO next_month_first_day;
	SELECT (date_trunc('month', bddat) +  INTERVAL '2 month' - INTERVAL '1 day' )::DATE INTO next_month_last_day;

	SELECT linkid1 FROM bee_docs_advance_t WHERE linkid2  = amnid AND date_ava BETWEEN next_month_first_day AND next_month_last_day LIMIT 1 INTO rowidavd;
	
	IF rowidavd IS NULL
		THEN RETURN -1;
		ELSE RETURN rowidavd;
	END IF;
END;

$$;

comment on function bee_get_billadvance_rowid(integer) is 'Используется в GroupDocsProcessing.java, AppUtils.java';

alter function bee_get_billadvance_rowid(integer) owner to pgsql;

