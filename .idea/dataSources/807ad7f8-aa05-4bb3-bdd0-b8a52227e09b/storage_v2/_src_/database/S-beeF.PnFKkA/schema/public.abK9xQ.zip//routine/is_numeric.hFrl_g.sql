create function is_numeric(val character varying) returns boolean
    language plpgsql
as
$$
BEGIN
      RETURN (SELECT ( 
            trim(val) ~ E'^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$'
  ));
END;
$$;

alter function is_numeric(varchar) owner to pgsql;

