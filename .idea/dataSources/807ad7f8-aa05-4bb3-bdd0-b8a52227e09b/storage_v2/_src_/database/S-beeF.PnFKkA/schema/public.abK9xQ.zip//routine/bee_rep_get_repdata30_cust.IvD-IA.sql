create function bee_rep_get_repdata30_cust(_host character varying) returns SETOF bee_repdata30
    language plpgsql
as
$$
/*
    ito07 2019-06-24 d_end_sum k_end_sum
	add ito06 2015-09-30 Изменили названия колонок для  разделителя
	add ito06 2015-05-12
	ito06 2015-02-02: Сводная реализация электроэнергии, развернутая по потребителю
*/
DECLARE RowLine bee_repdata30%rowtype;
BEGIN     

-- (1 + bee_get_doc_tax(1163, bd_rowid ) 1.XX
	FOR RowLine IN (
		(SELECT 'bold' 				AS row_style,
			null::varchar 				AS nn,
			'01' 						   AS nn1,
			'ВСЕГО'  					AS name,
			row.*,
			null::smallint 			AS accdir,
			null::int					AS loc,
			'ВСЕГО'  					AS ord
		FROM bee_rep_get_repdata30_summ(0,$1) AS row)
	UNION 
		(SELECT 'bold' 				AS row_style,
			'1' 							AS nn,
			'10' 							AS nn1,
			'Прочие потребители'  	AS name,
			row.*,
			null::smallint				AS accdir,
			null::int					AS loc,
			'Прочие потребители'  	AS ord
		    FROM bee_rep_get_repdata30_summ(10,$1) AS row)
	UNION 
		(SELECT 'norm' 				AS row_style,
			null::varchar 				AS nn,
			'100' 						AS nn1,
			CASE 
			    WHEN npp = 1 
				THEN  doc_num||', '||abo_num 
			    WHEN npp = 2 
				THEN  'в т.ч. юр.лица'
			    WHEN npp = 3 
				THEN  'в т.ч. население в пределах соц. нормы' 
			    WHEN npp = 4 
				THEN  'в т.ч. население свыше соц. нормы'   
			END     					AS name, 
			d_start_sum 				AS d_start_sum, 
			k_start_sum 				AS k_start_sum,  
			amount  					AS amount,   
			amount1 					AS amount1,  
			amount2 					AS amount2,  

			sum_with_tax      			AS sum_with_tax,
			sum_no_tax 					AS sum_no_tax,
			
			sum_with_tax1068    		AS sum_with_tax1068,
			sum_no_tax1068				AS sum_no_tax1068,
			
			sum_with_tax1069            AS sum_with_tax1069,    
			sum_no_tax1069 			    AS sum_no_tax1069,

			tar 						AS tar, 
			fact_all_sum 				AS fact_all_sum,
			payed_sum 					AS payed_sum,
			
			retrest_sum 				AS retrest_sum,
			
			disc_sum 					AS disc_sum,
			
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else d_end_sum
			end as d_end_sum,
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else k_end_sum
			end as k_end_sum,

-- as example of calculation for d_end_sum k_end_sum			
--			d_start_sum + sum_with_tax + coalesce(fact_all_sum,0) - coalesce(fact_adv_sum,0) - coalesce(disc_sum,0) AS d_end_sum,
--			k_start_sum - sum_with_tax + coalesce(fact_all_sum,0) + coalesce(retrest_sum,0)                         AS k_end_sum,
			
			pay_all_sum 				AS pay_all_sum,
			fact_adv_sum 				AS fact_adv_sum,
			ext_sum 					AS ext_sum,
			_host						AS host,
			accdir 						AS accdir,
			loc							AS loc,
			doc_num||', '||abo_num || ', ' ||npp  			AS ord
		   FROM bee_rep_get_repdata30_tmp 
		  WHERE accdir NOT IN (
		     835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND 
		     host like _host AND host NOT IN ('beex', 'localhost')
		)
	UNION
		(SELECT 'bold' 							AS row_style,
			'2' 							AS nn,
			'20' 							AS nn1,
			'Бюджетные потребители' AS name,  
			row.*,
			null::smallint				AS accdir,
			null::int					AS loc,
			'Бюджетные потребители' 				AS ord
		FROM bee_rep_get_repdata30_summ(20,$1) AS row)
	UNION 
		(SELECT 'bold' 							AS row_style,
			'2.1'  						AS nn,
			'21'  						AS nn1,
			'-федеральный бюджет'  	AS name,
			row.*,
			null::smallint				AS accdir,
			null::int					AS loc,
			'-областной бюджет'  	AS ord
		FROM bee_rep_get_repdata30_summ(21,$1) AS row)
	UNION 
		(SELECT 'norm' 				AS row_style,
			null::varchar 				AS nn,
			'210' 						AS nn1,
			CASE 
			    WHEN npp = 1 
				THEN  doc_num||', '||abo_num 
			    WHEN npp = 2 
				THEN  'в т.ч. юр.лица'
			    WHEN npp = 3 
				THEN  'в т.ч. население в пределах соц. нормы' 
			    WHEN npp = 4 
				THEN  'в т.ч. население свыше соц. нормы'   
			END     						AS name,  
			d_start_sum 				AS d_start_sum, 
			k_start_sum 				AS k_start_sum,  
			amount  						AS amount,   
			amount1 						AS amount1,  
			amount2 						AS amount2,  
            sum_with_tax               AS sum_with_tax,
			sum_no_tax 						AS sum_no_tax,
            sum_with_tax1068           as sum_with_tax1068, 
			sum_no_tax1068					AS sum_no_tax1068,
			sum_with_tax1069           AS sum_with_tax1069,
			sum_no_tax1069 				AS sum_no_tax1069,

			tar 							AS tar, 
			fact_all_sum 				AS fact_all_sum,
			payed_sum 					AS payed_sum,
			retrest_sum 				AS retrest_sum,
			disc_sum 					AS disc_sum,

--			d_end_sum 					AS d_end_sum,
--			k_end_sum 					AS k_end_sum,
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else d_end_sum
			end as d_end_sum,
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else k_end_sum
			end as k_end_sum,
			
			pay_all_sum 				AS  pay_all_sum,
			fact_adv_sum 				AS fact_adv_sum,
			ext_sum 						AS ext_sum,
			_host							AS host,
			accdir 						AS accdir,
			loc							AS loc,
			doc_num||', '||abo_num || ', ' ||npp  			AS ord
		   FROM bee_rep_get_repdata30_tmp 
		  WHERE accdir  =  835 AND host like _host AND host NOT IN ('beex', 'localhost'))
	UNION 
		(SELECT 'bold' 				AS row_style,
			'2.2' 						AS nn,
			'22' 							AS nn1,
			'-областной бюджет'  	AS name,
			row.*,
			null::smallint				AS accdir,
			null::int					AS loc,
			'-областной бюджет' 		AS ord
		FROM bee_rep_get_repdata30_summ(22,$1) AS row)
	UNION 
		(SELECT 'norm' 				AS row_style,
			null::varchar 				AS nn,
			'220' 						AS nn1,
			CASE 
			    WHEN npp = 1 
				THEN  doc_num||', '||abo_num 
			    WHEN npp = 2 
				THEN  'в т.ч. юр.лица'
			    WHEN npp = 3 
				THEN  'в т.ч. население в пределах соц. нормы' 
			    WHEN npp = 4 
				THEN  'в т.ч. население свыше соц. нормы'   
			END     						AS name,  
			d_start_sum 				AS d_start_sum, 
			k_start_sum 				AS k_start_sum,  
			amount  						AS amount,   
			amount1 						AS amount1,  
			amount2 						AS amount2,  

			sum_with_tax               as sum_with_tax,
			sum_no_tax 						AS sum_no_tax,
            sum_with_tax1068           as sum_with_tax1068,
 			sum_no_tax1068					AS sum_no_tax1068,
			sum_with_tax1069           as sum_with_tax1069,
			sum_no_tax1069 				AS sum_no_tax1069,

			tar 							AS tar, 
			fact_all_sum 				AS fact_all_sum,		
			payed_sum					AS payed_sum,
			retrest_sum 				AS retrest_sum,
			disc_sum 					AS disc_sum,

--			d_end_sum 					AS d_end_sum,
--			k_end_sum 					AS k_end_sum,
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else d_end_sum
			end as d_end_sum,
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else k_end_sum
			end as k_end_sum,
			
			
			pay_all_sum 				AS pay_all_sum,
			fact_adv_sum 				AS fact_adv_sum,
			ext_sum 						AS ext_sum,
			_host							AS host,
			accdir 						AS accdir,
			loc							AS loc,
			doc_num||', '||abo_num || ', ' ||npp 			AS ord
		   FROM bee_rep_get_repdata30_tmp 
		  WHERE accdir  =  836 AND host like _host AND host NOT IN ('beex', 'localhost'))
	UNION
		(SELECT 'bold' 				AS row_style,
			'2.3'							AS nn,
			'23' 							AS nn1,
			'-местный бюджет'  		AS name,
			row.*,
			null::smallint				AS accdir,
			null::int					AS loc,
			'-местный бюджет' 					AS ord
		FROM bee_rep_get_repdata30_summ(23,$1) AS row)
	UNION
		(SELECT 'bold' 				AS row_style,
			'2.3.1' 						AS nn,
			'231' 						AS nn1,
			'--юр. лица'  				AS name,
			row.*,
			null::smallint				AS accdir,
			null::int					AS loc,
			'--юр. лица' 				AS order_nam
		FROM bee_rep_get_repdata30_summ(231,$1) AS row)
	UNION 
		(SELECT 'norm' 				AS row_style,
			null::varchar 				AS nn,
			'2310' 						AS nn1,
			CASE 
			    WHEN npp = 1 
				THEN  doc_num||', '||abo_num 
			    WHEN npp = 2 
				THEN  'в т.ч. юр.лица'
			    WHEN npp = 3 
				THEN  'в т.ч. население в пределах соц. нормы' 
			    WHEN npp = 4 
				THEN  'в т.ч. население свыше соц. нормы'   
			END     						AS name,  
			d_start_sum 				AS d_start_sum, 
			k_start_sum 				AS k_start_sum,  
			amount  						AS amount,   
			amount1 						AS amount1,  
			amount2 						AS amount2,  

            sum_with_tax               as sum_with_tax,
			sum_no_tax 						AS sum_no_tax,
			sum_with_tax1068           as sum_with_tax1068,  
			sum_no_tax1068					AS sum_no_tax1068,
			
			sum_with_tax1069           as sum_with_tax1069,
			sum_no_tax1069 				AS sum_no_tax1069,

			tar 							AS tar, 
			fact_all_sum 				AS  fact_all_sum,		
			payed_sum 					AS payed_sum,
			retrest_sum 				AS retrest_sum,
			disc_sum 					AS disc_sum,

--			d_end_sum 					AS d_end_sum,
--			k_end_sum 					AS k_end_sum,
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else d_end_sum
			end as d_end_sum,
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else k_end_sum
			end as k_end_sum,

			
			pay_all_sum 				AS pay_all_sum,
			fact_adv_sum 				AS fact_adv_sum,
			ext_sum 						AS ext_sum,
			_host							AS host,
			accdir 						AS accdir,
			null::int					AS loc,
			doc_num||', '||abo_num || ', ' ||npp 			AS ord

		   FROM bee_rep_get_repdata30_tmp 
		  WHERE accdir IN (832, 837, 838, 839, 840, 841, 842) AND host like _host AND host NOT IN ('beex', 'localhost'))
	UNION 
		(SELECT 'bold' 				AS row_style,
			'2.3.2' 						AS nn,
			'232'  						AS nn1,
			'--уличное освещение'  	AS name,
			row.*,
			null::smallint 			AS accdir,
			null::int					AS loc,
			'--уличное освещение'  	AS ord
		FROM bee_rep_get_repdata30_summ(232,$1) AS row)
	UNION 
		(SELECT 'norm'  				AS row_style,
			null::varchar  			AS nn,
			'2320'  						AS nn1,
			CASE 
			    WHEN npp = 1 
				THEN  doc_num||', '||abo_num 
			    WHEN npp = 2 
				THEN  'в т.ч. юр.лица'
			    WHEN npp = 3 
				THEN  'в т.ч. население в пределах соц. нормы' 
			    WHEN npp = 4 
				THEN  'в т.ч. население свыше соц. нормы'   
			END      						AS name, 
			d_start_sum  					AS d_start_sum, 
			k_start_sum  					AS k_start_sum,  
			amount   						AS  amount,   
			amount1  						AS amount1,  
			amount2  						AS amount2,  

			sum_with_tax               as sum_with_tax,
			sum_no_tax 						AS sum_no_tax,

            sum_with_tax1068           as sum_with_tax1068,  
			sum_no_tax1068					AS sum_no_tax1068,
			
			sum_with_tax1069           as sum_with_tax1069, 
			sum_no_tax1069 				AS sum_no_tax1069,

			tar  							   AS tar, 
			fact_all_sum  					AS  fact_all_sum,		
			payed_sum  						AS payed_sum,
			retrest_sum  					AS retrest_sum,
			disc_sum  						AS disc_sum,
--			d_end_sum  						AS d_end_sum,
--			k_end_sum  						AS k_end_sum,
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else d_end_sum
			end as d_end_sum,
            case when d_end_sum = k_end_sum 
                 then 0.00
                 else k_end_sum
			end as k_end_sum,

			pay_all_sum  					AS pay_all_sum,
			fact_adv_sum  					AS fact_adv_sum,
			ext_sum  						AS ext_sum,
			_host							   AS host,
			accdir 							AS accdir,
			loc							   AS loc,
			doc_num||', '||abo_num || ', ' ||npp 			AS ord		
		   FROM bee_rep_get_repdata30_tmp 	        
		  WHERE accdir = 1623 AND host like _host AND host NOT IN ('beex', 'localhost'))
		 UNION (SELECT 'bold' 			AS row_style,
				'3' 							AS nn,
				'3' 							AS nn1,
				'Централизованные договоры' 				AS name,
				row.*,
				null::smallint					AS accdir,
				null::int						AS loc,
				'Централизованные договоры' 				AS ord
			FROM bee_rep_get_repdata30_summ(3,$1) AS row)	
		 UNION (SELECT 'norm' 							AS row_style,
				null::varchar 					AS nn,
				'300' 							AS nn1,
				CASE 
				    WHEN npp = 1 
					THEN  doc_num||', '||abo_num 
				    WHEN npp = 2 
					THEN  'в т.ч. юр.лица'
				    WHEN npp = 3 
					THEN  'в т.ч. население в пределах соц. нормы' 
				    WHEN npp = 4 
					THEN  'в т.ч. население свыше соц. нормы'   
				END     						AS name, 
				d_start_sum 				AS d_start_sum, 
				k_start_sum 				AS k_start_sum,  
				amount  						AS amount,   
				amount1 						AS amount1,  
				amount2 						AS amount2,  

  			    sum_with_tax               as sum_with_tax,
			    sum_no_tax 						AS sum_no_tax,
                sum_with_tax1068           as sum_with_tax1068,
		 	    sum_no_tax1068					AS sum_no_tax1068,
                sum_with_tax1069           as sum_with_tax1069,
			    sum_no_tax1069 				AS sum_no_tax1069,

				tar 							      AS tar, 
				fact_all_sum 						AS fact_all_sum,
				payed_sum 							AS payed_sum,
				retrest_sum 						AS retrest_sum,
				disc_sum 							AS disc_sum,
--				d_end_sum 							AS d_end_sum,
--				k_end_sum 							AS k_end_sum,
                case when d_end_sum = k_end_sum 
                    then 0.00
                    else d_end_sum
			    end as d_end_sum,
                case when d_end_sum = k_end_sum 
                     then 0.00
                     else k_end_sum
			    end as k_end_sum,

				pay_all_sum 						AS pay_all_sum,
				fact_adv_sum 						AS fact_adv_sum,
				ext_sum 							   AS ext_sum,
				_host							      AS host,
				accdir 							   AS accdir,
				loc							      AS loc,
				doc_num||', '||abo_num || ', ' ||npp  			AS ord
			   FROM bee_rep_get_repdata30_tmp 
			  WHERE npp=1 AND host like _host AND host IN ('beex', 'localhost'))			  
		  
	ORDER BY nn1, ord)
        LOOP    
		IF RowLine.amount <> 0 OR RowLine.nn1<>'3'  
		   THEN RETURN  NEXT RowLine;                    
		END IF;
		
	END LOOP;	
END;
$$;

comment on function bee_rep_get_repdata30_cust(varchar) is 'Сводная реализация эл эн. развернуть по потребителям. Используется в bee_rep_get_repdata30_all(int, date, date, varchar) ';

alter function bee_rep_get_repdata30_cust(varchar) owner to pgsql;

