create view vext_get_aboname_by_tag (aboid, agreeid, pointid, aboname, docnum, prodnumber, xaboid, xaboname, tag) as
SELECT customer.abo_code                                                          AS aboid,
       agreement.rowid                                                            AS agreeid,
       agreepoint.rowid                                                           AS pointid,
       customer.consum_name                                                       AS aboname,
       agreement.docnumber                                                        AS docnum,
       agreepoint.prodnumber,
       (regexp_split_to_array((agreeregdev_period.paramval)::text, '_'::text))[1] AS xaboid,
       (regexp_split_to_array((agreeregdev_period.paramval)::text, '_'::text))[2] AS xaboname,
       CASE
           WHEN (agreeregdev_period.paramid = 2037) THEN 'ЭСО'::text
           WHEN (agreeregdev_period.paramid = 2038) THEN 'ССО'::text
           ELSE NULL::text
           END                                                                    AS tag
FROM ((((agreeregdev_period
    JOIN agreepoint ON ((agreeregdev_period.linkid = agreepoint.rowid)))
    JOIN agreement ON ((agreepoint.linkid = agreement.rowid)))
    JOIN customer ON ((agreement.abo_code = customer.abo_code)))
         JOIN dic_elements ON ((agreeregdev_period.paramid = dic_elements.rowid)))
WHERE ((agreeregdev_period.paramid = ANY (ARRAY [2037, 2038])) AND
       ((agreeregdev_period.paramval)::text ~~ '%\_%'::text))
ORDER BY CASE
             WHEN (agreeregdev_period.paramid = 2037) THEN 'ЭСО'::text
             WHEN (agreeregdev_period.paramid = 2038) THEN 'ССО'::text
             ELSE NULL::text
             END, (regexp_split_to_array((agreeregdev_period.paramval)::text, '_'::text))[2];

alter table vext_get_aboname_by_tag
    owner to postgres;

