create function bee_rep_get_repdata28_get_en_4(amn_rowid integer, year1 date) returns SETOF bee_rep_tab28_en
    language sql
as
$$
/*
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	ito06 2013-01-18 Приложение 1а, договорные данные эл.эн.
*/
SELECT 
	amn.rowid     AS amnid,
	null::integer AS pointid,
        CASE WHEN ard.paramval::integer = 311  THEN 1
             WHEN ard.paramval::integer = 308  THEN 2
             WHEN ard.paramval::integer = 310  THEN 3
             WHEN ard.paramval::integer = 306  THEN 4
        END 						AS ul,
	null::varchar 					AS ulev,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.sum
	     ELSE  pce.sum
	END)				  		AS sum,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_1
	     ELSE pce.m_1	
	END)						AS m_1,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_2
	     ELSE pce.m_2	
	END)						AS m_2,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_3
	     ELSE pce.m_3		
	END)						AS m_3,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_4
	     ELSE pce.m_4	
	END)						AS m_4,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_5
	     ELSE pce.m_5	
	END)						AS m_5,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_6
	     ELSE pce.m_6	
	END)						AS m_6,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_7
	     ELSE pce.m_7	
	END)						AS m_7,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_8
	     ELSE pce.m_8	
	END)						AS m_8,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_9
	     ELSE pce.m_9	
	END)						AS m_9,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_10
	     ELSE pce.m_10	
	END)						AS m_10,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_11
	     ELSE pce.m_11	
	END)						AS m_11,
	sum(CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcef.m_12
	     ELSE pce.m_12	
	END)						AS m_12
     FROM agreement AS amn
     JOIN agreepoint As apn ON apn.linkid = amn.rowid
     JOIN bee_rep_get_ard_per_max(439) AS ard  ON apn.rowid = ard.linkid
LEFT JOIN agreeregdev  AS ard690 ON apn.rowid = ard690.linkid AND ard690.paramid = 690 AND is_date(ard690.paramval) AND length(ard690.paramval)>9

LEFT JOIN (select * from bee_rep28_get_consum($1,$2,1042))   AS pce ON pce.pointid  = apn.rowid
LEFT JOIN (select * from bee_rep28_get_consum_f($1,$2,1042)) AS pcef ON pcef.pointid  = apn.rowid

    WHERE amn.rowid = $1
      AND (ard690.paramval IS NULL OR ard690.paramval::date >= to_char($2,'YYYY-mm-01')::date - '11 month'::interval) 
GROUP BY amn.rowid,  ard.paramval
$$;

comment on function bee_rep_get_repdata28_get_en_4(integer, date) is 'Приложение 1, договорные данные - эл.эн. Используется в bee_rep_get_repdata28_get_en(int, date, int)';

alter function bee_rep_get_repdata28_get_en_4(integer, date) owner to postgres;

