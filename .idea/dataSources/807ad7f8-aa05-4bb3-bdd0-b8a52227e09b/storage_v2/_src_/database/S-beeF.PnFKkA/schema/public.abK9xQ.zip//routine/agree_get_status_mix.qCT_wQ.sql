create function agree_get_status_mix(src_host character varying, src_port character varying) returns SETOF vagree_mix
    language plpgsql
as
$$
/*add ito06 2012-12-07
*/
DECLARE
   r vagree_mix%ROWTYPE;
   ConnectParams VARCHAR; 
   ListConn      TEXT[];
   Res           TEXT;
   
BEGIN
   --
   SELECT * FROM dblink_get_connections() INTO ListConn;

   IF 'deconn' = ANY (ListConn) THEN
      SELECT dblink_disconnect('deconn') INTO Res;
   END IF;
  
   SELECT dblink_connect_u('deconn',
      ' dbname = '   ||  'beeU'        ||
      ' port = '     || src_port    ||
      ' host = '     || src_host    || 
      ' user = '     || 'pgsql'     ||
      ' password = ' || '') into Res;
   --
  
   FOR r IN (
      SELECT t.* FROM dblink('deconn','SELECT kod,uch,lid,acc,dev,dat, agr FROM vagree_mix'
      ) AS t (kod varchar,uch varchar,lid integer,acc varchar,dev varchar,dat date, agr varchar)
   )
   LOOP
      RETURN NEXT r;
   END LOOP;

   SELECT dblink_disconnect('deconn') INTO Res;

   RETURN;
END;
$$;

comment on function agree_get_status_mix(varchar, varchar) is 'Используется в AgreeJoinMix.java, SessionBean1.java';

alter function agree_get_status_mix(varchar, varchar) owner to pgsql;

