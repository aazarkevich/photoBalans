create function bee_rep_get_repdata30_tmpuni(loc_id integer, d_start_sum date, d_end_sum date) returns SETOF bee_repdata30_tmp
    language plpgsql
as
$$
/*
	add ito06 2015-09-30 Изменили названия колонок для  разделителя
	add ito06 2015-05-12
	ito06 2015-02-02 Сводная реализация электроэнергии по прямым договорам, выбирает реализацию из базы смешанных и централизованных (для указанного филиала)
	
*/
DECLARE rec record;
	ListConn TEXT[];
	Result TEXT;
BEGIN
	IF loc_id = 644
	     THEN 
	        FOR rec IN (SELECT distinct hostname FROM bee_closed_info WHERE dbstatus = 'X' AND hostname IN ('beex', 'localhost'))
		 LOOP
			SELECT * FROM dblink_get_connections() INTO ListConn;
			IF 'deconn0' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn0') INTO Result; END IF;  
			SELECT dblink_connect_u('deconn0',' dbname = beeX port = 5432 host = '||rec.hostname||' user = pgsql') INTO Result;			
			RETURN QUERY(SELECT DISTINCT points.* 
                                       FROM dblink('deconn0','select *,'''||rec.hostname||''' from bee_rep_get_repdata25_content('||$1||', '''||$2||''','''||$3||''')'
                                               ) AS points(npp int, abo_num varchar, doc_num varchar, accdir smallint,loc int, d_start_sum numeric, k_start_sum numeric, amount numeric,
					amount1 numeric, amount2 numeric, sum_with_tax numeric, sum_no_tax numeric, sum_with_tax1068 numeric, sum_no_tax1068 numeric,
					sum_with_tax1069 numeric, sum_no_tax1069 numeric, tar numeric, fact_all_sum numeric, payed_sum numeric, retrest_sum numeric, disc_sum numeric,
					d_end_sum numeric,k_end_sum numeric, pay_all_sum numeric, fact_adv_sum numeric, ext_sum numeric, host varchar));
		 END LOOP;
		 SELECT dblink_disconnect('deconn0') INTO Result;	   					
	END IF; 		
END;
$$;

comment on function bee_rep_get_repdata30_tmpuni(integer, date, date) is 'Сводная реализация электроэнергии. Используется в bee_rep_get_repdata30_create_tmp_table(int, date, date)';

alter function bee_rep_get_repdata30_tmpuni(integer, date, date) owner to postgres;

