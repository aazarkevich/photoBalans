create function bee_rep10_ulev_en_mid_real(locid integer, strdate date, ulev character varying, trm_filter character varying, accdir_filter character varying, cd_filter character varying, sd_filter character varying) returns SETOF bee_rep_tab10_en
    language plpgsql
as
$$
/*
ito06 2012-05-15 Приложение 1
*/
 DECLARE
  rec bee_rep_tab10_en%rowtype;
  summ numeric(10,3);
  coun integer;
  middle numeric(10,3);
 BEGIN
    FOR rec IN(SELECT * FROM bee_rep10_ulev_en_real(locid,strdate,ulev,trm_filter,accdir_filter, cd_filter, sd_filter ))
    LOOP
        IF rec.summ IS NULL OR rec.summ=0 
        THEN
		RETURN NEXT rec;
	ELSE
		summ=rec.summ;
		coun=0;
		middle=0;

		IF rec.summ1 IS NOT NULL AND rec.summ1<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ2 IS NOT NULL AND rec.summ2<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ3 IS NOT NULL AND rec.summ3<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ4 IS NOT NULL AND rec.summ4<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ5 IS NOT NULL AND rec.summ5<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ6 IS NOT NULL AND rec.summ6<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ7 IS NOT NULL AND rec.summ7<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ8 IS NOT NULL AND rec.summ8<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ9 IS NOT NULL AND rec.summ9<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ10 IS NOT NULL AND rec.summ10<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ11 IS NOT NULL AND rec.summ11<>0
		THEN
		    coun=coun+1;
		END IF;

		IF rec.summ12 IS NOT NULL AND rec.summ12<>0
		THEN
		    coun=coun+1;
		END IF;
		
		IF coun<12 THEN
			middle=rec.summ/coun;

			IF rec.summ1 IS NULL OR rec.summ1=0
			THEN
			    rec.summ1=middle;
			END IF;

			IF rec.summ2 IS NULL OR rec.summ2=0
			THEN
			    rec.summ2=middle;
			END IF;

			IF rec.summ3 IS NULL OR rec.summ3=0
			THEN
			    rec.summ3=middle;
			END IF;

			IF rec.summ4 IS NULL OR rec.summ4=0
			THEN
			    rec.summ4=middle;
			END IF;

			IF rec.summ5 IS NULL OR rec.summ5=0
			THEN
			    rec.summ5=middle;
			END IF;

			IF rec.summ6 IS NULL OR rec.summ6=0
			THEN
			    rec.summ6=middle;
			END IF;

			IF rec.summ7 IS NULL OR rec.summ7=0
			THEN
			    rec.summ7=middle;
			END IF;

			IF rec.summ8 IS NULL OR rec.summ8=0
			THEN
			    rec.summ8=middle;
			END IF;

			IF rec.summ9 IS NULL OR rec.summ9=0
			THEN
			    rec.summ9=middle;
			END IF;

			IF rec.summ10 IS NULL OR rec.summ10=0
			THEN
			    rec.summ10=middle;
			END IF;

			IF rec.summ11 IS NULL OR rec.summ11=0
			THEN
			    rec.summ11=middle;
			END IF;

			IF rec.summ12 IS NULL OR rec.summ12=0
			THEN
			    rec.summ12=middle;
			END IF;   
			rec.summ=rec.summ1+rec.summ2+rec.summ3+rec.summ4+rec.summ5+rec.summ6+rec.summ7+rec.summ8+rec.summ9+rec.summ10+rec.summ11+rec.summ12;
			RETURN NEXT rec;
		ELSE 
		    RETURN NEXT rec;
		END IF;
	END IF;
   END LOOP;
 END;
$$;

comment on function bee_rep10_ulev_en_mid_real(integer, date, varchar, varchar, varchar, varchar, varchar) is 'Приложение 1. Используется в bee_rep10_ulev_2(int, date, varchar, varchar, varchar, varchar, varchar)';

alter function bee_rep10_ulev_en_mid_real(integer, date, varchar, varchar, varchar, varchar, varchar) owner to pgsql;

