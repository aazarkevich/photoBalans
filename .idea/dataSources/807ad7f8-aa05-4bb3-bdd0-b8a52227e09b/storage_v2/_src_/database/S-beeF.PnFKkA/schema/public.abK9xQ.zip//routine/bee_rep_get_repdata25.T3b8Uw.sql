create function bee_rep_get_repdata25(loc_id integer, start_d date, end_d date) returns SETOF bee_repdata25
    language plpgsql
as
$$
/*
	add ito06 2015-09-30 Изменили названия колонок для  разделителя
	add ito06 2015-06-23
	add ito06 2015-05-12    
	add ito06 2013-10-22 
	add ito06 2012-10-02
	ito06 2011-07-21: Реализация эл эн	
*/
BEGIN
	DROP TABLE IF EXISTS bee_rep_get_repdata25_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata25_tmp AS
		(SELECT * FROM bee_rep_get_repdata25_content($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));

RETURN QUERY(          

		(SELECT 'bold'::varchar	   			AS row_style,
			null::varchar 				AS nn,
			'01'::varchar 				AS nn1,
			'ВСЕГО'::varchar  			AS name,
			row.*,	
			null::smallint 				AS accdir,
			null::int 				AS loc,
			'ВСЕГО'::varchar  			AS ord
		FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,0) AS row
		)
	UNION 
		(SELECT 'bold'::varchar	   			AS row_style,
			'1' ::varchar				AS nn,
			'10'::varchar 				AS nn1,
			'Прочие потребители'  			AS name,
			row.*,
			null::smallint 				AS accdir,
			null::int 				AS loc,
			'Прочие потребители'::varchar  		AS ord
		FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,10) AS row
		)
	UNION
		(SELECT 'bold'::varchar	   			AS row_style,
			'2' ::varchar				AS nn,
			'20'::varchar 				AS nn1,
			'Бюджетные потребители' 		AS name,  
			row.*,
			null::smallint 				AS accdir,
			null::int 				AS loc,
			'Бюджетные потребители'::varchar	AS ord
			
		FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,20) AS row
		)
	UNION 
		(SELECT 'bold'::varchar	   			AS row_style,
			'2.1' ::varchar 			AS nn,
			'21'::varchar  				AS nn1,
			'-федеральный бюджет'  			AS name,
			row.*,
			null::smallint 				AS accdir,
			null::int 				AS loc,
			'-федеральный бюджет'::varchar  	AS ord
		FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,21) AS row
		)
	UNION 
		(SELECT 'bold'::varchar	   			AS row_style,
			'2.2'::varchar 				AS nn,
			'22'::varchar 				AS nn1,
			'-областной бюджет'::varchar  		AS name,
			row.*,
			null::smallint 				AS accdir,
			null::int 				AS loc,
			'-областной бюджет'::varchar  		AS ord
		FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,22) AS row
		)
	UNION
		(SELECT 'bold'::varchar	   			AS row_style,
			'2.3'::varchar 				AS nn,
			'23'::varchar 				AS nn1,
			'-местный бюджет'::varchar  		AS name,
			row.*,
			null::smallint 				AS accdir,
			null::int 				AS loc,
			'-местный бюджет'::varchar  		AS ord
		FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,23) AS row)
	UNION
		(SELECT 'bold'::varchar	   			AS row_style,
			'2.3.1'::varchar 			AS nn,
			'231'::varchar 				AS nn1,
			'--юр. организации'  			AS name,
			row.*,
			null::smallint 				AS accdir,
			null::int 				AS loc,
			'--юр. организации'::varchar  		AS ord
		FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,231) AS row)
	UNION 
		(SELECT 'bold'::varchar	   			AS row_style,
			'2.3.2'::varchar 			AS nn,
			'232'::varchar 				AS nn1,
			'--уличное освещение'  			AS name,
			row.*,
			null::smallint 				AS accdir,
			null::int 				AS loc,
			'--уличное освещение'::varchar  	AS ord
		FROM bee_rep_get_repdata25_summ($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date,232) AS row)
	ORDER BY nn1, ord);
END;

$$;

comment on function bee_rep_get_repdata25(integer, date, date) is 'Реализация эл эн. Используется в RepCreate25.java';

alter function bee_rep_get_repdata25(integer, date, date) owner to pgsql;

