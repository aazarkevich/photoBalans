create function bee_iskraemeco_get_devload_list()
    returns TABLE(pointid integer, prodnum character varying, mark character varying, devid integer, amnid integer, docnumber character varying, src_name character varying, src integer, base character varying, db_tag character varying, locid integer, isload boolean, locid_name character varying, tp integer, tp_name text)
    language plpgsql
as
$$
/*
	add ito06 2015-11-17 добавили расшифровку участка и ТП
	ito06 2015-10-27 Получить список счетчиков подходящих для загрузки из других источников для всех баз
*/
DECLARE
	ListConn  TEXT[];
	Result    TEXT;
	Rec       RECORD;
	curr_dbase varchar = 'beeU';
	res_dbase varchar = 'beeF';
	
BEGIN
	--параметры соединения
	SELECT * FROM dblink_get_connections() INTO ListConn;
	IF 'iskrconn3' = ANY (ListConn) THEN SELECT dblink_disconnect('iskrconn3') INTO Result; END IF;
	
	select * from current_database() INTO curr_dbase;
	IF (curr_dbase = 'beeF') THEN res_dbase = 'beeU'; END IF;
		
	SELECT hostname,dbname,dbport FROM bee_closed_info WHERE dbname = res_dbase INTO Rec;
	--
	IF (Rec IS NOT NULL) THEN
	   SELECT dblink_connect_u('iskrconn3',
	      ' dbname   = ' || res_dbase   ||
	      ' port     = ' || Rec.dbport   ||
	      ' host     = ' || Rec.hostname ||
	      ' user     = ' || 'pgsql'      ||
	      ' password = ' || '') INTO Result;   

	RETURN QUERY(
		(SELECT t.* FROM dblink('iskrconn3', 'select * from bee_iskraemeco_get_devload_list_tmp()') 
		              AS t (pointid integer,prodnum varchar, mark varchar, devid integer,  amnid int, docnumber varchar,
		                    src_name varchar, src int, base varchar, db_tag  varchar(1), locid int, isload boolean, locid_name varchar, tp integer, tp_name text))
	  UNION (SELECT * from bee_iskraemeco_get_devload_list_tmp())
	  ORDER BY prodnum);
	
	     --удаляем соединение
	     IF 'iskrconn3' = ANY (ListConn) THEN SELECT dblink_disconnect('iskrconn3') INTO Result; END IF;	     
	   ELSE    
		SELECT * from bee_iskraemeco_get_devload_list_tmp() ORDER BY prodnum;		
	END IF; 

END;
$$;

comment on function bee_iskraemeco_get_devload_list() is 'Получить список счетчиков подходящих для загрузки из других источников для всех баз. Используется в IskraEmeco.java, SessionBean1.java';

alter function bee_iskraemeco_get_devload_list() owner to pgsql;

