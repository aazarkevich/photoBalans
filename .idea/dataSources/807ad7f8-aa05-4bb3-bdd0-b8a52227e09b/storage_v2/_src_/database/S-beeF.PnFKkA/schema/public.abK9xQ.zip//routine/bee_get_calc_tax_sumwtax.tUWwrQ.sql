create function bee_get_calc_tax_sumwtax(summ numeric, amnid integer, datfrom date, datto date)
    returns TABLE(sum_tax numeric, sum_with_tax numeric)
    language plpgsql
as
$$
/*
	ito06 2020-03-18 НДС и сумма с НДС берем из result, если есть
    ito06 2020-02-26 неверно счиатлась НДС и сумма с НДС, если есть корр и выставление
	ito06 2019-09-19 итого по потребителю (sum_no_tax), (sum_tax) считаем суммой строк по столбцам
	      для того что бы правильно считалась корректировка и нарастающий отчет.
    ito07 2018-10-26
    ito06 2015-06-23
    Расчет для суммы без налога (sum_no_tax): налога (sum_tax) и суммы с налогом (sum_with_tax).
*/
DECLARE 
    sum_without_tax /*summ_1*/ numeric;
    sum_with_tax               numeric;
    docid                      integer;
    tax_rate                   numeric;
    Rec                        RECORD; 	
	s_ntax				       numeric; --** ito06 2019-09-19	
	s_tax					   numeric; --** ito06 2019-09-19	
	s_wtax					   numeric; --** ito06 2019-09-19	
	tax_rate_1				   numeric; --** ito06 2019-09-19
	tax_rate_2				   numeric; --** ito06 2019-09-19
	sum_tax1 				   numeric; --** ito06 2020-03-18
	sum_with_tax1			   numeric; --** ito06 2020-03-18
	
BEGIN
	s_ntax  = 0;				--** ito06 2019-09-19
	s_tax = 0;				--** ito06 2019-09-18
	s_wtax = 0;				--** ito06 2019-09-18
	tax_rate_1 = 0;				--** ito06 2019-09-19
	tax_rate_2 = 0;				--** ito06 2019-09-19
	

    summ = summ::numeric(12,4); -- round it ? no but cut only !!! 
    for Rec in (
       select rowid as docid, doctyp AS dtyp from bee_docs 
       where 
          linkid = amnid AND 
          docdat between datFrom and datTo 
          and doctyp in (1065,1618,1705)		  
   ) loop      
     --** ito06 2019-09-19 % налога берем на корректируемую дату, а не дату создания корректировки
	 --** 2019-09-18 tax_rate = bee_get_doc_tax(1163,Rec.docid); 	 
     if Rec.dtyp = 1618
	   then 
	      tax_rate_1 = bee_get_doc_tax(1163,(select period from bee_docs_corr where linkid2 = Rec.docid limit 1));	
		  --**2020-03-18 select sum(sum_no_tax) from bee_docs_result where linkid in (Rec.docid) INTO sum_without_tax ;
		  select sum(sum_no_tax), sum(tax_sum), sum(bee_docs_result.sum_with_tax) from bee_docs_result where linkid in (Rec.docid) INTO sum_without_tax,sum_tax1, sum_with_tax1 ;
		  
	   else 
	      tax_rate_1 = bee_get_doc_tax(1163,Rec.docid);	      
		  --2020-03-18 select sum(sum_no_tax) from bee_docs_result where linkid in (Rec.docid) AND tar_typ = 1068 INTO sum_without_tax;
		  select sum(sum_no_tax), sum(tax_sum), sum(bee_docs_result.sum_with_tax) from bee_docs_result where linkid in (Rec.docid) AND tar_typ in (1068,1168) INTO sum_without_tax,sum_tax1 , sum_with_tax1 ;
	 end if;
	 	 --2020-02-26 select sum(sum_no_tax) from bee_docs_result where linkid in (Rec.docid) INTO sum_without_tax;   
	   
	 if (tax_rate_1 != tax_rate_2 AND tax_rate_2 !=0) 
	 then 
	 		--** 2020-03-18
	 		--** s_tax = s_tax + s_ntax * tax_rate_1;
	       --** s_wtax = s_wtax + s_ntax * (1+tax_rate_1);
		   
		  if sum_tax1 !=0 
		     then s_tax  = s_tax +  sum_tax1;
			 else  s_tax = s_tax + s_ntax * tax_rate_1;
		   end if;
		   if   sum_with_tax1 !=0 
		     then  s_wtax = s_wtax + sum_with_tax1;
		     else s_wtax = s_wtax + s_ntax * (1+tax_rate_1);
		   end if;
		   --**
	 	   s_ntax = 0;	 
		   s_tax  = 0; --**2020-03-18
		   s_wtax = 0; --**2020-03-18
	 end if;	 	

	 s_ntax = s_ntax + sum_without_tax;
     s_tax  = s_tax +   sum_tax1; --**2020-03-18
	 s_wtax = s_wtax + sum_with_tax1; --**2020-03-18		 
 
	 tax_rate_2 = tax_rate_1;	 
	   

	  /* -- ito06 2019-09-19
	  --summ = summ::numeric(12,2); -- round it ? no but cut only !!! 
       select sum(sum_no_tax) 
       from bee_docs_result 
       where linkid in (Rec.docid)
       --select rowid from bee_docs 
       --where 
        --  linkid = amnid AND 
        --  docdat between datFrom and datTo and 
         -- doctyp in (1065,1705)
       --) 
       INTO sum_without_tax;--summ_1;               
		
       select sum(oper_debit) 
       from bee_docs_sheet
       where linkid2 in (Rec.docid)
       --select rowid from bee_docs 
       --where 
       --   linkid = amnid 
       --   and docdat between datFrom and datTo 
       --   and doctyp in (1065,1618,1705)) 
    INTO sum_with_tax;	
    IF (summ = sum_without_tax)
       THEN 
		 RETURN QUERY (SELECT (sum_with_tax - summ)::numeric(20,4) AS sum_tax, (sum_with_tax)::numeric(20,4) AS sum_with_tax);
       ELSE	
		 RETURN QUERY (SELECT (summ * tax_rate)::numeric(20,4) AS sum_tax, (summ * (1 + tax_rate))::numeric(20,4) AS sum_with_tax);
    END IF; -- */

    end loop;  	


	 --** 2020-03-18 if (tax_rate_1!=0 AND s_ntax !=0 )
	if (tax_rate_1!=0 AND s_ntax !=0  AND (sum_tax1 = 0  OR  sum_with_tax1 =0))
	then
		   s_tax = s_tax + s_ntax * tax_rate_1;
	       s_wtax = s_wtax + s_ntax * (1+tax_rate_1);
  	end if;		
	   
	  RETURN QUERY (SELECT s_tax::numeric(20,4) AS sum_tax, s_wtax::numeric(20,4) AS sum_with_tax);	
END;
$$;

comment on function bee_get_calc_tax_sumwtax(numeric, integer, date, date) is 'Расчет налога и суммы с налогом для заданой суммы. Используется в TurnoverStatement.java';

alter function bee_get_calc_tax_sumwtax(numeric, integer, date, date) owner to pgsql;

