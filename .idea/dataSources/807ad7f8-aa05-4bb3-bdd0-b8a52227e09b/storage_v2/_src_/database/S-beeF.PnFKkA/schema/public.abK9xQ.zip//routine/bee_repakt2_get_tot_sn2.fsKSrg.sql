create function bee_repakt2_get_tot_sn2(bd_rowid integer) returns numeric[]
    language plpgsql
as
$$
/*
   ito07 181108 
    add ito06  2014-11-17
    ito06 2013-09-25 Акт (соц норма)
*/
DECLARE newform numeric = 0;
BEGIN 
    SELECT sum(sum_with_tax) FROM bee_docs_result where linkid =$1 INTO newform;	
    IF (newform  = 0 ) 
       THEN RETURN (SELECT 
	    ARRAY[ 
	       sum(sum_no_tax),				
		(sum(sum_no_tax) * bee_get_doc_tax(1163, bd_rowid) )::numeric(20,2),
		(sum(sum_no_tax) * (1 + bee_get_doc_tax(1163, bd_rowid)))::numeric(20,2)
		]
	   FROM bee_docs_result
	  WHERE linkid = $1 AND tar_grp IN (SELECT sn2_code FROM bee_rep_dtg_rebuilt()));
       ELSE RETURN (SELECT 
	    ARRAY[  sum(sum_no_tax),
		(SELECT sum (a) FROM unnest (ARRAY[-sum(sum_no_tax),sum(sum_with_tax)]) AS a),
		sum(sum_with_tax)]				
	   FROM bee_docs_result
	  WHERE linkid = $1 AND tar_grp IN (SELECT sn2_code FROM bee_rep_dtg_rebuilt()));
    END IF;
END;
$$;

comment on function bee_repakt2_get_tot_sn2(integer) is 'Акт (соц нормы). Используется в bee_repakt2_get_tot(int), bee_repakt2_get_tot_loss(int)';

alter function bee_repakt2_get_tot_sn2(integer) owner to pgsql;

