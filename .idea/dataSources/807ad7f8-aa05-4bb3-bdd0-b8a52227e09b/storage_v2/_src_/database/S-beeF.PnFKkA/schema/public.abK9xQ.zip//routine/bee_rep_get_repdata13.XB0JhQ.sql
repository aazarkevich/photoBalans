create function bee_rep_get_repdata13(locid integer, strdate date) returns SETOF bee_rep_tab13
    language sql
as
$$
/*
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2011-04-08	
	ito16 Справка по дебиторам
*/
   SELECT
	 amn.docnumber AS docnum,
	 cst.consum_name AS nam,
	 a.fd AS fd,
	 0::numeric(14,2) AS fd_w_nds,
	 0::numeric AS fk,
	 0::numeric(14,2) AS fk_w_nds,
	 a.ldat::date AS last_dat,
	 null::character varying,
	 null::date,
	 dic.element_name AS grp
    FROM agreement AS amn
    JOIN customer AS cst ON cst.abo_code=amn.abo_code
    JOIN
	  (SELECT 
	      bds.final_debit AS fd,
	      bds.linkid1 AS linkid, 
	      bds.operdate AS ldat
	   FROM bee_docs_sheet AS bds
	   JOIN
	      (SELECT 
		 bds.linkid1 AS linkid,
		 bds.operdate AS operdate,
		 max(bds.npp) AS sn
	      FROM bee_docs_sheet AS bds
	      JOIN 
		 (SELECT 
		    linkid1 AS linkid,
		    max(operdate) AS operdate
		 FROM bee_docs_sheet
		 WHERE
		    operdate <= $2
		 GROUP BY linkid) AS a ON a.linkid=bds.linkid1 AND a.operdate=bds.operdate
	       GROUP BY bds.linkid1, bds.operdate) AS a1 ON a1.sn=bds.npp AND a1.linkid = bds.linkid1 AND a1.operdate = bds.operdate
	   ) AS a ON a.linkid=amn.rowid
   JOIN dic_elements AS dic ON dic.rowid=amn.accdir
  WHERE 
	amn.locid=$1 AND
	a.fd>0       AND
	amn.doctype = 1910 --** 2016-04-25 

GROUP BY docnum,nam,fd,fd_w_nds,fk,fk_w_nds,grp, a.ldat
ORDER BY docnum;
$$;

comment on function bee_rep_get_repdata13(integer, date) is 'Справка по дебиторам. Используется в RepCreate13.java';

alter function bee_rep_get_repdata13(integer, date) owner to pgsql;

