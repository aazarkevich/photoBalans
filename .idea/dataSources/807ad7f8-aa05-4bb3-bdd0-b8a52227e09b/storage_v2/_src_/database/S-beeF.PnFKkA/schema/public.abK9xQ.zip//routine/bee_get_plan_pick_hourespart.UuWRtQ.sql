create function bee_get_plan_pick_hourespart(_year integer, _month integer) returns character varying
    language plpgsql
as
$$
/*
	ito06 2020-08-27 Получить плановые часы для заданного года и месяца
*/
DECLARE
   rec record;
  res varchar;
 BEGIN
 res = '';
    FOR rec IN(SELECT * FROM plan_pick_values where  yearpart = _year and monthpart =_month )
    LOOP
	if (res = '')
	then res = res || rec.hourfr || ' - ' || rec.hourto; 
	else res = res ||', '|| rec.hourfr || ' - ' || rec.hourto; 
	end if;
     
    END LOOP;
   	RETURN res;

 END;
$$;

comment on function bee_get_plan_pick_hourespart(integer, integer) is ' Получить плановые часы для заданного года и месяца. Используется в SessionBean1.java';

alter function bee_get_plan_pick_hourespart(integer, integer) owner to pgsql;

