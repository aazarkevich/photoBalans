create function bee_get_agreement_by_pointid(xlid integer, pointid integer) returns character varying
    language plpgsql
as
$$
    --
-- НОМЕР ДОГОВОРА ПО КОДУ ТОЧКИ УЧЁТА
-- lid     : код места обработки
-- pointid : код точки учёта
-- 
BEGIN
   RETURN (
      SELECT agreement.docnumber FROM agreement
      JOIN agreepoint ON agreement.rowid = agreepoint.linkid
      WHERE 
         agreement.locid  = xlid     AND 
         agreepoint.rowid = pointid
      LIMIT 1
   );
--
END;
$$;

comment on function bee_get_agreement_by_pointid(integer, integer) is 'Номер договора по коду точки учета. Используется в AgreeRegDev.java, RepAkt.java, RepAkt1.java, AppUtils.java';

alter function bee_get_agreement_by_pointid(integer, integer) owner to pgsql;

