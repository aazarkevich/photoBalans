create function bee_repakt2_change_get_content(bd_rowid integer) returns SETOF bee_repakt2_tab
    language plpgsql
as
$$
/*
	ito06 2015-07-09: Акт (соц. норма) для исправления	
*/
BEGIN
	RETURN QUERY SELECT * from tmp_repakt2_change_content;
END;
$$;

comment on function bee_repakt2_change_get_content(integer) is 'Акт (соц. норма) для исправления. Используется в repakt2_change.java; bee_repakt2_change_get_tot_grp(int, varchar), bee_repakt2_change_get_tot_grp_sum(int, varchar)';

alter function bee_repakt2_change_get_content(integer) owner to pgsql;

