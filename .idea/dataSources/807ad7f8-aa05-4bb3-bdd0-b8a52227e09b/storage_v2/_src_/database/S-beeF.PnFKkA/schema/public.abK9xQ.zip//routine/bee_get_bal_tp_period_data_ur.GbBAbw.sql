create function bee_get_bal_tp_period_data_ur(date_from text, date_to text, _locid integer, uselocid text, short_name text, tp_not_exist text) returns SETOF bal_tp_period_data_ur
    language plpgsql
as
$$
/*
    add ito06 2020-07-16 Добавили параметр виду учета "технический"
	add ito06 2016-06-22 accdir 1110 должен попадать в отчет
	add ito06 2015-05-12 Учитывать, только последние трассы
	add ito05 2015-03-24
	add ito02 2013-02-12 WHERE amn.locid::TEXT LIKE _locid AND accdir NOT IN (319, 1476,1110) добавлен 1110
	ito06 2011-12-20 Свод по ТП
	
	-- uselocid (true -сформировать c делением на участки)
	-- short_name (true - сформировать с сокращенным названием ТП)
	-- tp_not_exist (true - сформировать по отключенным трассам)

*/
DECLARE
	RowLine bal_tp_period_data_ur%rowtype;
	param character varying;
  
BEGIN
---  
	IF  tp_not_exist = 'false'
		THEN  param = ' NOT '; ELSE param =' ';
	END IF;   
	EXECUTE 'create TEMPORARY table  temp_gis_traces_for_bal_tp_period  AS
		(select gt.locid, gt.period, gt.pchain, gt.objowner, gt.objname, gt.objcode,  gt.objtype, gt.rowid, gt.kod  
		   from gis_traces as gt
		left join gis_traces_tmp as gtt USING (kod, locid,pchain, objowner, objname, objcode, objtype) where gtt.period is '|| param ||' NULL);';

	EXECUTE 'create TEMPORARY table temp_gis_traces_bal  AS
		(select gt.locid, gt.period, gt.pchain, gt.objowner,  gt.objname, gt.objcode, gt.objtype, gt.kod from gis_traces AS gt 
                   join (select  max(period) AS period, locid, objcode, objtype from gis_traces  group by locid, objcode, objtype) AS gt1
                  using (period, locid, objcode, objtype));';			
----     

  FOR RowLine IN (SELECT 
		
                        tab2.tpname 				AS fullname, --колонка 2
			tab1.obj_code				AS obj_code, -- для связки с из базы физ лиц
			1 					AS objowner_code, 
			SUM(tab1.kontrol) 			AS kol3, -- колонка 3
			SUM(tab1.potreb) 			AS kol4, -- колонка 4
			SUM(tab1.poteri2)+SUM(tab1.poteri3)	AS kol5, --колонка 5
			SUM(tab1.poteri1) 			AS kol6 --колонка 6
		   FROM
		        (SELECT 
				CASE 
				   WHEN gt.objtype=11 
				      THEN family.son_code
				   WHEN gt.objtype=10 OR gt.objtype=9 OR gt.objtype=8 THEN family.father_code
				END AS obj_code,
		                -- CASE WHEN a2.paramval='434' AND gt.objtype = 11 AND amn.accdir = 538 THEN SUM(a3.valman)
		                CASE WHEN a2.paramval in ('434', '2287') AND gt.objtype = 11 AND amn.accdir = 538 THEN SUM(a3.valman) 
		                END AS kontrol,--контроль
				CASE WHEN a1.paramval='432' THEN SUM(a3.valman)
				END AS potreb, --потребление
				CASE WHEN a1.paramval='432' THEN SUM(a4.valman)
				END AS poteri1, --потери в линиях
				CASE WHEN a1.paramval='432' THEN SUM(a5.valman)
				END AS poteri2, --потери холостого хода
				CASE WHEN a1.paramval='432' THEN SUM(a6.valman)
				END AS poteri3 --нагрузочные потери
			   FROM regdevconn AS rdc
			   JOIN agreepoint AS apn ON rdc.pointid=apn.rowid
		           JOIN agreement AS amn ON apn.linkid=amn.rowid
			   JOIN temp_gis_traces_for_bal_tp_period AS gt ON rdc.traceid = gt.rowid
			   JOIN (SELECT    apn.rowid AS r1, 
			                   t1.objcode AS son_code, 
			                   t2.objcode AS father_code
			              FROM agreepoint AS apn 
			              JOIN regdevconn AS rdc ON apn.rowid=rdc.pointid 
			              JOIN temp_gis_traces_for_bal_tp_period t1 ON rdc.traceid=t1.rowid 
			         LEFT JOIN temp_gis_traces_for_bal_tp_period AS t2 ON t2.objcode=t1.objowner 
                                     GROUP BY apn.rowid, t1.objname, t1.objcode, t1.objowner, t2.objname, t2.objcode
			        ) AS family ON rdc.pointid=family.r1 
		      LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid=189 AND paramval='432'
		                ) AS a1 ON rdc.pointid=a1.linkid
		      --LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid=189 AND paramval='434'
		      LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid=189 AND paramval in ('434', '2287')
		                ) AS a2 ON rdc.pointid=a2.linkid     
		           JOIN (SELECT SUM(CASE WHEN valman='' THEN 0 else valman::float END) AS valman, linkid 
		                   FROM regdevoper 
		                  WHERE paramid=850 AND valman <> '-' AND operdate between date_from::DATE AND date_to::DATE 
		                  GROUP BY linkid
		                ) AS a3 ON rdc.pointid=a3.linkid     
		      LEFT JOIN (SELECT SUM(CASE WHEN valman='' THEN 0 else valman::float END) AS valman, linkid 
				   FROM regdevoper 
				  WHERE paramid=919 AND valman <> '-' AND operdate between date_from::DATE AND date_to::DATE 
				  GROUP BY linkid
		                ) AS a4 ON rdc.pointid=a4.linkid     
		      LEFT JOIN (SELECT SUM(CASE WHEN valman='' THEN 0 else valman::float END) AS valman, linkid 
		                   FROM regdevoper 
				  WHERE paramid=918 AND valman <> '-' AND operdate between date_from::DATE AND date_to::DATE 
				  GROUP BY linkid
				) AS a5 ON rdc.pointid=a5.linkid     
		      LEFT JOIN (SELECT SUM(CASE WHEN valman='' THEN 0 else valman::float END) AS valman, 
		                        linkid 
		                   FROM regdevoper 
		                  WHERE paramid=917 AND valman <> '-' AND operdate between date_from::DATE AND date_to::DATE 
		                  GROUP BY linkid
			         ) AS a6 ON rdc.pointid=a6.linkid           
                            WHERE accdir NOT IN (319, 1476)
				-- ito05 150319
				AND amn.locid IN (SELECT rowid FROM denet WHERE kod LIKE ((SELECT kod FROM denet WHERE rowid = _locid) ||  (case when useLocid = 'true' then '%' else '' end)))
		            GROUP BY obj_code, a1.paramval, a2.paramval, amn.accdir,gt.objtype
		     ) AS tab1 
		JOIN ( SELECT 
		             CASE 
		                WHEN short_name = 'false'		            
                                   THEN(
   		         	        CASE 
					   WHEN a6.objname IS NOT NULL 
                                              THEN a6.objname
                                           ELSE ''
                                        END  || CASE 
                                              WHEN a5.objname IS NOT NULL 
                                                 THEN ' ' || a5.objname
                                              ELSE ''
                                        END || CASE 
                                              WHEN a4.objname IS NOT NULL 
                                                 THEN ' ' || a4.objname
                                              ELSE ''
                                        END || CASE 
                                              WHEN a3.objname IS NOT NULL 
                                                 THEN ' ' || a3.objname
                                              ELSE ''
                                        END || CASE 
                                             WHEN a2.objname IS NOT NULL 
                                                THEN ' ' || a2.objname
                                             ELSE ''
                                       END || CASE 
                                             WHEN a1.objname IS NOT NULL 
                                                THEN ' ' || a1.objname
                                             ELSE ''
                                       END || CASE 
                                             WHEN tmp_gt.objname IS NOT NULL 
                                                THEN ' ' || tmp_gt.objname
                                             ELSE ''
                                       END 
                                      ) ELSE tmp_gt.objname
                                 END 					        AS tpname,
                                 tmp_gt.objcode                                 AS objcode
                            FROM temp_gis_traces_for_bal_tp_period AS tmp_gt 
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a1 ON tmp_gt.objowner=a1.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a2 ON a1.objowner=a2.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a3 ON a2.objowner=a3.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a4 ON a3.objowner=a4.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a5 ON a4.objowner=a5.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a6 ON a5.objowner=a6.objcode
                           WHERE tmp_gt.objtype=11
                           ORDER BY tpname


		     ) AS tab2 ON tab2.objcode = tab1.obj_code

         	GROUP BY fullname, obj_code
		ORDER BY fullname

  )
	LOOP
		RETURN NEXT RowLine; 
	END LOOP;
---
	DROP TABLE IF EXISTS temp_gis_traces_for_bal_tp_period;
	DROP TABLE IF EXISTS temp_gis_traces_bal;	
	RETURN;
--
END;

$$;

comment on function bee_get_bal_tp_period_data_ur(text, text, integer, text, text, text) is 'Свод по ТП по юр. Используется в RepBal5.java, RepBal6.java';

alter function bee_get_bal_tp_period_data_ur(text, text, integer, text, text, text) owner to pgsql;

