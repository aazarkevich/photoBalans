create function bee_repakt2_change_get_tmp1(bd_rowid integer, tar_id integer, diff boolean, _tartyp integer) returns numeric[]
    language plpgsql
as
$$
/*
   add ito07 2018-11-07 bee_get_doc_tax(1163,$1)
	add ito06 2015-12-10  добавили входной параметр _tartyp
	ito06 2015-07-09: Акт (соц. норма) для исправления или корректировки
*/
DECLARE newform numeric = 0;
	dat date;
BEGIN 
	SELECT sum(sum_with_tax) FROM bee_docs_result where linkid =$1 INTO newform;	
	SELECT docdat FROM bee_docs WHERE rowid = bd_rowid INTO dat;
	
	IF (newform <> 0) 
	   THEN RETURN(
		SELECT ARRAY[sum(amount), sum(sum_no_tax), price, sum(tax_sum), sum(sum_with_tax)] AS m_tar
		  FROM bee_docs_result
		 WHERE tar_grp = $2 
		   AND linkid = $1 
		   AND tar_typ  = $4 AND (row_typ = 1070 OR diff)
		 GROUP BY price);
	ELSE RETURN(
		SELECT ARRAY[sum(amount), sum(sum_no_tax), price, sum(sum_no_tax) * bee_get_doc_tax(1163,bd_rowid), sum(sum_no_tax) * (1 + bee_get_doc_tax(1163,bd_rowid))] AS m_tar
		  FROM bee_docs_result
		 WHERE tar_grp = $2 
		   AND linkid = $1 
		   AND tar_typ  = $4 AND (row_typ = 1070 OR diff)
		 GROUP BY price);
	END IF;	  
END;
$$;

comment on function bee_repakt2_change_get_tmp1(integer, integer, boolean, integer) is 'Акт (соц. норма) для исправления или корректировки. Используется в bee_repakt2_change_get_intermediate_content1(int, boolean)';

alter function bee_repakt2_change_get_tmp1(integer, integer, boolean, integer) owner to pgsql;

