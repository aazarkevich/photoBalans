create function bee_is_point_type_1(pointid integer) returns boolean
    language plpgsql
as
$$
BEGIN
   RETURN EXISTS (SELECT 1 FROM agreeregdev WHERE linkid = $1 AND paramid = 189 AND paramval = '434');
   END;
$$;

comment on function bee_is_point_type_1(integer) is 'Используется в LossDistr.java, AppUtils.java';

alter function bee_is_point_type_1(integer) owner to pgsql;

