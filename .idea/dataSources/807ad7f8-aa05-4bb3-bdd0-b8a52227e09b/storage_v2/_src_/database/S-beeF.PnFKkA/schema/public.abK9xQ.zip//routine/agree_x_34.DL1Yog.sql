create function agree_x_34(dbn character varying, agr_num character varying, tagid integer, src_host character varying, src_port character varying) returns void
    language plpgsql
as
$$
/*
	добавление/изменение параметров линии для точки учета из филиала src_host в базу централизованных/смешнных для договора agr_num
*/
DECLARE
	Pnt RECORD; -- for agreepoint
	Rec RECORD;
BEGIN
	-- SCAN POINTS
	FOR Pnt IN (SELECT DISTINCT rowid FROM agree_get_agreepoint(dbn,agr_num,tagid,src_host, src_port) ORDER BY rowid)
	LOOP -- SCAN POINTS 
		DELETE FROM agreepoint_line WHERE pointid = Pnt.rowid;          
		-- REFILL
		FOR Rec IN (SELECT DISTINCT pointid,lineid,linlen,voltage,rowid  
			      FROM agree_get_agreepoint_line(dbn,agr_num,tagid,src_host, src_port) x
			     WHERE x.pointid = Pnt.rowid) 
		LOOP 
			BEGIN
				INSERT INTO agreepoint_line 
					(    pointid,    lineid,    linlen,    voltage,    rowid) VALUES
					(Rec.pointid,Rec.lineid,Rec.linlen,Rec.voltage,Rec.rowid);
			EXCEPTION
				WHEN unique_violation THEN CONTINUE;
				WHEN others           THEN CONTINUE;
			END;
		END LOOP;
	END LOOP; -- END POINTS
END;
$$;

comment on function agree_x_34(varchar, varchar, integer, varchar, varchar) is 'Добавление/изменение параметров линии для точки учета из указанного филиала в базу централизованных/смешнных для указанного договора. Используется в agree_w(int, varchar, varchar), agree_x(varchar, int, varchar)';

alter function agree_x_34(varchar, varchar, integer, varchar, varchar) owner to pgsql;

