create function bee_rep_get_repdata10(locid integer, strdate date, trm_filter character varying, accdir_filter character varying, cd_filter character varying, sd_filter character varying, rep_num integer) returns SETOF bee_rep_tab10
    language plpgsql
as
$$
/*
ito06 2012-05-15 Приложение 1

rep_num:1 - Реальные данные
	2 - Реальные данные с заполнением пустых ячеек средним
	3 - Пустая таблица
	4 - Договорные данные
	5 - Смешанные данные
	6 - Смешанные данные с заполнением пустых ячеек средним
*/
DECLARE 
RowLine bee_rep_tab10%RowType;

BEGIN


RETURN QUERY EXECUTE 
'(select * from bee_rep10_ulev_'||rep_num||'('||$1||', '||quote_literal($2)||', '||quote_literal('306')||', '||quote_literal($3)||', '||quote_literal($4)||', '||quote_literal($5)||', '||quote_literal($6)||')) UNION 
 (select * from bee_rep10_ulev_'||rep_num||'('||$1||', '||quote_literal($2)||', '||quote_literal('308')||', '||quote_literal($3)||', '||quote_literal($4)||', '||quote_literal($5)||', '||quote_literal($6)||')) UNION 
 (select * from bee_rep10_ulev_'||rep_num||'('||$1||', '||quote_literal($2)||', '||quote_literal('310')||', '||quote_literal($3)||', '||quote_literal($4)||', '||quote_literal($5)||', '||quote_literal($6)||')) UNION 
 (select * from bee_rep10_ulev_'||rep_num||'('||$1||', '||quote_literal($2)||', '||quote_literal('311')||', '||quote_literal($3)||', '||quote_literal($4)||', '||quote_literal($5)||', '||quote_literal($6)||'))
ORDER BY dl, docnumber, fil, loc, al,account;';

END;

$$;

comment on function bee_rep_get_repdata10(integer, date, varchar, varchar, varchar, varchar, integer) is 'Приложение 1. Используется в RepCreate10.java; bee_rep_get_repdata10_tot_en(int, date, varchar, varchar, varchar, varchar, int), bee_rep_get_repdata10_tot_pow(int, date, varchar, varchar, varchar, varchar, int)';

alter function bee_rep_get_repdata10(integer, date, varchar, varchar, varchar, varchar, integer) owner to pgsql;

