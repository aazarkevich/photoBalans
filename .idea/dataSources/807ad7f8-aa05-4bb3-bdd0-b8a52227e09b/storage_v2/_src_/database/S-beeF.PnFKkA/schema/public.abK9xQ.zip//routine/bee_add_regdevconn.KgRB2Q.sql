create function bee_add_regdevconn(poi integer, tra integer, loc integer, are character varying) returns integer
    language plpgsql
as
$$
/*
 * add ito06 2021-01-13
-- ПРИВЯЗКА УСТРОЙСТВА К ТОЧКЕ ТРАССЫ
-- poi точка учёта (agreepoint.rowid)
-- tra трасса      (gis_traces.rowid)
-- loc привязка    (denet.rowid)
*/
DECLARE
  ObjT integer; -- тип узла  (ЛИНИЯ ТП ...)
  NewRowid integer = -1;
BEGIN
   SELECT INTO ObjT objtype FROM gis_traces WHERE rowid = tra;
   IF ObjT IS NULL THEN
      ObjT := 0;
   END IF;
   BEGIN
      INSERT INTO regdevconn 
      (pointid, traceid, locid, kod, objtype) VALUES 
      (poi,     tra,     loc,   are, ObjT) RETURNING rowid INTO NewRowid;  
   EXCEPTION
      WHEN UNIQUE_VIOLATION THEN
      NewRowid =  -10;
   END;
   RETURN NewRowid;
--
end
$$;

comment on function bee_add_regdevconn(integer, integer, integer, varchar) is 'Привязка устройства к трассе. Используетя в AppUtils.java';

alter function bee_add_regdevconn(integer, integer, integer, varchar) owner to postgres;

