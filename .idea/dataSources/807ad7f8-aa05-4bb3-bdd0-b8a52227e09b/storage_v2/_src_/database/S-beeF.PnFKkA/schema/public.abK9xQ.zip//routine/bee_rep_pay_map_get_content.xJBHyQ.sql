create function bee_rep_pay_map_get_content(bd_rowid integer) returns SETOF bee_rep_pay_map
    language sql
as
$$
    /*
        ito06 2011-09-19 Карта расхода
        add ito06 2013-09-26 
        add ito06 2014-04-16	
    */
	     SELECT 
		    '01'||to_char(bd.docdat,'.MM.YYYY') AS s_date,
		    to_char((to_char(bd.docdat+'1 month'::interval,'YYYY-MM')||'-01')::date -'1 day'::interval,'DD.MM.YYYY') AS e_date,
		    func.*,
		    bdc.price,
		    sum (CASE 
		        WHEN func.amn_docnumber IS NOT NULL
			   THEN bdc1.cost_no_tax
			ELSE bdc.cost_no_tax
		    END),  
		    sum(CASE 
		        WHEN func.amn_docnumber IS NOT NULL
			   THEN bdc1.tax_sum         
			ELSE bdc.tax_sum
		    END), 
		    sum(CASE 
		        WHEN func.amn_docnumber IS NOT NULL
			   THEN bdc1.cost_with_tax           
			ELSE bdc.cost_with_tax
		    END)
	       FROM bee_rep_map_info_get_content((SELECT linkid FROM bee_docs WHERE rowid=$1),
		                                 (to_char((SELECT docdat FROM bee_docs WHERE rowid=$1),'YYYY-MM')||'-01')::date,
		                                 ((to_char((SELECT docdat FROM bee_docs WHERE rowid=$1)+'1 month'::interval,'YYYY-MM')||'-01')::date -'1 day'::interval)::date) AS func
	  LEFT JOIN bee_docs_calc AS bdc ON bdc.linkid2 = func.apn_rowid AND bdc.linkid1 = $1 AND func.row850 = bdc.quantity_id
	  LEFT JOIN (
		    (select linkid1, linkid2, 
			    sum(quantity_amo) AS quantity_amo,
		            sum(cost_no_tax) AS cost_no_tax, 
		            sum(b.tax_sum) As tax_sum, 
		            sum(b.cost_with_tax) As cost_with_tax
		      from bee_docs_calc AS b 
		      where b.linkid1 = $1  
		      group by linkid1, linkid2
		    )UNION
		     (select linkid1, linkid2, quantity_amo,
		            sum(cost_no_tax) AS cost_no_tax, 
		            sum(b.tax_sum) As tax_sum, 
		            sum(b.cost_with_tax) As cost_with_tax
		      from bee_docs_calc AS b 
		      where b.linkid1 = $1  
		      group by linkid1, linkid2,quantity_amo
		    ) 
		    )AS bdc1 ON bdc1.linkid2 = func.apn_rowid AND bdc1.linkid1 = $1  AND func.v850 = bdc1.quantity_amo
	  LEFT JOIN bee_docs AS bd ON bd.rowid = $1
	      GROUP BY amn_docnumber, cst_name, obj, prdnum, account, ul, v198, v196, v195, v407, v850, loss_h, loss_tot, loss_l, loss_n, koef, dopsum, bd.docdat, bdc.price, apn_rowid, row850, dat
	ORDER BY account, apn_rowid, prdnum, dat


$$;

comment on function bee_rep_pay_map_get_content(integer) is 'Карта расхода. Используется в bee_rep_pay_map_get_content_with_corr(int)';

alter function bee_rep_pay_map_get_content(integer) owner to pgsql;

