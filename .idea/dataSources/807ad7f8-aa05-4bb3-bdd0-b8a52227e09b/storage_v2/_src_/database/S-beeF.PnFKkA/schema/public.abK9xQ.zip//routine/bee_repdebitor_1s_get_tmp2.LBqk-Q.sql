create function bee_repdebitor_1s_get_tmp2(loc integer, dat date) returns SETOF bee_repdebitor_1s_tmp2
    language plpgsql
as
$$
DECLARE
     RowLine bee_repdebitor_1s_tmp2%rowtype;
     tmp numeric = 0;
 tmp2 numeric =0;
     
     
BEGIN


FOR RowLine IN (
        SELECT  null::integer,
                a.roww,		
		a.docdat, 
		a.o_deb, 	
		a.o_kr, 	
		a.col4, 	
		a.col5,	
		a.col6,	
		a.col7, 	
		a.col8,
		a2.col5
		
         from bee_repdebitor_1s_get_tmp($1,$2) As a
         JOIN (  SELECT roww AS roww,			
		        sum(col5) AS col5	
                    from bee_repdebitor_1s_get_tmp($1,$2) 
                    Group by roww)As a2 	ON a2.roww = a.roww
)
LOOP 


RETURN NEXT RowLine;
END LOOP;
       						
END;

$$;

alter function bee_repdebitor_1s_get_tmp2(integer, date) owner to postgres;

