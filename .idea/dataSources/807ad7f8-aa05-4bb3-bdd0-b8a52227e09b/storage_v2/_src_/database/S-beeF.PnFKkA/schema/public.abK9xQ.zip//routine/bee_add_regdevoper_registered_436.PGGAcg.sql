create function bee_add_regdevoper_registered_436(pointid integer, opdate date, days integer) returns integer
    language plpgsql
as
$$
/*
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2014-12-08 Для прямых договоров не вводить/сохраннять показания если параметр “потребление без суббабонентов” (850) отрицательный
	add ito06 2013-11-05 
	add ito06 2013-09-20 
	add ito07 2012-10-25 Лашин ВА (15,4 -->15,4)
	
	РАСЧЁТ ПО МОЩНОСТИ
	ЗАПОЛНЕНИЕ ПАРАМЕТРОВ в regdevoper 
	pointid  - код точки подключения по договору
	opdate   - дата занесения показаний
	days     - кол-во рабочих днй в расчётном периоде (  если < 0 то расчёт по вводимой дате )   
*/

DECLARE
   -- проверка на соответствие числу
   NUMBER_EXPR CONSTANT TEXT := E'^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$';

   -- *** ОПЕРАТИВНЫЕ ПАРАМЕТРЫ СЧЁТЧИКА
   OPER_CALC_TAG  CONSTANT INTEGER := 193;  -- paramid = 193 val = 99 valman = 435
   OPER_CALC_REF  CONSTANT TEXT    := '99';
   OPER_CALC_VID  CONSTANT TEXT    := '436';
   -- 
   OPER_CUR_DATE      CONSTANT INTEGER := 194; -- дата снятия показаний
   OPER_CUR_REGS      CONSTANT INTEGER := 195; -- текущие показания
   OPER_PREV_REGS     CONSTANT INTEGER := 196; -- предыдущие показания
   OPER_PREV_DATE     CONSTANT INTEGER := 197; -- дата снятия пред-х показаний
   OPER_DIFF_REGS     CONSTANT INTEGER := 198; -- разность показаний
   OPER_WORK_DAYS     CONSTANT INTEGER := 200; -- кол-во рабочих дней в расчётном периоде
   OPER_CNT_STOP_DATE CONSTANT INTEGER := 201; -- дата остановки счётчика   
   OPER_CNT_STOP_AMO  CONSTANT INTEGER := 256; -- показания при снятии   
   OPER_REP_AMO       CONSTANT INTEGER := 407; -- отчетное количество эл. эн.   
   OPER_SUB_SUM       CONSTANT INTEGER := 849; -- потреблено субабонентами   
   OPER_OWN_SUM       CONSTANT INTEGER := 850; -- потреблено без субабонентов

   --** add ito06 2013-09-20
   OPER_SOC_NORM   CONSTANT INTEGER := 1446; -- соц.норма
   OPER_OVER_SNORM   CONSTANT INTEGER := 1174; -- сверх соц.нормы
   --**
     
   --
   ATTR_ACCEPTABLE_POWER CONSTANT INTEGER := 424; -- разрешнная мощность   
   ATTR_DAY_WRK_HOURS    CONSTANT INTEGER := 425; -- кол-во рабочих часов в сутках   
   --
   PrevCalcVid  INTEGER; -- код предыдущего вида расчёта
   DevI 	INTEGER; -- 
   OpPrevDat    DATE;    -- дата предыдущих показаний
   OpCurrDat    DATE;    -- дата текущих    показаний 
   --
   WorkHours   INTEGER := 0; -- кол-во часов работы в сутки
   WorkDays    INTEGER := 0; -- кол-во рабочих дней
   OffDays     INTEGER := 0; -- кол-во выходных дней
   CntStopDate VARCHAR := '0';
   CntStopAmo  VARCHAR := '0';
   --
   SubAboSum   NUMERIC(15,4) := 0; -- потреблено субабонентами 
   OwnAboSum   NUMERIC(15,4) := 0; -- потреблено без субабонентов
   OpPrevReg   NUMERIC(15,4) := 0; -- предыдущие показания 
   OpRepVal    NUMERIC(15,4) := 0; -- отчётное кол-во эл.энергии (407) 
   AgreePower  NUMERIC(15,4) := 0; -- разрешённая мощность по ТУ
   --
   v202   varchar;
   v257   varchar;
   v637   varchar;
   v1005  varchar;
   _transmit boolean = false; --** 2014-12-08

   --
BEGIN
   -- SAVE
   v202  = (SELECT valman FROM regdevoper WHERE linkid = pointid AND operdate = opdate AND paramid = 202  LIMIT 1);
   v257  = (SELECT valman FROM regdevoper WHERE linkid = pointid AND operdate = opdate AND paramid = 257  LIMIT 1);
   v637  = (SELECT valman FROM regdevoper WHERE linkid = pointid AND operdate = opdate AND paramid = 637  LIMIT 1);
   v1005 = (SELECT valman FROM regdevoper WHERE linkid = pointid AND operdate = opdate AND paramid = 1005 LIMIT 1);
   --   
   --
   -- ОБОБЩИТЬ действия по (сохранить) и (заполнить)
   --
   --DELETE FROM regdevoper WHERE linkid = pointid AND operdate = opdate;

   --
   -- предыдущий вид расчётаparamval
   --
   PrevCalcVid := (
      SELECT valman::integer FROM regdevoper 
        WHERE 
          linkid    = pointid       AND
          operdate  < opdate        AND 
          paramid   = OPER_CALC_TAG AND 
          val       = OPER_CALC_REF 
        ORDER BY operdate DESC 
        LIMIT 1
   );

   OpPrevDat := COALESCE((SELECT valman::date FROM regdevoper 
         WHERE linkid    = pointid       
            AND operdate  < opdate         
            AND paramid   = OPER_CUR_DATE 
            AND valman LIKE '____-__-__' 
         ORDER BY operdate DESC 
         LIMIT 1
   ),opdate);

   --
   -- количество часов работы в сутки 
   --
   WorkHours = COALESCE((
       SELECT paramval::numeric FROM agreeregdev_period 
         WHERE 
	   linkid        = pointid 
	   AND paramid   = ATTR_DAY_WRK_HOURS 
	   AND paramval  ~ NUMBER_EXPR
           AND period    <= opdate
       ORDER BY period DESC    
       LIMIT 1),
   0);
   --
   -- разрешённая мощность по ТУ
   --
   AgreePower = COALESCE((
       SELECT paramval::numeric FROM agreeregdev_period 
         WHERE 
	   linkid        = pointid 
	   AND paramid   = ATTR_ACCEPTABLE_POWER 
	   AND paramval  ~ NUMBER_EXPR
           AND period    <= opdate
       ORDER BY period DESC    
       LIMIT 1),
   0);

   --
   -- выходные дни Будогянц
   --
   IF 
      (SELECT paramval FROM agreeregdev_period
        WHERE  
          linkid   = pointid  
          AND paramid  = 689
          AND period <= opdate
          ORDER BY period DESC
          LIMIT 1
      )::numeric = 430 THEN
          OffDays = 0;
   ELSEIF 
      (SELECT paramval FROM agreeregdev_period
        WHERE  
          linkid   = pointid  
          AND paramid  = 689
          AND period <= opdate
          ORDER BY period DESC
          LIMIT 1
      )::numeric = 431 THEN
              OffDays = (SELECT count(*) FROM bee_calendar 
                         WHERE dat BETWEEN  (OpPrevDat + INTERVAL '1 day') AND opdate 
                         LIMIT 1
                        );
   END IF;
   -- 

   --
   -- отсутствуют предудущие показания
   --  
   IF PrevCalcVid IS NULL THEN   
      IF days < 0 THEN -- дни из даты
         IF --Будогянц при первом расчете кол-во выходных дней считается от первого числа месяца 
           (SELECT paramval FROM agreeregdev_period
             WHERE  
                linkid   = pointid  
                AND paramid  = 689
                AND period <= opdate
              ORDER BY period DESC
            LIMIT 1
            )::numeric = 430 THEN
            OffDays = 0;
         ELSEIF 
            (SELECT paramval FROM agreeregdev_period
             WHERE  
                linkid   = pointid  
                AND paramid  = 689
                AND period <= opdate
             ORDER BY period DESC
             LIMIT 1
            )::numeric = 431 THEN
              OffDays = (SELECT count(*) FROM bee_calendar 
                   WHERE dat BETWEEN  (date_trunc('month', opdate)) AND opdate 
                   LIMIT 1
              );
         END IF; --Будогянц конец; 
         WorkDays = extract('day' from opdate) - OffDays; -- < 0  
      ELSE -- дни ручной ввод
         WorkDays = days; -- >0 руч ввод
      END IF;       
   --
   --  наличие в предыдущем периоде расчёта по (сумме) или по (мощности)
   --
   ELSEIF ((PrevCalcVid = 436) OR (PrevCalcVid = 437)) THEN

      OpPrevDat := (SELECT operdate FROM regdevoper 
         WHERE 
            linkid    = pointid       AND
            operdate  < opdate        AND 
            paramid   = OPER_CALC_TAG AND -- вид расчёта
            val       = OPER_CALC_REF 
         ORDER BY operdate DESC 
         LIMIT 1
      );    
        
     IF days < 0 THEN -- дни из даты
        WorkDays = opdate - OpPrevDat - OffDays;      
     ELSE -- дни ручной ввод
        WorkDays = days;
     END IF;
   --   
   -- расчёт по мощности после расчёта по показаниям
   --         
   ELSEIF PrevCalcVid = 435 THEN  
      IF days < 0 THEN -- дни из даты
         WorkDays = opdate - OpPrevDat - OffDays;      
      ELSE -- дни ручной ввод
         WorkDays = days;
      END IF;
      CntStopDate = OpPrevDat;
      CntStopAmo  = COALESCE((
         SELECT valman::numeric FROM regdevoper 
         WHERE 
	   linkid        = pointid 
	   AND paramid   = OPER_CUR_REGS  
	   AND valman   ~ NUMBER_EXPR
           AND operdate < opdate
         ORDER BY operdate DESC    
         LIMIT 1),
      0); 
           
   END IF; 
   
   -------------------------------------------------------------
   -- отчётное количество
   OpRepVal = WorkDays * WorkHours * AgreePower;
   -- потреблено субабонентами
   SubAboSum = COALESCE(bee_get_subabo_sum_1(pointid, opdate::text),0);
   --** 2014-12-08  SubAboSum = COALESCE(bee_set_subabo_sum_1(pointid, opdate::text),0);

   -- потреблено без субабонентов
   OwnAboSum = OpRepVal - SubAboSum;
   
   --** 2014-12-08 
   SELECT doctype in (1910, 1911) FROM agreement AS amn join agreepoint AS apn ON apn.linkid = amn.rowid AND apn.rowid = pointid  INTO _transmit;--** 2016-04-25   
   IF _transmit IS NULL THEN _transmit = false; END IF;

   IF  OwnAboSum < -0.50 AND _transmit
	THEN IF SubAboSum >  0 
	        THEN RETURN -7; 
	        ELSE RETURN -6; 
	      END IF;
   END IF;
   --**
   --
   DevI = (SELECT devid FROM agreepoint WHERE rowid = pointid LIMIT 1);   
   
   IF NOT EXISTS(SELECT 1 FROM regdevoper WHERE linkid = pointid AND operdate = opdate LIMIT 1) THEN
     INSERT INTO regdevoper 
       (linkid, operdate, paramid, ed,
          val, valman, timeperiod)  
       (SELECT pointid,opdate, paramid, ed,
       CASE -- val
          WHEN paramid = OPER_CALC_TAG THEN '99'
          WHEN paramid = 1005          THEN '121' 
          ELSE val
       END,	
       CASE -- valman 	
	  WHEN  paramid = OPER_CALC_TAG      THEN  OPER_CALC_VID              -- вид расчёта
	  WHEN  paramid = OPER_WORK_DAYS     THEN  WorkDays::text             -- количество рабочих дней в расч периоде  
          WHEN  paramid = OPER_CNT_STOP_DATE THEN  CntStopDate::text          -- дата остановки счётчика
          WHEN  paramid = OPER_CNT_STOP_AMO  THEN  CntStopAmo::text           -- показания при снятии          
          WHEN  paramid = OPER_CUR_DATE      THEN  opdate::text               -- дата снятия показани
	  WHEN  paramid = OPER_PREV_REGS     THEN  OpPrevReg::text            -- предыдущие показания 
          WHEN  paramid = OPER_PREV_DATE     THEN  OpPrevDat::text            -- дата снятия пред. показаний 
	  WHEN  paramid = OPER_REP_AMO       THEN  ROUND(OpRepVal,0)::text    -- отчётное кол-во эл.энергии
          WHEN  paramid = OPER_CUR_REGS      THEN  '0'                        -- текущие показания
          WHEN  paramid = OPER_SOC_NORM      THEN  '0'    		      -- соц. норма кВт*ч
          WHEN  paramid = OPER_OVER_SNORM    THEN  '0' 			      -- сверх соц. нормы кВт*ч                  
          WHEN  paramid = OPER_SUB_SUM       THEN  ROUND(SubAboSum,0)::text   -- потреблено субабонентами  
          WHEN  paramid = OPER_OWN_SUM       THEN  ROUND(OwnAboSum,0)::text   -- потреблено без субабонентов  
          WHEN  paramid = 1005               THEN '-'
	  ELSE  CASE WHEN valman IS NULL THEN '-'
	            ELSE valman END
       END,
       timeperiod 
       FROM regdevattr 
       WHERE 
          deviceid = DevI AND
          (paramid  IN (
              SELECT rowid FROM dic_elements 
              WHERE 
                 link = 38 AND 
                 element_code::text LIKE '3%'
          )
          ) AND
          (paramid  NOT IN (
              SELECT paramid FROM regdevoper 
              WHERE 
                 linkid    = pointid AND 
                 operdate  = opdate
              )
         )
     );
   ELSE 
     UPDATE regdevoper SET 
          val = 
             CASE
                WHEN paramid = OPER_CALC_TAG THEN '99'
                WHEN paramid = 1005          THEN '121' 
                ELSE val
             END,	
          valman =   
             CASE 	
	        WHEN  paramid = OPER_CALC_TAG      THEN  OPER_CALC_VID              -- вид расчёта
	        WHEN  paramid = OPER_WORK_DAYS     THEN  WorkDays::text             -- количество рабочих дней в расч периоде  
                WHEN  paramid = OPER_CNT_STOP_DATE THEN  CntStopDate::text          -- дата остановки счётчика
                WHEN  paramid = OPER_CNT_STOP_AMO  THEN  CntStopAmo::text           -- показания при снятии          
                WHEN  paramid = OPER_CUR_DATE      THEN  opdate::text               -- дата снятия показани
	        WHEN  paramid = OPER_PREV_REGS     THEN  OpPrevReg::text            -- предыдущие показания 
                WHEN  paramid = OPER_PREV_DATE     THEN  OpPrevDat::text            -- дата снятия пред. показаний 
	        WHEN  paramid = OPER_REP_AMO       THEN  ROUND(OpRepVal,0)::text    -- отчётное кол-во эл.энергии
                WHEN  paramid = OPER_CUR_REGS      THEN  '0'                        -- текущие показания
                WHEN  paramid = OPER_SOC_NORM      THEN  '0'    		    -- соц. норма кВт*ч
                WHEN  paramid = OPER_OVER_SNORM    THEN  '0' 			    -- сверх соц. нормы кВт*ч 
                WHEN  paramid = OPER_SUB_SUM       THEN  ROUND(SubAboSum,0)::text   -- потреблено субабонентами
                WHEN  paramid = OPER_OWN_SUM       THEN  ROUND(OwnAboSum,0)::text   -- потреблено без субабонентов
                WHEN  paramid = 1005               THEN '-'
	        ELSE CASE WHEN valman IS NULL THEN '-'
	            ELSE valman
	       END 
       END
       WHERE linkid = pointid AND operdate = opdate;
   END IF;

   -- RESORE
   IF v202 IS NOT NULL THEN 
	UPDATE regdevoper SET valman = v202  WHERE linkid = pointid AND operdate = opdate AND paramid = 202;
   END IF;
   IF v257 IS NOT NULL THEN 
	UPDATE regdevoper SET valman = v257  WHERE linkid = pointid AND operdate = opdate AND paramid = 257;
   END IF;
  
	UPDATE regdevoper SET valman = v637  WHERE linkid = pointid AND operdate = opdate AND paramid = 637;
  
   IF v1005 IS NOT NULL THEN 
	UPDATE regdevoper SET valman = v1005 WHERE linkid = pointid AND operdate = opdate AND paramid = 1005;
   END IF;
   
RETURN 0;
--
END;
$$;

comment on function bee_add_regdevoper_registered_436(integer, date, integer) is 'Расчет по мощности заполнение параметров в regdevoper. Используется в AgreeRegDev.java, AppUtils.java';

alter function bee_add_regdevoper_registered_436(integer, date, integer) owner to pgsql;

