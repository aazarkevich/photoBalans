create function bee_period_check() returns trigger
    language plpgsql
as
$$
/*
    add itio06 2014-11-27	
    add itio06 2013-08-05
    add itio06 2013-04-17
    add itio06 2012-01-25
    ito07 2011-05-20
    ПРОВЕРКА ЗАКРЫТИЯ РАБОЧЕГО ПЕРИОДА
*/
DECLARE
   IsClosed    BOOLEAN := FALSE;
   _NewDate    DATE;
   _CPeriodAll DATE; 
   _CPeriodUni DATE; 
   _CPeriodMix DATE;
   _CPeriodDir DATE;
   _CPeriodUniMix DATE;
   --
   IsSim      BOOLEAN := FALSE;
   IsUni      BOOLEAN := FALSE;
   IsMix      BOOLEAN := FALSE;
   IsSUM      BOOLEAN := FALSE;
   --
   tbl_name    VARCHAR;
   PointAgreeType  INTEGER; -- 0 - простая, 1 - центр, 2 - смеш, 3 - центр+смеш, 4 - прямой
   _PointID    INTEGER;
   -- 
   NEW_Y       INTEGER;
   OLD_Y       INTEGER;
   BTmp        BOOLEAN := FALSE;
   _Loc        INTEGER;
   --
BEGIN
   ----------- 191205 by ito07 ---------------------------
   if inet_client_addr() = '192.168.70.9' then
     raise notice '==== NO PASARAN : % : %',inet_client_addr(),current_query();
     return null; 
   end if;
   --------------------------------------------------------
   tbl_name = TG_TABLE_NAME::varchar;

   CASE tbl_name
      -- необходима проверка
      WHEN 'agreepoint_docs',
           'agreeregdev_period',
           'agreepoint_tarif',
           'bee_docs',
           'bee_docs_sheet',
           'bee_docs_bills',
           'bee_docs_calc',
           'bee_docs_pay',
           'bee_docs_rests',
           'bee_docs_corr',
           'bee_docs_result',
           'bee_docs_loss',
           'bee_points_consum',     
           'bee_points_consum_f',
           'bee_points_consum_t', --2014-11-27
           'regdevoper',
           'regdevoper937',
           'regdevoper975',
           'regdevoper976',
           'regdevoper977', 
           'agreement_info' 
        THEN isClosed = FALSE;
      ELSE
         -- без проверки
         IF (TG_OP = 'DELETE') THEN
            RETURN OLD;
         ELSIF (TG_OP = 'UPDATE') THEN
            RETURN NEW;
         ELSIF (TG_OP = 'INSERT') THEN
            RETURN NEW;
         ELSE 
            RETURN NULL;
         END IF;
   END CASE;


   -- определить точку учёта и проверяемую дату
   CASE tbl_name
      WHEN 'regdevoper',
           'regdevoper937',
           'regdevoper975',
           'regdevoper976',
           'regdevoper977'
            THEN 
                 IF   TG_OP = 'DELETE' THEN
                      _PointID = OLD.linkid; 
                      _NewDate = OLD.operdate;                
                      EXECUTE 'SELECT amn.locid  
                                FROM agreement AS amn
                                JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                               WHERE apn.rowid = '|| OLD.linkid||' 
                               LIMIT 1' into _Loc;
                   ELSE   
                       _PointID = NEW.linkid; 
                       _NewDate = NEW.operdate; 
                       EXECUTE 'SELECT amn.locid  
                                FROM agreement AS amn
                                JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                               WHERE apn.rowid = '|| NEW.linkid ||' 
                               LIMIT 1' into _Loc;                    
                 END IF;
      WHEN 'agreement_info'
           THEN                
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid;
                    _NewDate = OLD.period;
                     EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                              WHERE amn.rowid  = '|| OLD.linkid ||' 
                              LIMIT 1' into _Loc;                    
                 ELSE 
                    _PointID = NEW.linkid;
                    _NewDate = NEW.period; 
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn 
                              WHERE amn.rowid = '|| NEW.linkid ||' 
                              LIMIT 1' into _Loc;                     
                END IF;                    
              
      WHEN 'agreepoint_docs'
           THEN                
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid;
                    _NewDate = OLD.docdat; 
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                              WHERE apn.rowid = '|| OLD.linkid ||' 
                              LIMIT 1' into _Loc;                   
                 ELSE 
                    _PointID = NEW.linkid;
                    _NewDate = NEW.docdat; 
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                              WHERE apn.rowid = '|| NEW.linkid ||' 
                              LIMIT 1' into _Loc;                   
                END IF;      
      WHEN 'agreeregdev_period'
           THEN 
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid;
                    _NewDate = OLD.period;
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                              WHERE apn.rowid  = '|| OLD.linkid ||' 
                              LIMIT 1' into _Loc;                      
                 ELSE  
                    _PointID = NEW.linkid;
                    _NewDate = NEW.period; 
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                              WHERE apn.rowid  = '|| NEW.linkid ||' 
                              LIMIT 1' into _Loc;                                        
               END IF;    
      WHEN 'agreepoint_tarif' 
           THEN 
                
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.pointid;
                    _NewDate = OLD.period;
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid  
                              WHERE apn.rowid  = '|| OLD.pointid ||' 
                              LIMIT 1' into _Loc;                   
                 ELSE  
                    _PointID = NEW.pointid;
                    _NewDate = NEW.period;    
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid  
                              WHERE apn.rowid  = '|| NEW.pointid ||' 
                              LIMIT 1' into _Loc;                
              END IF;     
      WHEN 'bee_docs'         
           THEN                 
                IF TG_OP = 'DELETE' THEN
                   _PointID = OLD.rowid;
                   _NewDate = OLD.docdat;
                   EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                              WHERE amn.rowid  = '|| OLD.linkid ||' 
                              LIMIT 1' into _Loc;                   
                  ELSE  
                     _PointID = NEW.rowid;
                     _NewDate = NEW.docdat;
                     EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn 
                              WHERE amn.rowid = '|| NEW.linkid ||' 
                              LIMIT 1' into _Loc;                     
                END IF;             
      WHEN 'bee_docs_sheet'    
           THEN 
                IF TG_OP = 'DELETE' THEN
                   _PointID = OLD.linkid2; -- bee_docs.rowid
                   _NewDate = NULL;
                   EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                              WHERE amn.rowid  = '|| OLD.linkid1 ||' 
                              LIMIT 1' into _Loc;                   
                  ELSE
                     _PointID = NEW.linkid2; -- bee_docs.rowid
                     _NewDate = NULL;    
                     EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                              WHERE amn.rowid  = '|| NEW.linkid1 ||' 
                              LIMIT 1' into _Loc;             
                END IF;
      WHEN 'bee_docs_calc'    
           THEN                
                IF   TG_OP = 'DELETE' THEN
                     _PointID = OLD.linkid1; -- bee_docs.rowid
                     _NewDate = NULL; 
                     EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                              WHERE apn.rowid  = '|| OLD.linkid2 ||' 
                              LIMIT 1' into _Loc;                 
                  ELSE
                     _PointID = NEW.linkid1; -- bee_docs.rowid
                     _NewDate = NULL;
                 EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                              WHERE apn.rowid  = '|| NEW.linkid2 ||' 
                              LIMIT 1' into _Loc;                     
                END IF;
      WHEN 'bee_docs_result'    
           THEN 
                IF   TG_OP = 'DELETE' THEN
                     _PointID = OLD.linkid; -- bee_docs.rowid
                     _NewDate = NULL;
                     EXECUTE 'SELECT amn.locid  
                                FROM agreement AS amn
                                JOIN bee_docs  AS bd  ON bd.linkid = amn.rowid  
                               WHERE bd.rowid = '|| OLD.linkid ||' 
                               LIMIT 1' into _Loc;                     
                  ELSE
                     _PointID = NEW.linkid; -- bee_docs.rowid
                     _NewDate = NULL;
                     EXECUTE 'SELECT amn.locid  
                                FROM agreement AS amn
                                JOIN bee_docs  AS bd  ON bd.linkid = amn.rowid 
                                WHERE bd.rowid = '|| NEW.linkid ||' 
                               LIMIT 1' into _Loc;                      
              END IF;
      WHEN 'bee_docs_pay'     
           THEN 
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid2; -- bee_docs.rowid
                    _NewDate = NULL;
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                              WHERE amn.rowid = '|| OLD.linkid1 ||' 
                              LIMIT 1' into _Loc;                    
                 ELSE 
                    _PointID = NEW.linkid2; -- bee_docs.rowid
                    _NewDate = NULL;     
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                              WHERE amn.rowid = '|| NEW.linkid1 ||' 
                              LIMIT 1' into _Loc;               
                    
               END IF; 
      WHEN 'bee_docs_corr'     
           THEN 
                
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid2; -- bee_docs.rowid
                    _NewDate = NULL;   
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                              WHERE apn.rowid = '|| OLD.linkid2 ||' 
                              LIMIT 1' into _Loc;                 
                 ELSE 
                    _PointID = NEW.linkid2; -- bee_docs.rowid
                    _NewDate = NULL;
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid 
                              WHERE apn.rowid = '|| NEW.linkid2 ||' 
                              LIMIT 1' into _Loc;                      
               END IF; 
      WHEN 'bee_docs_rests'   
           THEN 
               
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid2; -- bee_docs.rowid
                    _NewDate = NULL;
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                              WHERE amn.rowid = '|| OLD.linkid1 ||' 
                              LIMIT 1' into _Loc;                       
                 ELSE  
                    _PointID = NEW.linkid2; -- bee_docs.rowid
                    _NewDate = NULL; 
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                              WHERE amn.rowid = '|| NEW.linkid1 ||' 
                              LIMIT 1' into _Loc;                   
               END IF;
      WHEN 'bee_docs_loss'    
           THEN 
               
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid2; -- bee_docs.rowid
                    _NewDate = NULL; 
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn 
                              WHERE amn.rowid = '|| OLD.linkid1 ||' 
                              LIMIT 1' into _Loc;  
                 ELSE
                    _PointID = NEW.linkid2; -- bee_docs.rowid
                    _NewDate = NULL;  
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn 
                              WHERE amn.rowid = '|| NEW.linkid1 ||' 
                              LIMIT 1' into _Loc;                                     
               END IF;
     WHEN 'bee_points_consum'
           THEN
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid;
                    _NewDate = OLD.period;
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid  
                              WHERE apn.rowid  = '||  OLD.linkid ||' 
                              LIMIT 1' into _Loc;                                       
                 ELSE   
                    _PointID = NEW.linkid;
                    _NewDate = NEW.period;   
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                               JOIN agreepoint AS apn  ON apn.linkid = amn.rowid  
                              WHERE apn.rowid  = '||  NEW.linkid ||' 
                              LIMIT 1' into _Loc;                  
                    
          END IF;
     WHEN 'bee_points_consum_f'
           THEN               
               IF    TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid2;
                    _NewDate = OLD.period; 
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn 
                              WHERE amn.rowid = '|| OLD.linkid1 ||' 
                              LIMIT 1' into _Loc;                   
                 ELSE   
                    _PointID = NEW.linkid2;
                    _NewDate = NEW.period; 
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn
                              WHERE amn.rowid = '|| NEW.linkid1 ||' 
                              LIMIT 1' into _Loc;                   
            END IF;
      -- 2014-11-27
      WHEN 'bee_points_consum_t'
           THEN
               IF   TG_OP = 'DELETE' THEN
                    _PointID = OLD.linkid;  --agreement.rowid
                    _NewDate = OLD.period;
                     EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn 
                              WHERE amn.rowid = '|| OLD.linkid ||' 
                              LIMIT 1' into _Loc;                                      
                 ELSE   
                    _PointID = NEW.linkid; --agreement.rowid
                    _NewDate = NEW.period;   
                    EXECUTE 'SELECT amn.locid  
                               FROM agreement AS amn 
                              WHERE amn.rowid = '|| NEW.linkid ||' 
                              LIMIT 1' into _Loc;                   
               END IF;       
      --       
      ELSE
   END CASE;
   
   -- даты закрытия
   SELECT period FROM bee_closed_period     WHERE  filloc = _loc LIMIT 1 INTO _CPeriodAll;
   SELECT period FROM bee_closed_period_uni WHERE  filloc = _loc LIMIT 1 INTO _CPeriodUni;
   SELECT period FROM bee_closed_period_mix WHERE  filloc = _loc LIMIT 1 INTO _CPeriodMix;
   SELECT period FROM bee_closed_period_dir WHERE  filloc = _loc LIMIT 1 INTO _CPeriodDir;

   IF (_CPeriodAll > _CPeriodDir) THEN
       _CPeriodDir = _CPeriodAll;
   END IF; 
   IF (_CPeriodDir > _CPeriodUni)  THEN
       _CPeriodUni = _CPeriodDir;
   END IF;  
   IF (_CPeriodDir > _CPeriodMix) THEN   
       _CPeriodMix = _CPeriodDir;    
   END IF;  
   -- **
   
  /* 
     код типа точки учёта по виду договора: 0 1 2 3 4  
     0 - простой
     1 - централизованный
     2 - смешанный
     3 - централизованная + смешанная
     4 - прямой
  */ 
 
    PointAgreeType = bee_get_point_agree_type(_PointID, tbl_name);
    
   ----------------------------------------------------
IF 
    (tbl_name = 'agreepoint_info') OR
    (tbl_name = 'bee_docs')        OR   
    (tbl_name = 'bee_docs_calc')   OR 
    (tbl_name = 'bee_docs_pay')    OR
    (tbl_name = 'bee_docs_rests')  OR
    (tbl_name = 'bee_docs_result') OR
    (tbl_name = 'bee_docs_loss')   OR       
    (tbl_name = 'bee_docs_corr')    THEN 
      ---------------------------------
      SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodDir,_NewDate) INTO BTmp;
      
      IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN
            IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN NEW;
            END IF; 
      END IF; 
      IF (TG_OP = 'DELETE') THEN
            IF BTmp = TRUE THEN
              RETURN NULL;
            ELSE
               RETURN OLD;
            END IF; 
      END IF; 
   END IF;
   ------------------------------------
  
   IF (tbl_name <> 'bee_points_consum' AND tbl_name <> 'bee_points_consum_f' AND tbl_name <> 'bee_points_consum_t' ) THEN
      --   простая точка учёта
      IF PointAgreeType = 0 THEN
         SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodAll,_NewDate) INTO BTmp;
         IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN
            IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN NEW;
            END IF; 
         END IF; 
         IF (TG_OP = 'DELETE') THEN
            IF BTmp = TRUE THEN
              RETURN NULL;
            ELSE
               RETURN OLD;
            END IF; 
         END IF; 
      END IF;

      -- централизованный
      IF (PointAgreeType = 1) THEN
         IF (_CPeriodAll > _CPeriodUni) THEN
            _CPeriodUni = _CPeriodAll;
         END IF;   
         SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodUni,_NewDate) INTO BTmp;        
         IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN
            IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN NEW;
            END IF; 
         END IF; 
         IF (TG_OP = 'DELETE') THEN
            IF BTmp = TRUE THEN
              RETURN NULL;
            ELSE
              RETURN OLD;
            END IF; 
         END IF; 
      END IF;

      -- смешанный
      IF PointAgreeType = 2 THEN
         IF (_CPeriodAll > _CPeriodMix) THEN
            _CPeriodMix = _CPeriodAll;
         END IF;   
         SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodMix,_NewDate) INTO BTmp;
         IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN
            IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN NEW;
            END IF; 
         END IF; 
         IF (TG_OP = 'DELETE') THEN
            IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN OLD;
            END IF; 
         END IF; 
      END IF;

 
    -- прямой
      IF PointAgreeType = 4 THEN
         IF (_CPeriodAll > _CPeriodDir) THEN
            _CPeriodDir = _CPeriodAll;
         END IF;   
         SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodDir,_NewDate) INTO BTmp;
         IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN
            IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN NEW;
            END IF; 
         END IF; 
         IF (TG_OP = 'DELETE') THEN
            IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN OLD;
            END IF; 
         END IF; 
      END IF;


      -- централизованная+смешанная
      IF PointAgreeType = 3 then -- 191127 by ito07 added where filloc = _loc
          SELECT max(period) FROM (
          SELECT period  FROM bee_closed_period     where filloc = _loc     UNION
          SELECT period  FROM bee_closed_period_uni where filloc = _loc  UNION
          SELECT period  FROM bee_closed_period_mix where filloc = _loc
          ) AS m INTO _CPeriodUniMix;

         SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodUniMix,_NewDate) INTO BTmp;
         IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN
            IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN NEW;
            END IF; 
         END IF; 
         IF (TG_OP = 'DELETE') THEN
            IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN OLD;
            END IF; 
         END IF; 
      END IF;
   END IF;

   ---------------------------------------------------------------
   IF (tbl_name = 'bee_points_consum' OR tbl_name = 'bee_points_consum_f' OR tbl_name = 'bee_points_consum_t') THEN  
      IF (TG_OP = 'UPDATE') THEN
        SELECT EXTRACT(YEAR FROM DATE (OLD.period)::date) INTO OLD_Y;
        SELECT EXTRACT(YEAR FROM DATE (NEW.period)::date) INTO NEW_Y;

        IF NEW_Y = OLD_Y THEN -- (Y = Y) 

          IF PointAgreeType = 0 THEN
             IF _CPeriodAll > (NEW_Y::text || '-01-01')::date THEN
               NEW.m01 = OLD.m01;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-02-01')::date THEN
                NEW.m02 = OLD.m02;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-03-01')::date THEN
               NEW.m03 = OLD.m03;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-04-01')::date THEN
               NEW.m04 = OLD.m04;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-05-01')::date THEN
               NEW.m05 = OLD.m05;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-06-01')::date THEN
               NEW.m06 = OLD.m06;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-07-01')::date THEN
                NEW.m07 = OLD.m07;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-08-01')::date THEN
                NEW.m08 = OLD.m08;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-09-01')::date THEN
                NEW.m09 = OLD.m09;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-10-01')::date THEN
               NEW.m10 = OLD.m10;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-11-01')::date THEN
                NEW.m11 = OLD.m11;
             END IF; 
             IF _CPeriodAll > (NEW_Y::text || '-12-01')::date THEN
               NEW.m12 = OLD.m12;
             END IF;
          END IF; -- 0 

          IF (PointAgreeType = 1) THEN -- UNI
            IF (_CPeriodAll > _CPeriodUni) THEN
               _CPeriodUni = _CPeriodAll;
            END IF;   
            --
            IF _CPeriodUni > (NEW_Y::text || '-01-01')::date THEN
               NEW.m01 = OLD.m01;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-02-01')::date THEN
                NEW.m02 = OLD.m02;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-03-01')::date THEN
               NEW.m03 = OLD.m03;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-04-01')::date THEN
               NEW.m04 = OLD.m04;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-05-01')::date THEN
               NEW.m05 = OLD.m05;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-06-01')::date THEN
               NEW.m06 = OLD.m06;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-07-01')::date THEN
                NEW.m07 = OLD.m07;
             END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-08-01')::date THEN
                NEW.m08 = OLD.m08;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-09-01')::date THEN
                NEW.m09 = OLD.m09;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-10-01')::date THEN
               NEW.m10 = OLD.m10;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-11-01')::date THEN
                NEW.m11 = OLD.m11;
            END IF; 
            IF _CPeriodUni > (NEW_Y::text || '-12-01')::date THEN
               NEW.m12 = OLD.m12;
            END IF;
          END IF; -- UNI   

            IF  (PointAgreeType = 4) THEN -- DIR
            IF (_CPeriodAll > _CPeriodDir) THEN
               _CPeriodDir = _CPeriodAll;
            END IF;   
            --
            IF _CPeriodDir > (NEW_Y::text || '-01-01')::date THEN
               NEW.m01 = OLD.m01;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-02-01')::date THEN
                NEW.m02 = OLD.m02;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-03-01')::date THEN
               NEW.m03 = OLD.m03;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-04-01')::date THEN
               NEW.m04 = OLD.m04;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-05-01')::date THEN
               NEW.m05 = OLD.m05;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-06-01')::date THEN
               NEW.m06 = OLD.m06;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-07-01')::date THEN
                NEW.m07 = OLD.m07;
             END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-08-01')::date THEN
                NEW.m08 = OLD.m08;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-09-01')::date THEN
                NEW.m09 = OLD.m09;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-10-01')::date THEN
               NEW.m10 = OLD.m10;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-11-01')::date THEN
                NEW.m11 = OLD.m11;
            END IF; 
            IF _CPeriodDir > (NEW_Y::text || '-12-01')::date THEN
               NEW.m12 = OLD.m12;
            END IF;
          END IF; -- DIR  
      
          IF PointAgreeType = 2 THEN -- MIX
            --
            IF (_CPeriodAll > _CPeriodMix) THEN
               _CPeriodMix = _CPeriodAll;
            END IF;   
            --
            IF _CPeriodMix > (NEW_Y::text || '-01-01')::date THEN
               NEW.m01 = OLD.m01;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-02-01')::date THEN
                NEW.m02 = OLD.m02;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-03-01')::date THEN
               NEW.m03 = OLD.m03;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-04-01')::date THEN
               NEW.m04 = OLD.m04;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-05-01')::date THEN
               NEW.m05 = OLD.m05;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-06-01')::date THEN
               NEW.m06 = OLD.m06;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-07-01')::date THEN
                NEW.m07 = OLD.m07;
             END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-08-01')::date THEN
                NEW.m08 = OLD.m08;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-09-01')::date THEN
                NEW.m09 = OLD.m09;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-10-01')::date THEN
               NEW.m10 = OLD.m10;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-11-01')::date THEN
                NEW.m11 = OLD.m11;
            END IF; 
            IF _CPeriodMix > (NEW_Y::text || '-12-01')::date THEN
               NEW.m12 = OLD.m12;
            END IF;
          END IF; -- MIX
  
          IF PointAgreeType = 3 THEN -- UNI-MIX
            --
            SELECT max(period) FROM (
            SELECT period  FROM bee_closed_period     UNION
            SELECT period  FROM bee_closed_period_uni UNION
            SELECT period  FROM bee_closed_period_mix 
            ) AS m INTO _CPeriodUniMix;
            --
            IF _CPeriodUniMix > (NEW_Y::text || '-01-01')::date THEN
               NEW.m01 = OLD.m01;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-02-01')::date THEN
                NEW.m02 = OLD.m02;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-03-01')::date THEN
               NEW.m03 = OLD.m03;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-04-01')::date THEN
               NEW.m04 = OLD.m04;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-05-01')::date THEN
               NEW.m05 = OLD.m05;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-06-01')::date THEN
               NEW.m06 = OLD.m06;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-07-01')::date THEN
                NEW.m07 = OLD.m07;
             END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-08-01')::date THEN
                NEW.m08 = OLD.m08;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-09-01')::date THEN
                NEW.m09 = OLD.m09;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-10-01')::date THEN
               NEW.m10 = OLD.m10;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-11-01')::date THEN
                NEW.m11 = OLD.m11;
            END IF; 
            IF _CPeriodUniMix > (NEW_Y::text || '-12-01')::date THEN
               NEW.m12 = OLD.m12;
            END IF;
          END IF; -- UNI+MIX  

          RETURN NEW; -- (Y=Y)

        ELSE -- (Y != Y)
           IF OLD.period >= NEW.period THEN
              RETURN NULL; 
           ELSE
              RETURN NEW;
           END IF;   
        END IF; -- (Y=Y) 
      END IF; -- UPDATE

      IF TG_OP = 'INSERT' THEN
         RETURN NEW;
      END IF;  

      IF TG_OP = 'DELETE' THEN
        
         IF PointAgreeType = 0 THEN -- 0
            SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodAll,_NewDate) INTO BTmp;
            IF BTmp = TRUE THEN
              RETURN NULL;
            ELSE
              RETURN OLD;
            END IF; 
         END IF; -- 0

    -- централизованная или прямой
        IF PointAgreeType = 1 THEN
           IF (_CPeriodAll > _CPeriodUni) THEN
             _CPeriodUni = _CPeriodAll;
           END IF;   
           SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodUni,_NewDate) INTO BTmp;        
           IF BTmp = TRUE THEN
               RETURN NULL;
           ELSE
               RETURN OLD;
           END IF; 
         END IF; -- 1 

         --  прямой
         IF  PointAgreeType = 4 THEN
           IF (_CPeriodAll > _CPeriodDir) THEN
             _CPeriodDir = _CPeriodAll;
           END IF;   
           SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodDir,_NewDate) INTO BTmp;        
           IF BTmp = TRUE THEN
               RETURN NULL;
           ELSE
               RETURN OLD;
           END IF; 
         END IF; -- 4 

         -- смешанная
         IF PointAgreeType = 2 THEN
           IF (_CPeriodAll > _CPeriodMix) THEN
              _CPeriodMix = _CPeriodAll;
           END IF;   
           SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodMix,_NewDate) INTO BTmp;
           IF BTmp = TRUE THEN
               RETURN NULL;
           ELSE
               RETURN OLD;
           END IF; 
         END IF; -- 2 

         -- централизованная+смешанная
         IF PointAgreeType = 3 THEN
           SELECT max(period) FROM (
           SELECT period  FROM bee_closed_period     UNION
           SELECT period  FROM bee_closed_period_uni UNION
           SELECT period  FROM bee_closed_period_mix 
           ) AS m INTO _CPeriodUniMix;

           SELECT bee_is_period_closed(_PointID,tbl_name,_CPeriodUniMix,_NewDate) INTO BTmp;
           IF BTmp = TRUE THEN
               RETURN NULL;
            ELSE
               RETURN OLD;
            END IF; 
         END IF; -- 3
         
      END IF; -- DELETE  
   END IF; -- bee_points_consum, bee_points_consum_f
   RETURN NULL;
END;
$$;

comment on function bee_period_check() is 'ПРОВЕРКА ЗАКРЫТИЯ РАБОЧЕГО ПЕРИОДА, Используется при работе с закрытым периодом.';

alter function bee_period_check() owner to pgsql;

