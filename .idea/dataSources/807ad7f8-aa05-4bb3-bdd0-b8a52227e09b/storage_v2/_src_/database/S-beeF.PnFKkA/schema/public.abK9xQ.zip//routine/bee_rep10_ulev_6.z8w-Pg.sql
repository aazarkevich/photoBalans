create function bee_rep10_ulev_6(locid integer, strdate date, ulev character varying, trm_filter character varying, accdir_filter character varying, cd_fiter character varying, sd_fiter character varying) returns SETOF bee_rep_tab10
    language sql
as
$$
/*
ito06 2012-05-15 Приложение 1
Смешанные данные с заполнением пустых ячеек средним
*/
SELECT 
        fil AS fil,  
	loc AS loc,
	docnumber AS docnumber,
	account   AS account,
	ulev AS ulev,
	summ AS summ,
	summ1 AS summ1,
	summ2 AS summ2,
	summ3 AS summ3,
	summ4 AS summ4,
	summ5 AS summ5,
	summ6 AS summ6,
	summ7 AS summ7,
	summ8 AS summ8,
	summ9 AS summ9,
	summ10 AS summ10,
	summ11 AS summ11,
	summ12 AS summ12,
	null::numeric(13,4) As summ_pow,
	summ1*1000/744::numeric(13,4) AS summ1_,
	summ2*1000/(24*(to_char($2,'YYYY-03-01')::date - to_char($2,'YYYY-02-01')::date))::numeric(13,4)  AS summ2_,
	summ3*1000/744::numeric(13,4) AS summ3_,
	summ4*1000/720::numeric(13,4)  AS summ4_,
	summ5*1000/744::numeric(13,4)  AS summ5_,
	summ6*1000/720::numeric(13,4)  AS summ6_,
	summ7*1000/744::numeric(13,4)  AS summ7_,
	summ8*1000/744::numeric(13,4)  AS summ8_,
	summ9*1000/720::numeric(13,4)  AS summ9_,
	summ10*1000/744::numeric(13,4)  AS summ10_,
	summ11*1000/720::numeric(13,4)  AS summ11_,
	summ12*1000/744::numeric(13,4) AS summ12_,
	maxpow AS maxpow,
	prispow AS prispow,
	dl AS dl,
	al AS al
FROM bee_rep10_ulev_en_mid_mix($1, $2, $3, $4, $5, $6, $7);
$$;

comment on function bee_rep10_ulev_6(integer, date, varchar, varchar, varchar, varchar, varchar) is 'Приложение 1 Смешанные данные с заполнением пустых ячеек средним. Используется в bee_rep_get_repdata10(int, date, varchar, varchar, varchar, varchar, int)';

alter function bee_rep10_ulev_6(integer, date, varchar, varchar, varchar, varchar, varchar) owner to pgsql;

