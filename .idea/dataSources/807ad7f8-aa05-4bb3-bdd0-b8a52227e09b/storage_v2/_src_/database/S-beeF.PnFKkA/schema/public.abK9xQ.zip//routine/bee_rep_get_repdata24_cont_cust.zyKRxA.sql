create function bee_rep_get_repdata24_cont_cust(loc_id integer, start_d date, end_d date) returns SETOF bee_repdata24
    language plpgsql
as
$$
/*
	add ito06 2014-08-06
	ito06 2012-02-10:Ведомость по объему услуг
*/
BEGIN
RETURN QUERY(
   SELECT * FROM (
		(SELECT *  FROM bee_rep_get_repdata24_cont_tmp) UNION ALL

		(SELECT * FROM bee_rep_get_repdata24_cont_cust1($1,$2,$3)
                         WHERE (nn,doc_name) IN (SELECT  nn,doc_name  FROM bee_rep_get_repdata24_cont_cust1($1,$2,$3) WHERE dat >'2001-01-01') 
                           AND  (grp  NOT IN ('31','32','33'))
		) UNION ALL
                (SELECT * FROM bee_rep_get_repdata24_cont_cust1($1,$2,$3)
                         WHERE grp IN ('31','32','33')
		) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont_cust2($1,$2,$3))
	) AS a
ORDER BY nn, doc_name, dat, nn_tmp);
END;
$$;

comment on function bee_rep_get_repdata24_cont_cust(integer, date, date) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24_all_cust(int, date, date), bee_rep_get_repdata24_cust(int, date, date)';

alter function bee_rep_get_repdata24_cont_cust(integer, date, date) owner to pgsql;

