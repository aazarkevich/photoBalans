create function bee_get_oper_repval(integer, integer, date, date) returns numeric
    language sql
as
$$
    -- 1 - pointid
  -- 2 - paramid
  -- 3 - operdate
  --
  --SELECT valman::numeric(12,3) FROM regdevoper 
  SELECT round(valman::numeric,0) FROM regdevoper 
  WHERE 
     linkid   = $1 AND
     paramid  = $2 AND 
     operdate BETWEEN $3 AND $4 AND
     valman   ~ E'^\\d{1,}'
  ;
$$;

comment on function bee_get_oper_repval(integer, integer, date, date) is 'Используется в bee_rep_get_repdata(int, date, date), bee_rep_get_repdata1(int, date, date), bee_rep_get_repdata1(int, date, date)';

alter function bee_get_oper_repval(integer, integer, date, date) owner to pgsql;

