create function bee_get_filllist_for_loss()
    returns TABLE(rowid integer, nam character varying, kod character varying)
    language sql
as
$$
/*
	ito06 2016-04-20 Получение списка филиалов для ввода потер РСК
*/
	SELECT rowid, nam, kod FROM denet WHERE length(kod) = 6 OR length(kod) = 3 order by kod;

$$;

comment on function bee_get_filllist_for_loss() is 'Получение списка филиалов для ввода потер РСК. Используется в LossRSK.java';

alter function bee_get_filllist_for_loss() owner to pgsql;

