create function bee_iskraemeco_get_countersrc_list_tmp(sdat date, edat date)
    returns TABLE(amnid integer, docnumber character varying, pointid integer, mark character varying, devid integer, prodnum character varying, operdate date, operval numeric, err integer, ok_text character varying, prim character varying, src_name character varying, src integer, base character varying, db_tag character varying, locid integer, loaddate date)
    language plpgsql
as
$$
/*
	ito06 2015-11-13 Получить список счетчиков незагруженных из bee_external_src (либо не отмечены, либо не подходящие по периоду) для текущей базы
*/
DECLARE 
	curr_dbase varchar = 'beeU';
BEGIN	
	select * from current_database() INTO curr_dbase;
/*
amn.rowid 	AS amnid,
amn.docnumber	AS docnum,
apn.rowid 	AS pointid,
*/	
	RETURN QUERY EXECUTE ('		 
		 SELECT DISTINCT 
		 	null::int										AS amnid,
		 	null::varchar										AS docnum,
			null::int 										AS pointid,
			de.element_name::varchar								AS mark,
			apn.devid 										AS devid,
			bes.dev_num 										AS prodnum,
			bes.operdate										AS operdate,
			bes.operval										AS operval,		
			bes.err  										AS err,
			null::varchar										AS ok_text,			
			de2.element_name									AS prim,			
			de1.element_name									AS src_name,			
			bes.srv											AS src, 
			CASE WHEN (select * from current_database())::varchar = '''||'beeU'||'''
				THEN '''||'юр. лица'||'''	
				ELSE '''||'физ. лица'||'''				
			END::varchar										AS base,
			(select * from ltrim( (select * from current_database()), '''||'bee'||'''))::varchar	AS db_tag,
			apn.lid 										AS locid, 
			bes.loaddate 										AS loaddate
			
		   FROM bee_external_src AS bes
	      LEFT JOIN agreepoint AS apn ON apn.prodnumber = bes.dev_num
	      LEFT JOIN agreement AS amn ON amn.rowid = apn.linkid 
	      LEFT JOIN dic_elements AS de ON de.rowid = apn.devid 
	      LEFT JOIN dic_elements AS de1 ON de1.element_code = bes.srv AND de1.link = 176
	      LEFT JOIN dic_elements AS de2 ON de2.element_code = bes.err AND de2.link = 177
	      LEFT JOIN regdevoper AS rdo 
	          ON rdo.linkid    = apn.rowid 
	          AND rdo.operdate = bes.operdate 
	          AND rdo.paramid  = 195 
	          AND rdo.valman::varchar = bes.operval::varchar
	          WHERE bes.operdate between '''||$1||''' and '''||$2||'''
	            AND (bes.ready = false OR rdo.rowid IS NULL)       
	            AND apn.rowid IS NOT NULL
		  ORDER BY bes.dev_num') ;
END;
$$;

comment on function bee_iskraemeco_get_countersrc_list_tmp(date, date) is 'Получить список счетчиков незагруженных из bee_external_src (либо не отмечены, либо не подходящие по периоду) для текущей базы. Используется в bee_iskraemeco_get_countersrc_list(date, date)';

alter function bee_iskraemeco_get_countersrc_list_tmp(date, date) owner to pgsql;

