create function bee_add_bee_docs(locid integer, agreeid integer, prefix integer, docnumber integer, doctype integer, docdate character varying) returns integer
    language plpgsql
as
$$
DECLARE
   NR     INTEGER;
BEGIN
   BEGIN
     INSERT INTO bee_docs 
     (linkid,  pref,   docnum,    doctyp,  docdat,        docvid, doc_tag, edit,   exported) VALUES
     (agreeid, prefix, docnumber, doctype, docdate::date, NULL,   NULL,    FALSE,  NULL) 
     RETURNING rowid INTO NR;

   EXCEPTION
      WHEN UNIQUE_VIOLATION THEN
      RETURN -1;
   END;

   RETURN NR;

END;
$$;

comment on function bee_add_bee_docs(integer, integer, integer, integer, integer, varchar) is 'Добавление нового документа. Используется в AdvanceInvoices.java, AppUtils.java';

alter function bee_add_bee_docs(integer, integer, integer, integer, integer, varchar) owner to pgsql;

