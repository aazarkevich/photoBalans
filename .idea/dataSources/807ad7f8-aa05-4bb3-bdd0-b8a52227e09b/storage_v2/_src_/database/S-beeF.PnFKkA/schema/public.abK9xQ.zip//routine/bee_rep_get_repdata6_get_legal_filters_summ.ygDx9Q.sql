create function bee_rep_get_repdata6_get_legal_filters_summ(fl integer) returns text
    language plpgsql
as
$$
/*
ito06 2011-12-02
*/
DECLARE filter_add text;
   BEGIN
	filter_add = '';
	IF fl=1 
	   THEN filter_add = ' AND (ard2.paramval NOT IN ('||quote_literal(704)||','||quote_literal(966)||') OR ard2.paramval IS NULL)';
        END IF;
    return filter_add;
  END;
$$;

comment on function bee_rep_get_repdata6_get_legal_filters_summ(integer) is 'Используется в bee_rep_get_repdata6_get_legal_summ(varchar, int, date, date, int, int),  bee_rep_get_repdata6_get_legal_summ_tot(varchar, int, date, date, int, int)  ';

alter function bee_rep_get_repdata6_get_legal_filters_summ(integer) owner to postgres;

