create function bee_get_oper_date_last(pointid integer) returns date
    language plpgsql
as
$$
DECLARE

BEGIN
   if NOT EXISTS (select 1 from regdevoper where linkid = pointid limit 1) then
      RETURN (select paramval::date from agreeregdev where linkid = pointid and paramid = 154 limit 1);
   else
      return (SELECT MAX(operdate) FROM regdevoper WHERE linkid = pointid limit 1);
   end if;
   RETURN null;
END;
$$;

comment on function bee_get_oper_date_last(integer) is 'Используется в vbee_oper_values, vbee_get_opervalues_buf';

alter function bee_get_oper_date_last(integer) owner to pgsql;

