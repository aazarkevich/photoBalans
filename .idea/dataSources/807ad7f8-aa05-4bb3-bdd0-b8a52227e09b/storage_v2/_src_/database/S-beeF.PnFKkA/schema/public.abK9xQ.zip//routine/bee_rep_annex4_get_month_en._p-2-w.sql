create function bee_rep_annex4_get_month_en(amnid integer, strdate date, enddate date) returns SETOF bee_rep_tab10_month
    language sql
as
$$
/*
	add ito06 2019-12-23 (если нет параметра 410 (адрес запитанного объекта*) все равно добавляем точку учета в табл
	ito06 2012-10-16 Приложение 1 (факт) реальные данные из формы "договоры" 
*/
	SELECT 
		(sum(rdo.valman::numeric(13,3))/1000)::numeric(10,3)  AS summ,
		amn.docnumber AS docnumber,
		apn.account AS account,
		--ard3.paramval || ', ' || ard4.paramval AS point, 2019-12-23
		CASE WHEN ard3.paramval IS NULL 
		  THEN 
		    CASE 
			   WHEN  ard4.paramval IS NULL 
			   THEN ' '
			   ELSE ard4.paramval
			END
		  ELSE
		    CASE 
			   WHEN ard4.paramval IS NULL 
			   THEN ard3.paramval
			   ELSE ard3.paramval || ', ' || ard4.paramval
			END		   
		 END 		 AS point, --2019-12-23
		apn.rowid AS id
	FROM  agreement    AS amn
		JOIN agreepoint   AS apn ON amn.rowid = apn.linkid
		JOIN bee_rep_get_ard_per_max(439)  AS ard ON apn.rowid = ard.linkid 
		JOIN agreeregdev AS ard3 ON ard3.linkid=apn.rowid AND ard3.paramid=418 
		-- 2019-12-23 JOIN agreeregdev AS ard4 ON ard4.linkid=apn.rowid AND ard4.paramid=410
		LEFT JOIN agreeregdev AS ard4 ON ard4.linkid=apn.rowid AND ard4.paramid=410		
		LEFT JOIN regdevoper   AS rdo ON apn.rowid = rdo.linkid AND rdo.paramid=850 AND rdo.valman~E'^\\d{1,}' AND rdo.operdate BETWEEN $2 AND $3
	WHERE amn.rowid = $1
	
	GROUP BY docnumber,account,ard3.paramval,ard4.paramval ,id
$$;

comment on function bee_rep_annex4_get_month_en(integer, date, date) is 'Приложение 1 (факт) - печать из формы "договоры". Используется в bee_rep_annex4_get_en_real(int, date)';

alter function bee_rep_annex4_get_month_en(integer, date, date) owner to postgres;

