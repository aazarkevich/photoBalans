create function bee_get_agreeregdev_value(pointid integer, parid integer) returns character varying
    language plpgsql
as
$$
    --
  -- ЗНАЧЕНИЕ ПОСТОЯННОГО ПАРАМЕТРА ПО КОДУ ТОЧКИ УЧЁТА
  -- pointid : код точки учёта
  -- parid   : код параметра
  -- 
DECLARE
   ParVal VARCHAR;
   RefVal VARCHAR;   
BEGIN
   -- проверить наличие ссылки
   SELECT INTO RefVal refs FROM dic_elements WHERE rowid = parid;
   --
   IF RefVal IS NULL THEN -- не ссылка
   -- берём прямо из agreeregdev 
      ParVal = (SELECT paramval FROM agreeregdev WHERE linkid = pointid AND paramid = parid LIMIT 1);
   ELSE
   -- тащим по ссылке из справочника
      ParVal = (SELECT element_name FROM dic_elements WHERE rowid = RefVal::integer);
   END IF;  
                              
   IF ParVal IS NULL THEN
      ParVal := '-';
   END IF;  
          
   RETURN ParVal;
   --
END;
$$;

comment on function bee_get_agreeregdev_value(integer, integer) is 'Используется в bee_agree_by_device, gis_update_points(character)';

alter function bee_get_agreeregdev_value(integer, integer) owner to pgsql;

