create function bee_closed_period_refill() returns void
    language plpgsql
as
$$
/*
        add ito06 2013-08-07
	by ito07 2012-10-31

*/
DECLARE
   Rec RECORD;
BEGIN
   FOR Rec IN (SELECT * FROM bee_close_period_list())
   LOOP
   -----------------------------
      UPDATE bee_closed_info SET 
         uni_period = Rec.uni_period,
         mix_period = Rec.mix_period,
         dir_period = Rec.dir_period,
         uri_period = Rec.uri_period,
         phi_period = Rec.phi_period
      WHERE hostname = Rec.hostname AND dbname = Rec.dbname AND filloc = Rec.filloc;
   END LOOP;
   UPDATE bee_closed_info SET dbstatus = 'U' WHERE (dbname = 'bee' );
   UPDATE bee_closed_info SET dbstatus = 'X' WHERE  dbname = 'beeX' AND hostname <> 'beex';
   UPDATE bee_closed_info SET dbstatus = 'F' WHERE (dbname = 'beeF');
   UPDATE bee_closed_info SET dbstatus = 'Z' WHERE  dbname = 'beeX' AND hostname = 'beex';
   
   
END;
$$;

comment on function bee_closed_period_refill() is 'Используется в AgreeJoinUni.java, AgreeJoinMix.java, AppUtils.java';

alter function bee_closed_period_refill() owner to pgsql;

