create function bee_docs_sheet_value_bubble(agreeid integer, docid integer, docdate date) returns void
    language plpgsql
as
$$
    --
-- ПУЗЫРЁК -->
--         <--
--         --> 
-- agreeid  - agreement.rowid
-- docid    - bee_docs.rowid
-- docdate  - bee_docs.docdat 
--
DECLARE
   RecCurr  RECORD;
   RecNext RECORD;
   RIDS INTEGER[];
   Amo  INTEGER;
   DK NUMERIC;
   KK NUMERIC;
BEGIN
   --
   PERFORM bee_docs_sheet_value_update(agreeid,docid,docdate);
   --
/*
   RIDS =  ARRAY(
      SELECT rowid FROM bee_docs_sheet
      WHERE  linkid1 = agreeid ORDER BY operdate
   );
   Amo = array_upper(RIDS,1);
   --
   FOR i IN 1..Amo LOOP

      --- CURR
      SELECT INTO RecCurr
         npp,
         start_debit  AS sd,
         start_kredit AS sk,
         oper_debit   AS od,
         oper_kredit  AS ok,
         final_debit  AS fd,
         final_kredit AS fk
      FROM 
         bee_docs_sheet
      WHERE  
         rowid = RIDS[i];

      --- NEXT   
      SELECT INTO RecNext
         npp,
         start_debit  AS sd,
         start_kredit AS sk,
         oper_debit   AS od,
         oper_kredit  AS ok,
         final_debit  AS fd,
         final_kredit AS fk
      FROM 
         bee_docs_sheet
      WHERE  
         rowid = RIDS[i+1];
      --- 
      --- *****************
      --- 
      DK = (RecCurr.fd - RecCurr.fk + RecNext.od - RecNext.ok);
      -- 
      CASE WHEN DK > 0 THEN
           DK  = DK;
           ELSE
           DK  = 0  ;    
      END CASE;
      CASE WHEN DK < 0 THEN
           KK =  -DK;
           ELSE
           KK = 0;
      END CASE;
      --
      UPDATE bee_docs_sheet SET
         npp          = Rec.npp + 1,
         start_debit  = RecCurr.fd,
         start_kredit = RecCurr.fk,
         final_debit  = DK,
         final_kredit = KK
      WHERE rowid = RIDS[i+1];  
      --    
   END LOOP;
*/
END;
--
--
$$;

comment on function bee_docs_sheet_value_bubble(integer, integer, date) is 'Используется в DocMain.java, DocsAdjustment.java, GroupDocsProcessing.java, LossRSK.java, AppUtils.java';

alter function bee_docs_sheet_value_bubble(integer, integer, date) owner to pgsql;

