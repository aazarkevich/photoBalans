create function bee_rep_get_repdata3(locid integer, str_date date, end_date date) returns SETOF bee_repdata3
    language plpgsql
as
$$
/*	
    add ito06 2021-01-19 выбираем все договоры 
	add ito06 2013-10-11
	ito06 2012-02-14: Сводный акт первичного учета эл.эн.; по абонентам; в разрезе лицевых счетов
*/
DECLARE
	rec_info bee_repdata3_info%ROWTYPE;
	rec_pers bee_rep_ard_periods%ROWTYPE;
	rec_resl bee_repdata3%ROWTYPE;
	tmp_num numeric := null;
	vn numeric := null;
	sn1 numeric := null;
	sn2 numeric := null;
	nn numeric := null;
	docstat int =0;
	
BEGIN
FOR rec_info IN (SELECT * FROM bee_rep_get_repdata3_info(locid, str_date, end_date) order by length(docnumber), docnumber, length(account), account, apn_rowid, npp)
    loop
   
	rec_resl.fil_name = rec_info.fil_name;
	rec_resl.fil_kod = rec_info.fil_kod;
	IF rec_info.provider IS NULL 
	   THEN rec_resl.provider = '-';
           ELSE rec_resl.provider = rec_info.provider;
        END IF;
	rec_resl.apn_rowid = rec_info.apn_rowid;
	rec_resl.direction = rec_info.direction;
	rec_resl.direction_code = rec_info.direction_code;
	rec_resl.docnumber = rec_info.docnumber;
	rec_resl.obj_name = rec_info.obj_name;
	rec_resl.cst_name = rec_info.cst_name;
        rec_resl.rdo_param = rec_info.rdo_param;
	rec_resl.account = rec_info.account;
	rec_resl.npp = rec_info.npp;
/*	IF rec_info.rdo_param = 850
	   THEN rec_resl.account = rec_info.account;
	   	   	        
	   ELSE rec_resl.account = '';
           
	END IF;   */
	
	rec_resl.p715 = rec_info.p715;
	rec_resl.amn_trmt = rec_info.amn_trmt;
	rec_resl.amn_cd_sd = rec_info.amn_cd_sd;
	IF rec_info.targrp IS NULL 
           THEN rec_resl.targrp = '--';
           ELSE rec_resl.targrp = rec_info.targrp;
	END IF;
	FOR rec_pers IN (SELECT * FROM bee_rep_get_agreeregdev_periods(rec_info.apn_rowid,str_date,end_date))
	    LOOP
		tmp_num = 0;
		
		EXECUTE 'SELECT '||'  sum(valman::numeric) '||
			 'FROM regdevoper '||
			'WHERE '||'  linkid = '||rec_info.apn_rowid ||' AND'||
			'  operdate BETWEEN'||quote_literal(rec_pers.str_date)||' AND '||quote_literal(rec_pers.end_date)||' AND '||
			'  paramid = '||rec_info.rdo_param ||' AND valman ~ '||quote_literal(E'^[\\d{1,}\\-]')||' AND ' ||
			'  valman<>'||quote_literal('-')
		   INTO tmp_num;
		IF rec_pers.ul =  '306' 
		   THEN IF nn IS NULL 
                           THEN nn = tmp_num;
                           ELSE nn = nn+tmp_num;
                        END IF;
		END IF;
		IF rec_pers.ul =  '308' 
		   THEN IF sn1 IS NULL 
			   THEN sn1 = tmp_num;
                           ELSE sn1 = sn1+tmp_num;
                        END IF;
		END IF;
		IF rec_pers.ul =  '310' 
		   THEN IF sn2 IS NULL 
                           THEN sn2 = tmp_num;
                           ELSE sn2 = sn2+tmp_num;
                        END IF;
		END IF;
		IF rec_pers.ul =  '311' 
		   THEN IF vn IS NULL 
			   THEN vn = tmp_num;
                           ELSE vn = vn+tmp_num;
			END IF;
		END IF;
	END LOOP;
	rec_resl.vn = vn;
	rec_resl.sn1 = sn1;
	rec_resl.sn2 = sn2;
	rec_resl.nn = nn;
	IF vn IS NOT NULL 
           THEN rec_resl.total = vn;
           ELSE rec_resl.total = 0;
	END IF;
	IF sn1 IS NOT NULL 
	   THEN rec_resl.total = rec_resl.total + sn1;
	END IF;
	IF sn2 IS NOT NULL 
	   THEN rec_resl.total = rec_resl.total + sn2;
	END IF;
	IF nn IS NOT NULL 
	   THEN rec_resl.total = rec_resl.total + nn;
	END IF;
	IF vn IS NULL AND sn1 IS NULL AND sn2 IS NULL AND nn IS NULL 
	   THEN rec_resl.total = null;
	END IF;

  RETURN NEXT rec_resl; 
  
  
  vn = null;
  nn = null;
  sn1 = null;
  sn2 = null;
  END LOOP;
END;
$$;

comment on function bee_rep_get_repdata3(integer, date, date) is 'Сводный акт первичного учета эл.эн.; по абонентам; в разрезе лицевых счетов. Используется в RepCreate2.java, RepCreate22.java, RepCreate3.java; bee_rep_get_repdata23_tmp1(int, date, date),bee_rep_get_repdata3_tot(int, date, date)';

alter function bee_rep_get_repdata3(integer, date, date) owner to postgres;

