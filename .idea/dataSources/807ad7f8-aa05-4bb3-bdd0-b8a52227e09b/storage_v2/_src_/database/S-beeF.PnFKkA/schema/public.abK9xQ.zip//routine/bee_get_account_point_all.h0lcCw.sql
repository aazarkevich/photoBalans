create function bee_get_account_point_all(p_date date)
    returns TABLE(id_sys integer, id_external_point integer, account_number character varying, is_legal integer, id_voltage_level integer, is_calc_counter integer, prod_number character varying, id_sign_account_point integer, docnumber character varying, existing integer, locid character varying, customer_name character varying, name_point character varying, adr_point character varying, type_device character varying, name_feeder character varying, category_reliability character varying, max_pow_agreement character varying, type_point integer, id_golov character varying, name_ps character varying, date_removal date)
    language plpgsql
as
$$
declare

	BEGIN
return QUERY(
SELECT * 
		FROM dblink(
			'fs_beeu_f663',
			format(	'select * from public.bee_get_account_point(%L)', p_date::date ))t
				(id_sys int, id_external_point integer, account_number character varying, is_legal integer, id_voltage_level int, is_calc_counter integer, prod_number character varying,    id_sign_account_point integer, docnumber varchar, existing int
				,locid varchar, customer_name varchar, name_point varchar, adr_point varchar,  type_device varchar, name_feeder varchar,  category_reliability varchar, max_pow_agreement varchar
, type_point int, id_golov varchar, name_ps varchar, date_removal date 
				)
union SELECT
			* 
		FROM dblink(
			'fs_beef_f663',
			format(	'select * from public.bee_get_account_point(%L)', p_date::date ))t
				(id_sys int, id_external_point integer, account_number character varying, is_legal integer, id_voltage_level int, is_calc_counter integer, prod_number character varying,      id_sign_account_point integer, docnumber varchar, existing int 
			,locid varchar, customer_name varchar, name_point varchar, adr_point varchar,  type_device varchar, name_feeder varchar,  category_reliability varchar, max_pow_agreement varchar
, type_point int, id_golov varchar, name_ps varchar, date_removal date ) );
					
                 
					end;
$$;

alter function bee_get_account_point_all(date) owner to postgres;

