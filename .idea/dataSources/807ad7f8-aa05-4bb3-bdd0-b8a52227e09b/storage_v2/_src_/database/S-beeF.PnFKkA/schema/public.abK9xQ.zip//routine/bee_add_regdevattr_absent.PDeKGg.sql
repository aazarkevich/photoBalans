create function bee_add_regdevattr_absent(paragrp integer, paraunits integer, markgrp integer) returns void
    language plpgsql
as
$$
-- 38 47 35
DECLARE
   devid integer;
BEGIN
-- 38:41: 
-- 51:77
-- 66:78
-- цикл по маркам устройства в группе markgrp
FOR devid IN (SELECT rowid FROM dic_elements WHERE link = markgrp)
LOOP
    -- (devid   устройство)  
    -- (paragrp параметры устройства) 
    -- (единицы измерения )
    PERFORM bee_fill_regdevattr( devid, paragrp, paraunits ) ;
END LOOP;
--
--
END;
$$;

comment on function bee_add_regdevattr_absent(integer, integer, integer) is 'Используется в RegDevAttr.java, AppUtils.java';

alter function bee_add_regdevattr_absent(integer, integer, integer) owner to pgsql;

