create function bee_rep_get_repdata6_get_quantity(digits character varying, code integer, date_start date, date_end date) returns SETOF bigint
    language plpgsql
as
$$
/*
ito06 2011-12-02
*/
BEGIN

RETURN QUERY EXECUTE
	 'SELECT 
		count(cst.consum_name) AS quantity
	   FROM gis_traces AS gis  
	   JOIN regdevconn  AS rdc ON rdc.traceid=gis.rowid 
	   JOIN agreepoint  AS apn ON apn.rowid=rdc.pointid  
	   JOIN agreement   AS amn ON amn.rowid=apn.linkid  
	   JOIN customer    AS cst ON cst.abo_code=amn.abo_code  
	   JOIN agreeregdev AS ard ON ard.linkid=rdc.pointid AND ard.paramid=189 AND ard.paramval='||quote_literal(432)||'  
          WHERE gis.objcode in ( select objcode 
                                   from gis_traces where objowner='||$2||'
                               ) 
           AND ( SELECT sum(valman::numeric('||$1||') )
          	   FROM regdevoper 
          	  WHERE linkid=rdc.pointid AND paramid=850 
          	    AND operdate BETWEEN '||quote_literal($3)||' 
                    AND ('||quote_literal($4)||')::date - '||quote_literal('1 day')||'::interval AND is_pokazania(valman)
               )<>0;'; 
      END;
$$;

comment on function bee_rep_get_repdata6_get_quantity(varchar, integer, date, date) is 'Используется в RepCreate6.java';

alter function bee_rep_get_repdata6_get_quantity(varchar, integer, date, date) owner to postgres;

