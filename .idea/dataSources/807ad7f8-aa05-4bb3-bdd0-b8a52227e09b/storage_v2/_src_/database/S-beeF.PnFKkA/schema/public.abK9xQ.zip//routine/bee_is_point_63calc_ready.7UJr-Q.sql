create function bee_is_point_63calc_ready(pointid integer, parid integer, parval character varying) returns boolean
    language plpgsql
as
$$
-- by ito07 2011-08-01
BEGIN
   RETURN (EXISTS (SELECT 1 FROM agreeregdev WHERE linkid = pointid AND paramid = parid AND paramval = parval));
END;
$$;

comment on function bee_is_point_63calc_ready(integer, integer, varchar) is 'Используется в LossDistr.java, AppUtils.java';

alter function bee_is_point_63calc_ready(integer, integer, varchar) owner to postgres;

