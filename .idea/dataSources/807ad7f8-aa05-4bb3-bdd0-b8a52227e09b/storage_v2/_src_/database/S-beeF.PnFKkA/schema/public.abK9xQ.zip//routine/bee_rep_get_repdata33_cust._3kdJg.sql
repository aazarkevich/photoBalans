create function bee_rep_get_repdata33_cust(_host character varying) returns SETOF bee_repdata33
    language plpgsql
as
$$
/*
	ito06 2016-04-26 Сводный журнал задолжненников (репс), развернутая по потребителю
*/
DECLARE RowLine bee_repdata33%rowtype;
	name_before1 varchar = null;
	name_before2 varchar = null;
BEGIN     
	FOR RowLine IN (
		(SELECT 'bold' 							AS row_style,
			null::varchar 						AS nn,
			'01' 							AS nn1,
			'ВСЕГО'  						AS name,
			row.*,
			null::smallint 						AS accdir,
			null::varchar 						AS loc,
			'ВСЕГО'  						AS ord
		FROM bee_rep_get_repdata33_summ(0,$1) AS row)
	UNION 
		(SELECT 'bold' 							AS row_style,
			'1' 							AS nn,
			'10' 							AS nn1,
			'Прочие потребители'  					AS name,
			row.*,
			null::smallint						AS accdir,
			null::varchar 						AS loc,
			'Прочие потребители'  					AS ord
		FROM bee_rep_get_repdata33_summ(10,$1) AS row)
	UNION 
		(SELECT 'norm' 							AS row_style,
			null::varchar 						AS nn,
			'100' 							AS nn1,
			docnum||', '||custname 		  			AS name,
			all_sum_debit 						AS all_sum_debit, 
			dat_debit 						AS dat_debit,
			sum_debit 						AS sum_debit,
			dat_debit20 						AS dat_debit20,
			sum_debit20 						AS sum_debit20,
			dat_debit45 						AS dat_debit45,
			sum_debit45 						AS sum_debit45,
			dat_debit90 						AS dat_debit90,
			sum_debit90 						AS sum_debit90,  
			dat_debit365 						AS dat_debit365,
			sum_debit365 						AS sum_debit365,
			dat_measure  						AS dat_measure,
			meas_measure 						AS meas_measure,
			comm_measure 						AS comm_measure,
			dat_collecting 						AS dat_collecting,
			sum_collecting 						AS sum_collecting,
			meas_collecting 					AS meas_collecting,
			comm_collecting 					AS comm_collecting, 
			_host							AS host,
			accdir 							AS accdir,
			loc							AS loc,
			docnum||', '||custname 		  			AS ord
		   FROM bee_rep_get_repdata33_tmp 
		  WHERE accdir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND host like _host AND host NOT IN ('beex', 'localhost'))
	UNION
		(SELECT 'bold' 							AS row_style,
			'2' 							AS nn,
			'20' 							AS nn1,
			'Бюджетные потребители'  				AS name,  
			row.*,
			null::smallint						AS accdir,
			null::varchar 						AS loc,
			'Бюджетные потребители' 				AS ord
		FROM bee_rep_get_repdata33_summ(20,$1) AS row)
	UNION 
		(SELECT 'bold' 							AS row_style,
			'2.1'  							AS nn,
			'21'  							AS nn1,
			'-федеральный бюджет'  					AS name,
			row.*,
			null::smallint						AS accdir,
			null::varchar						AS loc,
			'-областной бюджет'  					AS ord
		FROM bee_rep_get_repdata33_summ(21,$1) AS row)
	UNION 
		(SELECT 'norm' 							AS row_style,
			null::varchar 						AS nn,
			'210' 							AS nn1,
			docnum||', '||custname 		  			AS name, 
			all_sum_debit 						AS all_sum_debit, 
			dat_debit 						AS dat_debit,
			sum_debit 						AS sum_debit,
			dat_debit20 						AS dat_debit20,
			sum_debit20 						AS sum_debit20,
			dat_debit45 						AS dat_debit45,
			sum_debit45 						AS sum_debit45,
			dat_debit90 						AS dat_debit90,
			sum_debit90 						AS sum_debit90,  
			dat_debit365 						AS dat_debit365,
			sum_debit365 						AS sum_debit365,
			dat_measure  						AS dat_measure,
			meas_measure 						AS meas_measure,
			comm_measure 						AS comm_measure,
			dat_collecting 						AS dat_collecting,
			sum_collecting 						AS sum_collecting,
			meas_collecting 					AS meas_collecting,
			comm_collecting 					AS comm_collecting,   			
			_host							AS host,
			accdir 							AS accdir,
			loc							AS loc,
			docnum||', '||custname 		  			AS ord
		   FROM bee_rep_get_repdata33_tmp 
		  WHERE accdir  =  835 AND host like _host AND host NOT IN ('beex', 'localhost'))
	UNION 
		(SELECT 'bold' 							AS row_style,
			'2.2' 							AS nn,
			'22' 							AS nn1,
			'-областной бюджет'  					AS name,
			row.*,
			null::smallint						AS accdir,
			null::varchar						AS loc,
			'-областной бюджет' 					AS ord
		FROM bee_rep_get_repdata33_summ(22,$1) AS row)
	UNION 
		(SELECT 'norm' 							AS row_style,
			null::varchar 						AS nn,
			'220' 							AS nn1,
			docnum||', '||custname 		  			AS name,
			all_sum_debit 						AS all_sum_debit, 
			dat_debit 						AS dat_debit,
			sum_debit 						AS sum_debit,
			dat_debit20 						AS dat_debit20,
			sum_debit20 						AS sum_debit20,
			dat_debit45 						AS dat_debit45,
			sum_debit45 						AS sum_debit45,
			dat_debit90 						AS dat_debit90,
			sum_debit90 						AS sum_debit90,  
			dat_debit365 						AS dat_debit365,
			sum_debit365 						AS sum_debit365,
			dat_measure  						AS dat_measure,
			meas_measure 						AS meas_measure,
			comm_measure 						AS comm_measure,
			dat_collecting 						AS dat_collecting,
			sum_collecting 						AS sum_collecting,
			meas_collecting 					AS meas_collecting,
			comm_collecting 					AS comm_collecting,   
			
			_host							AS host,
			accdir 							AS accdir,
			loc							AS loc,
			docnum||', '||custname 		  			AS ord
		   FROM bee_rep_get_repdata33_tmp 
		  WHERE accdir  =  836 AND host like _host AND host NOT IN ('beex', 'localhost'))
	UNION
		(SELECT 'bold' 							AS row_style,
			'2.3'							AS nn,
			'23' 							AS nn1,
			'-местный бюджет'  					AS name,
			row.*,
			null::smallint						AS accdir,
			null::varchar						AS loc,
			'-местный бюджет' 					AS ord
		FROM bee_rep_get_repdata33_summ(23,$1) AS row)
	UNION
		(SELECT 'bold' 							AS row_style,
			'2.3.1' 						AS nn,
			'231' 							AS nn1,
			'--юр. лица'  						AS name,
			row.*,
			null::smallint						AS accdir,
			null::varchar						AS loc,
			'--юр. лица' 						AS order_nam
		FROM bee_rep_get_repdata33_summ(231,$1) AS row)
	UNION 
		(SELECT 'norm' 							AS row_style,
			null::varchar 						AS nn,
			'2310' 							AS nn1,
			docnum||', '||custname 		  			AS name,
			all_sum_debit 						AS all_sum_debit, 
			dat_debit 						AS dat_debit,
			sum_debit 						AS sum_debit,
			dat_debit20 						AS dat_debit20,
			sum_debit20 						AS sum_debit20,
			dat_debit45 						AS dat_debit45,
			sum_debit45 						AS sum_debit45,
			dat_debit90 						AS dat_debit90,
			sum_debit90 						AS sum_debit90,  
			dat_debit365 						AS dat_debit365,
			sum_debit365 						AS sum_debit365,
			dat_measure  						AS dat_measure,
			meas_measure 						AS meas_measure,
			comm_measure 						AS comm_measure,
			dat_collecting 						AS dat_collecting,
			sum_collecting 						AS sum_collecting,
			meas_collecting 					AS meas_collecting,
			comm_collecting 					AS comm_collecting,   
			
			_host							AS host,
			accdir 							AS accdir,
			loc							AS loc,
			docnum||', '||custname 		  			AS ord

		   FROM bee_rep_get_repdata33_tmp 
		  WHERE accdir IN (832, 837, 838, 839, 840, 841, 842) AND host like _host AND host NOT IN ('beex', 'localhost'))
	UNION 
		(SELECT 'bold' 							AS row_style,
			'2.3.2' 						AS nn,
			'232'  							AS nn1,
			'--уличное освещение'  					AS name,
			row.*,
			null::smallint 						AS accdir,
			null::varchar 						AS loc,
			'--уличное освещение'  					AS ord
		FROM bee_rep_get_repdata33_summ(232,$1) AS row)
	UNION 
		(SELECT 'norm'  						AS row_style,
			null::varchar  						AS nn,
			'2320'  						AS nn1,
			docnum||', '||custname 		  			AS name,
			all_sum_debit 						AS all_sum_debit, 
			dat_debit 						AS dat_debit,
			sum_debit 						AS sum_debit,
			dat_debit20 						AS dat_debit20,
			sum_debit20 						AS sum_debit20,
			dat_debit45 						AS dat_debit45,
			sum_debit45 						AS sum_debit45,
			dat_debit90 						AS dat_debit90,
			sum_debit90 						AS sum_debit90,  
			dat_debit365 						AS dat_debit365,
			sum_debit365 						AS sum_debit365,
			dat_measure  						AS dat_measure,
			meas_measure 						AS meas_measure,
			comm_measure 						AS comm_measure,
			dat_collecting 						AS dat_collecting,
			sum_collecting 						AS sum_collecting,
			meas_collecting 					AS meas_collecting,
			comm_collecting 					AS comm_collecting, 
			_host							AS host,
			accdir 							AS accdir,
			loc							AS loc,
			docnum||', '||custname 		  			AS ord		
		   FROM bee_rep_get_repdata33_tmp 	        
		  WHERE accdir = 1623 AND host like _host AND host NOT IN ('beex', 'localhost'))
		 UNION (SELECT 'bold' 							AS row_style,
				'3' 							AS nn,
				'3' 							AS nn1,
				'Централизованные договоры' 				AS name,
				row.*,
				null::smallint						AS accdir,
				null::varchar 						AS loc,
				'Централизованные договоры' 				AS ord
			FROM bee_rep_get_repdata33_summ(3,$1) AS row)	
		 UNION (SELECT 'norm' 							AS row_style,
				null::varchar 						AS nn,
				'300' 							AS nn1,
				docnum||', '||custname 		  			AS name,
				all_sum_debit 						AS all_sum_debit, 
				dat_debit 						AS dat_debit,
				sum_debit 						AS sum_debit,
				dat_debit20 						AS dat_debit20,
				sum_debit20 						AS sum_debit20,
				dat_debit45 						AS dat_debit45,
				sum_debit45 						AS sum_debit45,
				dat_debit90 						AS dat_debit90,
				sum_debit90 						AS sum_debit90,  
				dat_debit365 						AS dat_debit365,
				sum_debit365 						AS sum_debit365,
				dat_measure  						AS dat_measure,
				meas_measure 						AS meas_measure,
				comm_measure 						AS comm_measure,
				dat_collecting 						AS dat_collecting,
				sum_collecting 						AS sum_collecting,
				meas_collecting 					AS meas_collecting,
				comm_collecting 					AS comm_collecting, 
				_host							AS host,
				accdir 							AS accdir,
				loc							AS loc,
				docnum||', '||custname 		  			AS ord
			   FROM bee_rep_get_repdata33_tmp 
			  WHERE host like _host AND host IN ('beex', 'localhost'))			  
		  
	ORDER BY nn1, ord)
        LOOP    
		IF RowLine.sum_collecting = '0' THEN RowLine.sum_collecting = null; END IF;
		IF RowLine.nn1<>'3' OR RowLine.all_sum_debit<>0 
		   THEN 
			name_before2 = RowLine.name;
			IF RowLine.name = name_before1 THEN RowLine.name = null; RowLine.all_sum_debit = null; END IF;
			name_before1 = name_before2;			
		        RETURN  NEXT RowLine;                    
		END IF;			
	END LOOP;	
END;
$$;

comment on function bee_rep_get_repdata33_cust(varchar) is 'Сводный журнал задолжненников (репс) развернуть по потребителям. Используется в bee_rep_get_repdata33_all(int, date, boolean, boolean, boolean, varchar)';

alter function bee_rep_get_repdata33_cust(varchar) owner to pgsql;

