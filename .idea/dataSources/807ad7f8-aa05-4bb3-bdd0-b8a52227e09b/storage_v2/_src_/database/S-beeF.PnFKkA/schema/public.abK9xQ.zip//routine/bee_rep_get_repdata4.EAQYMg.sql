create function bee_rep_get_repdata4(locid integer, strdate date) returns SETOF bee_rep_tab4
    language sql
as
$$
/*
  	add ito06 2021-02-15 должны попадать расторгнутые
	ito16 2009-04-14 Результат обходов и среденее потребление
*/

SELECT DISTINCT
	apn.rowid       AS rdolink,
	ard.paramval	AS adr,
	replace(cst.abo_name,E'\\','/') AS fio, 
	apn.account     AS accoun,
          ---------- 
	bee_get_oper_regdevval(apn.rowid,715) AS grp

FROM customer AS cst
	JOIN agreement   AS amn ON cst.abo_code = amn.abo_code
	JOIN agreepoint  AS apn ON amn.rowid    = apn.linkid
	JOIN agreeregdev AS ard ON ard.linkid   = apn.rowid
--	LEFT OUTER JOIN regdevoper AS rdo ON rdo.linkid = apn.rowid
WHERE
--	rdo.paramid = 407 AND
	cst.locid=$1 AND
	ard.paramid=417 AND
      --ito06 2021-02-15  amn.docstatus = 79 AND
	    amn.docstatus in ( 77, 79 ) AND
--        bee_get_oper_regdevval_date(apn.rowid,197) IS NOT NULL AND 
        (bee_get_oper_regdevval_date(apn.rowid,690) IS NULL OR
         bee_get_oper_regdevval_date(apn.rowid,690) > $2)
GROUP BY accoun,adr,fio,rdolink
ORDER BY adr,fio;
$$;

comment on function bee_rep_get_repdata4(integer, date) is 'Результат обходов и среденее потребление. Используется в RepCreate4.java';

alter function bee_rep_get_repdata4(integer, date) owner to pgsql;

