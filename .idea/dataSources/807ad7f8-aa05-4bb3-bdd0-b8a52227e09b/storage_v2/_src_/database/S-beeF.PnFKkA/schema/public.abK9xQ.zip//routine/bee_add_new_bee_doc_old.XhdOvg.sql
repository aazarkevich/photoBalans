create function bee_add_new_bee_doc_old(doc_date text, ava_text text, loc_id integer, agreeid integer, doc_type integer, ava_type integer, ava_num integer) returns character varying
    language plpgsql
as
$$
/*
	add ito06 2016-05-06 вывод сообщения об ошибке
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2015-12-10 ввод новой проверки (договор на этом ли участке)
	add ito06 2014-12-01: из переименовали bee_add_new_bee_doc(text,text,int, int, int, int, int)
	Создание документа "счет на предоплату"
*/	
DECLARE
	result VARCHAR;
	fio VARCHAR := (SELECT COALESCE((SELECT paramval FROM agreement_info
						JOIN agreement ON agreement.rowid = agreement_info.linkid
						WHERE agreement_info.paramid = 1149
						AND agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = loc_id))
						AND agreement.rowid = agreeid
						ORDER BY period desc
						LIMIT 1),
					'Все договоры'));
		
	ava_date DATE := (SELECT (ava_text || '-01')::DATE);
	first_day_of_year DATE := (SELECT (date_trunc('year', ava_date::TIMESTAMP)::DATE));
	last_day_of_year DATE := (SELECT (date_trunc('year', ava_date) + INTERVAL '1 year' - INTERVAL '1 day'))::DATE;
	priv_month_first_day DATE := (SELECT (date_trunc('month', ava_date) - INTERVAL '1 month')::DATE);
	priv_month_last_day DATE := (SELECT (date_trunc('month', ava_date) - INTERVAL '1 month' +  INTERVAL '1 month' - INTERVAL '1 day' )::DATE);
	this_month_first_day DATE := (SELECT (date_trunc('month', ava_date))::DATE);
	this_month_last_day DATE := (SELECT (date_trunc('month', ava_date) +  INTERVAL '1 month' - INTERVAL '1 day' )::DATE);
	this_month_num VARCHAR := date_part('month', ava_date::TIMESTAMP);

	-- ito06 2012-04-13
	month_num VARCHAR := date_part('month', doc_date::TIMESTAMP);
	year_num VARCHAR := date_part('year', doc_date::TIMESTAMP);
	DocNum1 integer;
	-- ito06 2012-04-13
	bee_points_consum_col_name VARCHAR; 
	
	is_transmit BOOLEAN;
	is_docstatus_79 BOOLEAN;
	is_advance_not_pays BOOLEAN;
	is_advance_common BOOLEAN;
	is_advance_by_agreement BOOLEAN;
	--is_tarif_el_en BOOLEAN; 2014-12-01
	is_counter_exists BOOLEAN;
	
	Rec RECORD;
	is_point_tarif_el_en BOOLEAN;
	porteb_sum NUMERIC;
	is_potreb_sum_not_null BOOLEAN;
	
	advance_common_shad_num INTEGER;
	advance_agreement_shad_num INTEGER;
	existed_advance_date DATE;
	existed_advance_count INTEGER;
	existed_shad_num INTEGER;
	
	loops_count_bd INTEGER := 0;
	loops_count_bda INTEGER := 0;
	
	bd_curr_rowid NUMERIC;
	bda_linkid1 INTEGER;
	bda_linkid2 INTEGER;
	bda_tar_grp INTEGER;
	bda_quantity_fact NUMERIC;
	bda_quantity_plan NUMERIC;
	bda_quantity_max NUMERIC;
	bda_date_ava DATE;
	bda_percent_ava NUMERIC;
	bda_quantity_amo NUMERIC;
	bda_price NUMERIC;
	bda_cost_no_tax NUMERIC;
	bda_tax_rate NUMERIC;
	bda_tax_sum NUMERIC;
	bda_cost_with_tax NUMERIC;
	is_curr_locid BOOLEAN; --ito06 2015-12-10
	_docnum VARCHAR; 	--ito06 2016-05-06

BEGIN
	--** 2016-04-25
	is_transmit = (SELECT doctype in (1910,1911) FROM agreement WHERE rowid = agreeid);
	--**
	IF (is_transmit IS NULL OR is_transmit IS FALSE) 
	   THEN	--RETURN 'Договор не прямой! (' || fio || ', ' || agreeid || ')';
		RETURN '';
	END IF;

	--ito06 2015-12-10
        is_curr_locid = (SELECT (SELECT locid FROM agreement WHERE agreement.rowid = agreeid) IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = loc_id)));
        IF (is_curr_locid IS NULL OR is_curr_locid IS FALSE) 
	   THEN	RETURN 'Договор (' || (SELECT docnumber FROM agreement WHERE rowid = agreeid)  || ') находится другом в участке!';
	END IF;
        --**		
	is_docstatus_79 = (SELECT (SELECT docstatus FROM agreement WHERE agreement.rowid = agreeid AND agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = loc_id))) = 79);
	IF (is_docstatus_79 IS NULL OR is_docstatus_79 IS FALSE) 
	   THEN	RETURN 'Не действующий договор! (' || (SELECT docnumber FROM agreement WHERE rowid = agreeid)  || ')';
	END IF;
		
	is_advance_not_pays = (SELECT (SELECT paramid FROM agreement_info
					WHERE linkid = agreeid
					  AND period = (SELECT MAX(period) FROM agreement_info WHERE paramid = 1152 AND period <= ava_date AND linkid = agreeid)
					  AND paramid = 1152
					  AND paramval = '1157'
					ORDER BY period DESC LIMIT 1) IS NOT NULL);
	IF (is_advance_not_pays IS TRUE) 
	   THEN RETURN 'Не платит аванс! (' || fio || ', ' || agreeid || ')';
	END IF;
		
	is_advance_common = (SELECT (SELECT paramid FROM agreement_info
				      WHERE linkid = agreeid
					AND period = (SELECT MAX(period) FROM agreement_info WHERE paramid = 1152 AND period <= ava_date AND linkid = agreeid)
					AND paramid = 1152
					AND paramval = '1153'
				      ORDER BY period DESC LIMIT 1) IS NOT NULL);
	is_advance_by_agreement = (SELECT (SELECT paramid FROM agreement_info
					    WHERE linkid = agreeid
					     AND paramid = 1152
					     AND paramval = '1154'
					     AND period = (SELECT MAX(period) FROM agreement_info 
					                    WHERE paramid = 1152 AND period <= ava_date AND linkid = agreeid)
                                           ORDER BY period DESC LIMIT 1) IS NOT NULL);
		
	IF (is_advance_common IS NULL) THEN is_advance_common := FALSE; END IF;
	IF (is_advance_by_agreement IS NULL) THEN is_advance_by_agreement := FALSE; END IF;
		
	-- платит по общему графику
	IF (is_advance_common) 
	   THEN
		advance_common_shad_num = (SELECT shad_num FROM dic_schedule_advance
					    WHERE queue_ava = ava_num
					      AND dic_schedule_advance.period = (SELECT MAX(period) FROM dic_schedule_advance WHERE period <= ava_date));
		IF (advance_common_shad_num IS NOT NULL AND advance_common_shad_num >= 1) 
		   THEN
			existed_advance_date = (SELECT (ava_text || '-' || advance_common_shad_num::text)::date);
			existed_shad_num = advance_common_shad_num;
		    ELSE
			RETURN 'Не найден advance_common_shad_num!';
		END IF;
	-- платит по договору
	ELSEIF (is_advance_by_agreement) 
	   THEN
		advance_agreement_shad_num = (SELECT shad_num FROM bee_schedule_advance
					       WHERE queue_ava = ava_num
						 AND bee_schedule_advance.period = (SELECT MAX(period) FROM bee_schedule_advance 
						                                     WHERE period <= ava_date AND bee_schedule_advance.linkid = agreeid)
						 AND bee_schedule_advance.linkid = agreeid);
		IF (advance_agreement_shad_num IS NOT NULL AND advance_agreement_shad_num >= 1) 
		   THEN
			existed_advance_date = (SELECT (ava_text || '-' || advance_agreement_shad_num::text)::date);
			existed_shad_num = advance_agreement_shad_num;
		   ELSE
			RETURN 'Не найден advance_agreement_shad_num!';
		END IF;
	   ELSE
		RETURN 'Неизвестный график оплаты аванса (нет в общем графике, нет в графике по договору) для договора:'|| (SELECT docnumber FROM agreement WHERE rowid = agreeid)  ||'! ';
	END IF;

	existed_advance_count = (SELECT COUNT(bee_docs_advance.date_ava) FROM bee_docs 
				   JOIN bee_docs_advance ON bee_docs.rowid = bee_docs_advance.linkid1
				  WHERE bee_docs.doctyp = doc_type
				    AND bee_docs.linkid = agreeid
				    AND bee_docs_advance.date_ava = existed_advance_date);
	IF (existed_advance_count IS NOT NULL AND existed_advance_count >= 1) 
	   THEN
		RETURN 'Счёт на аванс на период ' || existed_advance_date || ', уже создан!';
	   ELSE
		IF (doc_date::DATE > existed_advance_date) 
		   THEN
			RETURN 'По договорам : ' || (SELECT docnumber FROM agreement WHERE rowid = agreeid) 
			        || ', не были сформированы авансы, т.к. дата счёта (' || doc_date || ') превышает срок оплаты аванса (' || existed_advance_date || ')!';
		END IF;
	END IF;
		
	----------------------------------------------------------------
	-- Вставка в bee_docs
	BEGIN

	    IF year_num<>'2012' 
	       THEN DocNum1 = (SELECT COALESCE ((SELECT MAX(docnum) + 1 FROM bee_docs 
						   JOIN bee_docs_advance AS bdat ON bee_docs.rowid = bdat.linkid1 
	                                          WHERE doctyp = doc_type AND date_ava BETWEEN first_day_of_year AND last_day_of_year), 1));
               ELSE IF month_num in ('1', '2', '3')
                       THEN DocNum1 = (SELECT COALESCE ((SELECT MAX(docnum) + 1 FROM bee_docs WHERE doctyp = doc_type AND docdat BETWEEN '2012-01-01' AND '2012-03-31'), 1));
                       ELSE DocNum1 = (SELECT COALESCE ((SELECT MAX(docnum) + 1 FROM bee_docs WHERE doctyp = doc_type AND docdat BETWEEN '2012-04-01' AND '2012-12-31'), 1));
		    END IF;
	    END IF;

	    INSERT INTO bee_docs(linkid,edit,pref,docnum,doctyp,docvid,docdat)
		          VALUES
				(agreeid,
				TRUE,
				(SELECT dic_prefix.prefix FROM dic_prefix WHERE dic_prefix.locid = loc_id),
				DocNum1,
				doc_type,
				ava_type,
				doc_date::DATE
				) RETURNING rowid INTO bd_curr_rowid ;
			
	    loops_count_bd := loops_count_bd + 1;
	    
	EXCEPTION
		WHEN unique_violation THEN
			--RETURN 'Вставка в таблицу bee_docs не выполнена! Документ на дату ' || doc_date || ' по договору ' || fio || ', ' || agreeid || ' уже существует!';
			RETURN 'Вставка в таблицу bee_docs не выполнена! Возможно, дублируется rowid';
		WHEN OTHERS THEN
			RETURN 'Вставка в bee_docs не выполнена! Ошибки при вставке ';
	END;
		
	-- цикл по счётчикам
	FOR Rec IN (SELECT rowid FROM agreepoint WHERE linkid = agreeid)
	LOOP
		----------------------------------------------------------------
		--2014-12-01  is_tarif_el_en
		is_point_tarif_el_en := (SELECT ((SELECT tarif_val FROM
						(SELECT tarif_val,agreepoint.rowid,agreepoint_tarif.period FROM dic_tarif_group
							JOIN agreepoint_tarif ON dic_tarif_group.rowid = agreepoint_tarif.tarifid
							JOIN agreepoint ON agreepoint_tarif.pointid = agreepoint.rowid
							WHERE agreepoint.rowid = Rec.rowid
							AND agreepoint_tarif.period <= ava_date
							ORDER BY agreepoint_tarif.period DESC LIMIT 1) AS a1) = ava_type));
							
		is_counter_exists := (SELECT (((SELECT octet_length(paramval) FROM agreepoint
								JOIN agreeregdev ON agreepoint.rowid = agreeregdev.linkid
							WHERE paramid = 690 AND agreepoint.rowid = Rec.rowid) < 3)
							OR
							((SELECT paramval FROM agreepoint
								JOIN agreeregdev ON agreepoint.rowid = agreeregdev.linkid
							WHERE paramid = 690 AND agreepoint.rowid = Rec.rowid) IS NULL)));
		--2014-12-01  IF (is_tarif_el_en IS NULL) THEN is_tarif_el_en = FALSE; END IF;
		IF (is_point_tarif_el_en IS NULL) THEN is_point_tarif_el_en = FALSE; END IF;
		IF (is_counter_exists IS NULL) THEN is_counter_exists = FALSE; END IF;
		
		--2014-12-01 IF (is_tarif_el_en AND is_counter_exists) 		
		IF (is_point_tarif_el_en AND is_counter_exists) 
		   THEN
			-- Вставка в bee_docs_advance
			/* 2014-12-01	
			is_point_tarif_el_en = (SELECT ((SELECT tarif_val FROM
								(SELECT tarif_val,agreepoint.rowid,agreepoint_tarif.period FROM dic_tarif_group
									JOIN agreepoint_tarif ON dic_tarif_group.rowid = agreepoint_tarif.tarifid
									JOIN agreepoint ON agreepoint_tarif.pointid = agreepoint.rowid
								 WHERE agreepoint.rowid = Rec.rowid
								 AND agreepoint_tarif.period <= ava_date
								 ORDER BY agreepoint_tarif.period DESC LIMIT 1) AS a1) = ava_type));
				
			is_counter_exists = (SELECT (((SELECT octet_length(paramval) FROM agreepoint
								JOIN agreeregdev ON agreepoint.rowid = agreeregdev.linkid
							WHERE paramid = 690 AND agreepoint.rowid = Rec.rowid) < 3)
							OR
							((SELECT paramval FROM agreepoint
								JOIN agreeregdev ON agreepoint.rowid = agreeregdev.linkid
							WHERE paramid = 690 AND agreepoint.rowid = Rec.rowid) IS NULL)));
			*/	
			
			IF (this_month_num = '1') THEN
				porteb_sum := (SELECT m01 FROM bee_points_consum 
				                WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year
				                  AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '2') THEN
				porteb_sum := (SELECT m02 FROM bee_points_consum 
				                WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
				                  AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '3') THEN
				porteb_sum := (SELECT m03 FROM bee_points_consum 
				                WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
				                  AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '4') THEN
				porteb_sum := (SELECT m04 FROM bee_points_consum 
						WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
						  AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '5') THEN
				porteb_sum := (SELECT m05 FROM bee_points_consum 
						WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year 
						AND last_day_of_year AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '6') THEN
				porteb_sum := (SELECT m06 FROM bee_points_consum 
						WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
						AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '7') THEN
				porteb_sum := (SELECT m07 FROM bee_points_consum 
						WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
						AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '8') THEN
				porteb_sum := (SELECT m08 FROM bee_points_consum 
						WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
						AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '9') THEN
				porteb_sum := (SELECT m09 FROM bee_points_consum 
						WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
						AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '10') THEN
				porteb_sum := (SELECT m10 FROM bee_points_consum 
						WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
						AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '11') THEN
				porteb_sum := (SELECT m11 FROM bee_points_consum 
						WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
						AND tarif_val = ava_type AND consumid = 1161);
			   ELSEIF (this_month_num = '12') THEN
				porteb_sum := (SELECT m12 FROM bee_points_consum 
						WHERE linkid = Rec.rowid AND period BETWEEN first_day_of_year AND last_day_of_year 
						AND tarif_val = ava_type AND consumid = 1161);
			END IF;
				
				
			IF (porteb_sum IS NULL) THEN porteb_sum := 0; END IF;				
			is_potreb_sum_not_null = (SELECT (porteb_sum > 0));
			
			--2014-12-01 IF (is_point_tarif_el_en IS NULL) THEN is_point_tarif_el_en = FALSE; END IF;
			--2014-12-01 IF (is_counter_exists IS NULL) THEN is_counter_exists = FALSE; END IF;
			IF (is_potreb_sum_not_null IS NULL) THEN is_potreb_sum_not_null = FALSE; END IF;

			--2014-12-01 IF (is_point_tarif_el_en AND is_counter_exists AND is_potreb_sum_not_null) THEN	
			IF (is_potreb_sum_not_null) 
			   THEN
				bda_linkid1 = bd_curr_rowid;
				bda_linkid2 = Rec.rowid;
				bda_tar_grp = (SELECT tarifid FROM (SELECT agreepoint_tarif.tarifid, agreepoint_tarif.period FROM agreepoint
						JOIN agreepoint_tarif ON agreepoint.rowid = agreepoint_tarif.pointid
						WHERE agreepoint.rowid = Rec.rowid AND agreepoint_tarif.period <= last_day_of_year
						ORDER BY period LIMIT 1 ) AS a1);
				bda_quantity_fact = (SELECT s1 FROM (SELECT sum(to_number(valman, '9999999999.999')) AS s1 FROM regdevoper
								      WHERE paramid = 850 AND valman <> '-'
								        AND operdate BETWEEN priv_month_first_day AND priv_month_last_day
									AND linkid = Rec.rowid GROUP BY linkid) AS a1);
				bda_quantity_plan = porteb_sum;
				bda_quantity_max = bda_quantity_plan;
				bda_date_ava = ava_date;
				IF (is_advance_common) 
				   THEN
					bda_percent_ava = (SELECT percent FROM dic_schedule_advance
							    WHERE period = (SELECT MAX(period) FROM dic_schedule_advance WHERE period <= ava_date)
							      AND queue_ava = ava_num);
				   ELSEIF (is_advance_by_agreement) THEN
					bda_percent_ava = (SELECT percent FROM bee_schedule_advance
							    WHERE period = (SELECT MAX(period) FROM bee_schedule_advance WHERE period <= ava_date AND linkid = agreeid)
							      AND queue_ava = ava_num AND linkid = agreeid);
				   ELSE
					bda_percent_ava = 0;
				END IF;

				IF (bda_percent_ava IS NULL) THEN bda_percent_ava = 100; END IF;
					
				bda_quantity_amo = ROUND(bda_quantity_plan * bda_percent_ava / 100, 0);
				bda_price = (SELECT summ FROM (SELECT summ, agreepoint_tarif.period, dic_tarif_sum.period FROM agreepoint
								 JOIN agreepoint_tarif ON agreepoint.rowid = agreepoint_tarif.pointid
								 JOIN dic_tarif_group ON agreepoint_tarif.tarifid = dic_tarif_group.rowid
								 JOIN dic_tarif_sum ON dic_tarif_group.rowid = dic_tarif_sum.tarifid
								WHERE dic_tarif_sum.period BETWEEN this_month_first_day AND this_month_last_day
								  AND dic_tarif_sum.period <= ava_date
								  AND agreepoint_tarif.period <= ava_date
								  AND agreepoint.rowid = Rec.rowid
								ORDER BY agreepoint_tarif.period DESC, dic_tarif_sum.period DESC LIMIT 1) AS a1);
								
				bda_cost_no_tax = ROUND(bda_quantity_amo * bda_price, 2);
				bda_tax_rate = ROUND((SELECT tax_proc FROM bee_docs_tax WHERE dat1 <= ava_date ORDER BY dat1 DESC LIMIT 1), 2);
				bda_tax_sum = ROUND(bda_cost_no_tax * bda_tax_rate / 100, 2);
				bda_cost_with_tax = ROUND(bda_cost_no_tax + bda_tax_sum, 2);
					
				BEGIN
					INSERT INTO bee_docs_advance (linkid1,linkid2,tar_grp,quantity_fact,quantity_plan,quantity_max,date_ava,
								      percent_ava,quantity_amo,price,cost_no_tax,tax_rate,tax_sum,cost_with_tax)
					VALUES (bda_linkid1,bda_linkid2,bda_tar_grp,bda_quantity_fact,bda_quantity_plan,bda_quantity_max,existed_advance_date,
						bda_percent_ava,bda_quantity_amo,bda_price,bda_cost_no_tax,bda_tax_rate,bda_tax_sum,bda_cost_with_tax);
								
					loops_count_bda := loops_count_bda + 1;
				EXCEPTION
					WHEN unique_violation THEN
						--RETURN 'Вставка в таблицу bee_docs_advance не выполнена! Документ на дату ' 
						--|| bda_date_ava || '  устройства ' || Rec.rowid || ' уже существует!';
						CONTINUE;
					WHEN OTHERS THEN
						--RETURN 'Вставка в bee_docs_advance не выполнена! Ошибки при вставке';
					END;
			   ELSE /* RETURN 'Вставка в bee_docs_advance не выполнена! 
				Сумма потребления = 0
				(' || is_potreb_sum_not_null || ') agreepoint.rowid : ' || Rec.rowid;*/
				--select docnumber from agreement where rowid = agreeid limit 1 INTO _docnum;-- 2016-05-06
				--RETURN 'Для договора '|| agreeid ||' в этом месяце в таблице "Плановые величины" cумма потребления = 0'; -- 2016-05-06
			END IF;
			---------------------------------------------------------------- 
		   ELSE /* RETURN 'Вставка в таблицу bee_docs_advance не выполнена! 
			Вид тарифа не эл.эн или счётсик снят (' || is_point_tarif_el_en || ' ' || is_counter_exists || ') agreepoint.rowid : ' || Rec.rowid; */
		END IF;
	END LOOP;

	IF loops_count_bda <= 0 THEN
		DELETE FROM bee_docs WHERE rowid = bd_curr_rowid;
		result = 'Создание не выполнено. Счётчиков по договору не найдено или они не соответствуют условиям добавления (не заполнена таблица "Плановые величины")! ( ' || fio || ', ' || agreeid || ' )'; -- 2016-05-06
	   ELSEIF result IS NULL OR result = '' THEN
		result = 'Создание выполнено ( ' || fio || ', bee_docs : ' || loops_count_bd || ', bee_docs_advance : ' || loops_count_bda || ' )';
	END IF;
		
	RETURN result;
END;
$$;

comment on function bee_add_new_bee_doc_old(text, text, integer, integer, integer, integer, integer) is 'Используется в bee_add_new_bee_doc_old(text, text, int, int, int, int, int)';

alter function bee_add_new_bee_doc_old(text, text, integer, integer, integer, integer, integer) owner to pgsql;

