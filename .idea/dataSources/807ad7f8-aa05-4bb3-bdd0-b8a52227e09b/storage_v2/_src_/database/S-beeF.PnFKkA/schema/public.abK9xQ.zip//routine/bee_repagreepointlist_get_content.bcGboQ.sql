create function bee_repagreepointlist_get_content(locid integer, filter_add text) returns SETOF bee_repagreepointlist
    language plpgsql
as
$$
DECLARE 
    RowLine bee_repagreepointlist%RowType;
BEGIN
RETURN QUERY EXECUTE'

SELECT
    apn.rowid,
        dn2.nam 								AS kol1,  --участок для договора 
    substring(pchain from 38)						AS kol2,  --Схема_подключения

    CASE
       WHEN gt.objtype=11 
         THEN family.son    
       ELSE family.father
    END									AS kol3,  --ТП

    amn.docnumber								AS kol4,  --номер договора
        TRIM(BOTH '||quote_literal(' ')||'
             FROM (COALESCE (de3.element_name,'||quote_literal('')||') 
         || '||quote_literal(' ')||' || consum_name)
        )::character varying(150)						AS kol5,  --наименование потребителя

    de31.element_name::character varying(47)				AS kol6,  --направление учета 
    dn1.nam									AS kol7,  --участок (для точки учета)
    arp.account664								AS kol8,  --лицевой счет головного абонента
    arp.prodnum664								AS kol9,  --номер счетчика головного абонента
    apn.account								AS kol10, --лицевой счет  
    ard.ard418								AS kol11, --запитанный объект 418
    ard.ard410								AS kol12, --адрес запитанного объекта 410
    ard.ard643								AS kol13, --место установки счетчика 643 
    ard.ard417								AS kol14, --адрес установки счетчика 417
    ard.ard715								AS kol15, --тип запитанного объекта 715
    de2.element_name 							AS kol16, --тип устройства
    apn.prodnumber								AS kol17, --номер устройства
    de1.element_name							AS kol18, --марка устройства
    attr.rda143								AS kol19, --класс точности A 143
    attr.rda146								AS kol20, --класс точности R 146 
    attr.rda148								AS kol21, --количество фаз 148
    ard.ard153								AS kol22, --год выпуска 153
    attr.rda171								AS kol23, --срок службы (лет) 171
    ard.ard154								AS kol24, --дата установки 154
    
        ard.ard155								AS kol25, --дата последней поверки 155
    attr.rda167::character varying(150)					AS kol26, --межповерочный интервал (лет) 167
    CASE 
       WHEN 
            ard.ard155::character varying like '||quote_literal('____-__-__' )||'    
            AND attr.rda167 IS NOT NULL
           THEN 
               -- error -> ard.ard155 + attr.rda167::int
               ( 
                 select ard.ard155::date +  concat(rda167,'' '',''YEAR'' )::interval
               )::date      
           ELSE 
               null
        END::date		 						AS kol27, --дата следующей поверки
    
        arp.arp439								AS kol28, --уровень напряжения 439
    dic_tarif_group.name::character varying(255)				AS kol29, --тарифная группа
    ard.ard168								AS kol30, --значность 168
    arp.arp356								AS kol31, --расчетный коэффициент 356
    arp.arp408								AS kol32, --потери в линиях 408
    arp.arp688								AS kol33, --нагрузочные потери 688
    arp.arp419								AS kol34, --потери холостого хода 419
    arp.arp1626								AS kol35, --потери в приборе учета 1626
    arp.arp851								AS kol36, --участок обхода 851
    arp.arp685								AS kol37, --присоединенная мощность 685
    arp.arp426								AS kol38, --макс. мощность (по договору) 426
    arp.arp830								AS kol39, --заявленная мощность 830
    arp.arp424								AS kol40, --разрешенная мощность по ТУ (кВт) 424
    arp.arp425								AS kol41, --кол-во часов работы в сутки 425
    arp.arp689								AS kol42, --работа в выходные дни 689
    ard.ard189 								AS kol43, --вид учета 189
    ard.ard690								AS kol44, --дата снятия(замены)счетчика 690
    ard.ard1469								AS kol45, --причина снятия(замены) счетчика 1469
    arp.arp1015								AS kol46, --примечание (пост) 1015
    arp.arp1016								AS kol47, --Контролер ФИО 1016
    arp.arp1474								AS kol48, --номер телефона 1474
    arp.arp1475								AS kol49, --номер SIM-карты 1475
    arp.arp1535 								AS kol50, --номер централизованного договора 1535
    arp.arp1614								AS kol51, --номер смешанного договора 1614
    attr.rda124								AS kol52, --тип счетчика 124
    attr.rda123								AS kol53, --вид энергии 123 
    attr.rda126								AS kol54, --номинальное напряжение 126
    attr.rda125								AS kol55, --ток номинальный 125
    attr.rda122								AS kol56, --ток максимальный 122
    attr.rda157								AS kol57, --номер в госреестре 157
    attr.rda170								AS kol58, --ток чувствительности 170
    attr.rda172								AS kol59, --выходной сигнал тип 172
    attr.rda173								AS kol60, --стандарт исполнения 173
    attr.rda174								AS kol61, --количество импульсов 174
    attr.rda175 								AS kol62, --температура минимальная 175
    attr.rda176 								AS kol63, --температура максимальная 176
    attr.rda177 								AS kol64, --тип интерфейса 177
    attr.rda178 								AS kol65, --наличие журнала событий 178
    attr.rda179 								AS kol66, --кол-во тарифов 179
    attr.rda180 								AS kol67, --кол-во тарифных зон 180
    attr.rda181 								AS kol68, --возможность програм. иск. дней 181
    attr.rda182 								AS kol69, --резервное питание 182
    attr.rda183 								AS kol70, --хранение профиля нагрузки  183
    attr.rda184 								AS kol71, --измерение в 2- напр 184
    attr.rda185 								AS kol72, --наличие электронной 185
        ard.ard1641 								AS kol73, --тип модема 1641

        ard.ard824 								AS kol74, --дата последней проверки 824
    CASE WHEN ard.ard831 IS NULL THEN '||quote_literal('')||'
	ELSE ard.ard831 	
    END									AS kol75, --N акта посл.пров.счетч. 831
    CASE WHEN ard.ard1471 IS NULL THEN '||quote_literal('')||'
	ELSE ard.ard1471
    END 									AS kol76, --комментарий 1471
	
    CASE WHEN arp.arp156 IS NULL THEN '||quote_literal('')||'
	ELSE arp.arp156
    END									AS kol77, --номер пломбы 156
    CASE WHEN arp.arp970 IS NULL THEN '||quote_literal('')||'
	ELSE arp.arp970
    END									AS kol78, --тип пломбы 970
    CASE WHEN arp.arp971 IS NULL THEN '||quote_literal('')||'
	ELSE arp.arp971
    END									AS kol79, --место установки пломбы 971
    CASE WHEN arp.arp1862 IS NULL THEN '||quote_literal('')||'
	ELSE arp.arp1862
    END									AS kol80, --ограничение режима потребления эл.эн. 1862
    arp.dat_restriction							AS kol81, --дата ограничения режима потребления эл.эн. 1862 period

    CASE WHEN arp.arp1863 IS NULL THEN '||quote_literal('')||'
	ELSE arp.arp1863
    END									AS kol82, --возобновление режима потребления эл.эн 1863
    
        arp.dat_renewal							        AS kol83,  --дата возобновления режима потребления эл.эн 1863 period
    ard.ard1445   							        AS kol84,  --дата акта раздела границ 1445
    CASE WHEN ard.ard690 IS NOT NULL
       THEN true
       ELSE false
    END   							       		AS p690, --состояние счетчика (снят/не снят)
    
    ard.ard686   							        AS kol85,  --номер ТУ 686
    ard.ard687  							        AS kol86,  --дата ТУ 687
    ard.ard1408   							        AS kol87,  --№ акта тех.присоединения 1408
        ard.ard1409   							        AS kol88,  --дата акта тех.присоединения 1409
    ard.ard1944   							        AS kol89,  --N уведомления о замене прибора учёта 1944
        ard.ard1945   							        AS kol90   --Дата выдачи уведомления о замене прибора учёта 1945


    FROM agreepoint								AS apn
   LEFT JOIN denet 								AS dn1  	ON dn1.rowid = apn.lid
        JOIN dic_elements 							AS de1  	ON de1.rowid = apn.devid
        JOIN dic_elements 							AS de2  	ON de2.rowid = apn.devtype
        JOIN agreement								AS amn 		ON amn.rowid = apn.linkid
        JOIN denet 								AS dn2  	ON dn2.rowid = amn.locid
        JOIN dic_elements 							AS de31		ON de31.rowid = amn.accdir
        JOIN customer 								AS cust		ON cust.abo_code = amn.abo_code
        JOIN dic_elements 							AS de3  	ON de3.rowid = cust.urstatus
        

   LEFT JOIN (SELECT agreepoint_tarif.tarifid, agreepoint_tarif.pointid 
                FROM agreepoint_tarif
                JOIN (SELECT pointid, MAX(period) AS period 
                        FROM agreepoint_tarif 
                       GROUP BY pointid
                     ) AS at ON agreepoint_tarif.pointid=at.pointid AND agreepoint_tarif.period=at.period
              ) 								AS agr_tar 	ON agr_tar.pointid = apn.rowid

   LEFT JOIN dic_tarif_group 							      		ON dic_tarif_group.rowid = agr_tar.tarifid
   LEFT JOIN regdevconn 							AS rdc  	ON rdc.pointid = apn.rowid
   LEFT JOIN gis_traces 							AS gt   	ON gt.rowid = rdc.traceid
    
--для выбора наименования ТП, не зависимо от подключения к ТП или к отходящей линии
   LEFT JOIN (SELECT agreepoint.rowid AS r1, 
                      t1.objname       AS son, 
                      t1.objcode       AS son_code, 
                      t1.objowner      AS son_owner_code,
	      t2.objname        AS father, 
	      t2.objcode        AS father_code
	 FROM agreepoint 
	 JOIN regdevconn ON agreepoint.rowid=regdevconn.pointid 
                 JOIN gis_traces AS t1 ON regdevconn.traceid=t1.rowid 
        LEFT JOIN gis_traces AS t2 ON t2.objcode=t1.objowner 
                 JOIN gis_traces_tmp ON t2.objcode=gis_traces_tmp.objcode AND t2.objowner=gis_traces_tmp.objowner
                GROUP BY agreepoint.rowid, t1.objname, t1.objcode, t1.objowner, t2.objname, t2.objcode
               ) 								AS family 	ON family.r1=rdc.pointid
 
--СПРАВОЧНЫЕ ПАРАМЕТРЫ СЧЕТЧИКА
    LEFT JOIN (select * from bee_repagreepointlist_get_regdevattr())		AS attr		ON apn.devid=attr.deviceid							
--ПЕРИОДИЧЕСКИЕ ПАРАМЕТРЫ
    LEFT JOIN (select * from bee_repagreepointlist_get_agreeregdev_period('||$1||'))		AS arp		ON apn.rowid=arp.rowid
--ПОСТОЯННЫЕ ПАРАМЕТРЫ
    LEFT JOIN (select * from bee_repagreepointlist_get_agreeregdev('||$1||'))			AS ard		ON apn.rowid=ard.rowid							

 WHERE amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = '||$1||')) '||$2||'
 ORDER BY dn2.nam;';
  
END;

$$;

comment on function bee_repagreepointlist_get_content(integer, text) is 'Список устройств. Используется в RepAgreepointList.java, SessionBean1.java';

alter function bee_repagreepointlist_get_content(integer, text) owner to postgres;

