create function bee_rep_get_repdata26(loc integer, str_date date, end_date date) returns SETOF bee_repdata26
    language plpgsql
as
$$
/*
	ito06 2011-10-28:Анализ динамики потребления ДЭ (репс)
	add tio06 2014-05-21
*/
DECLARE
     e_dat DATE = (SELECT (date_trunc('month', end_date) +  INTERVAL '1 month' - INTERVAL '1 day' )::DATE);
     RowLine bee_repdata26%rowtype;

BEGIN
FOR RowLine IN (
SELECT 
    fil_name,
    pchain,
    docnumber,
    account,
    prodnumber,
    cst_name,
    accdir,
    p1450,
    p418,
    p410,
    p643,
    p417,
    p356,
    p641,
    p642,
    p851,
    p189,
    p690,
    p424,
    v850[1] AS v850_1,
    v850[2] AS v850_2,
    v850[3] AS v850_3,
    v850[4] AS v850_4,
    v850[5] AS v850_5,
    v850[6] AS v850_6,
    v850[7] AS v850_7,
    v850[8] AS v850_8,
    v850[9] AS v850_9,
    v850[10] AS v850_10,
    v850[11] AS v850_11,
    v850[12] AS v850_12,
    v850[13] AS v850_13,
    state,
    deviation,
    deviation1,
    mid,
    p715,
    itogo,
    curr,
    removedat,
    transmit 
    from bee_repakt7_get_content($1,$2,e_dat,0, true) --формируется по всем договорам (вкл не дейсв)
    order by docnumber
)
        LOOP 
 RETURN  NEXT RowLine;
	END LOOP;	
END;

$$;

comment on function bee_rep_get_repdata26(integer, date, date) is 'Анализ динамики потребления ДЭ (репс). Используется в RepCreate26.java';

alter function bee_rep_get_repdata26(integer, date, date) owner to postgres;

