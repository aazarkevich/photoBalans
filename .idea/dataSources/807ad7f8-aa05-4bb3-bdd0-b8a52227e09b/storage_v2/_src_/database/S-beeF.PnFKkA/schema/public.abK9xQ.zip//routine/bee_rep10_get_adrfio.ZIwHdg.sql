create function bee_rep10_get_adrfio(docnumber character varying, locid integer) returns character varying
    language sql
as
$$
/*
ito06 2011-10-06 
Приложение 1
*/
select 
  replace(bee_rep8_get_adr(dic1.element_name,cst.consum_name,adr1.item,adr2.item,adr3.item,adr4.item),E'\\','/') AS adrfio
from customer as cst
  JOIN agreement as amn ON amn.abo_code=cst.abo_code AND amn.docnumber=$1
  LEFT JOIN customer_info AS adr1 ON cst.abo_code=adr1.abo AND adr1.elrowid=358
  LEFT JOIN customer_info AS adr2 ON cst.abo_code=adr2.abo AND adr2.elrowid=361
  LEFT JOIN customer_info AS adr3 ON cst.abo_code=adr3.abo AND adr3.elrowid=362
  LEFT JOIN customer_info AS adr4 ON cst.abo_code=adr4.abo AND adr4.elrowid=363  
  LEFT JOIN dic_elements AS dic1 ON cst.urstatus=dic1.rowid
  WHERE cst.locid = $2
$$;

comment on function bee_rep10_get_adrfio(varchar, integer) is 'Приложение 1. Используется в RepCreate10.java';

alter function bee_rep10_get_adrfio(varchar, integer) owner to pgsql;

