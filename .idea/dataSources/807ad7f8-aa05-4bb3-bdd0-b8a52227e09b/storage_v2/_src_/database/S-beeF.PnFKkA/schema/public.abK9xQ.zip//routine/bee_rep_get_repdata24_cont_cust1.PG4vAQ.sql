create function bee_rep_get_repdata24_cont_cust1(loc_id integer, start_d date, end_d date) returns SETOF bee_repdata24
    language sql
as
$$
    /*
        add ito06 2013-10-21
        ito06 2012-02-10: Ведомость по объему услуг
    */
	-- 11 потребление за отчётный период (1.1.2.1) 
	(SELECT
		11						AS grp,
		'norm'::text	 				AS row_style,
		dat 						AS dat,
		'1.1.2.1' 					AS "n/n",
		'1.1.2.1.1'					AS "n/n_tmp",
		'потребление за отчётный период'  		AS name,
		"name"						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot)::numeric(12,6),
		sum(tar_m_vn)::numeric(12,6),
		sum(tar_m_sn1)::numeric(12,6),
		sum(tar_m_sn2)::numeric(12,6),
		sum(tar_m_nn)::numeric(12,6),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=139
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=140
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=141
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=138
      LEFT JOIN bee_rep_get_repdata24_tmp1_cust($1,$2,$3,139,140,141,138)  ON true
          WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL
          GROUP BY dat,"name") 
UNION   -- 11 корректировка (1.1.2.1)
	(SELECT
		11 						AS grp,
		'norm'::text					AS row_style,
		dat 						AS dat,
		'1.1.2.1'					AS "n/n",
		'1.1.2.1.2'					AS "n/n_tmp",
		'корректировка за '|| to_char(dat,'YYYY-MM')	AS "name",
		name						AS doc_name,
		null::numeric 					AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6) 				AS tar_m_vn,
		null::numeric(12,6) 				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6) 				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr1_cust($1,$2,$3,139,140,141,138)
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat, name)
UNION   -- 12 потребление за отчётный период (1.2.1.2.1)
	(SELECT
		12						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'1.2.1.2.1' 					AS "n/n",
		'1.2.1.2.1.1' 					AS "n/n_tmp",
		'потребление за отчётный период'  		AS name,
		"name"			 			AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 		 			AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=142
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=144
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=147
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=148
      LEFT JOIN bee_rep_get_repdata24_tmp1_cust($1,$2,$3,142,144,147,148) ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL
	  GROUP BY dat, "name") 
UNION   -- 12 корректировка (1.2.1.2.1)
	(SELECT
		12 						AS grp,
		'norm'::text 					AS row_style,
		dat  						AS dat,
		'1.2.1.2.1' 					AS "n/n",
		'1.2.1.2.1.2'					AS "n/n_tmp",
		'корректировка за '|| to_char(dat,'YYYY-MM')	AS "name",
		"name"						AS doc_name,
		null::numeric					AS tar_vn,
		null::numeric					AS tar_sn1,
		null::numeric	 				AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6) 				AS tar_m_vn,
		null::numeric(12,6) 				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6) 				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr1_cust($1,$2,$3,142,144,147,148)
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat,"name")
UNION   -- 12 потребление за отчётный период (1.2.1.4.1)
	(SELECT
		12 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'1.2.1.4.1'					AS "n/n",
		'1.2.1.4.1.1'					AS "n/n_tmp",
		'потребление за отчётный период'  		AS name,
		"name" 						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=143
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=145
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=146
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=149
      LEFT JOIN bee_rep_get_repdata24_tmp1_cust($1,$2,$3,143,145,146,149)  ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL
	  GROUP BY dat,"name")
UNION   -- 12 корректировка (1.2.1.4.1)
	(SELECT
		12 						AS grp,
		'norm'::text 					AS row_style,
		dat  						AS dat,  
		'1.2.1.4.1' 					AS "n/n",
		'1.2.1.4.1.2'					AS "n/n_tmp",
		'корректировка за '||to_char(dat,'YYYY-MM') 	AS "name",
		"name"						AS doc_name,
		null::numeric 					AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6)			 	AS tar_m_vn,
		null::numeric(12,6)				AS tar_m_sn1,
		null::numeric(12,6)				AS tar_m_sn2,
		null::numeric(12,6) 				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr1_cust($1,$2,$3,143,145,146,149) AS vn 
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat, "name")
UNION   -- 21 потребление за отчётный период (2.1.2.1)
	(SELECT
		21 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'2.1.2.1' 					AS "n/n",
		'2.1.2.1.1' 					AS "n/n_tmp",
		'потребление за отчётный период'		AS name,
		"name"				 		AS doc_name,
		null::numeric 					AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=139
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=140
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=141
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=138
      LEFT JOIN bee_rep_get_repdata24_tmp2_cust($1,$2,$3,139,140,141,138)  ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL
	  GROUP BY dat,"name")
UNION   -- 21 корректировка (2.1.2.1)
	(SELECT
		21						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'2.1.2.1' 					AS "n/n",
		'2.1.2.1.2' 					AS "n/n_tmp",
		'корректировка за '|| to_char(dat,'YYYY-MM')	AS "name",
		"name"						AS doc_name,
		null::numeric AS tar_vn,
		null::numeric AS tar_sn1,
		null::numeric AS tar_sn2,
		null::numeric AS tar_nn,
		null::numeric(12,6) AS tar_m_tot,
		null::numeric(12,6) AS tar_m_vn,
		null::numeric(12,6) AS tar_m_sn1,
		null::numeric(12,6) AS tar_m_sn2,
		null::numeric(12,6) AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr2_cust($1,$2,$3,139,140,141,138)
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat, "name")
UNION   -- 22 потребление за отчётный период (2.2.1.2.1)
	(SELECT
		22 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'2.2.1.2.1'					AS "n/n",
		'2.2.1.2.1.1' 					AS "n/n_tmp",
		'потребление за отчётный период'  		AS name,
		"name" 						AS doc_name,
		null::numeric		 			AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=142
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=144
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=147
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=148
      LEFT JOIN bee_rep_get_repdata24_tmp2_cust($1,$2,$3,142,144,147,148)  ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL
	  GROUP BY dat,"name")
UNION   -- 22 корректировка (2.2.1.2.1)
	(SELECT
		22 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'2.2.1.2.1'					AS "n/n",
		'2.2.1.2.1.2'					AS "n/n_tmp",
		'корректировка за '|| to_char(dat,'YYYY-MM')	AS "name",
		"name" 						AS doc_name,
		null::numeric 					AS tar_vn,
		null::numeric					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6)	 			AS tar_m_tot,
		null::numeric(12,6) 				AS tar_m_vn,
		null::numeric(12,6) 				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6) 				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr2_cust($1,$2,$3,142,144,147,148) 
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat, "name")
UNION   -- 22 потребление за отчётный период (2.2.1.4.1)
	(SELECT	
		22 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'2.2.1.4.1'					AS "n/n",
		'2.2.1.4.1.1'					AS "n/n_tmp",
		'потребление за отчётный период'  		AS name,
		"name" 						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM 
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=143
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=145
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=146
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=149
      LEFT JOIN bee_rep_get_repdata24_tmp2_cust($1,$2,$3,143,145,146,149) ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL
	  GROUP BY dat,"name")
UNION   -- 22 корректировка (2.2.1.4.1)
	(SELECT
		22						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'2.2.1.4.1' 					AS "n/n",
		'2.2.1.4.1.1' 					AS "n/n_tmp",
		'корректировка за '|| to_char(dat,'YYYY-MM') 	AS "name",
		"name" 						AS doc_name,
		null::numeric					AS tar_vn,
		null::numeric					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6) 				AS tar_m_vn,
		null::numeric(12,6) 				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6) 				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum) 
	   FROM bee_rep_get_repdata24_corr2_cust($1,$2,$3,143,145,146,149) 
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat,"name")
UNION   -- 31 потребление за отчётный период (3.1.5.1)
	(SELECT
		31 						AS grp,
		'norm'::text 					AS row_style,
		dat						AS dat,
		'3.1.5.1' 					AS "n/n",
		'3.1.5.1.1' 					AS "n/n_tmp",
		'потребление за отчётный период'		AS "name",
		"name"						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 		 			AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum) 
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=150
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=156
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=154
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=155
      LEFT JOIN bee_rep_get_repdata24_tmp3_cust($1,$2,$3,150,156,154,155) ON true
           JOIN bee_rep_get_repdata24_corr_exists_cust($1,$2,$3,150,156,154,155) AS b on b.name = name  
	  WHERE (tot_sum IS NOT NULL OR tot_amount IS NOT NULL) 
	  GROUP BY dat,"name") 	  
UNION   -- 31 потреблено по соц. норме (3.1.5.1)
	(SELECT
		31 						AS grp,
		'norm'::text 					AS row_style,
		dat						AS dat,
		'3.1.5.1' 					AS "n/n",
		'3.1.5.1.2' 					AS "n/n_tmp",
		'потреблено в пределах соц. нормы'		AS "name",
		"name"						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 		 			AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum) 
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=150
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=156
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=154
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=155
      LEFT JOIN bee_rep_get_repdata24_tmp3_norm_cust($1,$2,$3,150,156,154,155) ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL
	  GROUP BY dat,"name") 	  
UNION   -- 31 потреблено сверх соц. нормы (3.1.5.1)
	(SELECT
		31 						AS grp,
		'norm'::text 					AS row_style,
		dat						AS dat,
		'3.1.5.1' 					AS "n/n",
		'3.1.5.1.3' 					AS "n/n_tmp",
		'потреблено сверх соц. нормы'			AS "name",
		"name"						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 		 			AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=150
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=156
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=154
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=155
      LEFT JOIN bee_rep_get_repdata24_tmp3_snorm_cust($1,$2,$3,150,156,154,155) ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL
	  GROUP BY dat,"name") 
UNION   -- 31 корректировка по соц. норме  (3.1.5.1)
	(SELECT
		31 						AS grp,
		'norm'::text					AS row_style,
		dat 						AS dat,
		'3.1.5.1' 					AS "n/n",
		'3.1.5.1.4' 					AS "n/n_tmp",
		'корректировка за '||to_char(dat,'YYYY-MM')
		||' в пределах соц. нормы'			  	AS "name",
		"name"						AS doc_name,
		null::numeric 					AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6)				AS tar_m_vn,
		null::numeric(12,6)				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6)				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr3_norm_cust($1,$2,$3,150,156,154,155) 
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat, "name")
UNION   -- 31 корректировка сверх соц. нормы  (3.1.5.1)
	(SELECT
		31 						AS grp,
		'norm'::text					AS row_style,
		dat 						AS dat,
		'3.1.5.1' 					AS "n/n",
		'3.1.5.1.5' 					AS "n/n_tmp",
		'корректировка за '||to_char(dat,'YYYY-MM')
		||' сверх соц. нормы'			  	AS "name",
		"name"						AS doc_name,
		null::numeric 					AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6)				AS tar_m_vn,
		null::numeric(12,6)				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6)				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr3_snorm_cust($1,$2,$3,150,156,154,155) 
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat, "name")
UNION   -- 32 потребление за отчётный период (3.2.5.1)
	(SELECT
		32 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'3.2.5.1' 					AS "n/n",
		'3.2.5.1.1' 					AS "n/n_tmp",
		'потребление за отчётный период'		AS "name",
		"name" 						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 		 			AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=152
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=159
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=157
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=158
      LEFT JOIN bee_rep_get_repdata24_tmp3_cust($1,$2,$3,152,159,157,158) ON true
           JOIN bee_rep_get_repdata24_corr_exists_cust($1,$2,$3,152,159,157,158) AS b on b.name = name
	  WHERE (tot_sum IS NOT NULL OR tot_amount IS NOT NULL) 
	GROUP BY dat,name)
UNION   -- 32 потреблено по соц. норме (3.2.5.1)
	(SELECT
		32 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'3.2.5.1' 					AS "n/n",
		'3.2.5.1.2' 					AS "n/n_tmp",
		'потреблено в пределах соц. нормы'		AS "name",
		"name" 						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 		 			AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=152
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=159
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=157
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=158
      LEFT JOIN bee_rep_get_repdata24_tmp3_norm_cust($1,$2,$3,152,159,157,158) ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL 
	  GROUP BY dat,name)
UNION   -- 32 потреблено сверх соц. нормы (3.2.5.1)
	(SELECT
		32 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'3.2.5.1' 					AS "n/n",
		'3.2.5.1.3' 					AS "n/n_tmp",
		'потреблено сверх соц. нормы'			AS "name",
		"name" 						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 		 			AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=152
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=159
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=157
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=158
      LEFT JOIN bee_rep_get_repdata24_tmp3_snorm_cust($1,$2,$3,152,159,157,158) ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL 
	  GROUP BY dat,name)
UNION   -- 32 корректировка в пределах соц. норме  (3.2.5.1)
	(SELECT
		32 						AS grp,
		'norm'::text					AS row_style,
		dat 						AS dat,
		'3.2.5.1' 					AS "n/n",
		'3.2.5.1.4' 					AS "n/n_tmp",
		'корректировка за '||to_char(dat,'YYYY-MM') 	
		||' в пределах соц. норм'			AS name,
		"name"  					AS odc_name,
		null::numeric 					AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6) 				AS tar_m_vn,
		null::numeric(12,6) 				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6) 				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr3_norm_cust($1,$2,$3,152,159,157,158)
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat,"name")
UNION   -- 32 корректировка сверх соц. нормы  (3.2.5.1)
	(SELECT
		32 						AS grp,
		'norm'::text					AS row_style,
		dat 						AS dat,
		'3.2.5.1' 					AS "n/n",
		'3.2.5.1.5' 					AS "n/n_tmp",
		'корректировка за '||to_char(dat,'YYYY-MM') 	
		||' сверх соц. нормы'				AS name,
		"name"  					AS odc_name,
		null::numeric 					AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6) 				AS tar_m_vn,
		null::numeric(12,6) 				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6) 				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr3_snorm_cust($1,$2,$3,152,159,157,158)
	  WHERE tot_sum <>0 OR tot_amount <>0
	  GROUP BY dat,"name")
UNION   -- 33 потребление за отчётный период (3.3.5.1)
	(SELECT
		33 						AS grp,
		'norm'::text					AS row_style,
		dat						AS dat,
		'3.3.5.1' 					AS "n/n",
		'3.3.5.1.1' 					AS "n/n_tmp",
		'потребление за отчётный период'		AS "name",
		"name"						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=153
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=162
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=160
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=161
      LEFT JOIN bee_rep_get_repdata24_tmp3_cust($1,$2,$3,153,162,160,161) ON true
          JOIN bee_rep_get_repdata24_corr_exists_cust($1,$2,$3,153,162,160,161) AS b on b.name = name
	  WHERE (tot_sum IS NOT NULL OR tot_amount IS NOT NULL) 
	  GROUP BY dat,name)
UNION   -- 33 потреблено в пределах соц. норме (3.3.5.1)
	(SELECT
		33 						AS grp,
		'norm'::text					AS row_style,
		dat						AS dat,
		'3.3.5.1' 					AS "n/n",
		'3.3.5.1.2' 					AS "n/n_tmp",
		'потреблено в пределах соц. нормы'		AS "name",
		"name"						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 		 			AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=153
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=162
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=160
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=161
      LEFT JOIN bee_rep_get_repdata24_tmp3_norm_cust($1,$2,$3,153,162,160,161) ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL 
	  GROUP BY dat,name)
UNION   -- 33 потреблено сверх соц. нормы (3.3.5.1)
	(SELECT
		33 						AS grp,
		'norm'::text					AS row_style,
		dat						AS dat,
		'3.3.5.1' 					AS "n/n",
		'3.3.5.1.3' 					AS "n/n_tmp",
		'потреблено сверх соц. нормы'			AS "name",
		"name"						AS doc_name,
		null::numeric	 				AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 		 			AS tar_sn2,
		null::numeric					AS tar_nn,
		sum(tar_m_tot),
		sum(tar_m_vn),
		sum(tar_m_sn1),
		sum(tar_m_sn2),
		sum(tar_m_nn),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=153
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=162
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=160
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=161
      LEFT JOIN bee_rep_get_repdata24_tmp3_snorm_cust($1,$2,$3,153,162,160,161) ON true
	  WHERE tot_sum IS NOT NULL OR tot_amount IS NOT NULL 
	  GROUP BY dat,name)
UNION   -- 33 корректировка в пределах соц. нормы  (3.3.5.1)
	(SELECT
		33 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'3.3.5.1' 					AS "n/n",
		'3.3.5.1.4' 					AS "n/n_tmp",
		'корректировка за '||to_char(dat,'YYYY-MM')	
		|| ' в пределах соц. нормы' 			AS "name",
		"name"						AS doc_name,
		null::numeric 					AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6) 				AS tar_m_vn,
		null::numeric(12,6) 				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6) 				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr3_norm_cust($1,$2,$3,153,162,160,161)
	  WHERE tot_sum <>0 OR tot_amount <>0  
	  GROUP BY dat,"name") 
UNION   -- 33 корректировка сверх соц.нормы  (3.3.2.1)
	(SELECT
		33 						AS grp,
		'norm'::text 					AS row_style,
		dat 						AS dat,
		'3.3.5.1' 					AS "n/n",
		'3.3.5.1.5' 					AS "n/n_tmp",
		'корректировка за '||to_char(dat,'YYYY-MM')	
		||' сверх соц.нормы'				AS "name",
		"name"						AS doc_name,
		null::numeric 					AS tar_vn,
		null::numeric 					AS tar_sn1,
		null::numeric 					AS tar_sn2,
		null::numeric 					AS tar_nn,
		null::numeric(12,6) 				AS tar_m_tot,
		null::numeric(12,6) 				AS tar_m_vn,
		null::numeric(12,6) 				AS tar_m_sn1,
		null::numeric(12,6) 				AS tar_m_sn2,
		null::numeric(12,6) 				AS tar_m_nn,
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	   FROM bee_rep_get_repdata24_corr3_snorm_cust($1,$2,$3,153,162,160,161)
	  WHERE tot_sum <>0 OR tot_amount <>0  
	  GROUP BY dat,"name") 
ORDER BY  "n/n", doc_name, dat, "n/n_tmp";
$$;

comment on function bee_rep_get_repdata24_cont_cust1(integer, date, date) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24_cont_cust(int, date, date), bee_rep_get_repdata24_cont_cust2(int, date, date)';

alter function bee_rep_get_repdata24_cont_cust1(integer, date, date) owner to pgsql;

