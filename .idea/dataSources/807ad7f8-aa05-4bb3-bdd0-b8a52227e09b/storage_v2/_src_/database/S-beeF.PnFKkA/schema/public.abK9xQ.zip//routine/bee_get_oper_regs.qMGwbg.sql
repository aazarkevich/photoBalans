create function bee_get_oper_regs(xlid integer, per character varying) returns text
    language plpgsql
as
$$
/*
	СПИСОК ТОЧЕК ПО ДОГОВОРУ ИМЕЮЩИХ НАЛИЧИЕ ПОКАЗАНИЙ НА УКАЗАННЫЙ ПЕРИОД
	locid : код места обработки
	per   : период (YYYY-MM)
	add ito06 2014-06-24
*/
DECLARE
	RC     REFCURSOR;
	Period VARCHAR := per || '%';
	Rec    RECORD;
	IdList TEXT := '';
	Delim  CONSTANT CHAR := '|';
	
BEGIN
	FOR Rec IN
		SELECT agreepoint.rowid FROM agreepoint 
		  JOIN agreement ON (agreepoint.linkid = agreement.rowid)  
		 WHERE 
			agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = xlid)) AND
			agreepoint.rowid IN (SELECT linkid FROM regdevoper 
					      WHERE 
						    operdate::text LIKE Period     AND 
						    paramid           = 407        AND  -- отчётное количество  
						    valman           IS NOT NULL   AND
						    valman            ~ E'\\d{1,}' AND
						    valman           <> '0'
					     )
	LOOP
		IdList := IdList || Rec.rowid || Delim;
	END LOOP;     
	--
	RETURN IdList;
	END;
$$;

comment on function bee_get_oper_regs(integer, varchar) is 'Список точек по договору имеющих наличие показаний на указанный период. Используется в AgreeByDevice.java, AppUtils.java';

alter function bee_get_oper_regs(integer, varchar) owner to pgsql;

