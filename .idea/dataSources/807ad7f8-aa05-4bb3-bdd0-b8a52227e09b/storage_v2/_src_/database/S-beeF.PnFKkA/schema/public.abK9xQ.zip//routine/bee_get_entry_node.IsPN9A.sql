create function bee_get_entry_node(lid integer) returns integer
    language plpgsql
as
$$
    --
-- ПОЛУЧИТЬ САМЫЙ ВЕРХНИЙ ID УЗЛА СЕТИ
-- lid - код места логации
-- возврат -  родительского
-- 
DECLARE
   ParentId integer;
   LabId    character varying;
BEGIN
  SELECT INTO LabId kod FROM denet WHERE rowid = lid;
  IF LabId IS NULL THEN 
     RETURN -1;
  END IF; 
  SELECT INTO ParentId rowid FROM denet WHERE kod = substring(LabId from 1 for 6) ;
  IF ParentId IS NULL THEN 
     RETURN -1;
  END IF;
--
RETURN ParentId;
--
--
END;
--
--
$$;

comment on function bee_get_entry_node(integer) is 'Используется в AgreeAddDev.java, ConnectDevice.java, CustomerForm.java, DeviceEdit.java, LossDistr.java, AppUtils.java; в bee_get_objects_by_type(int, int),  bee_get_traces_by_mask(int, varchar), bee_get_traces_by_type(int, int), bee_set_new_path(int)';

alter function bee_get_entry_node(integer) owner to pgsql;

