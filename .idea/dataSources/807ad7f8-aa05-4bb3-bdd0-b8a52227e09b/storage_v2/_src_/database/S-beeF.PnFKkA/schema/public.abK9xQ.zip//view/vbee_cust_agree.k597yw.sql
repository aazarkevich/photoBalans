create view vbee_cust_agree(locid, aboid, abonam, aboinn, agreeid, docnum) as
SELECT customer.locid,
       customer.abo_code   AS aboid,
       customer.abo_name   AS abonam,
       customer.consum_inn AS aboinn,
       agreement.rowid     AS agreeid,
       agreement.docnumber AS docnum
FROM (customer
         LEFT JOIN agreement ON ((customer.abo_code = agreement.abo_code)))
WHERE ((customer.valid = true) AND (agreement.abo_code IS NOT NULL) AND (agreement.locid IS NOT NULL) AND
       (agreement.doctype = ANY (ARRAY [1910, 1911])))
ORDER BY customer.locid, customer.abo_name, customer.consum_inn, agreement.docnumber;

comment on view vbee_cust_agree is 'Используется в LossRSK.java, PaymentDocs.java, SessionBean1.java';

alter table vbee_cust_agree
    owner to pgsql;

