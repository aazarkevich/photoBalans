create function bee_close_period_list() returns SETOF bee_close_date
    rows 100
    language plpgsql
as
$$
/*
        add ito06 2013-07-19 
	by ito07 2012-10-31

*/
DECLARE
   Loc RECORD;
   R   RECORD;
BEGIN
   FOR Loc IN (SELECT host_name AS h,db_name AS d, filloc AS f FROM bee_closed_bases WHERE available = TRUE)
   LOOP
      FOR R IN (SELECT * from bee_close_period_get(Loc.h,Loc.d, Loc.f))
      LOOP 
         RETURN NEXT R;
      END LOOP; 
   END LOOP;
END;
$$;

comment on function bee_close_period_list() is 'Используется в bee_closed_period_refill()';

alter function bee_close_period_list() owner to pgsql;

