create function bee_get_agreeid_by_pointid(xlid integer, pointid integer) returns integer
    language plpgsql
as
$$
/*
	ИДЕНТИФИКАТОР ДОГОВОРА ПО КОДУ ТОЧКИ УЧЁТА
	lid     : код места обработки
	pointid : код точки учёта
	add ito06 2014-06-24
*/ 
BEGIN
   RETURN (
      SELECT agreement.rowid FROM agreement
      JOIN agreepoint ON agreement.rowid = agreepoint.linkid       
      WHERE 
         agreement.locid  IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = xlid))      AND 
         agreepoint.rowid = pointid
      LIMIT 1
   );
END;
$$;

comment on function bee_get_agreeid_by_pointid(integer, integer) is 'Идентификатор договора по коду точки учета. Используется в AgreeRegDev.java, RepAkt.java, RepAkt1.java, AppUtils.java';

alter function bee_get_agreeid_by_pointid(integer, integer) owner to pgsql;

