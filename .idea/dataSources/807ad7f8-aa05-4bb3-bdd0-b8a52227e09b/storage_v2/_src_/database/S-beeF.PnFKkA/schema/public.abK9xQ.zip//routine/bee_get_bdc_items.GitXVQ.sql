create function bee_get_bdc_items(_locid integer, _docdat text, _docs_linkid integer, _docid integer) returns SETOF bdc_items
    language plpgsql
as
$$
/*
	add ito06 2020-04-16
	add ito06 2014-06-24
	add ito06 2013-10-09
	Отображение таблицы "результат" в форме "корректировка"
*/
DECLARE
	RowLine bdc_items%rowtype;
	_add text;	
BEGIN
	FOR RowLine IN (
			SELECT
				t1.docdat,
				t1.docnum,
				bee_docs_corr.period,
				customer.consum_inn,
				customer.consum_name,
				agreement.docnumber,
				agreepoint.account,
				agreepoint.prodnumber,
			        CASE 
                                    WHEN bee_docs_corr.con_sum = 850
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_new::integer)                                        
                                    WHEN bee_docs_corr.con_sum = 1446
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_new::integer) || '(в пределах соц. нормы)'
                                    WHEN bee_docs_corr.con_sum = 1174
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_new::integer) || '(сверх соц. нормы)'
                                END AS tar_grp_new_lab,     
                                CASE 
                                    WHEN bee_docs_corr.con_sum = 850
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_old::integer)                                        
                                    WHEN bee_docs_corr.con_sum = 1446
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_old::integer) || '(в пределах соц. нормы)'                                   
                                    WHEN bee_docs_corr.con_sum = 1174
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_old::integer) || '(сверх соц. нормы)'
                                END AS tar_grp_new_old,
				bee_docs_corr.quantity_old,
				bee_docs_corr.price_old,
				bee_docs_corr.cost_old,
				bee_docs_corr.quantity_new,
				bee_docs_corr.price_new,
				bee_docs_corr.cost_new,
				bee_docs_corr.diff_kvt,
				bee_docs_corr.diff_sum,
				(SELECT usr FROM deusers WHERE rowid = bee_docs_corr.userid) AS usr,
				bee_docs_corr.rowid AS bdc_rowid,
				bee_docs.rowid AS bd_rowid,
				agreepoint.rowid AS ap_rowid,
				agreement.rowid AS agreeid

				FROM bee_docs_corr

				JOIN agreepoint ON bee_docs_corr.linkid1 = agreepoint.rowid
				JOIN bee_docs ON bee_docs_corr.linkid2 = bee_docs.rowid
				JOIN agreement ON agreepoint.linkid = agreement.rowid
				JOIN customer ON agreement.abo_code = customer.abo_code
				/*2020-04-16 JOIN (SELECT 
					     bee_docs.docnum,bee_docs.docdat,
					     bee_docs.rowid,bee_docs_corr.period,bee_docs_corr.linkid2 --для проверки 
				        FROM
					     bee_docs
					JOIN agreement ON agreement.rowid=bee_docs.linkid   
					JOIN agreepoint ON agreepoint.linkid=agreement.rowid
					JOIN bee_docs_corr  ON bee_docs_corr.linkid1 = agreepoint.rowid 					 
					 
				      WHERE bee_docs_corr.period=bee_docs.docdat  
					 AND bee_docs.doctyp = 1065                     
					 AND bee_docs.linkid=_docs_linkid   -- выбранный договор 
				      GROUP BY bee_docs.docnum, bee_docs.docdat,bee_docs.rowid,bee_docs_corr.period,bee_docs_corr.linkid2 
			        ) AS t1 ON t1.linkid2 = bee_docs_corr.linkid2 */
				
				JOIN (select a.docnum, a.docdat, a.rowid, 
						sum (	case when a.doctyp = 1618
								then bdcorr.quantity_new
								else bdcalc.quantity_amo
								end
							) as sum1, 
							a.linkid2
					 from    (SELECT 
						     bee_docs.docnum,bee_docs.docdat,
						     bee_docs.rowid,bee_docs_corr.period,bee_docs_corr.linkid2, --для проверки 
						      bee_docs.doctyp 
					        FROM
						     bee_docs
						JOIN agreement ON agreement.rowid=bee_docs.linkid   
						JOIN agreepoint ON agreepoint.linkid=agreement.rowid
						JOIN bee_docs_corr  ON bee_docs_corr.linkid1 = agreepoint.rowid 					 					 
					      WHERE bee_docs_corr.period=bee_docs.docdat  
	                     AND bee_docs.doctyp in (1065, 1618)
						 AND bee_docs.linkid= _docs_linkid   -- выбранный договор 
					      GROUP BY bee_docs.docnum, bee_docs.docdat,bee_docs.rowid,bee_docs_corr.period,bee_docs_corr.linkid2 
					      ) as a
			       left join bee_docs_corr as bdcorr on bdcorr.linkid2 = a.rowid 
			       left join bee_docs_calc as bdcalc on bdcalc.linkid1 = a.rowid 
  		          GROUP BY a.docnum, a.docdat,a.rowid, a.linkid2
			        ) AS t1 ON t1.linkid2 = bee_docs_corr.linkid2 and t1.sum1 = (select sum(quantity_old) from  bee_docs_corr where linkid2 = _docid)

				WHERE agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = _locid)) 
				AND bee_docs.docdat = _docdat::DATE
				AND bee_docs.rowid = _docid
				ORDER BY agreement.docnumber,agreepoint.prodnumber, tar_grp_new_lab, bee_docs_corr.linkid1 ASC, bee_docs_corr.period ASC, bee_docs_corr.linkid2 ASC

		)
		LOOP 
		      RETURN NEXT RowLine; 
		END LOOP;		

  END;
$$;

comment on function bee_get_bdc_items(integer, text, integer, integer) is 'Отображение таблицы "результат" в форме "корректировка"';

alter function bee_get_bdc_items(integer, text, integer, integer) owner to pgsql;

