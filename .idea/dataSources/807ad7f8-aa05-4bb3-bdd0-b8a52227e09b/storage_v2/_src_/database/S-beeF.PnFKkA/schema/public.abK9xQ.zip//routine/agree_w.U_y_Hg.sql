create function agree_w(tagid integer, src_port character varying, agreen character varying) returns void
    language plpgsql
as
$$
DECLARE
  /*
   200207 by ito06 
   200117 by ito06
   190209 by ito07
   190118 by ito07 
   180210 by ito07
  */
    src_host VARCHAR;
    HOSTS    VARCHAR[];
    H        VARCHAR;
    Doc      RECORD;
    num      VARCHAR;
    rid      INTEGER;  
    DbN      VARCHAR;
    SqlCmd   VARCHAR = '';
    DocDat   VARCHAR;
    ConnectParams varchar;
    PntShifted  integer;
    OPEN_DATE DATE = '1990-12-31';
BEGIN
    
    PERFORM agree_w_info_save(); 
    --
	/* 2020-01-17 10-00 учитывать закрытый период
    UPDATE bee_closed_period     SET period = OPEN_DATE;
    UPDATE bee_closed_period_dir SET period = OPEN_DATE;
    UPDATE bee_closed_period_mix SET period = OPEN_DATE;
    UPDATE bee_closed_period_uni SET period = OPEN_DATE;
*/
    ALTER TABLE agreepoint         DISABLE TRIGGER agreepoint_audit;
    ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_audit;
    ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_trig;
    ALTER TABLE agreeregdev        DISABLE TRIGGER agreeregdev_audit;
    ALTER TABLE agreeregdev_period DISABLE TRIGGER agreeregdev_period_trig;
    ALTER TABLE agreeregdev_period DISABLE TRIGGER agreeregdev_period_audit;
    ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_trig;
    ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_audit;
    ALTER TABLE regdevconn         DISABLE TRIGGER regdevconn_audit;  
	ALTER TABLE bee_docs_calc      DISABLE TRIGGER bee_docs_calc_trig; -- добавили 2020-02-07
    ALTER TABLE bee_docs_calc      DISABLE TRIGGER bee_docs_calc_audit; --добавили 2020-02-07
	
	
   
    ALTER TABLE bee_docs_calc DROP CONSTRAINT bee_docs_calc_fk3;
    ALTER TABLE bee_docs_calc
      ADD CONSTRAINT bee_docs_calc_fk3 FOREIGN KEY (quantity_id)
      REFERENCES regdevoper (rowid) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE cascade;--RESTRICT;
    -- 

    --*** SCAN HOSTS SELECTED IN bee_closed_info.selected	
    FOR src_host IN (
       SELECT DISTINCT 
             hostname 
       FROM  bee_closed_info 
       WHERE hostname LIKE 'f__apps%' 
       ORDER BY hostname
    )
    LOOP -- HOSTS   
      IF src_host IN ('f66apps0','f66apps1','f66apps2','f66apps3') AND 
       (tagid = 1614 OR tagid = 1535 )
        THEN    H = src_host;
        ELSE IF src_host NOT LIKE 'f66apps%' 
            THEN H = src_host;
         END IF;
      END IF;
      -------       
      EXECUTE 
      'SELECT dbname FROM bee_closed_info WHERE hostname = ''' 
      || H || 
      ''' AND dbstatus = ''U'' AND selected = TRUE ORDER BY hostname LIMIT 1'  
      INTO DbN;
      IF DbN IS NULL THEN CONTINUE; END IF;
      ---
      RAISE NOTICE 'agree_w : host=% : db=%', H,DbN;
      --
      -- H = 'localhost';
      --
      -- traces
      PERFORM agree_x_1(H,DbN,tagid,src_port);
      
      -- SCAN DOCS LOCALY 
      SELECT docnumber, rowid, docdate FROM agreement WHERE docnumber = agreen and docstatus = 79 limit 1
      into num,rid,DocDat;
      ---
      ---------------------------------------------------------------------------------------------------   
      ConnectParams = 
            ' dbname=' || dbN 
         || ' port='   || src_port 
         || ' host='   || H 
         || ' user=postgres ';         
      SqlCmd = 'select agree_x_point_shift('
       || quote_literal(agreen)    || ',' 
       || quote_literal(DocDat)    || ','
       || quote_literal(H)|| ',' 
       || src_port::integer        || ','
       || quote_literal('postgres')|| ','
       || quote_literal('beeX')    || ','
       || tagid                    || ')';
      -- SHIFT POINTS
     -- SELECT  points_done.* FROM dblink(ConnectParams, SqlCmd ) 
	 --AS points_done(count integer) limit 1  INTO PntShifted;
      --RAISE notice '************* shifted : %:%:%:%:%:% ******************',agreen,DocDat,H,src_port,tagid,PntShifted;
      BEGIN
      
      PERFORM agree_x_2_1( DbN,num,rid,tagid,H,src_port);
      PERFORM agree_x_31_1(DbN,num,tagid,H,src_port);
      PERFORM agree_x_32(DbN,num,tagid,H,src_port);
      PERFORM agree_x_33(DbN,num,tagid,H,src_port);
      PERFORM agree_x_34(DbN,num,tagid,H,src_port);
      PERFORM agree_x_35(DbN,num,tagid,H,src_port);
      PERFORM agree_x_36(DbN,num,tagid,H,src_port);
      
      EXCEPTION
          WHEN unique_violation THEN 
             RAISE NOTICE '*** ERR agree_W unique : err %',num;
             CONTINUE;
          WHEN others THEN 
             RAISE NOTICE '*** ERR agree_W other : err %',num;
             CONTINUE;
      END;
      -- 
      UPDATE bee_closed_info SET isload = false where hostname = H;
      -- 	
      ALTER TABLE bee_docs_calc DROP CONSTRAINT bee_docs_calc_fk3;
      ALTER TABLE bee_docs_calc
        ADD CONSTRAINT bee_docs_calc_fk3 FOREIGN KEY (quantity_id)
        REFERENCES regdevoper (rowid) MATCH SIMPLE
        ON UPDATE CASCADE ON DELETE RESTRICT;
      ---
	  
	  ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_audit;
      ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_trig;
	  ALTER TABLE bee_docs_calc      ENABLE TRIGGER bee_docs_calc_trig;
      ALTER TABLE bee_docs_calc      ENABLE TRIGGER bee_docs_calc_audit;   
      ALTER TABLE regdevconn         ENABLE TRIGGER regdevconn_audit;     
      ALTER TABLE agreeregdev_period ENABLE TRIGGER agreeregdev_period_trig;
      ALTER TABLE agreeregdev_period ENABLE TRIGGER agreeregdev_period_audit;
      ALTER TABLE agreeregdev        ENABLE TRIGGER agreeregdev_audit;
      ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_audit;
      ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_trig;
      ALTER TABLE agreepoint         ENABLE TRIGGER agreepoint_audit;     
       
    END LOOP; -- HOSTS

    
	PERFORM agree_w_info_restore();   
    UPDATE bee_closed_info SET isload = false;  
   
END;
$$;

comment on function agree_w(integer, varchar, varchar) is 'Добавление/изменение показаний для точки учета из указанного филиала в базу централизованных/смешнных для указанного договора. Используется в agree_w(int, varchar, varchar), agree_x(varchar, int, varchar)';

alter function agree_w(integer, varchar, varchar) owner to pgsql;

