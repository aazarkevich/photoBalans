create function bee_rep28_get_month_en(amnid integer, strdate date, enddate date) returns SETOF bee_rep28_month
    language sql
as
$$
/*
	add ito06 2019-12-23 (если нет параметра 410 (адрес запитанного объекта*) все равно добавляем точку учета в табл
	ito06 2013-01-18 Приложение 1а
*/
	SELECT 
		(sum(rdo.valman::numeric(13,4))/1000)::numeric(13,4)  AS summ,
		amn.docnumber AS docnumber,
		apn.account AS account,
		--ard3.paramval || ', ' || ard4.paramval AS point, 2019-12-23
		CASE WHEN ard3.paramval IS NULL 
		  THEN 
		    CASE 
			   WHEN  ard4.paramval IS NULL 
			   THEN ' '
			   ELSE ard4.paramval
			END
		  ELSE
		    CASE 
			   WHEN ard4.paramval IS NULL 
			   THEN ard3.paramval
			   ELSE ard3.paramval || ', ' || ard4.paramval
			END		   
		 END 		 AS point, --2019-12-23
		apn.rowid AS id
	FROM  agreement    AS amn
		JOIN agreepoint   AS apn ON amn.rowid = apn.linkid
		JOIN bee_rep_get_ard_per_max(439)  AS ard ON apn.rowid = ard.linkid 
		JOIN agreeregdev AS ard3 ON ard3.linkid=apn.rowid AND ard3.paramid=418 
		-- JOIN agreeregdev AS ard4 ON ard4.linkid=apn.rowid AND ard4.paramid=410 2019-12-23
	LEFT JOIN agreeregdev AS ard4 ON ard4.linkid=apn.rowid AND ard4.paramid=410
		
		LEFT JOIN regdevoper   AS rdo ON apn.rowid = rdo.linkid AND rdo.paramid=850 AND rdo.valman~E'^\\d{1,}' AND rdo.operdate BETWEEN $2 AND $3
	WHERE amn.rowid = $1
	
	GROUP BY docnumber,account,ard3.paramval,ard4.paramval ,id
$$;

comment on function bee_rep28_get_month_en(integer, date, date) is 'Приложение 1а. Используется в bee_rep28_get_en_real(int, date)';

alter function bee_rep28_get_month_en(integer, date, date) owner to postgres;

