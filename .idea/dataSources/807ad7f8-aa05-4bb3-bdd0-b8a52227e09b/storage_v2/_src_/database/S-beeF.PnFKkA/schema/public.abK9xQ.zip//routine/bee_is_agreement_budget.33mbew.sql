create function bee_is_agreement_budget(agreeid integer) returns boolean
    language plpgsql
as
$$
/*
	ito06 2015-12-21 Является ли договор бюджетным.
*/
BEGIN
    RETURN EXISTS (SELECT 1 FROM agreement WHERE rowid  = agreeid AND accdir in (832,835,836,837,838,839,840,841,842));
END;
$$;

comment on function bee_is_agreement_budget(integer) is 'Является ли договор бюджетным. Используется в Agreeregdev.java, OperVal.java, AppUtils.java';

alter function bee_is_agreement_budget(integer) owner to pgsql;

