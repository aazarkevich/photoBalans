create function bee_fill_customer_info(lnk integer) returns void
    language plpgsql
as
$$
DECLARE
   rid integer;
BEGIN
   UPDATE customer_info SET item = '0' WHERE (abo = lnk) AND (item IS NULL);
   ---
   INSERT INTO customer_info 
   (abo,           elrowid,  item) (SELECT 
    lnk, dic_elements.rowid, '0' 
    FROM dic_elements 
    WHERE 
       link = 26 
       AND (rowid NOT IN (SELECT elrowid FROM customer_info WHERE abo = lnk))  
    );       
    END;
--
--
$$;

comment on function bee_fill_customer_info(integer) is 'Используется в Customer.java, AppUtils.java';

alter function bee_fill_customer_info(integer) owner to pgsql;

