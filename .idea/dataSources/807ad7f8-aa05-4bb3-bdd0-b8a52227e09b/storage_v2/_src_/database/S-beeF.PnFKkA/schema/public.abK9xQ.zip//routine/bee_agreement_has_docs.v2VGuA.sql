create function bee_agreement_has_docs(agreeid integer) returns boolean
    language plpgsql
as
$$
DECLARE
BEGIN
  IF EXISTS (SELECT rowid FROM bee_docs WHERE linkid = agreeid)
  THEN RETURN TRUE;
  ELSE RETURN FALSE;
  END IF;
END
$$;

alter function bee_agreement_has_docs(integer) owner to postgres;

