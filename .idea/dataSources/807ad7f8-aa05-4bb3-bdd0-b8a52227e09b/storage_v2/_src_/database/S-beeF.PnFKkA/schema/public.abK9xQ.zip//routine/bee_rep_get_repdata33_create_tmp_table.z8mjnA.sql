create function bee_rep_get_repdata33_create_tmp_table(loc_id integer, d_start date, filt character varying) returns integer
    language plpgsql
as
$$
/*
	ito06 2016-04-26 Сводный журнал задолжненников (репс), создает временную таблицу.
*/
	
BEGIN
	EXECUTE 
	 'create TEMPORARY table bee_rep_get_repdata33_tmp AS
	 SELECT U.*
	   FROM	(      (SELECT * FROM bee_rep_get_repdata33_tmpUr('||$1||','''||$2||'''))
                 union (SELECT * FROM bee_rep_get_repdata33_tmpMix('||$1||','''||$2||'''))  
                 union (SELECT * FROM bee_rep_get_repdata33_tmpUni('||$1||','''||$2||'''))                                
                ) AS U '||$3||';';
	RETURN 0;
END;
$$;

comment on function bee_rep_get_repdata33_create_tmp_table(integer, date, varchar) is 'Сводный журнал задолжненников (репс). Используется в bee_rep_get_repdata33_all(int, date, date, boolean, boolean, boolean, varchar)';

alter function bee_rep_get_repdata33_create_tmp_table(integer, date, varchar) owner to postgres;

