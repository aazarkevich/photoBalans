create function bee_docs_loss_delete(agreeid integer, docid integer) returns integer
    language plpgsql
as
$$
DECLARE
   NR INTEGER = - 1;
BEGIN
      BEGIN
            DELETE FROM bee_docs where rowid = docid and linkid = agreeid RETURNING rowid INTO NR;
            IF NR IS NULL  
               THEN NR =-2;
            END IF;
       
     EXCEPTION
            WHEN UNIQUE_VIOLATION THEN
            RETURN NR = -1;
   END;
RETURN NR;
END;
$$;

comment on function bee_docs_loss_delete(integer, integer) is 'Удаление нагрузочных потерь . Используется в LossRSK.java, AppUtils.java';

alter function bee_docs_loss_delete(integer, integer) owner to pgsql;

