create function bee_recalc(lid integer, per character varying) returns void
    language plpgsql
as
$$
DECLARE
  Rec RECORD;
BEGIN
   --
   -- ПЕРЕРАСЧЁТ (per  (% YYYY-% итд))
   -- цикл по устройствам 
   --
   FOR Rec IN (
      SELECT 
         regdevoper.linkid   AS pid, 
         regdevoper.operdate AS opdat,
         regdevoper.valman   AS val 
      FROM agreepoint
         LEFT JOIN agreement  ON agreepoint.linkid = agreement.rowid
         LEFT JOIN regdevoper ON agreepoint.rowid  = regdevoper.linkid
      WHERE 
         agreement.locid        = lid AND
         regdevoper.operdate::text LIKE per AND
         regdevoper.paramid     = 195 AND
         regdevoper.valman      ~ E'^\\d'
   )
   LOOP
      IF ((Rec.pid IS NOT NULL) AND (Rec.opdat IS NOT NULL) AND (Rec.val IS NOT NULL)) THEN
	PERFORM  bee_add_regdevoper_registered(Rec.pid,Rec.opdat,Rec.val); 
      END IF;
   END LOOP;
   --
END;
$$;

alter function bee_recalc(integer, varchar) owner to pgsql;

