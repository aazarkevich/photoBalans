create function bee_has_point_tarif(_agrid integer, _pointid integer, _period character varying) returns boolean
    language plpgsql
as
$$
/*
 agreeregdev_period :
 linkid - agreepoint.rowid
 439  - уровень напряжения
 1535 - номер центролизованного договора
      - period 
*/
declare
  hasTarif  boolean = false;
BEGIN
    -- центр
    hasTarif =  
       EXISTS(SELECT 1 
              FROM agreeregdev_period  AS arp
	      JOIN agreepoint          AS apn ON apn.rowid   = arp.linkid
	      JOIN agreement           As amn ON amn.rowid   = apn.linkid
	      join agreepoint_tarif    as apt on apt.pointid = apn.rowid  
	      join dic_tarif_group     as dtg on apt.tarifid = dtg.rowid  
	     where
	       amn.rowid       = _agrid
	       and amn.docstatus = 79
	       and apn.rowid   = _pointid 
	       AND arp.paramid = 1535
	       and arp.period  = _period::date
	       AND arp.paramval IS NOT NULL 
	       AND arp.paramval IS DISTINCT FROM '0'
	       AND arp.paramval IS DISTINCT FROM '-'
	       
	     );
   RETURN hasTarif;

END;
$$;

alter function bee_has_point_tarif(integer, integer, varchar) owner to postgres;

