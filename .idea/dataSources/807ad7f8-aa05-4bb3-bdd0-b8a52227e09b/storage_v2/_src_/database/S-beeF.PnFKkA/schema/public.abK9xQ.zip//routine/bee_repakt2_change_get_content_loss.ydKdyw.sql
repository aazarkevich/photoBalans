create function bee_repakt2_change_get_content_loss(br_rowid integer, _doctyp integer) returns SETOF bee_repakt2_tab1
    language plpgsql
as
$$
/*
	add ito06 2015-12-10  добавили входной параметр _doctyp
	ito06 2015-07-09: Акт (соц. норма) для исправления или корректировки
*/
DECLARE _tartyp text = '0';
	
BEGIN 
	IF _doctyp  = 1 
           THEN	--исправление
		_tartyp = '1707,1142';
	   ELSIF _doctyp  = 2
	      THEN 	
		--корректировка 
		_tartyp = '1069,1159';           		
        END IF;
        RETURN QUERY EXECUTE('
	select 
		bdr.docdat,
		null::numeric as vn_amount_fsk,
		null::numeric as vn_amount_rsk,
		null::numeric as vn_sum_fsk,
		null::numeric as vn_sum_rsk,

		null::numeric as sn1_amount_fsk,
		null::numeric as sn1_amount_rsk,
		null::numeric as sn1_sum_fsk,
		null::numeric as sn1_sum_rsk,
		
		null::numeric as sn2_amount_fsk,
		null::numeric as sn2_amount_rsk,
		null::numeric as sn2_sum_fsk,
		null::numeric as sn2_sum_rsk,
		
		null::numeric as nn_amount_fsk,
		null::numeric as nn_amount_rsk,
		null::numeric as nn_sum_fsk,
		null::numeric as nn_sum_rsk,

		(select a[1] from bee_repakt2_change_get_tmp_loss('||$1||',1731, '''||_tartyp||''') AS a) as tot_amount_fsk,
		(select a[1] from bee_repakt2_change_get_tmp_loss('||$1||',1732, '''||_tartyp||''') AS a) as tot_amount_rsk,
		-(select a[2] from bee_repakt2_change_get_tmp_loss('||$1||',1731, '''||_tartyp||''') AS a) as tot_sum_fsk,
		-(select a[2] from bee_repakt2_change_get_tmp_loss('||$1||',1732, '''||_tartyp||''') AS a) as tot_sum_rsk,
		(select a[3] from bee_repakt2_change_get_tmp_loss('||$1||',1731, '''||_tartyp||''') AS a) as prise

	   FROM (select distinct bd.docdat As docdat
		   from  bee_docs_result AS bdr 
		   join bee_docs As bd ON bdr.linkid = bd.rowid
		  where bdr.linkid = '||$1||' AND tar_grp IS NULL AND tar_typ = 1734 ) AS bdr');
END;
$$;

comment on function bee_repakt2_change_get_content_loss(integer, integer) is 'Акт (соц. норма) для исправления или корректировки. Используется в repakt2_change.java; bee_repakt2_change_get_tot_loss(int,boolean, int)';

alter function bee_repakt2_change_get_content_loss(integer, integer) owner to pgsql;

