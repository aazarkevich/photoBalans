create function bee_is_point_type_4(pointid integer, per date) returns boolean
    language plpgsql
as
$$
BEGIN
   RETURN EXISTS (
      SELECT 1 FROM agreepoint a 
         JOIN  agreeregdev b ON a.rowid = b.linkid
      WHERE 
         a.rowid = pointid
         AND (b.paramid = 189 AND b.paramval = '432')
         AND EXISTS(SELECT 1 FROM agreeregdev  
                    WHERE linkid = pointid 
                       AND paramid = 1655 AND  paramval = '1658'
             )
         AND EXISTS(SELECT 1 FROM agreeregdev_period  
                    WHERE  linkid = pointid 
                       AND paramid = 664  
                       AND paramval IS NOT NULL
                       AND length(paramval) > 0
                       AND paramval IN (SELECT rowid::text FROM agreepoint) 
                       AND period <= per
                    ORDER BY period DESC
            )         
      );
   END;
$$;

comment on function bee_is_point_type_4(integer, date) is 'Используется в LossDistr.java, AppUtils.java';

alter function bee_is_point_type_4(integer, date) owner to pgsql;

