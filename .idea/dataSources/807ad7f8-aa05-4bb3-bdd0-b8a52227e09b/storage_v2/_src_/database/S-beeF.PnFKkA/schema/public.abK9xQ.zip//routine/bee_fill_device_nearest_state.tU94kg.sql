create function bee_fill_device_nearest_state(_locid integer, curdat character varying, usr character varying) returns character varying
    language plpgsql
as
$$
    --ito07, add ito06 2012-05-03
-- СБОР ПОСЛЕДНИХ ПОКАЗАНИЙ ПО СЧЁТЧИКАМ
-- ГРУППОВОЙ ПЕРЕРАСЧЁТ ПО МОЩНОСТИ
DECLARE
--
   Rec      RECORD; 
   DevI     INTEGER; -- код устройства
   AWorkOff INTEGER; -- работа в выходные дни (430- прис  431-отс )
                     -- argreeregdev.paramid=689 
   ADate     DATE    := curdat::date; -- приведение значения
   ACalcDays INTEGER := 0;      -- дней в расчётном периоде
   AOffDays  INTEGER := 0;      -- нерабочих дней в расчётном периоде
   APower    NUMERIC := 0;      -- разрешённая мощность
   AHours    NUMERIC := 0;      -- кол-во часов работы в сутках
   EPAmount  NUMERIC := 0;      -- (APower * AHours)
   IDList    VARCHAR = '';      -- список обработанных

   PrevSum    DOUBLE PRECISION :=0;
   PointIDX   INTEGER := 0;
   XraceID    INTEGER := 0; --  трассы
   XracePath  VARCHAR ;     -- путь трассы 
   DeviceID   INTEGER := 0;
   DeviceNam  VARCHAR;
   ProdNum    VARCHAR ;
   AccNum     VARCHAR ;
   AgreeID    INTEGER := 0;
   AgreeNum   VARCHAR ;
   CustID     INTEGER := 0;
   CustName   VARCHAR ;
   TmpVal     VARCHAR ;
   -- agreeregdev
   FeededObj  VARCHAR;
   FeededAdr  VARCHAR;
   FeededDatIns VARCHAR;
   FeededDatChk VARCHAR;
   FeededDatDes VARCHAR;
   FeededActNum VARCHAR;  
   FeededModem INTEGER :=0; 
   FeededModemTyp VARCHAR;  
--   
BEGIN  
   --   
   DELETE FROM bee_rep_oper_registration 
   WHERE 
      locid   = _locid AND 
      userid  = usr AND 
      substring(period from '....-..') = substring(curdat from '....-..');
   --
   IDList = '';
   --
   -- перебор ближайших к дате curdat записей
   --
   FOR Rec IN (
      -->-- 
      SELECT 
         regdevoper.linkid,
         regdevoper.operdate 
      FROM regdevoper
         LEFT JOIN agreepoint on regdevoper.linkid = agreepoint.rowid --  
         LEFT JOIN agreement  on agreepoint.linkid = agreement.rowid  --
         LEFT JOIN customer   on agreement.abo_code = customer.abo_code  --
      WHERE
         agreement.locid  = _locid AND  -- код участка (РЭС МЭС)
         regdevoper.operdate <= curdat::date AND
         paramid = 193          AND  -- вид расчёта
         valman IS NOT NULL     AND 
         valman ~ E'\\d{1,}'    AND
         valman = '435'              -- код расчёта по показаниям
      ORDER BY operdate DESC
      --<-- 
   ) LOOP 
    -- только ближайшие  
     CONTINUE WHEN position('{' || Rec.linkid || ':' in IDList) > 0 ;
     -- запомнить новые
     IDList = IDList || '{' || Rec.linkid || ':' || Rec.operdate || '}';
     --RAISE NOTICE '*** % = %',Rec.linkid,Rec.operdate ;
     TmpVal = (SELECT valman FROM regdevoper 
              WHERE 
                 linkid   = Rec.linkid   AND 
                 operdate = Rec.operdate AND 
                 paramid  = 195 
              LIMIT 1 
     );
     -- проверка (слабая) на цифру 
     CONTINUE WHEN TmpVal !~ E'\\d{1,}';
     --
     PrevSum  := TmpVal::double precision;
     PointIDX := Rec.linkid;
     -- 
     XraceID   := (SELECT traceid       FROM regdevconn  WHERE locid = _locid AND pointid = PointIDX  LIMIT 1);
     IF XraceID IS NULL THEN
        XraceID   := 0;
        XracePath =  '-';
     ELSE
        XracePath := (SELECT pchain        FROM gis_traces  WHERE rowid = XraceID);
     END IF;   
     --
     DeviceID  := (SELECT devid         FROM agreepoint   WHERE rowid = PointIDX  LIMIT 1);
     DeviceNam := (SELECT element_name  FROM dic_elements WHERE rowid = DeviceID LIMIT 1);

     FeededObj    := (SELECT paramval   FROM agreeregdev  WHERE linkid = PointIDX AND paramid = 418 LIMIT 1);

     FeededAdr    := (SELECT paramval   FROM agreeregdev  WHERE linkid = PointIDX AND paramid = 410 LIMIT 1);
     
     FeededDatIns := (SELECT paramval   FROM agreeregdev  WHERE linkid = PointIDX AND paramid = 154 LIMIT 1);
     FeededDatIns := substring(FeededDatIns,1,10);
     FeededDatChk := (SELECT paramval   FROM agreeregdev  WHERE linkid = PointIDX AND paramid = 824 LIMIT 1);
     FeededDatChk := substring(FeededDatChk,1,10);
     FeededDatDes := (SELECT paramval   FROM agreeregdev  WHERE linkid = PointIDX AND paramid = 690 LIMIT 1);
     FeededDatDes := substring(FeededDatDes,1,10);
     
     FeededActNum := (SELECT paramval   FROM agreeregdev  WHERE linkid = PointIDX AND paramid = 637 LIMIT 1);  

     FeededModem   := (SELECT paramval   FROM agreeregdev  WHERE linkid = PointIDX AND paramid = 1641 LIMIT 1);
     FeededModemTyp := (SELECT element_name  FROM dic_elements WHERE rowid = FeededModem LIMIT 1);
     --IF FeededModemTyp IS NULL THEN FeededModemTyp := '-'; END IF;
     
     ProdNum  := (SELECT prodnumber FROM agreepoint   WHERE rowid    = PointIDX LIMIT 1);
     AccNum   := (SELECT account    FROM agreepoint   WHERE rowid    = PointIDX LIMIT 1);     
     AgreeID  := (SELECT linkid     FROM agreepoint   WHERE rowid    = PointIDX LIMIT 1);
     AgreeNum := (SELECT docnumber  FROM agreement    WHERE rowid    = AgreeID LIMIT 1);
     CustID   := (SELECT abo_code   FROM agreement    WHERE rowid    = AgreeID LIMIT 1);
     CustName := (SELECT abo_name   FROM customer     WHERE abo_code = CustID  LIMIT 1);


     INSERT INTO bee_rep_oper_registration
     (
      locid, userid, period, 
      agrid, docnumber, abo_code, abo_name, account, prodnumber, devid,    devname,   
      feeded_pathid,feeded_path,feeded_object, feeded_object_address, 
      feeded_obj_dat_ins, feeded_obj_dat_chk, feeded_obj_dat_des, feeded_obj_act_num,
      registration_date_prev, registration_value_prev, feeded_modem_typ
     ) 
     VALUES
     ( _locid, usr, curdat, 
       AgreeID , AgreeNum, CustID, CustName, AccNum, ProdNum, DeviceID, DeviceNam, 
       XraceID,XracePath,FeededObj, FeededAdr,
       FeededDatIns, FeededDatChk, FeededDatDes, FeededActNum,
       Rec.operdate, PrevSum,FeededModemTyp
     );
     
   END LOOP;
   --    
RETURN '';--IDList; 

END;
$$;

alter function bee_fill_device_nearest_state(integer, varchar, varchar) owner to pgsql;

