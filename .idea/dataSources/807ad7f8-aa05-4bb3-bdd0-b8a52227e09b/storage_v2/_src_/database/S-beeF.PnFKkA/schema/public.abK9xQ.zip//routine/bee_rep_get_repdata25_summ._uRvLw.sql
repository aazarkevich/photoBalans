create function bee_rep_get_repdata25_summ(loc_id integer, start_d date, end_d date, pp integer) returns SETOF bee_repdata25_summ
    language plpgsql
as
$$
/*
        ito07 2016-11-11 " (and d_start_sum > 0 or k_start_sum > 0) -> (and d_start_sum >= 0 or k_start_sum >= 0)"
	ito07 2016-11-10 "and  d_start_sum > 0" -> "(and d_start_sum > 0 or k_start_sum > 0)"
        add ito06 2015-09-30 Изменили названия колонок для  разделителя
	add ito06 2015-06-23
	add ito06 2014-06-30
	add ito06 2013-10-22
	add ito06 2012-10-02
	ito06 2011-07-21:Реализация эл эн	 
*/
DECLARE RowLine bee_repdata25_summ%rowtype;
BEGIN
     
 FOR RowLine IN (
         SELECT sum(d_start_sum) 		AS d_start_sum, 
		sum(k_start_sum) 		AS k_start_sum,
		sum(amount)			AS amount,
		sum(amount1)  			AS amount1,
		sum(amount2) 			AS amount2,
		 
		sum(round(sum_with_tax,2))  		AS sum_with_tax,
		sum(sum_no_tax) 		AS sum_no_tax,
		sum(round(sum_with_tax1068,2)) 		AS sum_with_tax1068, 
		sum(sum_no_tax1068) 		AS sum_no_tax1068,
		sum(round(sum_with_tax1069,2)) 		AS sum_with_tax1069,
		sum(sum_no_tax1069) 		AS sum_no_tax1069,

		null::numeric (12,6)		AS tar,
		sum(fact_all_sum) 		AS fact_all_sum,
		
		sum(payed_sum) 			AS payed_sum,
                sum(retrest_sum) 		AS retrest_sum,
		sum(disc_sum) 			AS disc_sum,
		sum(d_end_sum) 			AS d_end_sum,
		sum(k_end_sum) 			AS k_end_sum,
		sum(round(pay_all_sum,2)) 		AS pay_all_sum,
                sum(round(fact_adv_sum,2)) 		AS fact_adv_sum,
		sum(round(ext_sum,2)) 			AS ext_sum		

	FROM bee_rep_get_repdata25_tmp  AS row
	
        WHERE ((accdir NOT IN ( 835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND pp = 10)	-- прочие потребители 
		OR (accdir IN ( 835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND pp = 20)	-- бюджетные потребиели
		OR (accdir = 835					          AND pp = 21)	-- федеральный бюджет 
		OR (accdir = 836                                                  AND pp = 22)	-- областной бюджет
		OR (accdir IN (832, 837, 838, 839, 840, 841, 842,1623)            AND pp = 23)	-- местный бюджет
		OR (accdir IN (832, 837, 838, 839, 840, 841, 842)                 AND pp = 231)	-- юр. лица
		OR (accdir = 1623                                                 AND pp = 232)	-- уличное освещение
		OR (pp=0))                                                                      -- ВСЕГО
	   AND (npp=1)
           -- 161110 by ito07 --and  d_start_sum > 0    
           -- AND  (d_start_sum > 0 or k_start_sum > 0 )  
           AND  (d_start_sum >= 0 or k_start_sum >= 0 )  
	   )
        LOOP              
           IF RowLine.amount <> 0 
           THEN RowLine.tar = RowLine.sum_with_tax / RowLine.amount;
           END IF;
	   RETURN  NEXT RowLine;
	END LOOP;	
END;

$$;

comment on function bee_rep_get_repdata25_summ(integer, date, date, integer) is 'Реализация эл эн. Используется в bee_rep_get_repdata25(int, date, date), bee_rep_get_repdata25_all(int, date, date)';

alter function bee_rep_get_repdata25_summ(integer, date, date, integer) owner to pgsql;

