create function bee_rep_get_dats_for13(str_date date, end_date date) returns bee_rep_dats_tab
    cost 1000
    language plpgsql
as
$$
DECLARE
   dats date[][] ='{{null,null},{null,null},{null,null},{null,null},{null,null},{null,null},'||
                   '{null,null},{null,null},{null,null},{null,null},{null,null},{null,null},{null,null}}';
   tmp_date1 date;
   tmp_date2 date;
   start_date date=(to_char(str_date,'YYYY-MM') || '-01')::date;
   end_dat date=(to_char(end_date,'YYYY-MM') || '-01')::date + '1 month'::interval - '1 day'::interval;
   result bee_rep_dats_tab%ROWTYPE;
   n integer;
 BEGIN
   FOR i IN 1..12 LOOP
     tmp_date1 = start_date + ((i-1) || ' month')::interval;
     tmp_date2 = tmp_date1 + '1 month'::interval - '1 day'::interval;
     IF tmp_date2<=end_dat
       THEN
         dats[i][1] = tmp_date1;
         dats[i][2] = tmp_date2;
         n=i;
       ELSE
         EXIT;
     END IF;
   END LOOP;
   result.dats=dats;
   result.dat_not_null=n;   
   RETURN result;
 END;
$$;

comment on function bee_rep_get_dats_for13(date, date) is 'Используется в bee_rep21_get_rdo(int, date, date, int), bee_rep21_get_rdo975(int, date, date, int), bee_rep21_get_rdo977(int, date, date, int), bee_rep21_get_rdo977_mid_nat(date, date, int), bee_rep21_get_rdo_contr(int, date, date, int), bee_rep21_get_rdo_contr2(int, date, date, int), bee_rep21_get_rdo_mid_nat(int, date, date, int), bee_rep_get_repdata21_leg(int, date, date, boolean, boolean)';

alter function bee_rep_get_dats_for13(date, date) owner to pgsql;

