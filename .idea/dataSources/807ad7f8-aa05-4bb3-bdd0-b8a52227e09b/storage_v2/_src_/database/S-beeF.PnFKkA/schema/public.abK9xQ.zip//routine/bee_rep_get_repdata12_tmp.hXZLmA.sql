create function bee_rep_get_repdata12_tmp(loc integer, strdat date, enddat date) returns SETOF bee_rep_tab12_new
    cost 1000
    language plpgsql
as
$$
/* 
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	ito16 10.12.09 Движение остатков по потребителю.
*/
DECLARE
	dats dats_per_tab%ROWTYPE ;
	amn_rowid bee_rep_tab12_tmp%ROWTYPE;
	doc_row bee_rep_tab12%ROWTYPE;
	result bee_rep_tab12_new%ROWTYPE;
	is_first_month boolean;
BEGIN
   FOR amn_rowid IN 
    (SELECT 
       amn.rowid
     FROM 
       agreement AS amn 
       JOIN customer AS cst ON cst.abo_code = amn.abo_code 
       JOIN dic_elements AS dic ON dic.rowid = amn.accdir 
     WHERE 
        amn.locid = loc AND 
         amn.doctype = 1910) --** 2016-04-25 
   LOOP
      is_first_month = true;
      FOR dats IN (SELECT * FROM bee_rep_get_dats_per(strdat,enddat))
      LOOP
         IF is_first_month
            THEN
               EXECUTE 'SELECT * FROM bee_rep_get_repdata12_for_doc('|| loc ||','||amn_rowid.amn_rowid||','||quote_literal(dats.start_d)||', '||quote_literal(dats.end_d)||')' INTO doc_row;
               is_first_month = false;
            ELSE
               EXECUTE 'SELECT * FROM bee_rep_get_repdata12_for_doc1('|| loc ||','||amn_rowid.amn_rowid||','||quote_literal(dats.start_d)||', '||quote_literal(dats.end_d)||')' INTO doc_row;
         END IF;
         IF 
          (doc_row.sd IS NOT NULL OR doc_row.sd = 0) AND
          (doc_row.sk IS NOT NULL OR doc_row.sk = 0) AND
          (doc_row.od IS NOT NULL OR doc_row.od = 0) AND
          (doc_row.ok IS NOT NULL OR doc_row.ok = 0) AND
          (doc_row.fd IS NOT NULL OR doc_row.fd = 0) AND
          (doc_row.fk IS NOT NULL OR doc_row.fk = 0) 
            THEN
               result.month_quantity = amn_rowid.amn_rowid;
               result.docnum = doc_row.docnum;
               result.nam = doc_row.nam;
               result.grp = doc_row.grp;
               result.month = TO_CHAR(dats.start_d,'MM.YYYY');
               result.sd = doc_row.sd;
               result.sk = doc_row.sk;
               result.od = doc_row.od;
               result.ok = doc_row.ok;
               result.fd = doc_row.fd;
               result.fk = doc_row.fk;
               RETURN NEXT result;
         END IF;
      END LOOP;
   END LOOP;
 END;
$$;

comment on function bee_rep_get_repdata12_tmp(integer, date, date) is 'Движение остатков по потребителю. Используется в bee_rep_get_repdata12(int, date, date)';

alter function bee_rep_get_repdata12_tmp(integer, date, date) owner to pgsql;

