create function bee_get_points_consum_t(_period text, _lid integer) returns SETOF points_consum_t
    language plpgsql
as
$$
/*
	add ito06 2016-03-02 добавили тип договора (doctype вместо transmit)
	ito06 2014-11-27
	Отображение таблицы "Приложение 1: Плановые величины"
*/
DECLARE
	_year VARCHAR = date_part('year', (_period::date)::TIMESTAMP);
	RowLine points_consum_t%rowtype;
---  
BEGIN
---  
  FOR RowLine IN (SELECT      cust.consum_name,
			      amn.docnumber,   
			      bpct.period,			      
			      (select element_name from dic_elements where rowid = dtg.voltage_level) as plevel,
			      dtg.name AS tarif_name,
			      bpct.m01,
			      bpct.m02,
			      bpct.m03,
			      bpct.m04,
			      bpct.m05,
			      bpct.m06,
			      bpct.m07,
			      bpct.m08,
			      bpct.m09,
			      bpct.m10,
			      bpct.m11,
			      bpct.m12,
			      bpct.rowid
		         FROM agreement  AS amn
			   join customer AS cust on amn.abo_code = cust.abo_code
			   join bee_points_consum_t AS bpct on amn.rowid = bpct.linkid	
			   join dic_tarif_group As dtg on bpct.tarif = dtg.rowid 
			  where amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = _lid)) 		
			    and bpct.consumid = 1161
			    and bpct.period = _period::date			  
			    --2016-03-02 and amn.transmit = TRUE
			    AND amn.doctype in (1910, 1911) --** 2016-03-02
			  order by docnumber, plevel, bpct.tarif)
  LOOP
     RETURN NEXT RowLine; 
  END LOOP;

RETURN;

END;

$$;

comment on function bee_get_points_consum_t(text, integer) is 'Используется в AgreementParams.java, SessionBean.java';

alter function bee_get_points_consum_t(text, integer) owner to pgsql;

