create function agree_x_point_shift(agr_num character varying, agr_date date, host character varying, port integer, usr character varying, dbn character varying, tagid integer) returns integer
    language plpgsql
as
$$
DECLARE
   HX            varchar;
   ConnectParams VARCHAR; 
   SqlCmd        VARCHAR;
   --
   k         integer;
   Pnt       Record;
   MaxRid    INTEGER;
   ExtAgrNum varchar;
   ExtPntRid INTEGER;
   CurDbName varchar;
   NewRid    integer;
BEGIN

   SELECT current_database() limit 1 into CurDbName;
   --raise notice '+++ 0 : % : % : % : % : % ',CurDbName, agr_num, agr_date, host,dbn;  

   ALTER TABLE agreepoint         DISABLE TRIGGER agreepoint_audit;
   ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_audit;
   ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_trig;

   ALTER TABLE agreeregdev        DISABLE TRIGGER agreeregdev_audit;

   ALTER TABLE agreeregdev_period DISABLE TRIGGER agreeregdev_period_trig;
   ALTER TABLE agreeregdev_period DISABLE TRIGGER agreeregdev_period_audit;

   ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_trig;
   ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_audit;
 
   ALTER TABLE regdevconn         DISABLE TRIGGER regdevconn_audit;

   ALTER TABLE bee_docs_calc      DISABLE TRIGGER bee_docs_calc_trig;
   ALTER TABLE bee_docs_calc      DISABLE TRIGGER bee_docs_calc_audit;

     IF host LIKE 'f66apps%' THEN    
            HX = 'f66apps0';
        ELSE IF host NOT LIKE 'f66apps%' THEN 
            HX = host;
         END IF;
     END IF;

   
   ConnectParams = 'dbname=' || dbn || ' port='|| port ||' host=' || HX || ' user=' || usr;
   SqlCmd = 'SELECT docnumber::varchar from agreement where docnumber = ' || quote_literal(agr_num) || ' limit 1;';	
   SELECT  agr.* FROM dblink(ConnectParams, SqlCmd ) AS agr(docnumber varchar) limit 1 into ExtAgrNum;

   --raise notice '+++ 1 : % : % : %',host,dbn,ExtAgrNum;  

   if ExtAgrNum is null then
       raise notice '+++ NO AGREEMENT IN REMOTE MIX : %',agr_num;
       return 0;
   end if;
   ---------------------------------------------
   select max(rowid) from agreepoint into MaxRid; 
   k = 0;
   for Pnt in (
      select  
         agreepoint.rowid as cntid,
         max(agreeregdev_period.period) as maxper,
         agreeregdev_period.paramval as ext_num
      from agreeregdev_period
         join agreepoint  on agreeregdev_period.linkid = agreepoint.rowid
         join agreeregdev on agreeregdev.linkid        = agreepoint.rowid
         join agreement   on agreepoint.linkid         = agreement.rowid
      where
         agreeregdev_period.paramid  = tagid    and
         agreeregdev_period.paramval = agr_num  and -- '90000777/19'
         agreeregdev_period.period   >= agr_date    -- '2019-01-01'
      group by 
         agreepoint.rowid , 
         agreeregdev_period.period ,
         agreeregdev_period.paramval
      order by 
         agreepoint.rowid desc,
         agreeregdev_period.period desc
   )
   LOOP
      --raise notice '+++ 2 : %','!!!';    
      SqlCmd = '
         SELECT agreepoint.rowid::INTEGER 
         FROM   agreepoint 
         JOIN   agreement ON agreepoint.linkid = agreement.rowid
         WHERE 
            agreement.docnumber = ' || quote_literal(agr_num) ||' AND 
            agreement.docstatus = 79 AND
            agreepoint.rowid    = ' || Pnt.cntid || ' LIMIT 1';	 
       SELECT  points.* FROM dblink(ConnectParams, SqlCmd ) AS points(rowid integer) limit 1 
       into ExtPntRid;

      if ExtPntRid IS not NULL then
         --raise notice '+++ 3 : Exists : % : % : % : % : % : %', 
         --k, Pnt.cntid, Pnt.maxper, ExtAgrNum,ExtPntRid, Pnt.ext_num;
         continue;
      else
         k = k + 1;         
         NewRid = MaxRid + k;
         perform  setval('agreepoint_rowid_seq',max(NewRid)) from agreepoint;

         update agreepoint         set rowid   = NewRid where  agreepoint.rowid          = Pnt.cntid;
         update regdevconn         set pointid = NewRid where  regdevconn.pointid        = Pnt.cntid;
         update agreepoint_tarif   set pointid = NewRid where  agreepoint_tarif.pointid  = Pnt.cntid;
         update agreeregdev        set linkid  = NewRid where  agreeregdev.linkid        = Pnt.cntid;
         
         -- header point reference
         update agreeregdev_period set paramval = NewRid::varchar 
            where 
                paramid = 664 and 
                paramval = Pnt.cntid::varchar and 
                period = (select max(period) from agreeregdev_period where linkid = Pnt.cntid limit 1);
         --
         update agreeregdev_period set linkid  = NewRid where  agreeregdev_period.linkid = Pnt.cntid; 

         update regdevoper         set linkid  = NewRid where  regdevoper.linkid         = Pnt.cntid; 
         --perform  setval('agreepoint_rowid_seq',max(NewRid + k)) from agreepoint   ;        
         --          
         --raise notice '+++ 4: SHIFT FROM % TO --> %',Pnt.cntid,MaxRid + k;
         
      end if; 
   END LOOP;
   
   select max(rowid) from agreepoint into MaxRid; 
   perform setval('agreepoint_rowid_seq',MaxRid) from agreepoint; 


   ALTER TABLE bee_docs_calc      ENABLE TRIGGER bee_docs_calc_trig;
   ALTER TABLE bee_docs_calc      ENABLE TRIGGER bee_docs_calc_audit;
   
   ALTER TABLE regdevconn         ENABLE TRIGGER regdevconn_audit;
 
   ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_audit;
   ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_trig;

   ALTER TABLE agreeregdev_period ENABLE TRIGGER agreeregdev_period_trig;
   ALTER TABLE agreeregdev_period ENABLE TRIGGER agreeregdev_period_audit;

   ALTER TABLE agreeregdev        ENABLE TRIGGER agreeregdev_audit;

   ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_audit;
   ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_trig;

   ALTER TABLE agreepoint         ENABLE TRIGGER agreepoint_audit;

   return k;
   
END;
$$;

alter function agree_x_point_shift(varchar, date, varchar, integer, varchar, varchar, integer) owner to pgsql;

