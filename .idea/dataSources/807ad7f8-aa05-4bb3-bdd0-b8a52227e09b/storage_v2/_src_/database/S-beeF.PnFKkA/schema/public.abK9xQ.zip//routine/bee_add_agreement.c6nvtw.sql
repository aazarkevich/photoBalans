create function bee_add_agreement(lid integer, tag boolean, docstat integer, docnum character varying, docdat character varying, accd integer, aboco integer, closedat character varying, doctyp integer) returns integer
    language plpgsql
as
$$
/*
   ito07 2018-11-27 abivid
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2016-03-02 добавили новый параметр doctyp
	ito06  2015-06-30 Добавление нового договора
*/
DECLARE
	rid    int := 0;
   abovi  INT := -1;
BEGIN	
   SELECT abo_vid from customer where abo_code = aboco limit 1 into abovi;
	INSERT INTO agreement 
		(locid,valid, docstatus, docnumber, docdate,      abo_code, accdir, closedate,      doctype, abo_vid) VALUES
		(lid,  tag,   docstat,   docnum,    docdat::date, aboco,    accd,   closedat::date, doctyp,  abovi) RETURNING rowid INTO rid ;
	IF rid IS NULL THEN rid := -2; END IF;
	
	RETURN rid;

END;
$$;

comment on function bee_add_agreement(integer, boolean, integer, varchar, varchar, integer, integer, varchar, integer) is 'Добавление нового договора. Используется CustomerForm.java, AppUtils.java';

alter function bee_add_agreement(integer, boolean, integer, varchar, varchar, integer, integer, varchar, integer) owner to pgsql;

