create function bee_iskraemeco_get_devload_list_tmp_new(_prodnum character varying)
    returns TABLE(pointid integer, prodnum character varying, devid integer, amnid integer, docnumber character varying, src integer, db_tag character varying, is_corrmark boolean, is_working boolean, is_currdog boolean)
    language plpgsql
as
$$
/*
	ito06 2015-11-13 Получить список счетчиков подходящих для загрузки из других источников для текущей базы
*/
DECLARE
	rec       RECORD;
BEGIN		
	FOR rec IN (select devids, rowid from bee_external_sql)
	LOOP
		 RETURN QUERY EXECUTE ('
		 SELECT DISTINCT 
			apn.rowid 										AS pointid,
			apn.prodnumber 										AS prodnum,			
			apn.devid 										AS devid,
			amn.rowid 										AS amnid, 
			amn.docnumber										AS docnumber,	
			CASE WHEN (apn.devid IN ('||rec.devids||'))
			THEN '||rec.rowid||'		
			ELSE 0
			END											AS src, 
			
			(select * from ltrim( (select * from current_database()), '''||'bee'||'''))::varchar	AS db_tag,
		 		
			false 											AS is_corrmark,
			case when (ard.paramval IS NULL OR ard.paramval NOT LIKE ''____-__-__'')
			   then true
			   else false
			end											AS is_working,
			case when (amn.docstatus = 79 )
			   then true
			   else false
			end											AS is_currdog
		   FROM agreepoint AS apn           
	      LEFT JOIN agreeregdev AS ard ON apn.rowid = ard.linkid and ard.paramid = 690
	      LEFT JOIN agreement AS amn ON amn.rowid = apn.linkid 
	      LEFT JOIN bee_external_agreepoint AS bea ON bea.devid = apn.devid AND bea.prodnumber = apn.prodnumber 
	      WHERE apn.prodnumber = '''||_prodnum||''' ORDER BY prodnum') ;
	END LOOP;
END;
$$;

comment on function bee_iskraemeco_get_devload_list_tmp_new(varchar) is 'Получить список счетчиков подходящих для загрузки из других источников дя текущей базы. Используется в bee_iskraemeco_get_devload_list_new()';

alter function bee_iskraemeco_get_devload_list_tmp_new(varchar) owner to pgsql;

