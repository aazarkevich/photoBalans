create function bee_rep_get_repdata28_get_pow_1(amn_rowid integer, year1 date) returns SETOF bee_rep_tab28_pow
    language sql
as
$$
/*
ito06 2013-01-18 
Приложение 1а, реальные данные - мощность
*/
SELECT 
	ard_nam.paramval||', '|| apn.prodnumber AS obj_name,
	CASE WHEN bpc.ul = 311   THEN 1
             WHEN bpc.ul = 308   THEN 2
             WHEN bpc.ul = 310   THEN 3
             WHEN bpc.ul = 306   THEN 4
        END 					AS ul,
        null::varchar 				AS ulev,
        sum(bpc.m_1*1000/744)::numeric(13,4) 	AS m_1,
	sum(bpc.m_2*1000/(24*(to_char($2,'YYYY-03-01')::date - to_char($2,'YYYY-02-01')::date)))::numeric(13,4)  AS m_2,
	sum(bpc.m_3*1000/744)::numeric(13,4)  	AS m_3,
	sum(bpc.m_4*1000/720)::numeric(13,4)  	AS m_4,
	sum(bpc.m_5*1000/744)::numeric(13,4)  	AS m_5,
	sum(bpc.m_6*1000/720)::numeric(13,4)  	AS m_6,
	sum(bpc.m_7*1000/744)::numeric(13,4) 	AS m_7,
	sum(bpc.m_8*1000/744)::numeric(13,4) 	AS m_8,
	sum(bpc.m_9*1000/720)::numeric(13,4)  	AS m_9,
	sum(bpc.m_10*1000/744)::numeric(13,4) 	AS m_10,
	sum(bpc.m_11*1000/720)::numeric(13,4) 	AS m_11,
	sum(bpc.m_12*1000/744)::numeric(13,4) 	AS m_12,
	ard_maxpow.paramval 			AS max_pow,
	ard_addpow.paramval 			AS add_pow,
	ard_okved.paramval 			AS okved,
	null::text 				AS tg,
	null::bigint 				AS hours
      
     FROM bee_rep28_get_en_real($1,$2) 	AS bpc

     JOIN agreepoint AS apn ON apn.rowid = bpc.pointid
     JOIN agreeregdev AS ard_nam ON ard_nam.linkid = apn.rowid AND ard_nam.paramid = 418
LEFT JOIN agreeregdev AS ard_okved ON ard_okved.linkid = apn.rowid AND ard_okved.paramid = 1030

LEFT JOIN bee_rep_get_ard_per_max(426) AS ard_maxpow  ON apn.rowid = ard_maxpow.linkid
LEFT JOIN bee_rep_get_ard_per_max(685) AS ard_addpow  ON apn.rowid = ard_addpow.linkid

  WHERE bpc.sum IS NOT NULL
    GROUP BY obj_name,ul,max_pow,add_pow,okved,hours, bpc.ul, apn.account, apn.prodnumber
    ORDER BY ul,obj_name;
$$;

comment on function bee_rep_get_repdata28_get_pow_1(integer, date) is 'Приложение 1а, реальные данные - мощность. Используется в bee_rep_get_repdata28_get_pow(int, date, int),bee_rep_get_repdata28_get_pow_tot(int, date, int)';

alter function bee_rep_get_repdata28_get_pow_1(integer, date) owner to postgres;

