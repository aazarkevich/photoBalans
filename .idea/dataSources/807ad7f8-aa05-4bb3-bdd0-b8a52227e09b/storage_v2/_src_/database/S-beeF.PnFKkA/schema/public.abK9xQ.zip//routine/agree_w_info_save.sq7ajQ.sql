create function agree_w_info_save() returns void
    language plpgsql
as
$$
declare
   R RECORD;	
BEGIN
   --
   DROP TABLE IF EXISTS bee_closed_period_tmp; 
	EXECUTE 
	 'create TEMPORARY table bee_closed_period_tmp AS
	  SELECT U.* FROM ( SELECT * FROM bee_closed_period) AS U;';
   --
   DROP TABLE IF EXISTS bee_closed_period_uni_tmp; 
	EXECUTE 
	 'create TEMPORARY table bee_closed_period_uni_tmp AS
	  SELECT U.* FROM ( SELECT * FROM bee_closed_period_uni) AS U;';
   --
   DROP TABLE IF EXISTS bee_closed_period_dir_tmp; 
	EXECUTE 
	 'create TEMPORARY table bee_closed_period_dir_tmp AS
	  SELECT U.* FROM ( SELECT * FROM bee_closed_period_dir) AS U;';
   --
   DROP TABLE IF EXISTS bee_closed_period_mix_tmp; 
	EXECUTE 
	 'create TEMPORARY table bee_closed_period_mix_tmp AS
	  SELECT U.* FROM ( SELECT * FROM bee_closed_period_mix) AS U;';
   --


END;
$$;

alter function agree_w_info_save() owner to postgres;

