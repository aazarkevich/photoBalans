create function bee_fill_rep_net_income_data_crossflow(_top_locid integer, _df text, _dt text) returns SETOF integer
    language plpgsql
as
$$
/*
	ito05 - Прием в сеть
	add ito06 2013-09-04
	add ito05 2015-03-17
	add ito05 2015-03-18
*/
DECLARE
		_date_from DATE = _df::DATE;
		_date_to DATE = _dt::DATE;
  
BEGIN
  	
	DROP TABLE IF EXISTS tmp_rep_net_income;
	CREATE TEMPORARY table tmp_rep_net_income  AS 
		(SELECT
			agreement.accdir::text 		AS accdir,
			gt.r::text 			AS r,
			gt.l::text 			AS l,
			gt.rp::text 			AS rp,
			gt.f::text 			AS f,
			gt.tp::text 			AS tp,
			agreepoint.prodnumber::text 	AS prodnumber,       --номер счетчика
			a2.valman::text 		AS otchkol,          --отчетное кол-во
			a4.valman::text 		AS privpok,          --предыдущие показания
			a5.valman::text 		AS currpok,          --текущие показания
			a3.valman::text 		AS diffpok,          --разность показаний  
			a6.paramval::text 		AS koef,             --расчетный коэфф. 
			agreepoint.account::text 	AS account,          --лицевой счет   
			agreepoint.rowid::integer 	AS ap_rowid,             
			(SELECT rowid FROM denet WHERE kod = (SELECT SUBSTRING(kod, 1, 9) FROM denet WHERE rowid = agreement.locid))::integer AS res_locid,
			agreement.locid::integer	AS locid ,
			gt.objowner::integer 		AS objowner,
			gt.objcode::integer 		AS objcode,
			gt.objname::text 		AS objname,
			gt.objtype::integer 		AS objtype,
			gt.rowid 			AS gt_rowid,
			gt.pchain::text 		AS pchain,
			'-'::text 			AS currpok538
		   FROM regdevconn
		  JOIN ( SELECT 
				g1.objname,  
				g1.objcode, 
				g1.objowner,
				g1.objtype, 
				--g2.objowner AS f6owner, -- ito05 150317
							
				split_part(g1.pchain,'+',5) AS r,
				split_part(g1.pchain,'+',6) AS l,

				CASE WHEN array_length(regexp_split_to_array(g1.pchain, E'\\+'), 1) = 9
					THEN split_part(g1.pchain,'+',7)
				     WHEN array_length(regexp_split_to_array(g1.pchain, E'\\+'), 1) = 8
				        THEN split_part(g1.pchain,'+',7)
				     WHEN array_length(regexp_split_to_array(g1.pchain, E'\\+'), 1) = 7
					THEN (CASE WHEN SUBSTRING(g1.pchain, 'ТП') IS NULL
					           THEN g1.objname
					           ELSE '' END)
				     ELSE '' 
				END AS rp,

				CASE WHEN array_length(regexp_split_to_array(g1.pchain, E'\\+'), 1) = 9
					THEN split_part(g1.pchain,'+',8)
				     WHEN array_length(regexp_split_to_array(g1.pchain, E'\\+'), 1) = 8
				        THEN split_part(g1.pchain,'+',8)
				     WHEN array_length(regexp_split_to_array(g1.pchain, E'\\+'), 1) = 7
				        THEN ''
				     ELSE '' 
				END AS f,

				CASE WHEN array_length(regexp_split_to_array(g1.pchain, E'\\+'), 1) = 9
					THEN split_part(g1.pchain,'+',9)
				     WHEN array_length(regexp_split_to_array(g1.pchain, E'\\+'), 1) = 8
				        THEN ''
				     ELSE
				        (CASE WHEN SUBSTRING(g1.pchain, 'ТП') IS NOT NULL
					           THEN g1.objname
					           ELSE '' END) 
			         END AS tp,
							
				 g1.rowid  AS rowid,
				 g1.pchain AS pchain
						
			    FROM gis_traces g1 -- , gis_traces g2 -- ito05 150317
			   WHERE g1.objtype IN  (8,9,11)
				 --AND g1.objowner = g2.objcode -- ito05 150317
					
		      ) gt ON regdevconn.traceid=gt.rowid
				      
		  JOIN agreepoint ON regdevconn.pointid=agreepoint.rowid
		  JOIN agreement ON agreepoint.linkid=agreement.rowid
	     LEFT JOIN (SELECT valman::NUMERIC, paramid, linkid FROM regdevoper WHERE paramid=850 AND valman <> '-' AND operdate BETWEEN _date_from AND _date_to) AS a2 ON agreepoint.rowid=a2.linkid
	  	  JOIN (SELECT SUM(CASE WHEN (valman IN ('', '-')) THEN 0 ELSE valman::FLOAT END) AS valman,linkid FROM regdevoper WHERE paramid = 198 AND operdate BETWEEN _date_from AND _date_to GROUP BY linkid) AS a3 ON agreepoint.rowid=a3.linkid
		  JOIN (SELECT SUM(CASE WHEN (valman IN ('', '-')) THEN 0 ELSE valman::FLOAT END) AS valman,linkid FROM regdevoper WHERE paramid = 196 AND operdate BETWEEN _date_from AND _date_to GROUP BY linkid) AS a4 ON agreepoint.rowid=a4.linkid
		  JOIN (SELECT SUM(CASE WHEN (valman IN ('', '-')) THEN 0 ELSE valman::FLOAT END) AS valman,linkid FROM regdevoper WHERE paramid = 195 AND operdate BETWEEN _date_from AND _date_to GROUP BY linkid) AS a5 ON agreepoint.rowid=a5.linkid
		  JOIN (SELECT agreeregdev_period.linkid, agreeregdev_period.paramval FROM agreeregdev_period JOIN (SELECT linkid, MAX(period) AS period FROM agreeregdev_period where paramid = 1696 GROUP BY linkid) AS p1 ON agreeregdev_period.linkid=p1.linkid AND agreeregdev_period.period=p1.period WHERE agreeregdev_period.paramid = 1696) AS a6 ON agreepoint.rowid=a6.linkid

	         WHERE agreement.accdir IN (319,538,1476)
		       AND agreepoint.rowid NOT IN (SELECT linkid FROM agreeregdev 
		                                                  WHERE paramval LIKE '____-__-__' 
									AND paramid = 690
									AND paramval::DATE < _date_from)
		       AND agreement.locid IN (SELECT rowid FROM denet WHERE kod LIKE ((SELECT kod FROM denet WHERE rowid = _top_locid) || '%'))  
		       AND agreement.docstatus = 79
				 
	         ORDER BY a6.paramval, r, l, rp, f, tp);
	
	END;

$$;

comment on function bee_fill_rep_net_income_data_crossflow(integer, text, text) is 'Прием в сеть. Используется в RepNetIncome.java';

alter function bee_fill_rep_net_income_data_crossflow(integer, text, text) owner to pgsql;

