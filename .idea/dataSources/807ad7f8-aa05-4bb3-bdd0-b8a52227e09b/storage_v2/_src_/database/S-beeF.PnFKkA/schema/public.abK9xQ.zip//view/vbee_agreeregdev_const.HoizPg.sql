create view vbee_agreeregdev_const(element_code, element_name, link, rowid, refs, element_type, sort) as
SELECT dic_elements.element_code,
       dic_elements.element_name,
       dic_elements.link,
       dic_elements.rowid,
       dic_elements.refs,
       dic_elements.element_type,
       CASE
           WHEN ("position"((dic_elements.element_name)::text, '*'::text) > 0) THEN 1
           ELSE 2
           END AS sort
FROM (dic_elements
         JOIN agreeregdev_paramids ON ((dic_elements.rowid = agreeregdev_paramids.paramid)))
WHERE ((dic_elements.link = 38) AND (agreeregdev_paramids.const = true) AND ((agreeregdev_paramids.tag)::text IS NULL))
ORDER BY CASE
             WHEN ("position"((dic_elements.element_name)::text, '*'::text) > 0) THEN 1
             ELSE 2
             END, dic_elements.element_code;

comment on view vbee_agreeregdev_const is 'Используется в AgreeRegDev.java, DeviceParamC.java, SessionBean1.java';

alter table vbee_agreeregdev_const
    owner to pgsql;

