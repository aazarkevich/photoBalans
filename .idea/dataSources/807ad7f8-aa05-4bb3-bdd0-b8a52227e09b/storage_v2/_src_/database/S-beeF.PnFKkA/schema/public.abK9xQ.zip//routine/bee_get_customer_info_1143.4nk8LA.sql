create function bee_get_customer_info_1143(aboid integer) returns character varying
    language sql
as
$$
select item from customer_info where elrowid=1143 and abo=$1;
$$;

comment on function bee_get_customer_info_1143(integer) is 'Используется в RepAkt.java, RepAkt1.java, RepAkt3.java, RepAkt6.java, RepAkt8.java, AppUtils.java';

alter function bee_get_customer_info_1143(integer) owner to pgsql;

