create function bee_repakt2_fill_content(bd_rowid integer) returns SETOF integer[]
    language plpgsql
as
$$
/*
	ito06 2015-06-17 Акт (соц. норма) - создание временной таблицы
*/
BEGIN
	DROP TABLE IF EXISTS tmp_repakt2_content;
	CREATE TEMPORARY table tmp_repakt2_content 
	  AS ( SELECT * 
		FROM		 ((select * from bee_repakt2_get_intermediate_content1($1))
			UNION ALL (select * from bee_repakt2_get_intermediate_content2($1))
			UNION ALL (select * from bee_repakt2_get_intermediate_corr1($1))
			UNION ALL (select * from bee_repakt2_get_intermediate_corr2($1))) AS a
			WHERE tot_amount IS NOT NULL
			ORDER BY period, grp, tarname_grp);
END;
$$;

comment on function bee_repakt2_fill_content(integer) is 'Акт (соц. норма). Используется в bee_repakt2_get_content(integer)';

alter function bee_repakt2_fill_content(integer) owner to pgsql;

