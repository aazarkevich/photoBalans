create function bee_get_child_chained_devices(xlid integer) returns character varying
    language plpgsql
as
$$
/*	
	add ito06 2014-06-24
	add ito06 2012-06-28 
	ito07  2011-01-17 08:15 ПОЛУЧИТЬ СПИСОК УСТРОЙСТВ СУБАБОНЕНТОВ ПО LOCID (denet.rowid)
	agreeregdev.paramid = 664  (paramval - ссылка на головной счётчик)
*/
DECLARE
	Rec    RECORD;
	Points VARCHAR := '';
	tmpVal INTEGER;
BEGIN
	FOR Rec IN (   	
		SELECT DISTINCT agreepoint.rowid AS Pnt 	
		  FROM  agreepoint 
		  JOIN  bee_rep_get_ard_per_max(664) AS ard ON ard.linkid = agreepoint.rowid 
                   AND paramval IS NOT NULL AND paramval NOT IN ('?','-','0') AND paramval ~ E'^\\d{1,}'   
             LEFT JOIN agreement  ON agreepoint.linkid = agreement.rowid
		 WHERE agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = xlid))) 
	LOOP  
		Points = Points || Rec.Pnt || '|'; 
	END LOOP;   
   --
	IF (Points <> '') AND (Points <> '|')  
	   THEN
		tmpVal := char_length(Points);
		Points := substring(Points from 1 for tmpVal-1);
	   ELSE
		Points := '';
	END IF; 
	RETURN Points; 
END;

$$;

comment on function bee_get_child_chained_devices(integer) is 'Получить список устройств субабонентов по locid. Используется в AgreeByDevice.java, AppUtils.java';

alter function bee_get_child_chained_devices(integer) owner to pgsql;

