create view vbee_cust_agree_loss(locid, aboid, abonam, aboinn, agreeid, docnum) as
SELECT customer.locid,
       customer.abo_code   AS aboid,
       customer.abo_name   AS abonam,
       customer.consum_inn AS aboinn,
       agreement.rowid     AS agreeid,
       agreement.docnumber AS docnum
FROM ((customer
    LEFT JOIN agreement ON ((customer.abo_code = agreement.abo_code)))
         LEFT JOIN agreement_info ON ((agreement.rowid = agreement_info.linkid)))
WHERE ((customer.valid = true) AND (agreement.abo_code IS NOT NULL) AND (agreement.locid IS NOT NULL) AND
       (agreement_info.paramid = 1915))
ORDER BY customer.locid, customer.abo_name, customer.consum_inn, agreement.docnumber;

comment on view vbee_cust_agree_loss is 'Используется в LossRSK.java, SessionBean1.java';

alter table vbee_cust_agree_loss
    owner to postgres;

