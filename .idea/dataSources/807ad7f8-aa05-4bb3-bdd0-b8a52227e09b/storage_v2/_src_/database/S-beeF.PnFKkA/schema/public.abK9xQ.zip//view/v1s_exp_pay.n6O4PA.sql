create view v1s_exp_pay
            (abo_code, ur_status, consum_name, inn, kpp, u_adr, fiz_adr, tel, dog_num, dog_dat, dog_id, doc_id,
             doc_num_pref_id, doc_num_pref, doc_num, doc_dat, plase_typ_id, plase_typ, bank_doc_typ, bank_doc_typ_lab,
             bank_doc_num, bank_doc_dat, pay_vid, pay_vid_lab, pay_comment, pay_date, summ, ras_sch)
as
SELECT customer.abo_code,
       e6.element_name                                               AS ur_status,
       btrim(((replace(regexp_replace(btrim((customer.consum_name)::text), ',$'::text, '.'::text), '"'::text,
                       ' '::text))::character varying(350))::text)   AS consum_name,
       customer.consum_inn                                           AS inn,
       c1.item                                                       AS kpp,
       ((((((
                    CASE
                        WHEN (((a.item)::text <> '0'::text) AND ((a.item)::text <> '?'::text) AND (a.item IS NOT NULL))
                            THEN ((a.item)::text || ', '::text)
                        ELSE ''::text
                        END ||
                    CASE
                        WHEN (((a0.item)::text <> '0'::text) AND ((a0.item)::text <> '?'::text) AND
                              (a0.item IS NOT NULL)) THEN ((a0.item)::text || ', '::text)
                        ELSE ''::text
                        END) ||
            CASE
                WHEN (((a1.item)::text <> '0'::text) AND ((a1.item)::text <> '?'::text) AND (a1.item IS NOT NULL))
                    THEN ((a1.item)::text || ', '::text)
                ELSE ''::text
                END) ||
           CASE
               WHEN (((a2.item)::text <> '0'::text) AND ((a2.item)::text <> '?'::text) AND (a2.item IS NOT NULL))
                   THEN ((a2.item)::text || ', '::text)
               ELSE ''::text
               END) || (
              CASE
                  WHEN (((a3.item)::text <> '0'::text) AND ((a3.item)::text <> '?'::text) AND (a3.item IS NOT NULL))
                      THEN a3.item
                  ELSE ''::character varying
                  END)::text) ||
         CASE
             WHEN (((a4.item)::text <> '0'::text) AND ((a4.item)::text <> '?'::text) AND (a4.item IS NOT NULL))
                 THEN ('/'::text || (a4.item)::text)
             ELSE ''::text
             END) ||
        CASE
            WHEN (((a5.item)::text <> '0'::text) AND ((a5.item)::text <> '?'::text) AND (a5.item IS NOT NULL) AND
                  ((a5.item)::text <> ''::text)) THEN btrim(
                    replace((', кв.'::text || regexp_replace(btrim((a5.item)::text), ',$'::text, '.'::text)), '"'::text,
                            ' '::text))
            ELSE ''::text
            END)                                                     AS u_adr,
       ((((((
                    CASE
                        WHEN (((fa.item)::text <> '0'::text) AND ((fa.item)::text <> '?'::text) AND
                              (fa.item IS NOT NULL)) THEN ((fa.item)::text || ', '::text)
                        ELSE ''::text
                        END ||
                    CASE
                        WHEN (((fa0.item)::text <> '0'::text) AND ((fa0.item)::text <> '?'::text) AND
                              (fa0.item IS NOT NULL)) THEN ((fa0.item)::text || ', '::text)
                        ELSE ''::text
                        END) ||
            CASE
                WHEN (((fa1.item)::text <> '0'::text) AND ((fa1.item)::text <> '?'::text) AND (fa1.item IS NOT NULL))
                    THEN ((fa1.item)::text || ', '::text)
                ELSE ''::text
                END) ||
           CASE
               WHEN (((fa2.item)::text <> '0'::text) AND ((fa2.item)::text <> '?'::text) AND (fa2.item IS NOT NULL))
                   THEN ((fa2.item)::text || ', '::text)
               ELSE ''::text
               END) || (
              CASE
                  WHEN (((fa3.item)::text <> '0'::text) AND ((fa3.item)::text <> '?'::text) AND (fa3.item IS NOT NULL))
                      THEN fa3.item
                  ELSE ''::character varying
                  END)::text) ||
         CASE
             WHEN (((fa4.item)::text <> '0'::text) AND ((fa4.item)::text <> '?'::text) AND (fa4.item IS NOT NULL))
                 THEN ('/'::text || (fa4.item)::text)
             ELSE ''::text
             END) ||
        CASE
            WHEN (((fa5.item)::text <> '0'::text) AND ((fa5.item)::text <> '?'::text) AND (fa5.item IS NOT NULL) AND
                  ((fa5.item)::text <> ''::text)) THEN btrim(
                    replace((', кв.'::text || regexp_replace(btrim((fa5.item)::text), ',$'::text, '.'::text)),
                            '"'::text, ' '::text))
            ELSE ''::text
            END)                                                     AS fiz_adr,
       regexp_replace(btrim((c2.item)::text), ',$'::text, '.'::text) AS tel,
       agreement.docnumber                                           AS dog_num,
       agreement.docdate                                             AS dog_dat,
       agreement.rowid                                               AS dog_id,
       bee_docs.rowid                                                AS doc_id,
       bee_docs.pref                                                 AS doc_num_pref_id,
       e1.element_name                                               AS doc_num_pref,
       bee_docs.docnum                                               AS doc_num,
       bee_docs.docdat                                               AS doc_dat,
       bee_docs_pay.pay_place_typ                                    AS plase_typ_id,
       e2.element_name                                               AS plase_typ,
       bee_docs_pay.bank_doc_typ,
       e3.element_name                                               AS bank_doc_typ_lab,
       bee_docs_pay.bank_doc_num,
       bee_docs_pay.bank_doc_dat,
       bee_docs_pay.pay_vid,
       e4.element_name                                               AS pay_vid_lab,
       bee_docs_pay.pay_comment,
       bee_docs_pay.pay_date,
       bee_docs_pay.summ,
       (SELECT (denet_info.paramval)::text AS paramval
        FROM denet_info
        WHERE (denet_info.paramid = 1095))                           AS ras_sch
FROM ((((((((((((((((((((((((bee_docs
    JOIN bee_docs_pay ON ((bee_docs.rowid = bee_docs_pay.linkid2)))
    LEFT JOIN dic_elements e1 ON ((bee_docs.pref = e1.rowid)))
    LEFT JOIN dic_elements e2 ON ((bee_docs_pay.pay_place_typ = e2.rowid)))
    LEFT JOIN dic_elements e3 ON ((bee_docs_pay.bank_doc_typ = e3.rowid)))
    LEFT JOIN dic_elements e4 ON ((bee_docs_pay.pay_vid = e4.rowid)))
    JOIN agreement ON ((bee_docs.linkid = agreement.rowid)))
    JOIN customer ON ((agreement.abo_code = customer.abo_code)))
    JOIN dic_elements e6 ON ((customer.urstatus = e6.rowid)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo,
                      customer_info.elrowid,
                      customer_info.rowid
               FROM customer_info
               WHERE (customer_info.elrowid = 84)) c1 ON ((customer.abo_code = c1.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo,
                      customer_info.elrowid,
                      customer_info.rowid
               FROM customer_info
               WHERE (customer_info.elrowid = 85)) c2 ON ((customer.abo_code = c2.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 647)) a ON ((customer.abo_code = a.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 377)) a0 ON ((customer.abo_code = a0.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 358)) a1 ON ((customer.abo_code = a1.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 361)) a2 ON ((customer.abo_code = a2.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 362)) a3 ON ((customer.abo_code = a3.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 363)) a4 ON ((customer.abo_code = a4.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 364)) a5 ON ((customer.abo_code = a5.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 648)) fa ON ((customer.abo_code = fa.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 379)) fa0 ON ((customer.abo_code = fa0.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 365)) fa1 ON ((customer.abo_code = fa1.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 366)) fa2 ON ((customer.abo_code = fa2.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 367)) fa3 ON ((customer.abo_code = fa3.abo)))
    LEFT JOIN (SELECT customer_info.item,
                      customer_info.abo
               FROM customer_info
               WHERE (customer_info.elrowid = 368)) fa4 ON ((customer.abo_code = fa4.abo)))
         LEFT JOIN (SELECT customer_info.item,
                           customer_info.abo
                    FROM customer_info
                    WHERE (customer_info.elrowid = 369)) fa5 ON ((customer.abo_code = fa5.abo)))
WHERE (bee_docs.doctyp = ANY (ARRAY [1169, 1165, 1164, 1170]))
ORDER BY bee_docs.rowid;

alter table v1s_exp_pay
    owner to postgres;

