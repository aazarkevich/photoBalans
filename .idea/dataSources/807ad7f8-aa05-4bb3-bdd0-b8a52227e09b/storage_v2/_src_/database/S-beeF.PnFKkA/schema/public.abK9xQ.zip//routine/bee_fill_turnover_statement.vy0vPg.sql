create function bee_fill_turnover_statement(_top_locid integer, _df text, _dt text, amntyp integer) returns SETOF integer[]
    language plpgsql
as
$$
/*      
    add ito06 2019-09-18 НДС корректировки должен считаться по корректируемой дате, а не дате создания корр
        ito07 181026 bee_get_doc_tax 
        ito07 161214 (sum no nds), nds=(sum no nds)*0.18, (sum no nds)*1.18 для копейки  
    add ito06 2016-03-03 добавляем параметр тип договора amntyp
    add ito06 2015-12-14 в отчет должны попадать расторгнутые договоры, у ктр либо на начало, либо на конец периода есть задолженность!
    add ito06 2015-10-15 не учитывам нагрузочные потери в колонке "кол_во кВт*ч":14
    add ito06 2015-08-14 учитывам нагрузочные потери
    add ito06 2015-07-14
    add ito06 2015-06-22
    add ito06 2015-06-19
    add ito06 2015-05-28
    add ito06 2015-03-24
    add ito06 2015-03-03
    add ito06 2015-01-13
    add ito06 2014-11-17
    add ito06 2013-09-06
    ito05  ОБОРОТНО-САЛЬДОВАЯ ВЕДОМОСТЬ
*/
DECLARE
    _date_from date = _df::date;
    _date_to   date = _dt::date;
    _dat date := '2014-09-30';

BEGIN
    DROP TABLE IF EXISTS tmp_rep_turnover;
    IF (    (select date_trunc('month', _date_to)) = (select date_trunc('month', _date_from)) 
        AND (select date_trunc('year', _date_to)) = (select date_trunc('year', _date_from))) 
       THEN --формируем за 1 месяц
       
	CREATE TEMPORARY table tmp_rep_turnover AS 
	
	(SELECT 
	    de5.element_code::text					   AS c1,  --напрвление_учета_код
	    de5.element_name ::text					   AS c2,  --направление_учета
	    docnumber || ', ' || consum_name::text	AS c3,  --потребитель
	    agreement.rowid::text					AS c4,  --код_договора
	    bee_docs_sheet.operdate::text			AS c5,
	    bee_docs_sheet.npp::text				AS c6,
	    bee_docs.doctyp::text					AS c7,  --тип_документа_код
	    de1.element_name::text					AS c8,  --тип_документа
	    --
	    bds_start.start_debit::text			AS c9,  --сальдо_начало_Дт ***
	    bds_start.start_kredit::text			AS c10, --сальдо_начало_Кт
	    --
	    bee_docs.docdat::text					AS c11,
	    bee_docs.docnum::text					AS c12, 
	    de4.element_name::text					AS c13, --уровень_напряжения, 
	    bee_docs_result.amount::text		   AS c14, --кол_во кВт*ч, 
	    --
	    bee_docs_result.price::text			AS c15, --тариф, 
	    --------------------------------------------------------------
	    bee_docs_result.sum_no_tax::text		AS c16, --стоимость_безНДС, 
        (bee_docs_result.sum_no_tax * bee_get_doc_tax(1163,bee_docs.rowid))::text        AS c17, --сумма_НДС,
        (bee_docs_result.sum_no_tax * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::text  AS c18, --стоимость_с НДС, ***
	    ---------------------------------------------------------------
	    bee_docs_sheet.oper_debit::text		AS c19, --обороты_Дт,
	    --
	    bee_docs_pay.pay_place_typ::text		AS c20, --тип_места_оплаты_код, 
	    de2.element_name::text					AS c21, --тип_места_оплаты, 
	    bee_docs_pay.pay_vid::text				AS c22, --вид_оплаты_код, 
	    de3.element_name::text					AS c23, --вид_оплаты, 
                        
	    bee_docs_pay.summ::text					AS c24, 
                        bee_docs_sheet.oper_kredit::text			AS c25, --обороты_Кт,
	    
	    bds_final.final_debit::text			AS c26, --сальдо_конец_Дт, 		
	    bds_final.final_kredit::text			AS c27, --сальдо_конец_Кт, 
	    
	    agreement.locid::integer				AS c28,
	    agreement.accdir::integer				AS c29, --направление учёта
	    CASE WHEN bee_docs_result.sum_with_tax = 0
	           THEN null
	         ELSE CASE WHEN  _date_from >= _dat
	                     THEN null
	                   ELSE bee_docs_result.tax_sum
	              END   
	    END::text					 	         AS c30,  --сумма всего НДС 
	    CASE WHEN bee_docs_result.sum_with_tax = 0
	           THEN  null
	         ELSE CASE WHEN  _date_from >= _dat
	                     THEN  null
	                   ELSE bee_docs_result.sum_with_tax
	              END
	    END::text					 	         AS c31   --сумма всего с НДС
	    
	   FROM bee_docs_sheet 
	   JOIN bee_docs ON bee_docs_sheet.linkid2 = bee_docs.rowid 
	   JOIN dic_elements de1 ON bee_docs.doctyp = de1.rowid 
          LEFT JOIN bee_docs_result ON bee_docs.rowid=bee_docs_result.linkid 
          LEFT JOIN dic_tarif_group ON bee_docs_result.tar_grp=dic_tarif_group.rowid 
          LEFT JOIN dic_elements de4 ON dic_tarif_group.voltage_level=de4.rowid 
          LEFT JOIN bee_docs_pay ON bee_docs.rowid=bee_docs_pay.linkid2
		
          LEFT JOIN dic_elements de2 ON bee_docs_pay.pay_place_typ = de2.rowid 
          LEFT JOIN dic_elements de3 ON bee_docs_pay.pay_vid = de3.rowid 
	   JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid 
	   JOIN dic_elements de5 ON agreement.accdir=de5.rowid 
	   JOIN customer ON agreement.abo_code = customer.abo_code		   
          --** 2015-06-19	    
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
          --**	      
	  WHERE doctyp not in (1066,1713,1705,1618,1065) 
	    --AND agreement.docstatus = 79 
	    AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	         AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0 
	               OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
	    AND bee_docs_sheet.operdate BETWEEN _date_from AND _date_to
	    AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
	    AND agreement.valid=true
	    AND bee_docs_sheet.npp<>0
	    AND agreement.doctype = amntyp --2016-03-03 
    UNION ALL        
                 SELECT 
	    de5.element_code::text					   AS c1,  --напрвление_учета_код
	    de5.element_name ::text					   AS c2,  --направление_учета
	    docnumber || ', ' || consum_name::text	AS c3,  --потребитель
	    agreement.rowid::text					   AS c4,  --код_договора
	    bee_docs_sheet.operdate::text				AS c5,
	    bee_docs_sheet.npp::text				   AS c6,
	    bee_docs.doctyp::text					   AS c7,  --тип_документа_код
	    de1.element_name::text					   AS c8,  --тип_документа
	    
	    bds_start.start_debit::text				AS c9,  --сальдо_начало_Дт
	    bds_start.start_kredit::text				AS c10, -- сальдо_начало_Кт

	    bee_docs_sheet.operdate::text				AS c11,
	    bee_docs.docnum::text					   AS c12, 
	    null::text						            AS c13, --уровень_напряжения, 
	    CASE WHEN sum(bee_docs_result.amount) = 0 
	           THEN null
	         ELSE sum(CASE WHEN bee_docs_result.tar_typ<>1734
	                         THEN bee_docs_result.amount
	                       ELSE 0
	                   END)  
	    END::text 						           AS c14, --кол_во кВт*ч, 
	    null::text						           AS c15, --тариф, 
	    sum(bee_docs_result.sum_no_tax)::text AS c16, --стоимость_безНДС, 

         (sum(bee_docs_result.sum_no_tax * bee_get_doc_tax(1163,bee_docs.rowid)))::text            AS c17, --сумма_НДС,
         (sum(bee_docs_result.sum_no_tax * (1 + bee_get_doc_tax(1163,bee_docs.rowid))))::text      AS c18, --стоимость_с НДС,
                        --
                        bee_docs_sheet.oper_debit::text			AS c19, --обороты_Дт,		
                        bee_docs_pay.pay_place_typ::text			AS c20, --тип_места_оплаты_код, 
	    de2.element_name::text					AS c21, --тип_места_оплаты, 
	    bee_docs_pay.pay_vid::text				AS c22, --вид_оплаты_код, 
	    de3.element_name::text					AS c23, --вид_оплаты, 
	    bee_docs_pay.summ::text					AS c24, 
                        bee_docs_sheet.oper_kredit::text			AS c25, --обороты_Кт, 

	    bds_final.final_debit::text				     AS c26, --сальдо_конец_Дт, 
                        bds_final.final_kredit::text AS c27, --сальдо_конец_Кт,
	    
	    agreement.locid::integer				AS c28,
	    agreement.accdir::integer				AS c29,  --направление учёта
	    sum(CASE WHEN bee_docs_result.sum_with_tax = 0
	           THEN null
	         ELSE CASE WHEN  _date_from >= _dat
	                     THEN null
	                   ELSE bee_docs_result.tax_sum
	              END   
	    END)::text						AS c30,  --сумма всего НДС 
	    sum(CASE WHEN bee_docs_result.sum_with_tax = 0
	           THEN  null
	         ELSE CASE WHEN  _date_from >= _dat
	                     THEN  null
	                   ELSE bee_docs_result.sum_with_tax
	              END
	    END)::text					 	AS c31   --сумма всего с НДС
	
	   FROM bee_docs_sheet 
	   JOIN bee_docs ON bee_docs_sheet.linkid2 = bee_docs.rowid 
	   JOIN dic_elements de1 ON bee_docs.doctyp = de1.rowid 
          LEFT JOIN bee_docs_result ON bee_docs.rowid=bee_docs_result.linkid  AND name IN ('-', 'РСК','ФСК') --2015-08-14
          LEFT JOIN dic_tarif_group ON bee_docs_result.tar_grp=dic_tarif_group.rowid 
          LEFT JOIN dic_elements de4 ON dic_tarif_group.voltage_level=de4.rowid 
          LEFT JOIN bee_docs_pay ON bee_docs.rowid=bee_docs_pay.linkid2
		
          LEFT JOIN dic_elements de2 ON bee_docs_pay.pay_place_typ = de2.rowid 
          LEFT JOIN dic_elements de3 ON bee_docs_pay.pay_vid = de3.rowid 
	   JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid 
	   JOIN dic_elements de5 ON agreement.accdir=de5.rowid 
	   JOIN customer ON agreement.abo_code = customer.abo_code 
          --** 2015-06-19	    
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
          --**

	  WHERE doctyp = 1065
	    --AND agreement.docstatus = 79 
	    AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	         AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0
	              OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
	    AND bee_docs_sheet.operdate BETWEEN _date_from AND _date_to
	    AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
	    AND agreement.valid=true
	    AND bee_docs_sheet.npp<>0
	    AND agreement.doctype = amntyp --2016-03-03 
	    
	GROUP BY de5.element_code, de5.element_code,de5.element_name,docnumber, consum_name,agreement.rowid,
	     bee_docs_sheet.npp, bee_docs.doctyp, de1.element_name, bee_docs_sheet.start_debit,
	    bee_docs_sheet.start_kredit,bee_docs.docdat,bee_docs.docnum,bee_docs_sheet.oper_debit,
	    bee_docs_pay.pay_place_typ,de2.element_name,bee_docs_pay.pay_vid,de3.element_name,bee_docs_pay.summ,
	    bee_docs_sheet.oper_kredit,bee_docs_sheet.final_debit,bee_docs_sheet.final_kredit,agreement.locid,
	    agreement.accdir,bee_docs.rowid, bee_docs_sheet.operdate, 
	    bds_start.start_debit, bds_start.start_kredit, 	bds_final.final_debit, bds_final.final_kredit	
    
            UNION ALL
	    SELECT 
		de5.element_code::text					AS c1,  --напрвление_учета_код
		de5.element_name ::text					AS c2,  --направление_учета
		docnumber || ', ' || consum_name::text			AS c3,  --потребитель
		agreement.rowid::text					AS c4,  --код_договора
		bee_docs_sheet.operdate::text				AS c5,
		bee_docs_sheet.npp::text				AS c6,
		bee_docs.doctyp::text					AS c7,  --тип_документа_код
		de1.element_name::text					AS c8,  --тип_документа

		bds_start.start_debit::text				AS c9,  --сальдо_начало_Дт
		bds_start.start_kredit::text				AS c10, -- сальдо_начало_Кт
	    
		(select period from bee_docs_corr 
		  where linkid2 = bee_docs.rowid limit 1)::text		AS c11,
		bee_docs.docnum::text					AS c12, 
		null::text						AS c13, --уровень_напряжения, 
		CASE WHEN sum(bee_docs_result.amount) = 0 
		       THEN null
		     ELSE sum(bee_docs_result.amount)  
		END::text 						AS c14, --кол_во кВт*ч, 
		null::text						AS c15, --тариф, 
		sum(bee_docs_result.sum_no_tax)::text			AS c16, --стоимость_безНДС, 

	 --** ito06 2019-09-18 НДС корректировки должен считаться по корректируемой дате, а не дате создания корр
	 
     --** (sum(bee_docs_result.sum_no_tax * bee_get_doc_tax(1163,bee_docs.rowid)))::text        AS c17, --сумма_НДС,
	 --**  (sum(bee_docs_result.sum_no_tax * (1 + bee_get_doc_tax(1163,bee_docs.rowid))))::text   AS c18, --стоимость_с НДС,
	 (sum(bee_docs_result.sum_no_tax * bee_get_doc_tax(1163,(select  period from bee_docs_corr where linkid2 = bee_docs.rowid limit 1))))::text        AS c17, --сумма_НДС,
	 (sum(bee_docs_result.sum_no_tax * (1 + bee_get_doc_tax(1163,(select  period from bee_docs_corr where linkid2 = bee_docs.rowid limit 1)))))::text   AS c18, --стоимость_с НДС,
      --**     
                                --
		
                                bee_docs_sheet.oper_debit::text				AS c19, --обороты_Дт,
                                bee_docs_pay.pay_place_typ::text			AS c20, --тип_места_оплаты_код, 
		de2.element_name::text					AS c21, --тип_места_оплаты, 
		bee_docs_pay.pay_vid::text				AS c22, --вид_оплаты_код, 
		de3.element_name::text					AS c23, --вид_оплаты, 
		bee_docs_pay.summ::text					AS c24, 
		
                                bee_docs_sheet.oper_kredit::text			AS c25, --обороты_Кт, 
		bds_final.final_debit::text				AS c26, --сальдо_конец_Дт, 		
                                bds_final.final_kredit::text				AS c27, --сальдо_конец_Кт,
	    
		agreement.locid::integer				AS c28,
		agreement.accdir::integer				AS c29,  --направление учёта
		sum(CASE WHEN bee_docs_result.sum_with_tax = 0
		       THEN null
		     ELSE CASE WHEN  _date_from >= _dat
			
			 THEN null
		           ELSE bee_docs_result.tax_sum
		      END   
		END)::text						AS c30,  --сумма всего НДС 
		sum(CASE WHEN bee_docs_result.sum_with_tax = 0
		       THEN  null
		     ELSE CASE WHEN  _date_from >= _dat
			 THEN  null
		           ELSE bee_docs_result.sum_with_tax
		      END
		END)::text					 	AS c31   --сумма всего с НДС
		    

	       FROM bee_docs_sheet 
	       JOIN bee_docs ON bee_docs_sheet.linkid2 = bee_docs.rowid 
	       JOIN dic_elements de1 ON bee_docs.doctyp = de1.rowid 
	      LEFT JOIN bee_docs_result ON bee_docs.rowid=bee_docs_result.linkid 
	      LEFT JOIN dic_tarif_group ON bee_docs_result.tar_grp=dic_tarif_group.rowid 
	      LEFT JOIN dic_elements de4 ON dic_tarif_group.voltage_level=de4.rowid 
	      LEFT JOIN bee_docs_pay ON bee_docs.rowid=bee_docs_pay.linkid2
		    
	      LEFT JOIN dic_elements de2 ON bee_docs_pay.pay_place_typ = de2.rowid 
	      LEFT JOIN dic_elements de3 ON bee_docs_pay.pay_vid = de3.rowid 
	       JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid 
	       JOIN dic_elements de5 ON agreement.accdir=de5.rowid 
	       JOIN customer ON agreement.abo_code = customer.abo_code 
                 --** 2015-06-19	    
	     LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
	     LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
	     --**

	      WHERE doctyp in (1705,1618) 
		--AND agreement.docstatus = 79 
		AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	                 AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0
	                       OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
		AND bee_docs_sheet.operdate BETWEEN _date_from AND _date_to
		AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
		AND agreement.valid=true
		AND bee_docs_sheet.npp<>0
		AND agreement.doctype = amntyp --2016-03-03 
		
	    GROUP BY de5.element_code, de5.element_code,de5.element_name,docnumber, consum_name,agreement.rowid,
		 bee_docs_sheet.npp, bee_docs.doctyp, de1.element_name, bee_docs_sheet.start_debit,
		bee_docs_sheet.start_kredit,bee_docs.docdat,bee_docs.docnum,bee_docs_sheet.oper_debit,
		bee_docs_pay.pay_place_typ,de2.element_name,bee_docs_pay.pay_vid,de3.element_name,bee_docs_pay.summ,
		bee_docs_sheet.oper_kredit,bee_docs_sheet.final_debit,bee_docs_sheet.final_kredit,agreement.locid,
		agreement.accdir,bee_docs.rowid, bee_docs_sheet.operdate,
		bds_start.start_debit, bds_start.start_kredit, 	bds_final.final_debit, bds_final.final_kredit 
		
    	      
    UNION ALL
	 SELECT 
	    de5.element_code::text					AS c1,  --напрвление_учета_код
	    de5.element_name::text					AS c2,  --направление_учета
	    docnumber || ', ' || consum_name::text			AS c3,  --потребитель
	    agreement.rowid::text					AS c4,  --код_договора
	    bee_docs_sheet.operdate::text				AS c5,
	    bee_docs_sheet.npp::text				AS c6,
	    bee_docs.doctyp::text					AS c7,  --тип_документа_код
	    de1.element_name::text					AS c8,  --тип_документа

	    bds_start.start_debit::text				AS c9,  --сальдо_начало_Дт
	    bds_start.start_kredit::text				AS c10, -- сальдо_начало_Кт
	      
	    bee_docs.docdat::text					AS c11,
	    bee_docs.docnum::text					AS c12, 
	    '-'::text						AS c13, --уровень_напряжения, 
	    0::text							AS c14, --кол_во кВт*ч, 
	    0::text							AS c15, --тариф, 
	    0::text							AS c16, --стоимость_без НДС, 
	    0::text							AS c17, --сумма_НДС, 
	    0::text							AS c18, --стоимость_с НДС, 
	    0::text							AS c19, --обороты_Дт,
	    bee_docs_pay.pay_place_typ::text			AS c20, --тип_места_оплаты_код, 
	    de2.element_name::text					AS c21, --тип_места_оплаты, 
	    bee_docs_pay.pay_vid::text				AS c22, --вид_оплаты_код, 
	    de3.element_name ::text					AS c23, --вид_оплаты, 
	    bee_docs_pay.summ::text					AS c24, 
                        0::text							AS c25, --обороты_Кт, 

	    bds_final.final_debit::text				AS c26, --сальдо_конец_Дт, 
	    bds_final.final_kredit::text				AS c27, --сальдо_конец_Кт,
	    
	    agreement.locid::integer				AS c28,
	    agreement.accdir::integer				AS c29,  -- направление учёта
	    0::text					 		AS c30,  --сумма всего НДС
	    0::text					 		AS c31   --сумма всего с НДС

	   FROM bee_docs_sheet 
	   JOIN bee_docs ON bee_docs_sheet.linkid2 = bee_docs.rowid 
	   JOIN dic_elements de1 ON bee_docs.doctyp = de1.rowid 
		
          LEFT JOIN bee_docs_pay ON bee_docs.rowid=bee_docs_pay.linkid2
          LEFT JOIN bee_docs_result ON bee_docs.rowid=bee_docs_result.linkid
          LEFT JOIN dic_elements de2 ON bee_docs_pay.pay_place_typ = de2.rowid
          LEFT JOIN dic_elements de3 ON bee_docs_pay.pay_vid = de3.rowid 
	   JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid 
	   JOIN dic_elements de5 ON agreement.accdir=de5.rowid 
	   JOIN customer ON agreement.abo_code = customer.abo_code 
          --** 2015-06-19	    
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
          --**
	  WHERE doctyp = 1713 
	    --AND agreement.docstatus = 79 
	    AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	         AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0
	               OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
	    AND bee_docs_sheet.operdate BETWEEN _date_from AND _date_to
	    AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
	    AND agreement.valid=true
	    AND bee_docs_sheet.npp<>0
	    AND agreement.doctype = amntyp --2016-03-03 
    UNION ALL
	 SELECT 
	    de5.element_code::text 					AS c1,
	    de5.element_name::text					AS c2,
	    docnumber || ', ' || consum_name::text 			AS c3, 
	    agreement.rowid::text 					AS c4,
	    bee_docs_sheet.operdate::text				AS c5, 
	    bee_docs_sheet.npp::text				AS c6, 
	    '1065'::text						AS c7,
	    '-'::text						AS c8,
	    
	    bds_start.start_debit::text				AS c9,  --сальдо_начало_Дт
	    bds_start.start_kredit::text				AS c10, -- сальдо_начало_Кт
	    
	    _date_from::text					AS c11,
	    0::text							AS c12,
	    '-'::text						AS c13,
	    0::text							AS c14,
	    0::text							AS c15,
	    0::text							AS c16,
	    0::text							AS c17,
	    0::text							AS c18,
	    0::text							AS c19,
	    0::text							AS c20,
	    '-'::text						AS c21,
	    0::text							AS c22,
	    '-' ::text						AS c23,
	    0::text							AS c24,
	    0::text							AS c25,
	    
	    bds_final.final_debit::text				AS c26, --сальдо_конец_Дт, 
	    bds_final.final_kredit::text				AS c27, --сальдо_конец_Кт,
	    
	    agreement.locid::integer				AS c28,
	    agreement.accdir::integer				AS c29,
	    0::text							AS c30,   --сумма всего НДС
	    0::text							AS c31    --сумма всего с НДС

	   FROM bee_docs_sheet
	   JOIN (SELECT tab.linkid1, tab.operdate, tab.npp 
	       FROM (SELECT linkid1, operdate, MAX(npp) AS npp
		   FROM bee_docs_sheet 
		  WHERE operdate < _date_from
		    AND linkid1 NOT IN (SELECT linkid1 FROM bee_docs_sheet WHERE operdate BETWEEN _date_from AND _date_to)
		  GROUP by linkid1, operdate ORDER BY operdate) AS tab 
	       JOIN (SELECT linkid1, MAX(operdate) AS operdate 
		   FROM (SELECT linkid1, operdate, MAX(npp) AS npp
		       FROM bee_docs_sheet 
		      WHERE operdate < _date_from
		        AND linkid1 NOT IN (SELECT linkid1 FROM bee_docs_sheet WHERE operdate BETWEEN _date_from AND _date_to)
		      GROUP by linkid1, operdate ORDER BY operdate) AS tab1 
		  GROUP BY linkid1) AS tab3 ON tab.linkid1=tab3.linkid1 AND tab.operdate=tab3.operdate
	    ) AS bds ON bee_docs_sheet.linkid1=bds.linkid1 AND bee_docs_sheet.operdate=bds.operdate
		AND bee_docs_sheet.npp=bds.npp
	   JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid
	   JOIN dic_elements de5 ON agreement.accdir=de5.rowid
	   JOIN customer ON agreement.abo_code = customer.abo_code
          --** 2015-06-19	    
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
          --**		   
	  WHERE bee_docs_sheet.operdate < _date_from
	   --AND agreement.docstatus = 79 
	   AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	         AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0 
	              OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
	   AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
	   AND agreement.valid= true
	   AND agreement.rowid NOT IN (SELECT linkid1 FROM bee_docs_sheet WHERE bee_docs_sheet.operdate BETWEEN _date_from AND _date_to)
	   AND (bds_start.start_debit <>0 OR bds_start.start_kredit<>0 OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0) --2015-07-14
	   AND bee_docs_sheet.npp<>0
	   AND agreement.doctype = amntyp);

      ELSE --формируем за период
      CREATE TEMPORARY table tmp_rep_turnover AS 
	(SELECT 
	    de5.element_code::text					AS c1,  --напрвление_учета_код
	    de5.element_name ::text					AS c2,  --направление_учета
	    docnumber || ', ' || consum_name::text			AS c3,  --потребитель
	    agreement.rowid::text					AS c4,  --код_договора
	    bee_docs_sheet.operdate::text				AS c5,
	    bee_docs_sheet.npp::text				AS c6,
	    bee_docs.doctyp::text					AS c7,  --тип_документа_код
	    de1.element_name::text					AS c8,  --тип_документа
	    
	    bds_start.start_debit::text				AS c9,  --сальдо_начало_Дт
	    bds_start.start_kredit::text				AS c10, -- сальдо_начало_Кт

	    bee_docs.docdat::text					AS c11,
	    bee_docs.docnum::text					AS c12, 
	    de4.element_name::text					AS c13, --уровень_напряжения, 
	    bee_docs_result.amount::text				AS c14, --кол_во кВт*ч, 
	    bee_docs_result.price::text				AS c15, --тариф, 
	    bee_docs_result.sum_no_tax::text			AS c16, --стоимость_безНДС, 

         (bee_docs_result.sum_no_tax * bee_get_doc_tax(1163,bee_docs.rowid))::text        AS c17, --сумма_НДС,
         (bee_docs_result.sum_no_tax * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::text        AS c18, --стоимость_с НДС,
	    --
         bee_docs_sheet.oper_debit::text				AS c19, --обороты_Дт,
	    bee_docs_pay.pay_place_typ::text			AS c20, --тип_места_оплаты_код, 
	    de2.element_name::text					AS c21, --тип_места_оплаты, 
	    bee_docs_pay.pay_vid::text				AS c22, --вид_оплаты_код, 
	    de3.element_name::text					AS c23, --вид_оплаты, 
	    bee_docs_pay.summ::text					AS c24, 
	    bee_docs_sheet.oper_kredit::text			AS c25, --обороты_Кт, 

	    bds_final.final_debit::text				AS c26, --сальдо_конец_Дт, 	
                        bds_final.final_kredit::text				AS c27, --сальдо_конец_Кт,
	    
	    agreement.locid::integer				AS c28,
	    agreement.accdir::integer				AS c29, -- направление учёта
	    CASE WHEN bee_docs_result.sum_with_tax = 0
	           THEN null
	         ELSE CASE WHEN  _date_from >= _dat
	                     THEN null
	                   ELSE bee_docs_result.tax_sum
	              END   
	    END::text					 	AS c30,  --сумма всего НДС 
	    CASE WHEN bee_docs_result.sum_with_tax = 0
	           THEN  null
	         ELSE CASE WHEN  _date_from >= _dat
	                     THEN  null
	                   ELSE bee_docs_result.sum_with_tax
	              END
	    END::text					 	AS c31   --сумма всего с НДС
	    
	   FROM bee_docs_sheet 
	   JOIN bee_docs ON bee_docs_sheet.linkid2 = bee_docs.rowid 
	   JOIN dic_elements de1 ON bee_docs.doctyp = de1.rowid 
          LEFT JOIN bee_docs_result ON bee_docs.rowid=bee_docs_result.linkid 
          LEFT JOIN dic_tarif_group ON bee_docs_result.tar_grp=dic_tarif_group.rowid 
          LEFT JOIN dic_elements de4 ON dic_tarif_group.voltage_level=de4.rowid 
          LEFT JOIN bee_docs_pay ON bee_docs.rowid=bee_docs_pay.linkid2
		
          LEFT JOIN dic_elements de2 ON bee_docs_pay.pay_place_typ = de2.rowid 
          LEFT JOIN dic_elements de3 ON bee_docs_pay.pay_vid = de3.rowid 
	   JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid 
	   JOIN dic_elements de5 ON agreement.accdir=de5.rowid 
	   JOIN customer ON agreement.abo_code = customer.abo_code 
          --** 2015-06-19	    
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
          --**		   

	  WHERE doctyp not in (1066,1713,1065,1705,1618) 
	    --AND agreement.docstatus = 79 
	    AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	         AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0 
	              OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
	    AND bee_docs_sheet.operdate BETWEEN _date_from AND _date_to
	    AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
	    AND agreement.valid=true
	    AND bee_docs_sheet.npp<>0
	    AND agreement.doctype = amntyp
UNION ALL 
    SELECT 	c1,c2,c3,c4,c5, 
	sum(CASE WHEN num = 1 THEN c6::int ELSE 0 END)::text 			AS c6,
	'1065'::text 								AS c7,
	null::text 								AS c8, 
	sum(CASE WHEN num = 1 THEN c9::numeric ELSE 0::numeric END)::text 	AS c9,
	sum(CASE WHEN num = 1 THEN c10::numeric ELSE 0::numeric END)::text 	AS c10,
	c11,
	null::text 								AS c12,
	c13,
	sum(c14::numeric)::text							AS c14, --кол_во кВт*ч, 
	c15,
	sum(c16::numeric)::text 						AS c16, --стоимость_без НДС, 

	CASE WHEN sum(c17::numeric) = 0 
	       THEN sum(c19::numeric-c16::numeric)
	       ELSE sum(c17::numeric)
                END::text								AS c17, --сумма_НДС,
                ----- 
                CASE WHEN sum(c18::numeric) = 0 
	       THEN sum(c19::numeric)	
	       ELSE sum(c18::numeric)
                END::text								AS c18, --стоимость_с НДС, 
	-----
                sum(c19::numeric)::text	 						AS c19, --обороты_Дт,
	c20,c21,c22,c23,c24,
	sum(c25::numeric)::text							AS c25, --обороты_Кт,
	--
                sum(CASE WHEN numdesc = 1 THEN c26::numeric ELSE 0::numeric END)::text	AS c26, --сальдо_конец_Дт,
                --
	 
	sum(CASE WHEN numdesc= 1 THEN c27::numeric ELSE 0::numeric END)::text	AS c27,	--сальдо_конец_Кт
	c28,
	c29,		
	CASE WHEN sum(c30::numeric) = 0 
	       THEN sum(c19::numeric-c16::numeric)
	       ELSE sum(c30::numeric)
                END ::text								AS c30, 
                CASE WHEN sum(c31::numeric) = 0 
	       THEN sum(c19::numeric)
	       ELSE sum(c31::numeric)
                END::text								AS c31 
    
      FROM (select c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21,c22,c23,c24,c25,c26,c27,c28,c29,c30,c31, 
	    row_number() over (partition  BY c4,c5 order by c5,c6 ) 		AS num,
	    row_number() over (partition  BY c4,c5 order by c5 desc, c6 desc) 	AS numdesc	 
                FROM((SELECT 
		de5.element_code::text    				AS c1,  --напрвление_учета_код
		de5.element_name ::text					AS c2,  --направление_учета
		docnumber || ', ' || consum_name::text			AS c3,  --потребитель
		agreement.rowid::text					AS c4,  --код_договора
		bee_docs_sheet.operdate::text				AS c5,
		bee_docs_sheet.npp::text                         	AS c6,
		bee_docs.doctyp::text                            	AS c7,  --тип_документа_код
		de1.element_name::text                           	AS c8,  -- тип_документа
		
		bds_start.start_debit::text				AS c9,  --сальдо_начало_Дт
		bds_start.start_kredit::text				AS c10, -- сальдо_начало_Кт
		
		bee_docs.docdat::text					AS c11,
		bee_docs.docnum::text                            	AS c12, 
		null::text						AS c13, --уровень_напряжения, 
		sum(bee_docs_result.amount)::text			AS c14, --кол_во кВт*ч, 
		null::text						AS c15, --тариф, 
                                
		sum(bee_docs_result.sum_no_tax)::text			AS c16, --стоимость_без НДС, 

            sum(bee_docs_result.sum_no_tax * bee_get_doc_tax(1163,bee_docs.rowid))::text              AS c17, --сумма_НДС,
            sum(bee_docs_result.sum_no_tax * (1 + bee_get_doc_tax(1163,bee_docs.rowid)))::text              AS c18, --стоимость_с НДС,
                                -- 
		bee_docs_sheet.oper_debit::text				AS c19, --обороты_Дт,
		bee_docs_pay.pay_place_typ::text			AS c20, --тип_места_оплаты_код, 
		de2.element_name::text					AS c21, --тип_места_оплаты, 
		bee_docs_pay.pay_vid::text				AS c22, --вид_оплаты_код, 
		de3.element_name::text					AS c23, --вид_оплаты, 
		bee_docs_pay.summ::text					AS c24, 
		bee_docs_sheet.oper_kredit::text			AS c25, --обороты_Кт, 
		
		bds_final.final_debit::text				AS c26, --сальдо_конец_Дт, 
                	bds_final.final_kredit::text				AS c27, --сальдо_конец_Кт,
	      
		agreement.locid::integer				AS c28,
		agreement.accdir::integer				AS c29, --направление учёта
				
		sum(bee_docs_result.tax_sum)::text		 	AS c30, --сумма всего НДС
		sum(bee_docs_result.sum_with_tax)::text			AS c31  --сумма всего с НДС
	    
	       FROM bee_docs 
	       JOIN bee_docs_sheet ON bee_docs_sheet.linkid2 = bee_docs.rowid
	       JOIN dic_elements de1 ON bee_docs.doctyp = de1.rowid 
	      LEFT JOIN bee_docs_result ON bee_docs.rowid=bee_docs_result.linkid 
	      LEFT JOIN dic_tarif_group ON bee_docs_result.tar_grp=dic_tarif_group.rowid 
	      LEFT JOIN dic_elements de4 ON dic_tarif_group.voltage_level=de4.rowid 
	      LEFT JOIN bee_docs_pay ON bee_docs.rowid=bee_docs_pay.linkid2
		    
	      LEFT JOIN dic_elements de2 ON bee_docs_pay.pay_place_typ = de2.rowid 
	      LEFT JOIN dic_elements de3 ON bee_docs_pay.pay_vid = de3.rowid 
	       JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid 
	       JOIN dic_elements de5 ON agreement.accdir=de5.rowid 
	       JOIN customer ON agreement.abo_code = customer.abo_code 
	      --** 2015-06-19	    
	      LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
	      LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
	      --**
	      WHERE doctyp in (1705,1618)
		--AND agreement.docstatus = 79 
		AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	                 AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0
	                        OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
		AND bee_docs_sheet.operdate BETWEEN _date_from AND _date_to
		AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
		AND agreement.valid=true
		AND bee_docs_sheet.npp<>0
		AND agreement.doctype = amntyp	
	      GROUP BY  c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c19,c20,c21,c22,c23,c24,c25,c26,c27,c28,c29, bee_docs_sheet.operdate,bee_docs_sheet.npp,
		    agreement.rowid,bee_docs_sheet.operdate 
	      ORDER BY c5 asc, c6 asc) 
	UNION ALL			  
	    (SELECT 
		de5.element_code::text    				AS c1,  --напрвление_учета_код
		de5.element_name ::text					AS c2,  --направление_учета
		docnumber || ', ' || consum_name::text			AS c3,  --потребитель
		agreement.rowid::text					AS c4,  --код_договора
		bee_docs_sheet.operdate::text				AS c5,
		bee_docs_sheet.npp::text                         	AS c6,
		bee_docs.doctyp::text                            	AS c7,  --тип_документа_код
		de1.element_name::text                           	AS c8,  -- тип_документа
		
		bds_start.start_debit::text				AS c9,  --сальдо_начало_Дт
		bds_start.start_kredit::text				AS c10, -- сальдо_начало_Кт
		  
		bee_docs.docdat::text					AS c11,
		bee_docs.docnum::text                            	AS c12, 
		null::text						AS c13, --уровень_напряжения, 
		sum(CASE WHEN bee_docs_result.tar_typ<>1734
	                         THEN bee_docs_result.amount
	                       ELSE 0
	                   END)::text					AS c14, --кол_во кВт*ч, 
		null::text						AS c15, --тариф, 
		sum(bee_docs_result.sum_no_tax)::text			AS c16, --стоимость_без НДС, 

            (sum(bee_docs_result.sum_no_tax * bee_get_doc_tax(1163,bee_docs.rowid)))::text        AS c17, --сумма_НДС,
            (sum(bee_docs_result.sum_no_tax * (1 + bee_get_doc_tax(1163,bee_docs.rowid))))::text        AS c18, --стоимость_с НДС,
		--   
                                bee_docs_sheet.oper_debit::text				AS c19, --обороты_Дт,
		bee_docs_pay.pay_place_typ::text			AS c20, --тип_места_оплаты_код, 
		de2.element_name::text					AS c21, --тип_места_оплаты, 
		bee_docs_pay.pay_vid::text				AS c22, --вид_оплаты_код, 
		de3.element_name::text					AS c23, --вид_оплаты, 
		bee_docs_pay.summ::text					AS c24, 
		bee_docs_sheet.oper_kredit::text			AS c25, --обороты_Кт, 

		bds_final.final_debit::text				AS c26, --сальдо_конец_Дт, 
                            bds_final.final_kredit::text				AS c27, --сальдо_конец_Кт,
		
		agreement.locid::integer				AS c28,
		agreement.accdir::integer				AS c29, --направление учёта
				
		sum(bee_docs_result.tax_sum)::text		 	AS c30, --сумма всего НДС
		sum(bee_docs_result.sum_with_tax)::text			AS c31  --сумма всего с НДС
		
		
	       FROM bee_docs 
	       JOIN bee_docs_sheet ON bee_docs_sheet.linkid2 = bee_docs.rowid
	       JOIN dic_elements de1 ON bee_docs.doctyp = de1.rowid 
	      LEFT JOIN bee_docs_result ON bee_docs.rowid=bee_docs_result.linkid AND name IN ('-', 'РСК','ФСК')
	      LEFT JOIN dic_tarif_group ON bee_docs_result.tar_grp=dic_tarif_group.rowid 
	      LEFT JOIN dic_elements de4 ON dic_tarif_group.voltage_level=de4.rowid 
	      LEFT JOIN bee_docs_pay ON bee_docs.rowid=bee_docs_pay.linkid2
		    
	      LEFT JOIN dic_elements de2 ON bee_docs_pay.pay_place_typ = de2.rowid 
	      LEFT JOIN dic_elements de3 ON bee_docs_pay.pay_vid = de3.rowid 
	       JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid 
	       JOIN dic_elements de5 ON agreement.accdir=de5.rowid 
	       JOIN customer ON agreement.abo_code = customer.abo_code 
	      --** 2015-06-19	    
	      LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
	      LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
	      --**
	      WHERE doctyp  = 1065
		--AND agreement.docstatus = 79 
		AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	                 AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0
	                        OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
		AND bee_docs_sheet.operdate BETWEEN _date_from AND _date_to
		AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
		AND agreement.valid=true
		AND bee_docs_sheet.npp<>0
		AND agreement.doctype = amntyp	
	      GROUP BY  c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c19,c20,c21,c22,c23,c24,c25,c26,c27,c28,c29, bee_docs_sheet.operdate,bee_docs_sheet.npp,
		    agreement.rowid,bee_docs_sheet.operdate
	      ORDER BY c5 asc, c6 asc)  ORDER BY c5 asc, c6 asc ) AS un ) AS tmprow
      GROUP BY c1,c2,c3,c4,c5,c9, c10,c11, c13, c15,c20,c21,c22,c23,c24,c26,c27, c28,c29        		  
    UNION ALL
	 SELECT 
	    de5.element_code::text					AS c1,  --напрвление_учета_код
	    de5.element_name::text					AS c2,  --направление_учета
	    docnumber || ', ' || consum_name::text			AS c3,  --потребитель
	    agreement.rowid::text					AS c4,  --код_договора
	    bee_docs_sheet.operdate::text				AS c5,
	    bee_docs_sheet.npp::text				AS c6,
	    bee_docs.doctyp::text					AS c7,  --тип_документа_код
	    de1.element_name::text					AS c8,  -- тип_документа
	    
	    bds_start.start_debit::text				AS c9,  --сальдо_начало_Дт
	    bds_start.start_kredit::text				AS c10, -- сальдо_начало_Кт
		  
	    bee_docs.docdat::text					AS c11,
	    bee_docs.docnum::text					AS c12, 
	    '-'::text						AS c13, --уровень_напряжения, 
	    0::text	        					AS c14, --кол_во кВт*ч, 
	    0::text							AS c15, --тариф, 
	    0::text 						AS c16, --стоимость_без НДС, 
	    0::text							AS c17, --сумма_НДС, 
	    0::text							AS c18, --стоимость_с НДС, 
	    0::text	     						AS c19, --обороты_Дт,
	    bee_docs_pay.pay_place_typ::text			AS c20, --тип_места_оплаты_код, 
	    de2.element_name::text					AS c21, --тип_места_оплаты, 
	    bee_docs_pay.pay_vid::text				AS c22, --вид_оплаты_код, 
	    de3.element_name ::text					AS c23, --вид_оплаты, 
	    bee_docs_pay.summ::text					AS c24, 
	    0::text	 						AS c25, --обороты_Кт, 

	    bds_final.final_debit::text				AS c26, --сальдо_конец_Дт, 		
                        bds_final.final_kredit::text				AS c27, --сальдо_конец_Кт,
		
	    agreement.locid::integer				AS c28,
	    agreement.accdir::integer				AS c29,  -- направление учёта
	    0::text					 		AS c30,   --сумма всего НДС
	    0::text					 		AS c31   --сумма всего с НДС
	    
	   FROM bee_docs_sheet 
	   JOIN bee_docs ON bee_docs_sheet.linkid2 = bee_docs.rowid 
	   JOIN dic_elements de1 ON bee_docs.doctyp = de1.rowid 
		
          LEFT JOIN bee_docs_pay ON bee_docs.rowid=bee_docs_pay.linkid2
          LEFT JOIN bee_docs_result ON bee_docs.rowid=bee_docs_result.linkid
          LEFT JOIN dic_elements de2 ON bee_docs_pay.pay_place_typ = de2.rowid
          LEFT JOIN dic_elements de3 ON bee_docs_pay.pay_vid = de3.rowid
	   JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid
	   JOIN dic_elements de5 ON agreement.accdir=de5.rowid
	   JOIN customer ON agreement.abo_code = customer.abo_code
          --** 2015-06-19	    
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
          --**
	  WHERE doctyp = 1713 
	    --AND agreement.docstatus = 79 
	    AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	         AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0 
	                OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
	    AND bee_docs_sheet.operdate BETWEEN _date_from AND _date_to
	    AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
	    AND agreement.valid=true
	    AND bee_docs_sheet.npp<>0
	    AND agreement.doctype = amntyp
    UNION ALL
	 SELECT 
	    de5.element_code::text 					AS c1,
	    de5.element_name::text					AS c2,
	    docnumber || ', ' || consum_name::text 			AS c3, 
	    agreement.rowid::text 					AS c4,
	    bee_docs_sheet.operdate::text				AS c5, 
	    bee_docs_sheet.npp::text				AS c6, 
	    '1065'::text						AS c7,
	    '-'::text						AS c8,
	    
	    bds_start.start_debit::text				AS c9,  --сальдо_начало_Дт
	    bds_start.start_kredit::text				AS c10, -- сальдо_начало_Кт
	      
	    _date_from::text					AS c11,
	    0::text							AS c12,
	    '-'::text						AS c13,
	    0::text							AS c14,
	    0::text							AS c15,
	    0::text							AS c16,
	    0::text							AS c17,
	    0::text							AS c18,
	    0::text							AS c19,
	    0::text							AS c20,
	    '-'::text						AS c21,
	    0::text							AS c22,
	    '-' ::text						AS c23,
	    0::text							AS c24,
	    0::text							AS c25,
	    
	    bds_final.final_debit::text				AS c26, --сальдо_конец_Дт, 
	    bds_final.final_kredit::text				AS c27, --сальдо_конец_Кт,
	    
	    agreement.locid::integer				AS c28,
	    agreement.accdir::integer				AS c29,
	    0::text							AS c30,   --сумма всего НДС
	    0::text							AS c31   --сумма всего с НДС
			    
	   FROM bee_docs_sheet
	   JOIN (SELECT tab.linkid1, tab.operdate, tab.npp 
	       FROM (SELECT linkid1, operdate, MAX(npp) AS npp
		   FROM bee_docs_sheet 
		  WHERE operdate < _date_from
		    AND linkid1 NOT IN (SELECT linkid1 FROM bee_docs_sheet WHERE operdate BETWEEN _date_from AND _date_to)
		  GROUP by linkid1, operdate ORDER BY operdate) AS tab 
	       JOIN (SELECT linkid1, MAX(operdate) AS operdate 
		   FROM (SELECT linkid1, operdate, MAX(npp) AS npp
		       FROM bee_docs_sheet 
		      WHERE operdate < _date_from
		        AND linkid1 NOT IN (SELECT linkid1 FROM bee_docs_sheet WHERE operdate BETWEEN _date_from AND _date_to)
		      GROUP by linkid1, operdate ORDER BY operdate) AS tab1 
		  GROUP BY linkid1) AS tab3 ON tab.linkid1=tab3.linkid1 AND tab.operdate=tab3.operdate
	    ) AS bds ON bee_docs_sheet.linkid1=bds.linkid1 AND bee_docs_sheet.operdate=bds.operdate
		AND bee_docs_sheet.npp=bds.npp
	   JOIN agreement ON bee_docs_sheet.linkid1=agreement.rowid
	   JOIN dic_elements de5 ON agreement.accdir=de5.rowid
	   JOIN customer ON agreement.abo_code = customer.abo_code
          --** 2015-06-19	    
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'asc') AS bds_start ON bds_start.linkid1 = agreement.rowid
          LEFT JOIN bee_fill_turnover_statement_get_debit_kredit(agreement.rowid,_date_from, _date_to, 'desc') AS bds_final ON bds_final.linkid1 = agreement.rowid
          --**
	  WHERE bee_docs_sheet.operdate < _date_from
	   --AND agreement.docstatus = 79 
	   AND (     agreement.docstatus = 79 OR agreement.docstatus = 77 AND agreement.closedate IS NOT NULL 
	    AND (agreement.closedate >= _date_from OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0 
	           OR bds_start.start_debit<>0 OR bds_start.start_kredit<>0)) --2015-07-14, 2015-12-14
	   AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
	   AND agreement.valid= true
	   AND agreement.rowid NOT IN (SELECT linkid1 FROM bee_docs_sheet WHERE bee_docs_sheet.operdate BETWEEN _date_from AND _date_to)
	   AND (bds_start.start_debit <>0 OR bds_start.start_kredit<>0 OR bds_final.final_debit<>0 OR bds_final.final_kredit<>0) --2015-07-14
	   AND bee_docs_sheet.npp<>0
	   AND agreement.doctype = amntyp
	 );
    END IF; 	   
END;
$$;

comment on function bee_fill_turnover_statement(integer, text, text, integer) is 'Оборотно-сальдовая ведомость. Используется в TurnoverStatement.java';

alter function bee_fill_turnover_statement(integer, text, text, integer) owner to pgsql;

