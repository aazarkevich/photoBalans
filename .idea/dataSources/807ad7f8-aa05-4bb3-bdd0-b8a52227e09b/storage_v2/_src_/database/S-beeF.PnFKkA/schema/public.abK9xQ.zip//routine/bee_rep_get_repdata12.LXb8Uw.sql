create function bee_rep_get_repdata12(loc integer, str_date date, end_date date) returns SETOF bee_rep_tab12_new
    language sql
as
$$
/*
   ito16
   10.12.09
*/
SELECT
   a.docnum,
   a.nam,
   a.month,
   b.month_q::int,
   a.sd,
   a.sk,
   a.od,
   a.ok,
   a.fd,
   a.fk,
   a.grp
FROM
   (SELECT * FROM bee_rep_get_repdata12_tmp($1,$2,$3)) AS a
   JOIN 
   (SELECT
      month_quantity AS rowid,
      count(month_quantity) AS month_q
    FROM
      bee_rep_get_repdata12_tmp($1,$2,$3)
    GROUP BY month_quantity
   ) AS b ON a.month_quantity = b.rowid
$$;

comment on function bee_rep_get_repdata12(integer, date, date) is 'Движение остатков по потребителю. Используется в RepCreate12.java';

alter function bee_rep_get_repdata12(integer, date, date) owner to pgsql;

