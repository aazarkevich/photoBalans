create function bee_add_customer_info(custcode integer) returns integer
    language plpgsql
as
$$
BEGIN
--
INSERT INTO customer_info (abo, elrowid, item) 
(SELECT custcode,rowid,'?' FROM dic_elements 
 WHERE 
    link = 26 AND
    rowid NOT IN 
    (
      SELECT elrowid FROM customer_info WHERE abo = custcode
    ) 
);
RETURN 0;
--
END;
$$;

comment on function bee_add_customer_info(integer) is 'Создание параметров для потребителя. Используется в CustomerForm.java, AppUtils.java';

alter function bee_add_customer_info(integer) owner to pgsql;

