create function bee_rep_get_repdata25_content_result(link integer) returns SETOF bee_repdata25_result
    language plpgsql
as
$$
/*
    add ito06 2020-02-04 Если потребителю выставлен только корректировочный счет-фактура, договор расторгнут и выставление счет-фактуры в расчетном периоде не произведено, 
                        нужно учитывать сумму корр
    add ito06 2016-06-17 если показания  0 и сумма без НДС 0, то и сумма с НДС 0
    add ito06 2016-05-27 при расчете обычной с-ф не берем строки корректировки
    add ito06 2015-06-23
    add ito06 2015-05-28
    ito06 2015-01-16: Реализация эл эн
    param: (0 sum_with_tax и tax_sum=0 расчет summ(sum_with_tax) для 1068,1168 и (1069,1159, 1707,1142)отдельно
	1 sum_with_tax и tax_sum=0 расчет summ(sum_with_tax) для 1068,1168 1069,1159, 1707,1142 все вместе из bee_docs_sheet
	2 sum_with_tax и tax_sum < >0 записываются, так как есть
     
*/
DECLARE
   RowLine record;
   count int = 0;	
   summ numeric = 0;	
   summ_1068 numeric = 0;
   summ_1069 numeric = 0;	
  _doctyp int := 0;
  _row int :=0;
  _param int :=0;
    
BEGIN
   SELECT doctyp  FROM bee_docs  where rowid = link  INTO _doctyp;
   IF  _doctyp IS NULL THEN  _doctyp = 0; END IF;

   SELECT sum(sum_with_tax) FROM bee_docs_result WHERE linkid = link INTO summ;   
   if summ is null then summ=0;   end if;
   
   IF summ = 0 --1 если в bee_docs_result поля sum_with_tax и tax_sum = 0
      THEN --1    
		 SELECT sum(COALESCE(sum_no_tax,0)) FROM  bee_docs_result 
		 WHERE linkid = link  AND tar_typ IN (1068,1168) INTO summ_1068;

		 SELECT sum(COALESCE(sum_no_tax,0)) FROM  bee_docs_result 
		 WHERE linkid = link  AND tar_typ IN (1069,1159, 1707,1142) INTO summ_1069;

     count = 0;
     IF (summ_1068 <> 0)  --2 расчитываем для 1068,1168 если есть и 1069,1159,1707,1142
        THEN --2 
           FOR RowLine IN 
		   (  select *, 0 AS param from bee_docs_result AS res 
              where res.linkid = link AND tar_typ IN (1068,1168) 
              order by name, tar_typ, row_typ)
           LOOP  
			  count = count+1;
			  IF count = 1 THEN 
				 RowLine.sum_with_tax = summ_1068 * (1 + bee_get_doc_tax(1163, link))::numeric(20,2) ;-- 1.18; 
			  END IF;
			  RETURN NEXT RowLine; 
           END LOOP;
     ELSE  -- 2 берем из sheet для для 1068,1168, если  1069,1159,1707,1142 нет
          FOR RowLine IN (
              select *, 0 AS param from bee_docs_result AS res 
              where res.linkid = link AND tar_typ IN (1068,1168) 
              order by name, tar_typ, row_typ)
          LOOP 
			 count=count+1;			
			 IF RowLine.sum_with_tax = 0 --7
				THEN --7
				  IF count = 1 AND RowLine.amount <> 0 --8 2016-06-17
				  THEN  --8
					select oper_debit from bee_docs_sheet 
					where linkid2 = link  INTO RowLine.sum_with_tax;	 
				  END IF; --8
				  RETURN NEXT RowLine;    				 
			 END IF; --7			
          END LOOP;		   
     END IF;--2
	
     count = 0;
     IF (_doctyp <> 1065) --3
	 	THEN --3 2016-05-27 
            IF (summ_1069 <> 0)  --4 расчитываем для 1069,1159, 1707,1142 если есть и 1068,1168
           THEN  
				FOR RowLine IN (
					 select *, 0 AS param  from bee_docs_result AS res
					 where res.linkid = link AND tar_typ IN(1069,1159,1707,1142) 
					 order by name, tar_typ, row_typ)
			  LOOP  
				 count = count+1;
				 IF count=1 THEN 
					 RowLine.sum_with_tax = summ_1069 * (1 + bee_get_doc_tax(1163, link))::numeric(20,2) ; --1.18; 
				 END IF;
				 RETURN NEXT RowLine; 
			  END LOOP;  
	  ELSE --4 берем из sheet для для 1069,1159,1707,1142, если 1068,1168  нет
		   FOR RowLine IN (
			  select *, 0 AS param from bee_docs_result AS res
			  where res.linkid = link AND tar_typ IN(1069,1159,1707,1142) order by name, tar_typ, row_typ)
		   LOOP 
			  count = count + 1;			
			  IF RowLine.sum_with_tax = 0 THEN
				 IF  count = 1 THEN  
					 select oper_debit  from bee_docs_sheet 
					 where linkid2 = link INTO RowLine.sum_with_tax;		 
				 END IF;
			 RETURN NEXT RowLine;    
			  END IF;			
		   END LOOP;		   
        END IF; --4
     END IF; --**2
	 
     count = 0; -- для всех
		 FOR RowLine IN (SELECT *, 1 AS param FROM bee_docs_result WHERE linkid = link)
		 LOOP 
		   count =count+1;			
		   IF RowLine.sum_with_tax = 0 THEN
			  IF  count = 1 THEN
				 select oper_debit  from bee_docs_sheet 
				 where linkid2 = link INTO RowLine.sum_with_tax;
				 RETURN NEXT RowLine;    				 
			  END IF ;
		   END IF;			
		 END LOOP;
    ELSE --1
      IF (_doctyp = 1618) THEN --5
	   	--** 2020-02-04 если корр последний документ для договора, то данные из result долдны подать
		select bd.rowid from bee_docs AS bd  join  bee_docs AS bd2 ON bd2.linkid = bd.linkid AND bd2.rowid = $1 AND bd.docdat>= bd2.docdat   AND bd.doctyp = 1065 limit 1 INTO _row;
		
			if (_row IS NULL) --10
				then --10 значит корр поледний док
						_param = 6;
				 else --10
						 _param =5;
			end if; --10
		--**
          FOR RowLine IN (
          select *, _param AS param from bee_docs_result AS res 
          where res.linkid = link and (res.row_typ = 1071 or res.row_typ = 1070))
          LOOP 
          	RETURN NEXT RowLine; 
          END LOOP;
      else --5
          FOR RowLine IN (
          select *, 2 AS param  from bee_docs_result AS res 
          where res.linkid = link)
          LOOP  	
         	RETURN NEXT RowLine; 
          END LOOP;
      end if; --5	
   END IF;	--1						
END;
$$;

comment on function bee_rep_get_repdata25_content_result(integer) is 'Реализация эл эн. Используется в bee_rep_get_repdata25_content(integer, date, date)';

alter function bee_rep_get_repdata25_content_result(integer) owner to pgsql;

