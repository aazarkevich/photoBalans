create view bee_docs_nocalc(agrid, docid, agrnum, docnum, docdat, lnkc, lnkr) as
SELECT DISTINCT agr.rowid     AS agrid,
                doc.rowid     AS docid,
                agr.docnumber AS agrnum,
                doc.docnum,
                doc.docdat,
                CASE
                    WHEN (cal.linkid1 IS NULL) THEN NULL::text
                    ELSE 'X'::text
                    END       AS lnkc,
                CASE
                    WHEN (res.linkid IS NULL) THEN NULL::text
                    ELSE 'X'::text
                    END       AS lnkr
FROM ((((agreement agr
    JOIN bee_docs doc ON (((agr.rowid = doc.linkid) AND (doc.doctyp = 1065))))
    LEFT JOIN bee_docs_calc cal ON ((doc.rowid = cal.linkid1)))
    LEFT JOIN agreepoint pnt ON ((cal.linkid2 = pnt.rowid)))
         LEFT JOIN bee_docs_result res ON ((doc.rowid = res.linkid)))
WHERE ((agr.docstatus = 79) AND (doc.docnum IS NOT NULL) AND ((cal.linkid1 IS NULL) OR (res.linkid IS NULL)) AND
       (agr.doctype = 1910))
ORDER BY agr.rowid, doc.rowid DESC, doc.docdat DESC;

alter table bee_docs_nocalc
    owner to postgres;

