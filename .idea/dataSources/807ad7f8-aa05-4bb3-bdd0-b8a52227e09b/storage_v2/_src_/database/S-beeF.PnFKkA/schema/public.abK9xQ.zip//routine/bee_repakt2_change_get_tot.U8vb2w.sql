create function bee_repakt2_change_get_tot(bd_rowid integer, diff boolean, _doctyp integer) returns SETOF bee_repakt2_tot_tab
    language plpgsql
as
$$
/*
	ito06 2015-07-09: Акт (соц. норма) для исправления или корректировки.
*/
DECLARE newform numeric = 0;
	_docdat date;
	datnew date := '2014-09-30';
	rec record;
	_tartyp text = '0';
	
BEGIN 
	IF _doctyp  = 1 
           THEN	--исправление
		_tartyp = '1707,1142';
	   ELSIF _doctyp  = 2
	      THEN 	
		--корректировка 
		_tartyp = '1069,1159';           		
        END IF;
        
	SELECT sum(sum_with_tax) FROM bee_docs_result where linkid =$1 INTO newform;
	SELECT bd.docdat FROM bee_docs AS bd where  bd.rowid =$1 limit 1 INTO _docdat;	
		
	IF (newform  = 0 OR _docdat>datnew) 
	   THEN FOR rec IN  (SELECT 
				vn[1] 			AS vn_sum_no_tax,
				null::numeric 		AS vn_tax,
				null::numeric 		AS vn_sum,
				sn1[1] 			AS sn1_sum_no_tax,
				null::numeric 		AS sn1_tax,
				null::numeric 		AS sn1_sum,
				sn2[1] 			AS sn2_sum_no_tax,
				null::numeric 		AS sn2_tax,
				null::numeric 		AS sn2_sum,
				nn[1] 			AS nn_sum_no_tax,
				null::numeric 		AS nn_tax,
				null::numeric 		AS nn_sum,
				tot[1] 			AS tot_sum_no_tax,
				(select sum (a) from unnest (ARRAY[tot[2],fsk[2],rsk[2]]) AS a)::numeric(16,2)  AS tot_tax,
				(select sum (a) from unnest (ARRAY[tot[3],fsk[3],rsk[3]]) AS a)::numeric(16,2) AS tot_sum
			FROM    bee_repakt2_change_get_tot_all($1,diff, _tartyp) AS tot,
				bee_repakt2_change_get_tot_vn($1,diff, _tartyp) AS vn,
				bee_repakt2_change_get_tot_sn1($1,diff,_tartyp) AS sn1,
				bee_repakt2_change_get_tot_sn2($1,diff,_tartyp) AS sn2,
				bee_repakt2_change_get_tot_nn($1,diff,_tartyp) AS nn,
				bee_repakt2_change_get_tot_loss2($1, 1731,_tartyp) AS fsk,
				bee_repakt2_change_get_tot_loss2($1, 1732,_tartyp) AS rsk)
		LOOP
			return next rec;
		END LOOP;		
	  ELSE FOR rec IN (SELECT 
				vn[1] AS vn_sum_no_tax,
				vn[2] AS vn_tax,
				vn[3] AS vn_sum,
				sn1[1] AS sn1_sum_no_tax,
				sn1[2] AS sn1_tax,
				sn1[3] AS sn1_sum,
				sn2[1] AS sn2_sum_no_tax,
				sn2[2] AS sn2_tax,
				sn2[3] AS sn2_sum,
				nn[1] AS nn_sum_no_tax,
				nn[2] AS nn_tax,
				nn[3] AS nn_sum,
				tot[1] AS tot_sum_no_tax,
				(select sum (a) from unnest (ARRAY[tot[2],fsk[2],rsk[2]]) AS a)::numeric(16,2)  AS tot_tax,
				(select sum (a) from unnest (ARRAY[tot[3],fsk[3],rsk[3]]) AS a)::numeric(16,2) AS tot_sum
			FROM    bee_repakt2_change_get_tot_all($1,diff, _tartyp) AS tot,
				bee_repakt2_change_get_tot_vn($1,diff, _tartyp) AS vn,
				bee_repakt2_change_get_tot_sn1($1,diff, _tartyp) AS sn1,
				bee_repakt2_change_get_tot_sn2($1,diff, _tartyp) AS sn2,
				bee_repakt2_change_get_tot_nn($1,diff, _tartyp) AS nn,
				bee_repakt2_change_get_tot_loss2($1, 1731, _tartyp) AS fsk,
				bee_repakt2_change_get_tot_loss2($1, 1732, _tartyp) AS rsk)
		LOOP
			return next rec;
		END LOOP;
	END IF;				
END;
$$;

comment on function bee_repakt2_change_get_tot(integer, boolean, integer) is 'Акт (сверх нормы) для исправления или корректировки. Используется в repakt2_change.java';

alter function bee_repakt2_change_get_tot(integer, boolean, integer) owner to pgsql;

