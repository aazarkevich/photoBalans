create view vbee_agreeregdev_const_real (linkid, rowid, paramid, paramval, refs, element_name, element_type, sort) as
SELECT agreeregdev.linkid,
       agreeregdev.rowid,
       agreeregdev.paramid,
       agreeregdev.paramval,
       dic_elements.refs,
       dic_elements.element_name,
       dic_elements.element_type,
       CASE
           WHEN ("position"((dic_elements.element_name)::text, '*'::text) > 0) THEN 1
           ELSE 2
           END AS sort
FROM ((agreeregdev
    JOIN dic_elements ON ((agreeregdev.paramid = dic_elements.rowid)))
         JOIN agreeregdev_paramids ON ((agreeregdev.paramid = agreeregdev_paramids.paramid)))
WHERE ((dic_elements.link = 38) AND (agreeregdev_paramids.const = true) AND ((agreeregdev_paramids.tag)::text IS NULL))
ORDER BY CASE
             WHEN ("position"((dic_elements.element_name)::text, '*'::text) > 0) THEN 1
             ELSE 2
             END, dic_elements.element_code;

comment on view vbee_agreeregdev_const_real is 'Используется в DeviceParamC.java, SessionBean1.java';

alter table vbee_agreeregdev_const_real
    owner to pgsql;

