create function bee_rep_get_history975_content(_rowid integer) returns SETOF hitory975_content
    language sql
as
$$
/*
	
	ito06 2015-02-06: История заргузок по устройству
*/
		 SELECT rdo194.valman 			AS datecurr,
			rdo195.valman 			AS pokcurr,
			rdo196.valman 			AS pokbefore,
			rdo197.valman 			AS datebefore,
			rdo198.valman 			AS difference,
			rdo985.valman 			AS sumsbit
		   FROM agreepoint  AS apn
	      LEFT JOIN regdevoper975 As rdo194 ON rdo194.linkid = apn.rowid AND rdo194.paramid = 194 
	      LEFT JOIN regdevoper975 As rdo195 ON rdo195.linkid = apn.rowid AND rdo195.paramid = 195 AND rdo195.operdate =rdo194.operdate
	      LEFT JOIN regdevoper975 As rdo196 ON rdo196.linkid = apn.rowid AND rdo196.paramid = 196 AND rdo196.operdate =rdo194.operdate
	      LEFT JOIN regdevoper975 As rdo197 ON rdo197.linkid = apn.rowid AND rdo197.paramid = 197 AND rdo197.operdate =rdo194.operdate
	      LEFT JOIN regdevoper975 As rdo198 ON rdo198.linkid = apn.rowid AND rdo198.paramid = 198 AND rdo198.operdate =rdo194.operdate
	      LEFT JOIN regdevoper975 As rdo985 ON rdo985.linkid = apn.rowid AND rdo985.paramid = 985 AND rdo985.operdate =rdo194.operdate
	          WHERE apn.rowid = _rowid
	         ORDER BY rdo194.valman DESC
$$;

comment on function bee_rep_get_history975_content(integer) is 'История заргузок по устройству. Используется в AgreeRegExt.java';

alter function bee_rep_get_history975_content(integer) owner to postgres;

