create function bee_repakt2_get_tot(bd_rowid integer) returns SETOF bee_repakt2_tot_tab
    language plpgsql
as
$$
/*
	add ito06 2015-05-22
	add ito06 2014-11-26
	add ito06 2013-10-24
	ito06 2013-09-25 Акт (сверх нормы)
*/
DECLARE newform numeric = 0;
	_docdat date;
	datnew date := '2014-09-30';
	rec record;
BEGIN 
	SELECT sum(sum_with_tax) FROM bee_docs_result where linkid =$1 INTO newform;
	SELECT bd.docdat FROM bee_docs AS bd where  bd.rowid =$1 limit 1 INTO _docdat;	
		
	IF (newform  = 0 OR _docdat>datnew) 
	   THEN FOR rec IN  (SELECT 
				vn[1] 			AS vn_sum_no_tax,
				null::numeric 		AS vn_tax,
				null::numeric 		AS vn_sum,
				sn1[1] 			AS sn1_sum_no_tax,
				null::numeric 		AS sn1_tax,
				null::numeric 		AS sn1_sum,
				sn2[1] 			AS sn2_sum_no_tax,
				null::numeric 		AS sn2_tax,
				null::numeric 		AS sn2_sum,
				nn[1] 			AS nn_sum_no_tax,
				null::numeric 		AS nn_tax,
				null::numeric 		AS nn_sum,
				tot[1] 			AS tot_sum_no_tax,
				(select sum (a) from unnest (ARRAY[tot[2],fsk[2],rsk[2]]) AS a)::numeric(16,2)  AS tot_tax,
				(select sum (a) from unnest (ARRAY[tot[3],fsk[3],rsk[3]]) AS a)::numeric(16,2) AS tot_sum
			FROM    bee_repakt2_get_tot_all($1) AS tot,
				bee_repakt2_get_tot_vn($1) AS vn,
				bee_repakt2_get_tot_sn1($1) AS sn1,
				bee_repakt2_get_tot_sn2($1) AS sn2,
				bee_repakt2_get_tot_nn($1) AS nn,
				bee_repakt2_get_tot_loss2($1, 1731) AS fsk,
				bee_repakt2_get_tot_loss2($1, 1732) AS rsk)
		LOOP
			return next rec;
		END LOOP;		
	  ELSE FOR rec IN (SELECT 
				vn[1] AS vn_sum_no_tax,
				vn[2] AS vn_tax,
				vn[3] AS vn_sum,
				sn1[1] AS sn1_sum_no_tax,
				sn1[2] AS sn1_tax,
				sn1[3] AS sn1_sum,
				sn2[1] AS sn2_sum_no_tax,
				sn2[2] AS sn2_tax,
				sn2[3] AS sn2_sum,
				nn[1] AS nn_sum_no_tax,
				nn[2] AS nn_tax,
				nn[3] AS nn_sum,
				tot[1] AS tot_sum_no_tax,
				(select sum (a) from unnest (ARRAY[tot[2],fsk[2],rsk[2]]) AS a)::numeric(16,2)  AS tot_tax,
				(select sum (a) from unnest (ARRAY[tot[3],fsk[3],rsk[3]]) AS a)::numeric(16,2) AS tot_sum
			FROM    bee_repakt2_get_tot_all($1) AS tot,
				bee_repakt2_get_tot_vn($1) AS vn,
				bee_repakt2_get_tot_sn1($1) AS sn1,
				bee_repakt2_get_tot_sn2($1) AS sn2,
				bee_repakt2_get_tot_nn($1) AS nn,
				bee_repakt2_get_tot_loss2($1, 1731) AS fsk,
				bee_repakt2_get_tot_loss2($1, 1732) AS rsk)
		LOOP
			return next rec;
		END LOOP;
	END IF;				
END;
$$;

comment on function bee_repakt2_get_tot(integer) is 'Акт (сверх нормы). Используется в RepAkt2.java';

alter function bee_repakt2_get_tot(integer) owner to pgsql;

