create function bee_get_filsrek(_locid integer) returns SETOF bee_filsrek
    language sql
as
$$
/*
	add ito06 2016-04-14 добавился параметр 1916
	add ito06 2016-02-29 добавились параметры 1907,1908, добавили сортировку
	add ito06 2016-01-20 добавились параметры 1902,1903,1904 
	ito06 2015-03-08 Получить реквизиты филиала 
*/
SELECT DISTINCT * 
          FROM (--параметры, которые для всех участков одни
                (SELECT linkid 			AS linkid, 
			paramid 		AS paramid, 
			dic.element_name	AS element_name, 
			paramval 		AS paramval, 
			dic.element_code	AS npp
		FROM denet_info AS de
		JOIN dic_elements AS dic on de.paramid = dic.rowid 
		WHERE case when (select ((select count(distinct(linkid)) from denet_info) = 1 AND (select linkid from denet_info limit 1) = 644)) = TRUE 
			   then linkid = 644 else linkid != 644 end and paramid NOT IN (1527,1815,1816,1817,1818,1819,1820, 1902,1903,1904,1907,1908, 1916) --**ito06 2016-01-20
		  AND paramid NOT IN (1849,1850,1851,1852) --эти параметры не должны отображаться (для печати актов)
		ORDER BY paramid)
	 UNION --параметры, которые для разных участков разные
	       (SELECT  linkid 			AS linkid, 
			paramid 		AS paramid, 
			dic.element_name 	AS element_name, 
			paramval 		AS paramval, 
			dic.element_code	AS npp
		FROM denet_info AS de 
		JOIN dic_elements  AS dic on de.paramid = dic.rowid 
		WHERE paramid IN (1527,1815,1816,1817,1818,1819,1820,1902,1903,1904,1907,1908, 1916) AND de.linkid = _locid --**ito06 2016-01-20
		  AND paramid NOT IN (1849,1850,1851,1852) --эти параметры не должны отображаться (для печати актов)
		ORDER BY paramid)) AS a ORDER BY npp, linkid, paramid;

$$;

comment on function bee_get_filsrek(integer) is 'Получить реквизиты филиала. Используется в FilsRec.java, SessionBean1.java';

alter function bee_get_filsrek(integer) owner to pgsql;

