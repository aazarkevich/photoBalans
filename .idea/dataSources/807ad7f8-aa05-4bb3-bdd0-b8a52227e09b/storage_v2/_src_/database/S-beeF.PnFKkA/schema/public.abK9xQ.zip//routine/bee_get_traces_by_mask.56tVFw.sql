create function bee_get_traces_by_mask(lid integer, mask character varying) returns text
    language plpgsql
as
$$
    --
-- ОТБОР ТОЧЕК ПОДКЛЮЧЕНИЯ ПО МАСКЕ (pchain)
-- lid : код места обработки
-- mask: фильтр
-- 
DECLARE
   Rec            RECORD; 
   IdList         TEXT := '';
   Delim CONSTANT CHAR := '|'; 
   EntryNode      INTEGER; 
--
BEGIN
   --
   EntryNode := bee_get_entry_node(lid);
   FOR Rec IN (
    SELECT pointid AS pid FROM regdevconn -- код точки привязки
    LEFT JOIN gis_traces ON gis_traces.rowid = regdevconn.traceid
    WHERE 
       gis_traces.locid      = EntryNode AND
       regdevconn.locid      = lid       AND
       gis_traces.pchain ILIKE mask
       ORDER BY pchain 	
   ) LOOP
      IdList = IdList || Rec.pid || Delim;
   END LOOP;       
   --
   RETURN IdList; 
--
END;
$$;

comment on function bee_get_traces_by_mask(integer, varchar) is 'Отбор точек подключения по маске (pchain). Используется в ConnectDevice.java, AppUtils.java';

alter function bee_get_traces_by_mask(integer, varchar) owner to pgsql;

