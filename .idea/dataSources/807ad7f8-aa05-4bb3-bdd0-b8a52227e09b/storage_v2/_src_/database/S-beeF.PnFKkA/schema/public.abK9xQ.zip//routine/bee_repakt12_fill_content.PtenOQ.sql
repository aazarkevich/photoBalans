create function bee_repakt12_fill_content(bd_rowid integer) returns SETOF integer[]
    language plpgsql
as
$$
/*
	ito06 2021-02-02 Акт (соц. норма) без корр - создание временной таблицы
*/
BEGIN
	DROP TABLE IF EXISTS tmp_repakt12_content;
	CREATE TEMPORARY table tmp_repakt12_content 
	  AS ( SELECT * 
		FROM		 ((select * from bee_repakt2_get_intermediate_content1($1))
			UNION ALL (select * from bee_repakt2_get_intermediate_content2($1))) AS a
			WHERE tot_amount IS NOT NULL
			ORDER BY period, grp, tarname_grp);
END;
$$;

comment on function bee_repakt12_fill_content(integer) is 'Акт (соц. норма) без корр. Используется в bee_repakt12_get_content , RepAkt12.java';

alter function bee_repakt12_fill_content(integer) owner to postgres;

