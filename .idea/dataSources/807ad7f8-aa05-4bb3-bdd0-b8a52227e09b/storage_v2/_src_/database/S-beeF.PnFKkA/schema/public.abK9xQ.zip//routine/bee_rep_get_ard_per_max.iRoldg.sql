create function bee_rep_get_ard_per_max(_paramid integer, period date) returns SETOF bee_ard_tab_with_per
    language plpgsql
as
$$
/*
	add ito06 2015-06-18 изменили тип возврата
	ito06 2014-09-16
*/
DECLARE 
	filt varchar;
BEGIN

IF _paramid NOT IN (439,689,664,1015) --значения из dic_elements
    THEN 
	filt =' AND paramval IS NOT NULL 
		AND paramval <> '||quote_literal('-')||'
		AND paramval <> '||quote_literal('')||'
		AND paramval <> '||quote_literal('0')||'
		AND paramval <> '||quote_literal('?')||' ';
    ELSE
	IF _paramid  = 664 
	    THEN filt = ' AND ((is_numeric(paramval) AND length(paramval)>7) OR (paramval = '||quote_literal('0')||'))';
	    ELSE filt = ' AND is_numeric(paramval)';
	END IF; 
END IF;

RETURN QUERY EXECUTE 
	'SELECT 
		ard.linkid AS linkid,
		ard.paramval AS paramval,
		ard. period AS period
		FROM agreeregdev_period AS ard
		JOIN (SELECT max(period) AS period, linkid
			FROM agreeregdev_period 
                       WHERE paramid='||$1||'  AND
                             period < '''||$2||''' 
		       GROUP BY linkid
                     ) AS per ON per.period = ard.period AND per.linkid = ard.linkid
     WHERE ard.paramid = '||$1||' '||filt||'';
 
 END;
$$;

comment on function bee_rep_get_ard_per_max(integer, date) is 'Используется в bee_repakt7_get_vals(int, date, date, boolean), bee_repakt7_get_vals_975(int, date, date, boolean)';

alter function bee_rep_get_ard_per_max(integer, date) owner to pgsql;

