create function bee_is_counter_online(pointid integer) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN not EXISTS (
       SELECT 1 FROM agreeregdev 
       WHERE linkid = pointid 
       AND paramid = 690
       AND paramval like '____-__-__'
    );
END;
$$;

comment on function bee_is_counter_online(integer) is 'проверка : счётчик включен/снят';

alter function bee_is_counter_online(integer) owner to pgsql;

