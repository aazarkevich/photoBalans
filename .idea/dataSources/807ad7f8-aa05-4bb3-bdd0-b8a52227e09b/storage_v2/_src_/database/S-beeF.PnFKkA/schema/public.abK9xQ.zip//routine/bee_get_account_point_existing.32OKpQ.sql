create function bee_get_account_point_existing(p_date date)
    returns TABLE(id_sys integer, id_external_point integer, account_number character varying, is_legal integer, id_voltage_level integer, is_calc_counter integer, prod_number character varying, id_sign_account_point integer, docnumber character varying, existing integer, locid character varying, customer_name character varying, name_point character varying, adr_point character varying, type_device character varying, name_feeder character varying, category_reliability character varying, max_pow_agreement character varying, type_point integer, id_golov character varying, name_ps character varying, date_removal date)
    language sql
as
$$
select distinct

	 case
	 	  when right((select split_part(kod, ' ', 1) from denet where length(kod) = 6), 2) = '66' 
	 	   then '66'||  right((select split_part(kod, ' ', 1) from denet where length(kod) = 9), 1)

	 	  else right((select split_part(kod, ' ', 1) from denet where length(kod) = 6), 2) 
	  	  
	  end::int as id_sys, 
		
		apn.rowid as id_external_point,			
		apn.account as account_number, 
		
		case when lower(left((select current_database()), 4))  like 'beeu' 
			then 1
			else 0
		end		as is_legal,
		
		case
  			when ard439.paramval = '311' then 1
			when ard439.paramval = '308' then 2
			when ard439.paramval = '310' then 3
			when ard439.paramval = '306' then 4
			else 5
 		 
 		 end  		 as id_voltage_level,
		
		
		case when rdo.valman = '435' or rdo.valman  is null
			then 1
			else 0 
		end as is_calc_counter,
		
		apn.prodnumber as prod_number, 
		
 		 
 		case 
 		   when amn.doctype = 1910 and amn.accdir not in (1025, 441) then 7
 		   when amn.doctype = 1910 and amn.accdir in (1025, 441)  then 8
 		   when amn.doctype <> 1910 and ardp2009.paramval is not null and ardp2009.paramval = '383'	then 2
   		   when amn.doctype <> 1910 and amn.accdir in (842,1185,837,840, 1186,832, 839,1026,836,838,841,1184,1623,835, 316, 1190, 318)	then 3
  		   when amn.doctype <> 1910 and amn.accdir in (1025)	then 4
   		   when amn.doctype <> 1910 and amn.accdir in (441)	then 5
		   when amn.doctype <> 1910 and amn.accdir in (504,317, 684)	then 6
 		   else 1
 		end as id_sign_account_point,
 		
 		amn.docnumber as docnumber,
 		case when  ard690.paramval is null or length(ard690.paramval)<10 or  ard690.paramval::date > p_date
 		then 1 	
 		else 0
 		end as existing,
 		
 		den.nam AS locid,
 		cust.abo_name AS customer_name, 
 		ard418.paramval AS name_point, 
 		ard417.paramval AS adr_point, 
 		
        de.element_name AS type_device, 
        gt.objname AS  name_feeder,
	    de_cat.element_name AS  category_reliability,
	    ard426.paramval AS max_pow_agreement, 
	    
	    CASE WHEN ard664_sub.paramval IS NOT NULL AND  ard664_gol.paramval IS NOT NULL THEN 4
	    WHEN ard664_gol.paramval IS NOT NULl THEN 3 
	    WHEN ard664_sub.paramval IS NOT NULL THEN 2
	   ELSE 1
	    END AS type_point,
	    
        ard664_sub.paramval AS id_golov,
	    gt.pchain AS name_ps,
	    CASE WHEN  ard690.paramval IS NOT null  AND  length(ard690.paramval)= 10 AND is_date(ard690.paramval)  
	    THEN ard690.paramval
	    ELSE null
	    END::date AS date_removal
	    
		from agreepoint as apn
		
   left join (select min(valman) as valman, linkid from regdevoper where paramid = 193 group by linkid) as rdo on rdo.linkid = apn.rowid 
   left join (
   select * from agreeregdev_period as ardp1 
   join  (select max(period) as per, ardp.linkid as link from agreeregdev_period as ardp where ardp.period <= p_date and ardp.paramid = 439 group by link ) as ardp2
   on ardp1.period = ardp2.per  and ardp1.linkid = ardp2.link
   where ardp1.paramid = 439) as ard439 on  ard439.linkid  = apn.rowid


   left join agreeregdev as ard690 on ard690.paramid = 690 and ard690.linkid = apn.rowid 
    

   left join (select ard.paramid, ard.linkid as link, ard.paramval from agreeregdev_period as ard
                join (select max(period) as period, ad.linkid from agreeregdev_period as ad where paramid = 2009 group by linkid)as ard1
               on ard.period = ard1.period and ard.linkid = ard1.linkid   
               where ard.paramid = 2009) as ardp2009 on ardp2009.link = apn.rowid
               
         join agreement as amn on amn.rowid = apn.linkid
         join customer as cust on cust.abo_code = amn.abo_code
         JOIN denet AS den ON den.rowid = apn.lid
         
   left join agreeregdev as ard418 on ard418.paramid = 418 and ard418.linkid = apn.rowid 
   left join agreeregdev as ard417 on ard417.paramid = 417 and ard417.linkid = apn.rowid 
        join dic_elements AS de ON de.rowid = apn.devid
   left join regdevconn as rdc ON rdc.pointid = apn.rowid 
   LEFT JOIN (SELECT objname,  rowid ,
    btrim(REPLACE(REPLACE(substring(REPLACE(REPLACE(pchain, '+Сеть электроснабжения', ''), '+ОАО Донэнерго+',''), 6), objname, '' ), '+', ' '))  AS pchain
   from gis_traces) AS gt ON gt.rowid = rdc.traceid
   
     left join (
   select * from agreeregdev_period as ardp1 
   join  (select max(period) as per, ardp.linkid as link from agreeregdev_period as ardp where ardp.period <= p_date and ardp.paramid = 426 group by link ) as ardp2
   on ardp1.period = ardp2.per  and ardp1.linkid = ardp2.link
   where ardp1.paramid = 426) as ard426 on  ard426.linkid  = apn.rowid

        join dic_elements AS de_cat ON de_cat.rowid = cust.category_code
        
        
    left join (
   SELECT distinct ardp1.linkid, ardp1.paramval from agreeregdev_period as ardp1 
   join  (select max(period) as per, ardp.linkid as link from agreeregdev_period as ardp where ardp.period <= p_date and ardp.paramid = 664 group by link ) as ardp2
   on ardp1.period = ardp2.per  and ardp1.linkid = ardp2.link
   where ardp1.paramid = 664 AND paramval NOT IN ('0', '-', '')) as ard664_sub on  ard664_sub.linkid  = apn.rowid   
   
     left join (   SELECT distinct  ardp1.paramval from agreeregdev_period as ardp1 
   join  (select max(period) as per, ardp.linkid as link from agreeregdev_period as ardp where ardp.period <= p_date and ardp.paramid = 664 group by link ) as ardp2
   on ardp1.period = ardp2.per  and ardp1.linkid = ardp2.link
   where ardp1.paramid = 664 AND paramval NOT IN ('0', '-', '')) as ard664_gol on  ard664_gol.paramval  = apn.rowid::varchar

        
  where  amn.accdir not in (538,1476,1110,319) AND (ard690.paramval IS NULL OR length(ard690.paramval)<10 );
$$;

alter function bee_get_account_point_existing(date) owner to postgres;

