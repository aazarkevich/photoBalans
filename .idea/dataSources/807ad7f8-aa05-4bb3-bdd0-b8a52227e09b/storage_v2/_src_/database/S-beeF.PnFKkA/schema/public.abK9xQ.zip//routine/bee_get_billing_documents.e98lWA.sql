create function bee_get_billing_documents(_df text, _dt text, _top_locid integer) returns SETOF billing_documents
    language plpgsql
as
$$
/*
	add ito06 2016-03-02 добавили тип договора (doctype вместо transmit)
	Список сформированных документов выставления за период
*/
	DECLARE
		RowLine billing_documents%rowtype;
		_date_from date = _df::date;
		_date_to date = _dt::date;
	---  
	BEGIN
	---  	
		FOR RowLine IN (
			SELECT
				dic_elements.element_name                      AS c1, --направление учета
				agreement.docnumber                            AS c2, --номер договора
				customer.consum_inn                            AS c3, --ИНН,   
				e3.element_name || ' ' || customer.consum_name AS c4, --наименование контрагента 
				bee_docs.docnum                                AS c5, --номер документа
				bee_docs.docdat                                AS c6, --дата докум   
				sum(bee_docs_result.sum_no_tax)                AS c7, --сумма без НДС
				sum(bee_docs_result.tax_sum)                   AS c8, --сумма НДС
				sum(bee_docs_result.sum_with_tax)              AS c9, --сумма с НДС 
				bee_docs.rowid                                 AS c10, --внутренний код документа для проверки
				agreement.rowid                                AS c11
			FROM 
				bee_docs_result
				JOIN bee_docs ON bee_docs_result.linkid=bee_docs.rowid 
				JOIN agreement ON bee_docs.linkid = agreement.rowid
				LEFT JOIN dic_elements ON agreement.accdir=dic_elements.rowid
				JOIN customer ON agreement.abo_code = customer.abo_code
				JOIN dic_elements AS e3 ON customer.urstatus = e3.rowid
				
			WHERE  bee_docs.doctyp = 1065                               --документ выставления (акт приема-передачи)
				AND bee_docs.docdat BETWEEN _date_from AND _date_to --период выгрузки документов
				AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
				--AND agreement.locid = _top_locid  
				--2016-03-02 AND agreement.transmit = TRUE
				AND agreement.doctype in (1910, 1911) --** 2016-03-02
				
			GROUP BY  c5,c6,agreement.accdir,c1,c4,c2,c3,c10,c11
			ORDER BY  c1,case when regexp_replace(agreement.docnumber, E'[^\\d*]', E'\\1','g') = '' then 0 else 
			regexp_replace(agreement.docnumber, E'[^\\d*]', E'\\1','g')::bigint end,c4,c6
		)
		LOOP
			RETURN NEXT RowLine;
		END LOOP;
	--
	END;


$$;

comment on function bee_get_billing_documents(text, text, integer) is 'Список сформированных документов выставления за период. Используется в GroupDocsProcessing.java, SessionBean1.java';

alter function bee_get_billing_documents(text, text, integer) owner to pgsql;

