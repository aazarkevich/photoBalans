create function bee_rep_map_info_get_content(amn_row integer, start_dat date, end_dat date) returns SETOF bee_rep_map_info
    language sql
as
$$
/*
	add ito06 2019-11-18 При выборе периодических параметров дату сравниваем <= (было <)
	ito06 2011-09-19: Карта расхода, add ito06 2013-09-26, 2013-10-04
*/
	(SELECT
		apn.rowid,
		amn.docnumber 						AS amn_docnumber,
		urs.element_name || ' ' || cst.consum_name 		AS cst_name,
		apn.prodnumber 						AS prdnum,
		apn.account						AS account,
		obj_name.paramval || ', ' || obj_adr.paramval 		AS obj,
		ul.element_name 					AS ul,
		rdo196.v 						AS v196,
		rdo195.v 						AS v195,
		rdo198.v 						AS v198,
		koef.paramval 						AS koef,
		CASE
		    WHEN loss_n.v IS NULL
			THEN 0
                     ELSE loss_n.v
		END +
		CASE
		    WHEN loss_l.v IS NULL
			THEN 0
		    ELSE loss_l.v
		END +  
		CASE
		    WHEN loss_h.v IS NULL
			THEN 0
		    ELSE loss_h.v
		END 							AS loss_tot,
		loss_n.v 						AS loss_n,
		loss_l.v 						AS loss_l,
		loss_h.v 						AS loss_h,
		dopsum.v 						AS dopsum,
		rdo407.v 						AS v407,
		rdo850.v 						AS v850,  
		rdo850.rowid,
		rdo850.operdate 
	   FROM customer AS cst
	   JOIN agreement AS amn ON amn.abo_code = cst.abo_code
           JOIN agreepoint AS apn ON apn.linkid = amn.rowid AND apn.devtype = 644
           JOIN dic_elements AS urs ON urs.rowid = cst.urstatus
      LEFT JOIN agreeregdev AS ard690 ON ard690.paramid = 690 AND ard690.paramval LIKE '____-__-__' AND apn.rowid = ard690.linkid
      LEFT JOIN agreeregdev AS ard690_1 ON ard690_1.paramid = 690 AND ard690_1.paramval NOT LIKE '____-__-__' AND CHAR_LENGTH(ard690_1.paramval) > 2 
                                       AND apn.rowid = ard690_1.linkid
      LEFT JOIN agreeregdev AS obj_name ON obj_name.paramid=418 AND obj_name.linkid = apn.rowid
      LEFT JOIN agreeregdev AS obj_adr ON obj_adr.paramid=410 AND obj_adr.linkid = apn.rowid
      LEFT JOIN (SELECT ard.linkid, paramval
                   FROM agreeregdev_period AS ard
                   JOIN  (SELECT linkid,max(period) AS p
                            FROM   agreeregdev_period
                           WHERE   period <= $3 AND --2019-11-18
		                   paramid = 439
                             GROUP BY linkid
                         ) AS ard_p ON ard_p.linkid = ard.linkid AND ard_p.p = ard.period AND ard.paramid = 439
                ) AS ul_1 ON ul_1.linkid = apn.rowid
      LEFT JOIN dic_elements AS ul ON ul.rowid = (ul_1.paramval)::int
      LEFT JOIN (SELECT rowid, operdate, sum(valman::numeric) AS v,linkid 
                  FROM regdevoper
                 WHERE paramid = 850 AND 
                       operdate BETWEEN $2 AND $3 AND 
                       valman ~ E'^[\\d{1,}\\-]' AND 
                       valman<>'-' 
                 GROUP BY linkid,operdate, rowid
                ) AS rdo850 ON rdo850.linkid = apn.rowid 
      LEFT JOIN (SELECT rowid, operdate, sum(valman::numeric) AS v,linkid 
                  FROM regdevoper
                 WHERE paramid = 1174 AND 
                       operdate BETWEEN $2 AND $3 AND 
                       valman ~ E'^[\\d{1,}\\-]' AND 
                       valman<>'-' 
                 GROUP BY linkid,operdate, rowid
                ) AS rdo1174 ON rdo1174.linkid = apn.rowid  
      LEFT JOIN (SELECT rowid, operdate, sum(valman::numeric) AS v, linkid 
                  FROM regdevoper
                 WHERE paramid = 1446 AND 
                       operdate BETWEEN $2 AND $3 AND 
                       valman ~ E'^[\\d{1,}\\-]' AND 
                       valman<>'-' 
                 GROUP BY linkid,operdate, rowid
                ) AS rdo1446 ON rdo1446.linkid = apn.rowid 
      LEFT JOIN (SELECT operdate, sum(valman::numeric) AS v, linkid
                  FROM regdevoper
                 WHERE paramid = 196 AND 
                       operdate BETWEEN $2 AND $3 AND 
                       valman ~ E'^[\\d{1,}\\-]' AND 
                       valman<>'-' 
                 GROUP BY linkid, operdate
                ) AS rdo196 ON rdo196.linkid = apn.rowid   AND rdo850.operdate = rdo196.operdate
      LEFT JOIN (SELECT operdate,  sum(valman::numeric) AS v, linkid 
		  FROM  regdevoper
                 WHERE  paramid = 195 AND 
                        operdate BETWEEN $2 AND $3 AND 
                        valman ~ E'^[\\d{1,}\\-]' AND 
                        valman<>'-' 
                  GROUP BY linkid, operdate
                 ) AS rdo195 ON rdo195.linkid = apn.rowid   AND  rdo195.operdate = rdo850.operdate
       LEFT JOIN (SELECT operdate,  sum(valman::numeric) AS v, linkid 
                    FROM regdevoper
                   WHERE paramid = 198 AND 
                         operdate BETWEEN $2 AND $3 AND 
                         valman ~ E'^[\\d{1,}\\-]' AND valman<>'-' 
                   GROUP BY linkid, operdate
                  ) AS rdo198 ON rdo198.linkid = apn.rowid AND rdo198.operdate = rdo850.operdate
        LEFT JOIN ( SELECT operdate,  sum(valman::numeric) AS v, linkid 
		      FROM regdevoper
		     WHERE paramid = 407 AND 
			   operdate BETWEEN $2 AND $3 AND 
			   valman ~ E'^[\\d{1,}\\-]' AND 
			   valman<>'-' 
		     GROUP BY linkid, operdate
                  ) AS rdo407 ON rdo407.linkid = apn.rowid AND rdo407.operdate = rdo850.operdate
   
        LEFT JOIN ( SELECT ard.linkid, paramval
                      FROM agreeregdev_period AS ard
                      JOIN ( SELECT linkid, max(period) AS p
                               FROM agreeregdev_period
                              WHERE period <= $3 AND paramid = 356 --2019-11-18 
							 
                              GROUP BY linkid
                           )  AS ard_p ON ard_p.linkid = ard.linkid AND ard_p.p = ard.period AND ard.paramid = 356
                  ) AS koef ON koef.linkid = apn.rowid
        LEFT JOIN ( SELECT operdate, sum(valman::numeric) AS v, linkid 
                      FROM regdevoper
                     WHERE paramid = 917 AND 
                           operdate BETWEEN $2 AND $3 AND 
                           valman ~ E'^[\\d{1,}\\-]' AND 
                           valman<>'-' 
                     GROUP BY linkid, operdate
                  ) AS loss_n ON loss_n.linkid = apn.rowid AND loss_n.operdate = rdo850.operdate
        LEFT JOIN ( SELECT operdate, sum(valman::numeric) AS v, linkid 
                      FROM regdevoper
                     WHERE paramid = 919 AND 
                           operdate BETWEEN $2 AND $3 AND 
                           valman ~ E'^[\\d{1,}\\-]' AND 
                           valman<>'-' 
                     GROUP BY linkid,operdate
                  ) AS loss_l ON loss_l.linkid = apn.rowid    AND loss_l.operdate = rdo850.operdate
        LEFT JOIN ( SELECT operdate, sum(valman::numeric) AS v, linkid 
                      FROM regdevoper
                     WHERE paramid = 918 AND 
                           operdate BETWEEN $2 AND $3 AND 
                           valman ~ E'^[\\d{1,}\\-]' AND 
                           valman<>'-' 
                     GROUP BY linkid, operdate
                  ) AS loss_h ON loss_h.linkid = apn.rowid    AND loss_h.operdate = rdo850.operdate
        LEFT JOIN ( SELECT operdate, sum(valman::numeric) AS v, linkid 
                      FROM regdevoper
                     WHERE paramid = 199 AND 
                           operdate BETWEEN $2 AND $3 AND 
                           valman ~ E'^[\\d{1,}\\-]' AND 
                           valman<>'-' 
                     GROUP BY linkid, operdate
                  ) AS dopsum ON dopsum.linkid = apn.rowid  AND dopsum.operdate = rdo850.operdate
            WHERE ( ard690.paramval::date >= $2 OR ard690.paramval IS NULL) AND
                    ard690_1.paramval IS NULL AND
                    amn.rowid = $1)
UNION (  SELECT
		apn.rowid,
		null::varchar 						AS amn_docnumber,
		null::varchar 						AS cst_name,
		null::varchar						AS prdnum,
		apn.account						AS account,
		'в пределах соц. нормы потребления' 			AS obj,
		ul.element_name 					AS ul,
		null::numeric 						AS v196,
		null::numeric 						AS v195,
		null::numeric						AS v198,
		null::varchar 						AS koef,
		null::numeric						AS loss_tot,
		null::numeric 						AS loss_n,
		null::numeric 						AS loss_l,
		null::numeric 						AS loss_h,
		null::numeric 						AS dopsum,
		null::numeric						AS v407,
		rdo1446.v 						AS v850,  
		rdo1446.rowid,
		rdo1446.operdate 
	   FROM  agreement AS amn 
           JOIN agreepoint AS apn ON apn.linkid = amn.rowid AND apn.devtype = 644

           JOIN ( SELECT apt.pointid, tarifid  FROM agreepoint_tarif As apt
                    JOIN (SELECT max(period) as period, pointid FROM agreepoint_tarif 
                           WHERE period <= $3 GROUP BY pointid ) As a ON a.pointid = apt.pointid  and a.period = apt.period                          
                 ) AS apnt ON apnt.pointid = apn.rowid AND tarifid IN (150,156,154,155,152,159,157,158,153,162,160,161)

      LEFT JOIN agreeregdev AS ard690 ON ard690.paramid = 690 AND ard690.paramval LIKE '____-__-__' AND apn.rowid = ard690.linkid
      LEFT JOIN agreeregdev AS ard690_1 ON ard690_1.paramid = 690 AND ard690_1.paramval NOT LIKE '____-__-__' AND CHAR_LENGTH(ard690_1.paramval) > 2 
                                       AND apn.rowid = ard690_1.linkid
      LEFT JOIN (SELECT ard.linkid, paramval
                   FROM agreeregdev_period AS ard
                   JOIN  (SELECT linkid,max(period) AS p
                            FROM   agreeregdev_period
                           WHERE   period <= $3 AND --2019-11-18
		                   paramid = 439
                             GROUP BY linkid
                         ) AS ard_p ON ard_p.linkid = ard.linkid AND ard_p.p = ard.period AND ard.paramid = 439
                ) AS ul_1 ON ul_1.linkid = apn.rowid
      LEFT JOIN dic_elements AS ul ON ul.rowid = (ul_1.paramval)::int                                          
           JOIN ( SELECT rowid, operdate, sum(valman::numeric) AS v, linkid 
                    FROM regdevoper
                   WHERE paramid = 1446 AND 
                         operdate BETWEEN $2 AND $3 AND 
                         valman ~ E'^[\\d{1,}\\-]' AND 
                         valman<>'-' 
                    GROUP BY linkid,operdate, rowid
                ) AS rdo1446 ON rdo1446.linkid = apn.rowid AND rdo1446.v<>0 
                 
          WHERE ( ard690.paramval::date >= $2 OR ard690.paramval IS NULL) AND
                  ard690_1.paramval IS NULL AND
                  amn.rowid = $1
) UNION (SELECT
		apn.rowid,
		null::varchar 						AS amn_docnumber,
		null::varchar 						AS cst_name,
		null::varchar						AS prdnum,
		apn.account						AS account,
		'сверх соц. нормы потребления' 				AS obj,
		ul.element_name 					AS ul,
		null::numeric 						AS v196,
		null::numeric 						AS v195,
		null::numeric						AS v198,
		null::varchar 						AS koef,
		null::numeric						AS loss_tot,
		null::numeric 						AS loss_n,
		null::numeric 						AS loss_l,
		null::numeric 						AS loss_h,
		null::numeric 						AS dopsum,
		null::numeric						AS v407,
		rdo1174.v 						AS v850,
		rdo1174.rowid,
		rdo1174.operdate 
	   FROM agreement AS amn 
           JOIN agreepoint AS apn ON apn.linkid = amn.rowid AND apn.devtype = 644  
           JOIN ( SELECT apt.pointid, tarifid  FROM agreepoint_tarif As apt
                    JOIN (SELECT max(period) as period, pointid FROM agreepoint_tarif 
                           WHERE period <= $3 GROUP BY pointid ) As a ON a.pointid = apt.pointid and a.period = apt.period                          
                 ) AS apnt ON apnt.pointid = apn.rowid AND tarifid IN (150,156,154,155,152,159,157,158,153,162,160,161)         
      LEFT JOIN agreeregdev AS ard690 ON ard690.paramid = 690 AND ard690.paramval LIKE '____-__-__' AND apn.rowid = ard690.linkid
      LEFT JOIN agreeregdev AS ard690_1 ON ard690_1.paramid = 690 AND ard690_1.paramval NOT LIKE '____-__-__' AND CHAR_LENGTH(ard690_1.paramval) > 2 
                                       AND apn.rowid = ard690_1.linkid
      LEFT JOIN (SELECT ard.linkid, paramval
                   FROM agreeregdev_period AS ard
                   JOIN  (SELECT linkid,max(period) AS p
                            FROM   agreeregdev_period
                           WHERE   period <= $3 AND --2019-11-18
		                   paramid = 439
                             GROUP BY linkid
                         ) AS ard_p ON ard_p.linkid = ard.linkid AND ard_p.p = ard.period AND ard.paramid = 439
                ) AS ul_1 ON ul_1.linkid = apn.rowid
      LEFT JOIN dic_elements AS ul ON ul.rowid = (ul_1.paramval)::int                                       
           JOIN (SELECT rowid, operdate, sum(valman::numeric) AS v, linkid 
                  FROM regdevoper
                 WHERE paramid = 1174 AND 
                       operdate BETWEEN $2 AND $3 AND 
                       valman ~ E'^[\\d{1,}\\-]' AND 
                       valman<>'-' 
                 GROUP BY linkid,operdate, rowid
                ) AS rdo1174 ON rdo1174.linkid = apn.rowid AND rdo1174.v<>0      
          WHERE  (ard690.paramval::date >= $2 OR ard690.paramval IS NULL) AND
                 ard690_1.paramval IS NULL AND
                 amn.rowid = $1 
   )
$$;

comment on function bee_rep_map_info_get_content(integer, date, date) is 'Карта расхода. Используется в bee_rep_pay_map_get_content(int)';

alter function bee_rep_map_info_get_content(integer, date, date) owner to pgsql;

