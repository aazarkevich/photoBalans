create function bee_del_agreepointconn(point integer) returns integer
    language plpgsql
as
$$
/*
ito06 2012-12-13 Удаление трассы у точки учета
*/
DECLARE NR INTEGER =-1;

 BEGIN
 NR = -1; 
 DELETE FROM regdevconn WHERE pointid = point RETURNING 1 INTO NR;
 IF NR IS NOT NULL
    THEN  RETURN 1;
 ELSE RETURN -1;
 END IF;

END;
$$;

comment on function bee_del_agreepointconn(integer) is 'Удаление трассы у точки учета. Используется в ConnectDevice.java, AppUtils.java';

alter function bee_del_agreepointconn(integer) owner to pgsql;

