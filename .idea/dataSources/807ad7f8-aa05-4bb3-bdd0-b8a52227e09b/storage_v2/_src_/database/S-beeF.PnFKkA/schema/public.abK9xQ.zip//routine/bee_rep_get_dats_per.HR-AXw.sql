create function bee_rep_get_dats_per(str_date date, end_date date) returns SETOF dats_per_tab
    language plpgsql
as
$$
/*
   ito16
   10.12.09
*/
 DECLARE
   result dats_per_tab%ROWTYPE;
   tmp_dat date;
   start_end_dat date := (TO_CHAR(str_date,'YYYY-MM') || '-01')::date + '1 month'::interval -'1 day'::interval;
BEGIN
   result.start_d = str_date;
   IF end_date > start_end_dat THEN
     result.end_d = start_end_dat;
     tmp_dat = (TO_CHAR(str_date,'YYYY-MM') || '-01')::date + '1 month'::interval;
     LOOP
       RETURN NEXT result;
       EXIT WHEN (tmp_dat + '1 month'::interval - '1 day'::interval)::date >= end_date;
       result.start_d = tmp_dat;
       tmp_dat = tmp_dat + '1 month'::interval;
       result.end_d = tmp_dat - '1 day'::interval;
     END LOOP;
     result.start_d = tmp_dat;
   END IF;
   result.end_d = end_date;
   RETURN NEXT result;
END;
$$;

comment on function bee_rep_get_dats_per(date, date) is 'Используется в bee_rep_get_repdata12_tmp(int, date, date)';

alter function bee_rep_get_dats_per(date, date) owner to pgsql;

