create function bee_login_audit_process(lid integer, opr character varying, usr character varying) returns boolean
    language plpgsql
as
$$
DECLARE 	
	TagRecord record;
	listconn  text[];
	----
	res       text;
	db 	  varchar;
	usrip 	  varchar = '0.0.0';
	sql 	  varchar;
	
  
BEGIN
	BEGIN 
		db = (select current_database());
		usrip = (select get_usrvar('userip'));			

		-- получить параметры подключеия
		SELECT * FROM dblink_get_connections() INTO listconn; 		
			
		IF 'deconn_laudit' = ANY (listconn) 
			THEN SELECT dblink_disconnect('deconn_laudit') INTO res;
		END IF;

		EXECUTE 'SELECT * FROM bee_external WHERE tag =''audit'' LIMIT 1' INTO TagRecord;
		SELECT dblink_connect_u('deconn_laudit', 'dbname = ' || TagRecord.dbname ||
					' port = '|| TagRecord.port || 
					' host = '|| TagRecord.host ||
					' user = '|| TagRecord.usr ||
					' password = ' || TagRecord.pwd) into res;
	
		
		
		SQL = 'INSERT INTO login_audit(xlocid, dbase, operation, stamp, xuid, userip)
		       VALUES ('||$1||', '''||db||''', '''||$2||''', '''||now()||''', '''||$3||''', '''||usrip||''');';	

		PERFORM dblink('deconn_laudit',	sql);		
		       
	
		-- DROP CONNECTION IF EXISTS
		SELECT dblink_disconnect('deconn_laudit') INTO res;

		RETURN true;
		
	EXCEPTION WHEN others THEN 
	RETURN false;
	END;

END;
$$;

comment on function bee_login_audit_process(integer, varchar, varchar) is 'Используется в *.java ,AppUtils.java';

alter function bee_login_audit_process(integer, varchar, varchar) owner to pgsql;

