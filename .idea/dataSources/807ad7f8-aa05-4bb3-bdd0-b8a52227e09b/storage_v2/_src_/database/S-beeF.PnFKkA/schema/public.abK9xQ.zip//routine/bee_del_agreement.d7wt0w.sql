create function bee_del_agreement(lid integer, docnum character varying) returns integer
    language plpgsql
as
$$
/*
ito06 2012-08-27 Удаление договора
*/
DECLARE NR INTEGER =-1;

 BEGIN
 NR = -1; 
  DELETE FROM agreement  WHERE locid = lid AND docnumber = docnum  RETURNING 1 INTO NR;
 IF NR IS NOT NULL
    THEN  RETURN 1;
 ELSE RETURN -1;
 END IF;

END;
$$;

comment on function bee_del_agreement(integer, varchar) is 'Удаление договора. Используется в Agreement.java, AppUtils.java';

alter function bee_del_agreement(integer, varchar) owner to pgsql;

