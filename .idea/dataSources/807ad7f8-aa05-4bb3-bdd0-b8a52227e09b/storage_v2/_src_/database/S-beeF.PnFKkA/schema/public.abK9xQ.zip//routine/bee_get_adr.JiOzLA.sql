create function bee_get_adr(character varying, character varying) returns SETOF bee_dic_adr1
    language sql
as
$$
SELECT 
   dic_adr1.tag AS tag1,
   upper(dic_adr1.name) AS lab1,
   dic_adr2.tag AS tag2,
   upper(dic_adr2.name) AS lab2,
   dic_adr2.rowid AS rowid
FROM dic_adr1 
JOIN dic_adr2 
   ON dic_adr1.rowid = dic_adr2.linkid
WHERE 
   dic_adr1.region    = $1 AND 
   dic_adr1.tag    LIKE $2
ORDER BY 
   dic_adr1.name, 
   dic_adr2.name
$$;

comment on function bee_get_adr(varchar, varchar) is 'Используется в DicAddress.java, SessionBean1.java';

alter function bee_get_adr(varchar, varchar) owner to pgsql;

