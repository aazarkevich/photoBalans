create function bee_rep11_get_pch(pchain character varying) returns character varying
    language plpgsql
as
$$
/*
ito16 
Сравнительная ведомость в разрезе схем подключения
*/
DECLARE
  part character varying;
  pc   text[];
  len  int;
  code int;
  result character varying;
BEGIN
  IF pchain IS NULL THEN
    RETURN NULL;
  END IF;
  pc:=string_to_array(pchain,'+');
  len:=array_upper(pc,1);
  part:='';
  result:='';
  code:=0;
  FOR i IN 2..len LOOP
	IF result='' THEN
		part := part || '+' || pc[i];
		EXECUTE 'SELECT objtype FROM gis_traces WHERE pchain= '||quote_literal(part) ||' LIMIT 1' INTO code;
		IF code=11 THEN
		  result:= pc[i];
		END IF;	
	ELSE 
		result:=result || '+' || pc[i];
	END IF;
  END LOOP;
  RETURN result;
END
$$;

comment on function bee_rep11_get_pch(varchar) is 'Сравнительная ведомость в разрезе схем подключения. Используется в bee_rep_get_fullrepdata11(int, date, date), bee_rep_get_repdata11(int, date, date)';

alter function bee_rep11_get_pch(varchar) owner to postgres;

