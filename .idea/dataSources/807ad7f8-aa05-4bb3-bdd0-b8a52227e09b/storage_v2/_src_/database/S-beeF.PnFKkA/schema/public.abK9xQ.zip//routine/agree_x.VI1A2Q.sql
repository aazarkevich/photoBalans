create function agree_x(src_host character varying, tagid integer, src_port character varying) returns void
    language plpgsql
as
$$
DECLARE
    HOSTS VARCHAR[];
    H     VARCHAR;
    Doc   RECORD;
    num   VARCHAR;
    rid   INTEGER;  
    DbN   VARCHAR;
begin
    ALTER TABLE agreepoint         DISABLE TRIGGER agreepoint_audit;
    ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_audit;
    ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_trig;
    ALTER TABLE agreeregdev        DISABLE TRIGGER agreeregdev_audit;
    ALTER TABLE agreeregdev_period DISABLE TRIGGER agreeregdev_period_trig;
    ALTER TABLE agreeregdev_period DISABLE TRIGGER agreeregdev_period_audit;
    ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_trig;
    ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_audit;
    ALTER TABLE regdevconn         DISABLE TRIGGER regdevconn_audit;   
   
    ALTER TABLE bee_docs_calc DROP CONSTRAINT bee_docs_calc_fk3;
    ALTER TABLE bee_docs_calc
      ADD CONSTRAINT bee_docs_calc_fk3 FOREIGN KEY (quantity_id)
      REFERENCES regdevoper (rowid) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE cascade;--RESTRICT;
    
    -- SCAN ALL HOST BY bee_closed_info.dbstatus = ''U''	
    FOR H IN (SELECT DISTINCT hostname FROM bee_closed_info WHERE hostname LIKE  src_host||'%' ORDER BY hostname)
    LOOP       
	EXECUTE 'SELECT dbname FROM bee_closed_info WHERE hostname = ''' || H || 
	    ''' AND dbstatus = ''U''  ORDER BY hostname LIMIT 1' INTO DbN;

	IF DbN IS NULL THEN CONTINUE; END IF;       
	------- 
	PERFORM agree_x_1(H,DbN,tagid,src_port);
	-------
	FOR Doc IN (select docnumber, rowid from agreement order by docnumber)
	LOOP
	    num = Doc.docnumber;
	    rid = Doc.rowid;
	    PERFORM agree_x_2( DbN,num,rid,tagid,H,src_port);
	    PERFORM agree_x_31(DbN,num,tagid,H,src_port);
	    PERFORM agree_x_32(DbN,num,tagid,H,src_port);
	    PERFORM agree_x_33(DbN,num,tagid,H,src_port);
	    PERFORM agree_x_34(DbN,num,tagid,H,src_port);
	    PERFORM agree_x_35(DbN,num,tagid,H,src_port);
	    PERFORM agree_x_36(DbN,num,tagid,H,src_port);
	END LOOP;-- DOCS
	
    END LOOP; -- HOSTS
    
    ALTER TABLE bee_docs_calc DROP CONSTRAINT bee_docs_calc_fk3;
    ALTER TABLE bee_docs_calc
          ADD CONSTRAINT bee_docs_calc_fk3 FOREIGN KEY (quantity_id)
          REFERENCES regdevoper (rowid) MATCH SIMPLE
          ON UPDATE CASCADE ON DELETE RESTRICT;
        ---
    ALTER TABLE bee_docs_calc      ENABLE TRIGGER bee_docs_calc_trig;
    ALTER TABLE bee_docs_calc      ENABLE TRIGGER bee_docs_calc_audit;   
    ALTER TABLE regdevconn         ENABLE TRIGGER regdevconn_audit;
    ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_audit;
    ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_trig;
    ALTER TABLE agreeregdev_period ENABLE TRIGGER agreeregdev_period_trig;
    ALTER TABLE agreeregdev_period ENABLE TRIGGER agreeregdev_period_audit;
    ALTER TABLE agreeregdev        ENABLE TRIGGER agreeregdev_audit;
    ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_audit;
    ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_trig;
    ALTER TABLE agreepoint         ENABLE TRIGGER agreepoint_audit;     
    
    UPDATE bee_closed_info SET isload = false;  --ito06 2016-02-05
    --------
END;
$$;

comment on function agree_x(varchar, integer, varchar) is 'Используется в AgreeJoinMix.java, AgreeJoinUni.java, AppUtils.java';

alter function agree_x(varchar, integer, varchar) owner to pgsql;

