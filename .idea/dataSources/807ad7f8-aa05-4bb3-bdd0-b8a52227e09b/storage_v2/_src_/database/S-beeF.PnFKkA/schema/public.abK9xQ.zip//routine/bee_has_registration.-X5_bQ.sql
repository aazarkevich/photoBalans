create function bee_has_registration(pointid integer, operdat character varying) returns boolean
    language plpgsql
as
$$
    --
-- ПРОВЕРКА НАЛИЧИЯ ПОКАЗАНИЙ В ДАННЫЙ ПЕРИОД (месяц)
--
BEGIN
-- pointid - устройство  учёта
-- operdat - период в формате YYYY-MM
-- 194     - дата снятия показаний (код поля)
--
RETURN EXISTS(
   SELECT 1 FROM regdevoper
   WHERE 
      regdevoper.linkid               = pointid          AND
      regdevoper.operdate::varchar LIKE operdat || '___' AND
      regdevoper.paramid              = 194 AND
      regdevoper.valman              IS NOT NULL         AND  
      regdevoper.valman               = regdevoper.operdate::varchar  
   LIMIT 1
); 
--
END;
$$;

comment on function bee_has_registration(integer, varchar) is 'Проверка наличия показаний в данный период (месяц). Используется в AgreeByDevice.java, AppUtils.java';

alter function bee_has_registration(integer, varchar) owner to pgsql;

