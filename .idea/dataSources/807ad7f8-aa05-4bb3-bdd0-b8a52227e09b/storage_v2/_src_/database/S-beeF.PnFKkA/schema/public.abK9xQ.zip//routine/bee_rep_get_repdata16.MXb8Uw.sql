create function bee_rep_get_repdata16(locid integer, strdate date, enddate date) returns SETOF bee_rep_tab16
    language sql
as
$$
/*
ito16 
*/
SELECT 
 a.nam,
 a.docnum,
 a.sd,
 a.sk,
 b.price,
 b.quant,
 b.sum_no_tax,
 c.sum_quant,
 c.tot_no_tax,
 c.tax_sum,
 c.tot_no_tax+c.tax_sum AS tot,
 a.fd,
 a.fk,
 c.row_count,
 a.grp
FROM
	(SELECT 
		bdr.price       AS price,
		sum(bdr.amount) AS quant,
		sum(bdr.sum_no_tax) AS sum_no_tax,
		bdr.linkid      AS docid
	FROM bee_docs_result AS bdr
		JOIN bee_docs AS docs ON docs.rowid=bdr.linkid AND docs.doctyp=1065
		JOIN bee_docs_sheet AS bds ON bds.linkid2=docs.rowid AND bds.operdate BETWEEN $2 AND $3
	GROUP BY price,docid
	) AS b 
RIGHT JOIN
	(SELECT
		a3.docid AS docid,
		amn.docnumber AS docnum,
		cst.consum_name AS nam,
		a1.sd::numeric(14,2) AS sd,
		a1.sk::numeric(14,2) AS sk,
		a3.fd::numeric(14,2) AS fd,
		a3.fk::numeric(14,2) AS fk,
		dic.element_name AS grp
	FROM agreement AS amn
	JOIN customer AS cst ON cst.abo_code=amn.abo_code
	JOIN 
		(
	/*
	выборка полей с минимальной operdate и минимальной pnn между заданными датами
	*/	
		SELECT 
			bds.start_debit::numeric(14,2) AS sd,
			bds.start_kredit::numeric(14,2) AS sk,
			bds.linkid1 AS linkid
		FROM bee_docs_sheet AS bds
		JOIN 
			(SELECT 
				linkid1 AS linkid,
				min(operdate) AS operdate
			FROM bee_docs_sheet
			WHERE operdate BETWEEN $2 AND $3
			GROUP BY linkid) AS a ON a.linkid=bds.linkid1
		JOIN
			(SELECT 
				rowid AS id,
				linkid1 AS linkid,
				min(operdate) AS operdate,
				min(npp) AS sn
			FROM bee_docs_sheet
			WHERE operdate BETWEEN $2 AND $3
			GROUP BY linkid,rowid) AS a1 ON a.operdate=a1.operdate AND a1.id=bds.rowid
		GROUP BY bds.linkid1,sd,sk
		) AS a1 ON a1.linkid=amn.rowid
	JOIN
		(
	/*
	выборка полей с максмальной operdate и максимальной pnn между заданными датами
	*/	
		SELECT 
			bds.final_debit::numeric(14,2) AS fd,
			bds.final_kredit::numeric(14,2) AS fk,
			bds.linkid1 AS linkid,
			bds.linkid2 AS docid
		FROM bee_docs_sheet AS bds
		JOIN 
			(SELECT 
				linkid1 AS linkid,
				max(operdate) AS operdate
			FROM bee_docs_sheet
			WHERE operdate BETWEEN $2 AND $3
			GROUP BY linkid) AS a ON a.linkid=bds.linkid1
		JOIN
			(SELECT 
				linkid1 AS linkid,
				max(operdate) AS operdate,
				max(npp) AS sn
			FROM bee_docs_sheet
			WHERE operdate BETWEEN $2 AND $3
			GROUP BY linkid) AS a1 ON a.operdate=a1.operdate AND a1.sn=bds.npp
		GROUP BY bds.linkid1,fd,fk,docid
		) AS a3 ON a3.linkid=amn.rowid

	JOIN dic_elements AS dic ON dic.rowid=amn.accdir
	WHERE amn.locid=$1
	GROUP BY nam,grp,docnum,sd,sk,fd,fk,docid
	) AS a ON a.docid=b.docid
LEFT JOIN
	(SELECT 
		sum(bdr.amount) AS sum_quant,
		sum(bdr.sum_no_tax) AS tot_no_tax,
		sum(bdr.tax_sum) AS tax_sum,
		count(bdr.rowid) AS row_count,
		bdr.linkid      AS docid
	FROM bee_docs_result AS bdr
		JOIN bee_docs AS docs ON docs.rowid=bdr.linkid AND docs.doctyp=1065
		JOIN bee_docs_sheet AS bds ON bds.linkid2=docs.rowid AND bds.operdate BETWEEN $2 AND $3
	GROUP BY docid
	) AS c ON a.docid=c.docid
WHERE price>0;
$$;

comment on function bee_rep_get_repdata16(integer, date, date) is 'Формирование оборотной ведомости по расчету с предприятием за электроэнергию. Используется в RepCreate16.java';

alter function bee_rep_get_repdata16(integer, date, date) owner to postgres;

