create function bee_rep_get_repdata21_nat977(locid integer, start_date date, end_date date, fl boolean, tp_is_exists boolean) returns SETOF bee_repdata21_nat
    language plpgsql
as
$$
/*
	add ito06 2015-05-12 Учитывать, только последние трассы
	add ito06 2012-08-02
	ito06 2012-02-02 Сводный баланс за период
*/
DECLARE
	RowLine bee_repdata21_nat%rowtype;
	count_n bigint;
	param character varying;
BEGIN
--
	IF  tp_is_exists = true
		THEN  param = ' NOT '; ELSE param =' ';
	END IF;   
	EXECUTE 'create TEMPORARY table  temp_gis_traces_for_rep21  AS               
		(select gt.locid, gt.period, gt.pchain, gt.objowner, gt.objname, gt.objcode,  gt.objtype, gt.rowid, gt.kod  
		   from gis_traces as gt
		left join gis_traces_tmp as gtt USING (kod, locid,pchain, objowner, objname, objcode, objtype) where gtt.period is '|| param ||' NULL);';

       	EXECUTE 'create TEMPORARY table temp_gis_traces21  AS
		(select gt.locid, gt.period, gt.pchain, gt.objowner,  gt.objname, gt.objcode, gt.objtype, gt.kod from gis_traces AS gt 
                   join (select  max(period) AS period, locid, objcode, objtype from gis_traces  group by locid, objcode, objtype) AS gt1
                  using (period, locid, objcode, objtype));';	
--
FOR RowLine IN (
	SELECT
		gis.objcode AS code,
		CASE WHEN $4 
		   THEN CASE WHEN gis.objname IS NOT NULL
			   THEN gis.objname || ' '
			   ELSE ''
			END
		   ELSE CASE WHEN a6.objname IS NOT NULL
			   THEN a6.objname || ' '
			   ELSE ''
			END 
			||CASE WHEN a5.objname IS NOT NULL
			     THEN a5.objname || ' '
			     ELSE ''
			  END
			||CASE WHEN a4.objname IS NOT NULL
			     THEN a4.objname || ' '
			     ELSE ''
			  END 
			||CASE WHEN a3.objname IS NOT NULL
			     THEN a3.objname || ' '
			     ELSE ''
			  END
			||CASE WHEN a2.objname IS NOT NULL
			     THEN a2.objname || ' '
			     ELSE ''
			  END
			||CASE WHEN a1.objname IS NOT NULL
			     THEN a1.objname || ' '
			     ELSE ''
			END 
			||CASE WHEN gis.objname IS NOT NULL
			     THEN gis.objname || ' '
			     ELSE ''
			  END 
		END 									AS pch,
		CASE WHEN n_off.n_off  IS NOT NULL
		   THEN n_off.n_off  
		   ELSE 0
		END									AS n_off,
		CASE WHEN n.n IS NOT NULL 
		   THEN n.n 
		   ELSE 0 	
		END 									AS n,
		0::bigint 								AS count_nat,
		ARRAY[
		    rdo1.valman::numeric,
		    rdo2.valman::numeric,
		    rdo3.valman::numeric,
		    rdo4.valman::numeric,
		    rdo5.valman::numeric,
		    rdo6.valman::numeric,
		    rdo7.valman::numeric,
		    rdo8.valman::numeric,
		    rdo9.valman::numeric,
		    rdo10.valman::numeric,
		    rdo11.valman::numeric,
		    rdo12.valman::numeric,
		    rdo13.valman::numeric
		] 									AS v850,
		gto.ownerid 								AS subst_type

	   FROM temp_gis_traces_for_rep21  AS gis
	   JOIN temp_gis_traces_for_rep21 AS gis_child ON gis.objcode = gis_child.objowner OR gis.objcode = gis_child.objcode
	   JOIN regdevconn AS rdc ON rdc.traceid = gis_child.rowid
	   JOIN agreepoint AS apn ON apn.rowid = rdc.pointid
	   JOIN agreement AS amn ON amn.rowid = apn.linkid
      LEFT JOIN (SELECT gis.objcode AS code,
			count(ard.linkid) AS n
		   FROM temp_gis_traces_for_rep21 AS gis
		   JOIN temp_gis_traces_for_rep21 AS gis_child ON gis.objcode = gis_child.objowner OR gis.objcode = gis_child.objcode   
		   JOIN regdevconn AS rdc ON rdc.traceid = gis_child.rowid
	      LEFT JOIN agreeregdev AS ard ON ard.linkid = rdc.pointid AND ard.paramid=189 AND ard.paramval='432'
		  WHERE ard.linkid NOT IN (select linkid from agreeregdev 
                                            where paramid = 690 and length(paramval) = 10
					      and is_date(paramval) and paramval::date < $3)
		  GROUP BY gis.objcode
		) AS n ON n.code = gis.objcode
      LEFT JOIN (SELECT gis.objcode AS code,
			count(ard.linkid) AS n_off
		   FROM temp_gis_traces_for_rep21 AS gis
		   JOIN temp_gis_traces_for_rep21 AS gis_child ON gis.objcode = gis_child.objowner OR gis.objcode = gis_child.objcode
		   JOIN regdevconn AS rdc ON rdc.traceid = gis_child.rowid
	      LEFT JOIN agreeregdev AS ard ON ard.linkid = rdc.pointid AND ard.paramid=189 AND ard.paramval='432'
		  WHERE ard.linkid IN (select linkid from agreeregdev 
					where paramid = 690 and length(paramval) = 10
					  and is_date(paramval) and paramval::date < $3)
		  GROUP BY gis.objcode
		) AS n_off ON n_off.code = gis.objcode
      LEFT JOIN gis_traces_owner AS gto ON gis.rowid = gto.linkid
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,1) AS rdo1 ON rdo1.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,2) AS rdo2 ON rdo2.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,3) AS rdo3 ON rdo3.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,4) AS rdo4 ON rdo4.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,5) AS rdo5 ON rdo5.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,6) AS rdo6 ON rdo6.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,7) AS rdo7 ON rdo7.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,8) AS rdo8 ON rdo8.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,9) AS rdo9 ON rdo9.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,10) AS rdo10 ON rdo10.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,11) AS rdo11 ON rdo11.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,12) AS rdo12 ON rdo12.linkid = gis.objcode
      LEFT JOIN bee_rep21_get_rdo977($1,$2,$3,13) AS rdo13 ON rdo13.linkid = gis.objcode
  
      LEFT JOIN temp_gis_traces21 AS a1 ON a1.objcode = gis.objowner AND a1.objtype<>1000
      LEFT JOIN temp_gis_traces21 AS a2 ON a2.objcode = a1.objowner  AND a2.objtype<>1000    
      LEFT JOIN temp_gis_traces21 AS a3 ON a3.objcode = a2.objowner  AND a3.objtype<>1000    
      LEFT JOIN temp_gis_traces21 AS a4 ON a4.objcode = a3.objowner  AND a4.objtype<>1000    
      LEFT JOIN temp_gis_traces21 AS a5 ON a5.objcode = a4.objowner  AND a5.objtype<>1000    
      LEFT JOIN temp_gis_traces21 AS a6 ON a6.objcode = a5.objowner  AND a6.objtype<>1000    

	  WHERE amn.locid IN(SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1)) 
	    AND gis.objtype = 11 AND gis.objowner IN(select objcode FROM temp_gis_traces21 WHERE objtype IN(9,8,1000)) 
	  GROUP BY gis.objcode, pch, subst_type, n.n, v850, n_off, gis.objname
	  ORDER BY pch)
       LOOP
		count_n =0;		
		IF RowLine.subst_nat[1] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[2] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[3] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[4] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[5] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[6] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[7] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[8] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[9] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[10] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[11] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[12] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		IF RowLine.subst_nat[13] IS NOT NULL  THEN count_n = count_n + 1; END IF; 
		  
		RowLine.count_nat = count_n;
		RETURN NEXT RowLine;
		
	END LOOP;								

	DROP TABLE IF EXISTS temp_gis_traces_for_rep21;
	DROP TABLE IF EXISTS temp_gis_traces21;
END;

$$;

comment on function bee_rep_get_repdata21_nat977(integer, date, date, boolean, boolean) is 'Cводный баланс по ТП за период по выставленным данным. Используется в RepCreate21.java';

alter function bee_rep_get_repdata21_nat977(integer, date, date, boolean, boolean) owner to pgsql;

