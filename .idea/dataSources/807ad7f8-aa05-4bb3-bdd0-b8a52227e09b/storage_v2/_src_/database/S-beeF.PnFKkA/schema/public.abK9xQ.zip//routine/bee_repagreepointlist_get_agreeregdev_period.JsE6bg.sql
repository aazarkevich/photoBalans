create function bee_repagreepointlist_get_agreeregdev_period(loc integer) returns SETOF bee_repagreepointlist_agreeregdev_period
    language sql
as
$$
/*
	add ito06 2015-06-18
	ito06 2011-12-01 Список устройств
*/
SELECT 
	apn.rowid,
	arp356.paramval,							-- расчетный коэффициент			*kol31*
	arp408.paramval,							-- потери в линиях				*kol32*
	arp419.paramval,							-- потери холостого хода			*kol34*
	arp424.paramval,							-- разрешенная мощность по ТУ (кВт)		*kol40*
	arp425.paramval,							-- кол-во часов работы в сутки			*kol41*
	arp426.paramval,								-- макс. мощность (по договору)		*kol38*
	arp439.element_name::text,						-- уровень напряжения				*kol28*
	arp664.account,								-- лицевой счет головного абонента		*kol8* 
	arp664.prodnumber,							-- номер счетчика головного абонента		*kol9* 
	arp685.paramval,							-- присоединенная мощность			*kol37*
	arp688.paramval,							-- нагрузочные потери				*kol33*
	arp689.element_name,							-- работа в выходные дни			*kol42*
	arp830.paramval,							-- заявленная мощность				*kol39*
	arp851.paramval,							-- участок обхода				*kol36*
	arp1015.element_name,							-- примечание (пост)				*kol46*
	arp1016.paramval,							-- Контролер ФИО				*kol47*
	arp1474.paramval,							-- номер телефона				*kol48*
	arp1475.paramval,							-- номер SIM-карты				*kol49*
	arp1535.paramval,							-- номер централизованного договора		*kol50*
	arp1614.paramval,							-- номер смешанного договора			*kol51*
	arp1626.paramval,							-- потери в приборе учета			*kol35*
	
	arp156.paramval,							-- номер пломбы					*kol77*
	arp970.paramval,							-- тип пломбы					*kol78*
	arp971.paramval,							-- место установки пломбы			*kol79*
	arp1862.paramval,							-- ограничение режима потребления эл.эн.	*kol80*
	arp1862.period,								-- дата	ограничения режима потребления эл.эн. 	*kol81*
	arp1863.paramval,							-- возобновление режима потребления эл.эн	*kol82*
	arp1863.period								-- дата возобновления режима потребления эл.эн	*kol83*
		

  FROM agreepoint 									AS apn	
  JOIN agreement									AS amn 		ON amn.rowid = apn.linkid
--номер пломбы
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(156)) 		AS arp156 	ON apn.rowid=arp156.linkid 
--расчетный коэфициент
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(356)) 		AS arp356	ON apn.rowid=arp356.linkid
--потери в линиях %
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(408)) 		AS arp408 	ON apn.rowid=arp408.linkid
--потери холостого хода (кВт*ч)*
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(419)) 		AS arp419 	ON apn.rowid=arp419.linkid
--разрешенная мощность по ТУ(кВт)   
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(424)) 		AS arp424	ON apn.rowid=arp424.linkid
--колич. часов работы в сутки
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(425)) 		AS arp425	ON apn.rowid=arp425.linkid
---макс. мощность (по договору)
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(426)) 		AS arp426  	ON apn.rowid=arp426.linkid
--уровень напряжения
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(439)) 		AS arp_439 	ON apn.rowid=arp_439.linkid
   LEFT JOIN dic_elements 								AS arp439 	ON arp_439.paramval::integer=arp439.rowid
--счетчик головного абонента
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(664)) 		AS arp_664 	ON arp_664.linkid = apn.rowid
   LEFT JOIN agreepoint 								AS arp664 	ON arp664.rowid = arp_664.paramval::integer  
--присоединенная мощность   
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(685)) 		AS arp685 	ON apn.rowid=arp685.linkid
--нагрузочные потери в %
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(688)) 		AS arp688 	ON apn.rowid=arp688.linkid
--работа в выходные дни   
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(689)) 		AS arp_689	ON apn.rowid=arp_689.linkid
   LEFT JOIN dic_elements 								AS arp689	ON arp689.rowid = arp_689.paramval::integer
--место установки пломбы
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(791)) 		AS arp791 	ON apn.rowid=arp791.linkid  
--заявленная мощность   
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(830))		AS arp830 	ON apn.rowid=arp830.linkid
--участок обхода
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(851)) 		AS arp851  	ON apn.rowid=arp851.linkid
--тип пломбы
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(970)) 		AS arp970 	ON apn.rowid=arp970.linkid 
--Примечание (пост)
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(1015))	 	AS arp_1015 	ON apn.rowid=arp_1015.linkid
   LEFT JOIN dic_elements 								AS arp1015 	ON arp_1015.paramval::integer=arp1015.rowid
--ФИО Контролера
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(1016)) 		AS arp1016 	ON apn.rowid=arp1016.linkid
--номер телефона
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(1474)) 		AS arp1474   	ON apn.rowid=arp1474.linkid
--номер SIM карты
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(1475)) 		AS arp1475 	ON apn.rowid=arp1475.linkid 
--номер центр дог.
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(1535)) 		AS arp1535 	ON apn.rowid=arp1535.linkid 
--номер смеш. дог.
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(1614)) 		AS arp1614 	ON apn.rowid=arp1614.linkid 
--потери в приборе учета
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(1626)) 		AS arp1626 	ON apn.rowid=arp1626.linkid 
-- место установки пломбы
   LEFT JOIN (select linkid, paramval from bee_rep_get_ard_per_max(971)) 		AS arp971 	ON apn.rowid=arp971.linkid 
-- ограничение режима потребления эл.эн./дата	ограничения режима потребления эл.эн. 
   LEFT JOIN (select linkid, paramval, period from bee_rep_get_ard_per_max_with_per(1862)) AS arp1862 	ON apn.rowid=arp1862.linkid  
-- возобновление режима потребления эл.эн / дата возобновления режима потребления эл.эн
   LEFT JOIN (select linkid, paramval, period from bee_rep_get_ard_per_max_with_per(1863))AS arp1863 	ON apn.rowid=arp1863.linkid  


WHERE amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1))
$$;

comment on function bee_repagreepointlist_get_agreeregdev_period(integer) is 'Список устройств, периодические параметры. Используется в bee_repagreepointlist_get_content(int, text)';

alter function bee_repagreepointlist_get_agreeregdev_period(integer) owner to postgres;

