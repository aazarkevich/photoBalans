create function bee_rep_get_repdata28_get_en_1(amn_rowid integer, year1 date) returns SETOF bee_rep_tab28_en
    language sql
as
$$
/*
ito06 2013-01-18 
Приложение 1а, реальные данные  - эл.эн.
*/

SELECT 
    bpc.amnid AS amnid,
    null::integer AS pointid,
    CASE WHEN bpc.ul = 311  THEN 1
         WHEN bpc.ul = 308  THEN 2
         WHEN bpc.ul = 310  THEN 3
         WHEN bpc.ul = 306  THEN 4
    END AS ul,
    null::varchar AS ulev,
    
    sum(bpc.sum) AS sum,
    sum(bpc.m_1) AS m_1,
    sum(bpc.m_2) AS m_2,
    sum(bpc.m_3) AS m_3,
    sum(bpc.m_4) AS m_4,
    sum(bpc.m_5) AS m_5,
    sum(bpc.m_6) AS m_6,
    sum(bpc.m_7) AS m_7,
    sum(bpc.m_8) AS m_8,
    sum(bpc.m_9) AS m_9,
    sum(bpc.m_10) AS m_10,
    sum(bpc.m_11) AS m_11,
    sum(bpc.m_12) AS m_12
FROM bee_rep28_get_en_real($1, $2) AS bpc 
GROUP BY amnid,ul
ORDER BY ul;
$$;

comment on function bee_rep_get_repdata28_get_en_1(integer, date) is 'Приложение 1а, реальные данные  - эл.эн. Используется в  bee_rep_get_repdata28_get_en(int, date, int)';

alter function bee_rep_get_repdata28_get_en_1(integer, date) owner to postgres;

