create function bee_repakt10_get_tot(bd_rowid integer)
    returns TABLE(vn_sum numeric, vn_sum_tot numeric, sn1_sum numeric, sn1_sum_tot numeric, sn2_sum numeric, sn2_sum_tot numeric, nn_sum numeric, nn_sum_tot numeric, tot_sum numeric, tot_sum_tot numeric, tot_tax_sum numeric)
    language plpgsql
as
$$
/*
	ito06 2021-01-29 Акт(передача 2021) итог
*/
BEGIN
	RETURN QUERY (SELECT 
		sum(a.vn_sum) ,
		sum(vn_sum_w_tax) as vn_sum_tot,
		sum(a.sn1_sum) as sn1_sum,
		sum(sn1_sum_w_tax) as sn1_sum_tot,
		sum(a.sn2_sum) as sn2_sum,
		sum(sn2_sum_w_tax) as sn2_sum_tot,
		sum(a.nn_sum) as nn_sum,
		sum(nn_sum_w_tax) as nn_sum_tot,
		sum(a.tot_sum) as tot_sum,
		sum(a.tot_sum_w_tax) as tot_sum_tot,
	    sum(a.tot_tax_sum) as tot_tax_sum


	from tmp_repakt10_content as a) ;
END;
$$;

comment on function bee_repakt10_get_tot(integer) is 'Акт (передача) итог. Используется в RepAkt10.java';

alter function bee_repakt10_get_tot(integer) owner to postgres;

