create function bee_get_bal_tp_period_data_phis977(date_from text, date_to text, _locid integer, usemkd text, uselocid text, short_name text, tp_not_exist text) returns SETOF bal_tp_period_data_phis
    language plpgsql
as
$$
/*
	add ito06 2015-05-12 Учитывать, только последние трассы
	add ito05 2015-03-24
	add ito06 2012-08-06
	ito06 2011-12-20 Свод по ТП

	-- uselocid (true -сформировать c делением на участки)
	-- short_name (true - сформировать с сокращенным названием ТП)
	-- tp_not_exist (true - сформировать по отключенным трассам)
*/
DECLARE
	RowLine bal_tp_period_data_phis%rowtype;
	param character varying;
BEGIN
	IF  tp_not_exist = 'false'
		THEN  param = ' NOT '; ELSE param =' ';
	END IF;   
	EXECUTE 'create TEMPORARY  table  temp_gis_traces_for_bal_tp_period  AS
		(select gt.locid, gt.period, gt.pchain, gt.objowner, gt.objname, gt.objcode,  gt.objtype, gt.rowid, gt.kod  
		   from gis_traces as gt
		left join gis_traces_tmp as gtt USING (kod, locid,pchain, objowner, objname, objcode, objtype) where gtt.period is '|| param ||' NULL);';
	EXECUTE 'create TEMPORARY table temp_gis_traces_bal  AS
		(select gt.locid, gt.period, gt.pchain, gt.objowner,  gt.objname, gt.objcode, gt.objtype, gt.kod from gis_traces AS gt 
                   join (select  max(period) AS period, locid, objcode, objtype from gis_traces  group by locid, objcode, objtype) AS gt1
                  using (period, locid, objcode, objtype));'; 
   
  IF (useMKD::boolean = true) THEN
	FOR RowLine IN (SELECT 
				tab2.tpname AS fullname, -- колонка 2
		                tab1.obj_code, -- для связки с данными из базы юр лиц
		                1 as objowner_code, 
                                sum(tab1.potreb) AS kol4 -- колонка 7
		           FROM ( SELECT
	                                 CASE WHEN gt.objtype=11 THEN family.son_code
		                              WHEN gt.objtype=10 OR gt.objtype=9 OR gt.objtype=8 THEN family.father_code
	                                 END AS obj_code,
	        	                 CASE WHEN a1.paramval='432' THEN sum(a3.valman)
	                                 END AS potreb --потребление
	                            FROM regdevconn AS rdc
	                            JOIN agreepoint AS apn ON rdc.pointid=apn.rowid
 	                            JOIN agreement AS amn ON apn.linkid=amn.rowid
	                            JOIN temp_gis_traces_for_bal_tp_period AS gt ON rdc.traceid = gt.rowid
	                            JOIN ( SELECT apn.rowid AS r1,
	                                          t1.objcode AS son_code,
		                                  t2.objcode AS father_code
 		                             FROM agreepoint AS apn 
		                             JOIN regdevconn AS rdc ON apn.rowid=rdc.pointid 
                                             JOIN temp_gis_traces_for_bal_tp_period AS t1 ON rdc.traceid=t1.rowid 
   		                        LEFT JOIN temp_gis_traces_for_bal_tp_period AS t2 ON t2.objcode=t1.objowner 
                                            GROUP BY apn.rowid, t1.objname, t1.objcode, t1.objowner, t2.objname, t2.objcode
	       	                        ) AS family ON rdc.pointid=family.r1 
	                      LEFT JOIN ( SELECT paramval, linkid 
	                                    FROM agreeregdev WHERE paramid=189 AND paramval='432'
	                                ) AS a1 ON rdc.pointid=a1.linkid
	                     LEFT JOIN ( SELECT sum(valman::float) AS valman, linkid 
	                                   FROM regdevoper977 
	                                  WHERE paramid=407 
	                                    AND valman <> '-' AND valman <> ''
	                                    AND operdate BETWEEN date_from::date AND date_to::date 
	                                  GROUP BY linkid
	                                ) AS a3 ON rdc.pointid=a3.linkid     
	                           WHERE -- ito05 150319
				       amn.locid IN (SELECT rowid FROM denet WHERE kod LIKE ((SELECT kod FROM denet WHERE rowid = _locid) ||  (case when useLocid = 'true' then '%' else '' end)))
	                           GROUP BY obj_code, a1.paramval, gt.objtype
	                      ) AS tab1 
	       JOIN ( SELECT 
		             CASE 
		                WHEN short_name = 'false'		            
                                   THEN(
   		         	        CASE 
					   WHEN a6.objname IS NOT NULL 
                                              THEN a6.objname
                                           ELSE ''
                                        END || CASE 
                                              WHEN a5.objname IS NOT NULL 
                                                 THEN ' ' || a5.objname
                                              ELSE ''
                                        END || CASE 
                                              WHEN a4.objname IS NOT NULL 
                                                 THEN ' ' || a4.objname
                                              ELSE ''
                                        END || CASE 
                                              WHEN a3.objname IS NOT NULL 
                                                 THEN ' ' || a3.objname
                                              ELSE ''
                                        END || CASE 
                                             WHEN a2.objname IS NOT NULL 
                                                THEN ' ' || a2.objname
                                             ELSE ''
                                       END || CASE 
                                             WHEN a1.objname IS NOT NULL 
                                                THEN ' ' || a1.objname
                                             ELSE ''
                                       END || CASE 
                                             WHEN tmp_gt.objname IS NOT NULL 
                                                THEN ' ' || tmp_gt.objname
                                             ELSE ''
                                       END 
                                      ) ELSE tmp_gt.objname
                                 END 					        AS tpname,
                                 tmp_gt.objcode                                 AS objcode
                            FROM temp_gis_traces_for_bal_tp_period AS tmp_gt 
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a1 ON tmp_gt.objowner=a1.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a2 ON a1.objowner=a2.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a3 ON a2.objowner=a3.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a4 ON a3.objowner=a4.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a5 ON a4.objowner=a5.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a6 ON a5.objowner=a6.objcode
                           WHERE tmp_gt.objtype=11
                           ORDER BY tpname
		     ) AS tab2 ON tab2.objcode = tab1.obj_code

	       GROUP BY fullname, obj_code
	       ORDER BY fullname
	  )
	  LOOP
	     RETURN NEXT RowLine; 
	  END LOOP;
  ELSE
	FOR RowLine IN (SELECT 
				tab2.tpname AS fullname, -- колонка 2
				tab1.obj_code, -- для связки с данными из базы юр лиц
				1 as objowner_code, 
				sum(tab1.potreb) AS kol4 -- колонка 7
			   FROM ( SELECT 
	          	                 CASE WHEN gt.objtype=11 THEN family.son_code
		                              WHEN gt.objtype=10 OR gt.objtype=9 OR gt.objtype=8 THEN family.father_code
	                                 END AS obj_code,
	         	                 CASE WHEN a1.paramval='432' THEN sum(a3.valman)
	                                 END AS potreb --потребление
	                            FROM regdevconn AS rdc
	                            JOIN agreepoint AS apn ON rdc.pointid=apn.rowid
 	                            JOIN agreement AS amn ON apn.linkid=amn.rowid
	                            JOIN temp_gis_traces_for_bal_tp_period AS gt ON rdc.traceid = gt.rowid
	                            JOIN ( SELECT apn.rowid AS r1, 
	                                          t1.objcode AS son_code, 
		                                  t2.objcode AS father_code
 		                             FROM agreepoint AS apn 
		                             JOIN regdevconn AS rdc ON apn.rowid=rdc.pointid 
                                             JOIN temp_gis_traces_for_bal_tp_period AS t1 ON rdc.traceid=t1.rowid 
   		                        LEFT JOIN temp_gis_traces_for_bal_tp_period AS t2 ON t2.objcode=t1.objowner 
                                            GROUP BY apn.rowid, t1.objname, t1.objcode, t1.objowner, t2.objname, t2.objcode
	       	                         ) AS family ON rdc.pointid=family.r1 
	                       LEFT JOIN ( SELECT paramval, linkid 
	                                     FROM agreeregdev WHERE paramid=189 AND paramval='432'
	                                 ) AS a1 ON rdc.pointid=a1.linkid
	                       LEFT JOIN ( SELECT sum(valman::float) AS valman, linkid 
	                                     FROM regdevoper977 
	                                    WHERE paramid=407 
	                                      AND valman <> '-' AND valman <> ''
	                                      AND operdate BETWEEN date_from::date AND date_to::date 
	                                    GROUP BY linkid
	                                  ) AS a3 ON rdc.pointid=a3.linkid     
	                            WHERE -- ito05 150319
				       amn.locid IN (SELECT rowid FROM denet WHERE kod LIKE ((SELECT kod FROM denet WHERE rowid = _locid) ||  (case when useLocid = 'true' then '%' else '' end)))
	                              AND apn.rowid NOT IN (SELECT linkid FROM agreeregdev WHERE paramid = 715 AND paramval IN ('704', '966'))
	                            GROUP BY obj_code, a1.paramval, gt.objtype
	                   ) AS tab1
	         JOIN ( SELECT 
		             CASE 
		                WHEN short_name = 'false'		            
                                   THEN(
   		         	        CASE 
					   WHEN a6.objname IS NOT NULL 
                                              THEN a6.objname
                                           ELSE ''
                                        END || CASE 
                                              WHEN a5.objname IS NOT NULL 
                                                 THEN ' ' || a5.objname
                                              ELSE ''
                                        END || CASE 
                                              WHEN a4.objname IS NOT NULL 
                                                 THEN ' ' || a4.objname
                                              ELSE ''
                                        END || CASE 
                                              WHEN a3.objname IS NOT NULL 
                                                 THEN ' ' || a3.objname
                                              ELSE ''
                                        END || CASE 
                                             WHEN a2.objname IS NOT NULL 
                                                THEN ' ' || a2.objname
                                             ELSE ''
                                       END || CASE 
                                             WHEN a1.objname IS NOT NULL 
                                                THEN ' ' || a1.objname
                                             ELSE ''
                                       END || CASE 
                                             WHEN tmp_gt.objname IS NOT NULL 
                                                THEN ' ' || tmp_gt.objname
                                             ELSE ''
                                       END 
                                      ) ELSE tmp_gt.objname
                                 END 					        AS tpname,
                                 tmp_gt.objcode                                 AS objcode
                            FROM temp_gis_traces_for_bal_tp_period AS tmp_gt 
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a1 ON tmp_gt.objowner=a1.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a2 ON a1.objowner=a2.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a3 ON a2.objowner=a3.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a4 ON a3.objowner=a4.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a5 ON a4.objowner=a5.objcode
                       LEFT JOIN (SELECT * FROM temp_gis_traces_bal WHERE objtype <> 1000) AS a6 ON a5.objowner=a6.objcode
                           WHERE tmp_gt.objtype=11
                           ORDER BY tpname
		     ) AS tab2 ON tab2.objcode = tab1.obj_code 

	       GROUP BY fullname, obj_code
	       ORDER BY fullname
	  )
	  LOOP
	     RETURN NEXT RowLine; 
	  END LOOP;
  END IF;

	DROP TABLE IF EXISTS temp_gis_traces_for_bal_tp_period;
	DROP TABLE IF EXISTS temp_gis_traces_bal;	
	RETURN;
END;
$$;

comment on function bee_get_bal_tp_period_data_phis977(text, text, integer, text, text, text, text) is 'Свод по ТП по выставленным данным. Используется в RepBal5.java, RepBal6.java';

alter function bee_get_bal_tp_period_data_phis977(text, text, integer, text, text, text, text) owner to pgsql;

