create function bee_add_agreement_info(agreeid integer, par integer, val character varying, per character varying) returns integer
    language plpgsql
as
$$
/*
	ito06 2013-11-21 ввод парараметра в таблицу agreement_info
*/
DECLARE
	NR INTEGER;
BEGIN
 BEGIN
    INSERT INTO agreement_info (linkid,paramid,paramval,period) 
                        values (agreeid,  par , val , per::date) RETURNING rowid INTO NR;
      EXCEPTION
      WHEN UNIQUE_VIOLATION THEN
      RETURN -1;
   END;
   RETURN NR;                  

END;
$$;

comment on function bee_add_agreement_info(integer, integer, varchar, varchar) is 'Ввод парараметра в таблицу agreement_info. Используется RepDebitor.java, AppUtils.java';

alter function bee_add_agreement_info(integer, integer, varchar, varchar) owner to pgsql;

