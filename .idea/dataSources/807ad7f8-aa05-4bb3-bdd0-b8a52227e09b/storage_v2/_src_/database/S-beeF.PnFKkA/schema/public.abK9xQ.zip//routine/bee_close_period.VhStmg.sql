create function bee_close_period(dst_host character varying, db_name character varying, tbl_name character varying, dat character varying, fill integer) returns void
    language plpgsql
as
$$
/*
         Установка закрытого периода по участкам 
	 ito06 2013-08-07
*/
DECLARE
   ConnectParams VARCHAR;
   SQL VARCHAR;
   Z   VARCHAR; 
BEGIN
  ConnectParams = 'dbname = '|| db_name 
               || ' port = 5432' 
               || ' host=' || dst_host 
               || ' user = pgsql '
               || ' password=''123'' ';
  --   
  SQL= 'SELECT bee_close_period_set(''' || tbl_name || ''', '''|| dat || ''','||fill||')'; 
  SELECT typ.* FROM dblink(ConnectParams, SQL) AS typ (i INTEGER) INTO Z; 
END;
$$;

comment on function bee_close_period(varchar, varchar, varchar, varchar, integer) is 'Установка закрытого периода по участкам. Используется в AgreeJoinUni.java, AgreeJoinMix.java, AppUtils.java';

alter function bee_close_period(varchar, varchar, varchar, varchar, integer) owner to pgsql;

