create function bee_get_gis_rtp(_period text, _locid integer) returns SETOF t_gis_rtp
    language plpgsql
as
$$
    --
--
DECLARE
  RowLine t_gis_rtp%rowtype;
---  
BEGIN
---  
  FOR RowLine IN (SELECT gis_traces.pchain,
			 gis_traces.objname,
			 gis_rtp.loss_val,
			 gis_rtp.rowid,
			 gis_rtp.period,
			 gis_traces.objcode::text,
			 gis_traces.objowner::text
                  FROM gis_traces
                  join gis_rtp on gis_traces.rowid = gis_rtp.traceid
                  where objtype = 11
                  and gis_rtp.period = _period::date
		  order by gis_rtp.rowid
  )
  LOOP
     RETURN NEXT RowLine; 
  END LOOP;
---
RETURN;
--
END;

$$;

comment on function bee_get_gis_rtp(text, integer) is 'Используется в PoteriRTP.java, SessionBean1.java';

alter function bee_get_gis_rtp(text, integer) owner to pgsql;

