create function bee_rep_get_repdata31(loc_id integer, str_date date, end_date date, fil character varying) returns SETOF bee_repdata31
    language plpgsql
as
$$
/*	
	ito06 2015-12-08: Сводный акт первичного учета эл.эн.; по абонентам ВСЕГО по фидиалу
*/	
BEGIN
	DROP TABLE IF EXISTS bee_rep_get_repdata31_tmp; 
	PERFORM bee_rep_get_repdata31_create_tmp_table($1,$2,$3, $4);
	RETURN QUERY( SELECT * FROM bee_rep_get_repdata31_tmp);
        DROP TABLE IF EXISTS bee_rep_get_repdata31_tmp;  
END;
$$;

comment on function bee_rep_get_repdata31(integer, date, date, varchar) is 'Сводный акт первичного учета эл.эн.; по абонентам ВСЕГО по филиалу. Используется в RepCreate31.java, RepCreate32.java';

alter function bee_rep_get_repdata31(integer, date, date, varchar) owner to pgsql;

