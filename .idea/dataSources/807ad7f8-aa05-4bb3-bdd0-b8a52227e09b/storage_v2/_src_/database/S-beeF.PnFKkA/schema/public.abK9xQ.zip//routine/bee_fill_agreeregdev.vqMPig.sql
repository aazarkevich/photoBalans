create function bee_fill_agreeregdev(pointid integer, markid integer, xfilter character varying) returns integer
    language plpgsql
as
$$
    --
-- заполнение параметров устройств
--
-- pointid - rowid нового устройства в agreepoint
-- markid  - марка устройства (rowid из dic_elements)
-- filter  - фильтр параметров по код 2XX из dic_elements
-- ОЧЕНЬ ЖАЛЬ ЧТО НЕ ИСПОЛЬЗУЮТ ЗНАЧЕНИЯ ПО УМОЛЧАНИЮ ИЗ СПРАВОЧНИКА
--
BEGIN
--
INSERT INTO agreeregdev (linkid,paramid,paramval) 
SELECT pointid,regdevattr.paramid, 

CASE WHEN regdevattr.paramid = 356 THEN '1'
     WHEN regdevattr.paramid = 408 THEN '0'
     WHEN regdevattr.paramid = 688 THEN '0'
     WHEN regdevattr.paramid = 419 THEN '0'
     ELSE '?'
END

FROM regdevattr
   LEFT JOIN dic_elements ON regdevattr.paramid = dic_elements.rowid
WHERE 
    regdevattr.deviceid                   = markid  AND
    dic_elements.link                     = 38      AND  
    dic_elements.element_code::varchar LIKE xfilter AND  
    regdevattr.paramid NOT IN 
        (SELECT paramid FROM agreeregdev WHERE linkid = pointid)
;
---
RETURN 0;
---
END;
$$;

comment on function bee_fill_agreeregdev(integer, integer, varchar) is 'Заполнение параметров устройств.';

alter function bee_fill_agreeregdev(integer, integer, varchar) owner to pgsql;

