create function bee_docs_result_add_z1(docid integer, _doctyp integer) returns void
    language plpgsql
as
$$
/*
	add ito06 2014-11-11
	2009-12-16   Будогянц Д.В.
	2010-05-26   Будогянц Д.В.
*/
DECLARE
	LastDate DATE;   
BEGIN
	--
	LastDate  = (SELECT docdat FROM bee_docs WHERE rowid   = docid   ORDER BY docdat DESC LIMIT 1);
       	--ПРОВЕРКА Если текущий документ это первый документ в  месяце и если бета <> 0

	IF (SELECT COUNT(*) FROM bee_docs 
             WHERE linkid IN (SELECT linkid FROM bee_docs WHERE rowid = docid)
               AND doctyp = _doctyp --добавлено 2010-05-25
               AND docdat BETWEEN
                   (SELECT (to_char(LastDate::DATE,'YYYY-MM')||'-01')::DATE) 
                       AND 
                    (SELECT (to_char(LastDate::DATE,'YYYY-MM')||'-01')::DATE+
                                '1 month'::INTERVAL -'1 day'::INTERVAL)) = 1 

	AND (SELECT beta FROM dic_cons_share 
              WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                       ||'-01')::DATE)) <> 1
	   THEN

		IF (LastDate>'2014-09-30') THEN      
		-- вставить записи в таблицу bee_docs_result
		INSERT INTO bee_docs_result(
			linkid,      -- 1 код текущего документа
			tar_grp,     -- 2 код тарифной группы
			tar_typ,     -- 3 тип тарифа (рег / нерег)
			row_typ,     -- 4 тип строки (положит / отриц)
			name,        -- 5 не используется
			amount,      -- 6 количество 
			price,       -- 7 цена
			sum_no_tax,  -- 8 стоимость без налога
			tax_rate,    -- 9 ставка налога
			tax_sum,     -- 10 сумма налога
			sum_with_tax-- 11 стоимость с налогом
		) (
		SELECT 
			docid,             --1
			tar_grp AS tar_g,  --2
			1069 AS tar_t,     --3
			1070 AS row_t,     --4
			'-'  AS nam,       --5   
		-- 6 (количество * доля потребления)
		-- доля потребления = 1 - бета (для электроэнергии) или 1-гамма (для мощности)
		SUM(CASE WHEN dic_tarif_group.tarif_val = 1043
			  THEN amount * (1-(SELECT beta FROM dic_cons_share 
                                             WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
			
			 WHEN dic_tarif_group.tarif_val = 1042
			  THEN amount * (1-(SELECT gamma FROM dic_cons_share 
                                             WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
		    END)::NUMERIC(11,3) AS amount, 
 
		-- конец 6
		-- 7 (нерег тариф) см. последнюю строку, исправлена группировка по price на dic_terif_sum.summ1 из-за ресшепления(2010-05-25)
		CASE 
		   WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
		   WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
			(100 + (SELECT tax_proc FROM bee_docs_tax 
                                 WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)
                                 ORDER BY dat1 DESC LIMIT 1))  
		END AS price, 
		-- конец 7
		-- 8 (стоимость без налога = количество * доля потребления * нерег тариф)
		SUM((CASE 
			WHEN dic_tarif_group.tarif_val = 1043
                          THEN amount * (1-(SELECT beta FROM dic_cons_share 
                                              WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
			WHEN dic_tarif_group.tarif_val = 1042 
			  THEN amount * (1-(SELECT gamma FROM dic_cons_share 
                                             WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
		     END )::NUMERIC(11,3) *
                    (CASE 
			WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
			WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
				(100 + (SELECT tax_proc FROM bee_docs_tax 
                                         WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                                                                    ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)
					 ORDER BY dat1 DESC LIMIT 1)) 
		     END)) ::NUMERIC(11,2) AS s_no_tax,  --исправлено 2010-05-25
		-- конец 8
		0, --9 2014-11-11
		0, --10 2014-11-11
		0  --11 2014-11-11
		
      FROM bee_docs_result
      JOIN bee_docs ON bee_docs_result.linkid = bee_docs.rowid
      JOIN dic_tarif_group ON bee_docs_result.tar_grp = dic_tarif_group.rowid
      JOIN dic_tarif_sum ON dic_tarif_group.rowid = dic_tarif_sum.tarifid
      JOIN dic_elements ON dic_tarif_group.usr_grp = dic_elements.rowid

      WHERE bee_docs.linkid IN 
         (SELECT bee_docs.linkid FROM bee_docs
          JOIN bee_docs_result ON bee_docs.rowid = bee_docs_result.linkid
          WHERE bee_docs.linkid IN
             (SELECT linkid FROM bee_docs WHERE rowid = docid)
         )

      AND bee_docs.docdat BETWEEN 
                    -- месяц предшествующий месяцу текущего документа 
                    (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                             ||'-01')::DATE) 
                    AND 
                    (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                             ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL) 
      AND bee_docs.doctyp = _doctyp
      AND bee_docs.docvid = 1043
      AND dic_tarif_sum.period BETWEEN 
                    -- месяц предшествующий месяцу текущего документа
                    (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                             ||'-01')::DATE) 
                    AND 
                    (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                             ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL) 
      AND (dic_elements.element_code < 30000 OR dic_elements.element_code >= 40000)

      GROUP BY docid, tar_g, tar_t, row_t, nam, dic_tarif_sum.summ1, tax_r, dic_tarif_group.vat_val, 
               dic_tarif_sum.summ1 
      ); 

			ELSE
			-- вставить записи в таблицу bee_docs_result
		INSERT INTO bee_docs_result(
			linkid,      -- 1 код текущего документа
			tar_grp,     -- 2 код тарифной группы
			tar_typ,     -- 3 тип тарифа (рег / нерег)
			row_typ,     -- 4 тип строки (положит / отриц)
			name,        -- 5 не используется
			amount,      -- 6 количество 
			price,       -- 7 цена
			sum_no_tax,  -- 8 стоимость без налога
			tax_rate,    -- 9 ставка налога
			tax_sum,     -- 10 сумма налога
			sum_with_tax-- 11 стоимость с налогом
		) (
		SELECT 
			docid,             --1
			tar_grp AS tar_g,  --2
			1069 AS tar_t,     --3
			1070 AS row_t,     --4
			'-'  AS nam,       --5   
		-- 6 (количество * доля потребления)
		-- доля потребления = 1 - бета (для электроэнергии) или 1-гамма (для мощности)
		SUM(CASE WHEN dic_tarif_group.tarif_val = 1043
			  THEN amount * (1-(SELECT beta FROM dic_cons_share 
                                             WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
			
			 WHEN dic_tarif_group.tarif_val = 1042
			  THEN amount * (1-(SELECT gamma FROM dic_cons_share 
                                             WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
		    END)::NUMERIC(11,3) AS amount, 
 
		-- конец 6
		-- 7 (нерег тариф) см. последнюю строку, исправлена группировка по price на dic_terif_sum.summ1 из-за ресшепления(2010-05-25)
		CASE 
		   WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
		   WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
			bee_docs_calc_add(100 + (SELECT tax_proc FROM bee_docs_tax 
                                 WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)
                                 ORDER BY dat1 DESC LIMIT 1))  
		END AS price, 
		-- конец 7
		-- 8 (стоимость без налога = количество * доля потребления * нерег тариф)
		SUM((CASE 
			WHEN dic_tarif_group.tarif_val = 1043
                          THEN amount * (1-(SELECT beta FROM dic_cons_share 
                                              WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
			WHEN dic_tarif_group.tarif_val = 1042 
			  THEN amount * (1-(SELECT gamma FROM dic_cons_share 
                                             WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
		     END )::NUMERIC(11,3) *
                    (CASE 
			WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
			WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
				(100 + (SELECT tax_proc FROM bee_docs_tax 
                                         WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                                                                    ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)
					 ORDER BY dat1 DESC LIMIT 1)) 
		     END)) ::NUMERIC(11,2) AS s_no_tax,  --исправлено 2010-05-25
		-- конец 8
		
		-- 9 ставка налога
		(SELECT tax_proc FROM bee_docs_tax 
		  WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                      ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)   
		  ORDER BY dat1 DESC LIMIT 1) AS tax_r,                       
		-- конец 9
		--10 сумма налога = кол-во * доля потребления * нерег тариф * ставка налога / 100
		SUM(((CASE WHEN dic_tarif_group.tarif_val = 1043
			     THEN amount * (1-(SELECT beta FROM dic_cons_share 
                                                WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
	
			   WHEN dic_tarif_group.tarif_val = 1042
			     THEN amount * (1-(SELECT gamma FROM dic_cons_share 
                                                WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
                      END )::NUMERIC(11,3)*
                     (CASE WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
                           WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
                                (100 + (SELECT tax_proc FROM bee_docs_tax 
                                         WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                                                        ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)    
                                         ORDER BY dat1 DESC LIMIT 1)) 
                      END)) ::NUMERIC(11,2)*(SELECT tax_proc FROM bee_docs_tax 
                                              WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                                                           ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)  
                                              ORDER BY dat1 DESC LIMIT 1) / 100 ) ::NUMERIC(11,2) AS tax_sum, --добавлено 2010-05-25
		--конец 10
		-- 11 сумма с налогом = (количество * доля потребления *нерег тариф) + (кол-во * доля потребления * нерег тариф * ставка налога /100)
		SUM(((CASE WHEN dic_tarif_group.tarif_val = 1043
                              THEN amount * (1-(SELECT beta FROM dic_cons_share 
                                                 WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
			   WHEN dic_tarif_group.tarif_val = 1042
                              THEN amount * (1-(SELECT gamma FROM dic_cons_share 
                                                 WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
                       END)::NUMERIC(11,3)*
                    (CASE WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
                          WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / 
                                (100 + (SELECT tax_proc FROM bee_docs_tax 
                                         WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                                                     ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)  
                                         ORDER BY dat1 DESC LIMIT 1))
                     END)) ::NUMERIC(11,2) +
               (((CASE
                       WHEN dic_tarif_group.tarif_val = 1043
                         THEN amount * (1-(SELECT beta FROM dic_cons_share 
                                            WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
		       WHEN dic_tarif_group.tarif_val = 1042
		          THEN amount * (1-(SELECT gamma FROM dic_cons_share 
                                             WHERE period = (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE) LIMIT 1)) 
                 END )::NUMERIC(11,3)*
                (CASE WHEN dic_tarif_group.vat_val = 1057 THEN dic_tarif_sum.summ1
                      WHEN dic_tarif_group.vat_val = 1056 THEN dic_tarif_sum.summ1 * 100 / (100 + (SELECT tax_proc FROM bee_docs_tax 
                                        WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                                    ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)  
                                ORDER BY dat1 DESC LIMIT 1)) 
                  END)) *(SELECT tax_proc FROM bee_docs_tax 
                           WHERE dat1 <= (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL)
                           ORDER BY dat1 DESC LIMIT 1) / 100
               ) ::NUMERIC(11,2)) AS kon_sum
		--конец 11 
      FROM bee_docs_result
      JOIN bee_docs ON bee_docs_result.linkid = bee_docs.rowid
      JOIN dic_tarif_group ON bee_docs_result.tar_grp = dic_tarif_group.rowid
      JOIN dic_tarif_sum ON dic_tarif_group.rowid = dic_tarif_sum.tarifid
      JOIN dic_elements ON dic_tarif_group.usr_grp = dic_elements.rowid

      WHERE bee_docs.linkid IN 
         (SELECT bee_docs.linkid FROM bee_docs
          JOIN bee_docs_result ON bee_docs.rowid = bee_docs_result.linkid
          WHERE bee_docs.linkid IN
             (SELECT linkid FROM bee_docs WHERE rowid = docid)
         )

      AND bee_docs.docdat BETWEEN 
                    -- месяц предшествующий месяцу текущего документа 
                    (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                             ||'-01')::DATE) 
                    AND 
                    (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                             ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL) 
      AND bee_docs.doctyp = _doctyp
      AND bee_docs.docvid = 1043
      AND dic_tarif_sum.period BETWEEN 
                    -- месяц предшествующий месяцу текущего документа
                    (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                             ||'-01')::DATE) 
                    AND 
                    (SELECT (to_char((LastDate::DATE-'1 month'::INTERVAL)::DATE,'YYYY-MM')
                             ||'-01')::DATE+'1 month'::INTERVAL -'1 day'::INTERVAL) 
      AND (dic_elements.element_code < 30000 OR dic_elements.element_code >= 40000)

      GROUP BY docid, tar_g, tar_t, row_t, nam, dic_tarif_sum.summ1, tax_r, dic_tarif_group.vat_val, 
               dic_tarif_sum.summ1 
      ); 
		END IF;
 		 

   END IF;

END;
$$;

comment on function bee_docs_result_add_z1(integer, integer) is 'Используется в DocMain.java, DocsAdjustment.java, GroupDocsProcessing.java, AppUtils.java';

alter function bee_docs_result_add_z1(integer, integer) owner to pgsql;

