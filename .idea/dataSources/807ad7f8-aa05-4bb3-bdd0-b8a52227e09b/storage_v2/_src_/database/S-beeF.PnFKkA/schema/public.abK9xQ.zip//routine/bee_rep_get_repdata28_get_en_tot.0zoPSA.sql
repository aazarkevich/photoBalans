create function bee_rep_get_repdata28_get_en_tot(amn_rowid integer, year1 date, typ integer) returns SETOF bee_rep_tab28_en_tot
    language plpgsql
as
$$
/*
ito06 2013-01-18 Приложение 1a
*/
BEGIN

  RETURN QUERY EXECUTE 
	'select  amn.docnumber AS docnum,
	         amn.docdate   AS docdat,
	         cust.abo_name AS cstname,
	         func.sum AS totsum,
	         (SELECT sum(a) from unnest(ARRAY[m_1,m_2,m_3])    as a) AS kvart1,
	         (SELECT sum(a) from unnest(ARRAY[m_4,m_5,m_6])    as a) AS kvart2,
	         (SELECT sum(a) from unnest(ARRAY[m_7,m_8,m_9])    as a) AS kvart3,
	         (SELECT sum(a) from unnest(ARRAY[m_10,m_11,m_12]) as a) AS kvart4
            from bee_rep_get_repdata28_get_en('||$1||', '||quote_literal($2)||','||$3||') As func
       left join agreement AS amn On amn.rowid = '||$1||'
       left join customer AS cust ON cust.abo_code = amn.abo_code
where ul =0 ';

END;
$$;

comment on function bee_rep_get_repdata28_get_en_tot(integer, date, integer) is 'Приложение 1a. Используется в RepCreate28.java';

alter function bee_rep_get_repdata28_get_en_tot(integer, date, integer) owner to postgres;

