create function bee_rep_get_repdata6_get_legal_filters(filter integer, fl integer) returns text
    language plpgsql
as
$$
/*
ito06 2011-12-02
*/
DECLARE filter_add text;
BEGIN
	IF filter = 100 
	   THEN  filter_add = ' AND legal_all.v <> 0 ';
	   ELSE IF filter = 20 
	           THEN filter_add = ' AND legal_all.v IS NULL ';
                   ELSE IF filter = 3 
                           THEN filter_add = ' AND legal_all.v::numeric = 0 ';
                           ELSE IF filter = 120 
                                   THEN filter_add = ' AND (legal_all.v::numeric <> 0  OR legal_all.v IS NULL) ';
                                   ELSE IF filter = 103 
                                           THEN filter_add = ' AND (legal_all.v::numeric <> 0  OR legal_all.v::numeric = 0) ';
                                           ELSE IF filter = 23 
                                                   THEN filter_add = 'AND (legal_all.v IS NULL OR legal_all.v::numeric = 0)';
                                                   ELSE IF filter = 123 
                                                           THEN filter_add = ' AND (legal_all.v::numeric <> 0 OR legal_all.v IS NULL OR legal_all.v::numeric = 0) ';
				                           ELSE IF filter = 0 
				                                   THEN filter_add = ' AND (legal_all.v::numeric<> 0 AND legal_all.v::numeric=0) ';
                                                                END IF;
                                                        END IF;
                                                END IF;
                                        END IF;
                                END IF;
                       END IF;
                 END IF;
	END IF; 

IF fl=1 
    THEN filter_add = filter_add ||' AND (ard1.paramval NOT IN ('||quote_literal(704)||','||quote_literal(966)||') OR ard1.paramval IS NULL)';
END IF;

return filter_add;
END;
$$;

comment on function bee_rep_get_repdata6_get_legal_filters(integer, integer) is 'Используется в bee_rep_get_repdata6_get_legal(varchar, int, date, date, int, int) ';

alter function bee_rep_get_repdata6_get_legal_filters(integer, integer) owner to postgres;

