create function bee_get_oper_regs(integer, integer, date) returns character varying
    language sql
as
$$
    --
-- ЗНАЧЕНИЕ ОПЕРАТИВНЫХ ПОКАЗАНИЙ ПО УКАЗАННОЙ ДАТЕ И ПАРАМЕТРА
-- 1 - устройство agreepoint.rowid
-- 2 - код параметра
-- 3 - дата
--
SELECT valman FROM regdevoper
WHERE 
   linkid    = $1  AND
   paramid   = $2  AND
   operdate  = $3  AND
   valman    ~ E'^\\d{1,}'
;
$$;

comment on function bee_get_oper_regs(integer, integer, date) is 'Значение оперативных показаний по указанной дате и параметру. Используется в OperVal.java, AppUtils.java';

alter function bee_get_oper_regs(integer, integer, date) owner to pgsql;

