create function bee_repakt2_get_intermediate_corr1(br_rowid integer) returns SETOF bee_repakt2_tab
    language sql
as
$$
/*
	add ito06 2015-06-05
	ito06 2013-10-14
*/
	(SELECT
		CASE
		     WHEN tarname_grp in (0,1,2)
			THEN 21
		     WHEN tarname_grp in (3,4,5) 
			THEN 22
		END 										as grp,  
		tarname_grp 									as tarname_grp,
		replace(bdr.period,'корректировка за ','')::date 				as period,
		CASE
		     WHEN tarname_grp = 0
			THEN '<b>Прочие потребители. Электрическая энергия, всего </b>'
		     WHEN tarname_grp = 1
			THEN 'Электрическая энергия (2 став)'
		     WHEN tarname_grp = 2
			THEN 'Электрическая энергия (мощность 2 став)'
		     WHEN tarname_grp = 3
			THEN 'Электрическая энергия в пределах социальной нормы потребления электрической энергии (мощности) <b>(население газ) </b>'
		     WHEN tarname_grp = 4
			THEN 'Электрическая энергия в пределах социальной нормы потребления электрической энергии (мощности)  <b>(население эл.плиты)</b>'
		     WHEN tarname_grp = 5
			THEN 'Электрическая энергия в пределах социальной нормы потребления электрической энергии (мощности)  <b>(население село)</b>'
		END 										as tar_name1,
		CASE
		     WHEN tarname_grp in (0,1,2)
			THEN 'Тариф на услуги по передаче электрической энергии (одноставочный)'
		     WHEN tarname_grp in (3,4,5)
			THEN 'Тариф в пределах социальной нормы потребления электрической энергии (мощности) (одноставочный)'
		     ELSE ''	
		END 										as tar_name2,
		(select a[1] from bee_repakt2_get_tmp1_corr1($1,dtg.vn_code, bdr.period) AS a) 			as vn_amount,
		(select a[2] from bee_repakt2_get_tmp1_corr1($1,dtg.vn_code, bdr.period) AS a) 			as vn_sum,
		(select a[3] from bee_repakt2_get_tmp1_corr1($1,dtg.vn_code, bdr.period) AS a) 			as vn_price,
		(select a[4] from bee_repakt2_get_tmp1_corr1($1,dtg.vn_code, bdr.period) AS a) 			as vn_tax_sum,
		(select a[5] from bee_repakt2_get_tmp1_corr1($1,dtg.vn_code, bdr.period) AS a) 			as vn_sum_with_tax,
		
		(select a[1] from bee_repakt2_get_tmp1_corr1($1,dtg.sn1_code, bdr.period) AS a) 		as sn1_amount,
		(select a[2] from bee_repakt2_get_tmp1_corr1($1,dtg.sn1_code, bdr.period) AS a) 		as sn1_sum,
		(select a[3] from bee_repakt2_get_tmp1_corr1($1,dtg.sn1_code, bdr.period) AS a) 		as sn1_price,
		(select a[4] from bee_repakt2_get_tmp1_corr1($1,dtg.sn1_code, bdr.period) AS a) 		as sn1_tax_sum,
		(select a[5] from bee_repakt2_get_tmp1_corr1($1,dtg.sn1_code, bdr.period) AS a) 		as sn1_sum_with_tax,
		
		(select a[1] from bee_repakt2_get_tmp1_corr1($1,dtg.sn2_code, bdr.period) AS a) 		as sn2_amount,
		(select a[2] from bee_repakt2_get_tmp1_corr1($1,dtg.sn2_code, bdr.period) AS a) 		as sn2_sum,
		(select a[3] from bee_repakt2_get_tmp1_corr1($1,dtg.sn2_code, bdr.period) AS a) 		as sn2_price,
		(select a[4] from bee_repakt2_get_tmp1_corr1($1,dtg.sn2_code, bdr.period) AS a) 		as sn2_tax_sum,
		(select a[5] from bee_repakt2_get_tmp1_corr1($1,dtg.sn2_code, bdr.period) AS a) 		as sn2_sum_with_tax,
		
		(select a[1] from bee_repakt2_get_tmp1_corr1($1,dtg.nn_code, bdr.period) AS a) 			as nn_amount,
		(select a[2] from bee_repakt2_get_tmp1_corr1($1,dtg.nn_code, bdr.period) AS a) 			as nn_sum,
		(select a[3] from bee_repakt2_get_tmp1_corr1($1,dtg.nn_code, bdr.period) AS a) 			as nn_price,
		(select a[4] from bee_repakt2_get_tmp1_corr1($1,dtg.nn_code, bdr.period) AS a) 			as nn_tax_sum,
		(select a[5] from bee_repakt2_get_tmp1_corr1($1,dtg.nn_code, bdr.period) AS a) 			as nn_sum_with_tax,
		
		(select sum (a) 
		   from unnest(ARRAY[
				(select a[2] from bee_repakt2_get_tmp1_corr1($1,dtg.vn_code, bdr.period)  AS a),
				(select a[2] from bee_repakt2_get_tmp1_corr1($1,dtg.sn1_code, bdr.period) AS a),	
				(select a[2] from bee_repakt2_get_tmp1_corr1($1,dtg.sn2_code, bdr.period) AS a),
				(select a[2] from bee_repakt2_get_tmp1_corr1($1,dtg.nn_code, bdr.period)  AS a)
				]) AS a) AS tot_sum,
		(select sum (a) 
		   from unnest(ARRAY[
				(select a[1] from bee_repakt2_get_tmp1_corr1($1,dtg.vn_code, bdr.period) AS a),
				(select a[1] from bee_repakt2_get_tmp1_corr1($1,dtg.sn1_code, bdr.period) AS a),
				(select a[1] from bee_repakt2_get_tmp1_corr1($1,dtg.sn2_code, bdr.period) AS a),
				(select a[1] from bee_repakt2_get_tmp1_corr1($1,dtg.nn_code, bdr.period) AS a)
				]) AS a) 									as  tot_amount,
		(select sum (a) 
		   from unnest(ARRAY[
				(select a[4] from bee_repakt2_get_tmp1_corr1($1,dtg.vn_code, bdr.period)  AS a),
				(select a[4] from bee_repakt2_get_tmp1_corr1($1,dtg.sn1_code, bdr.period) AS a),	
				(select a[4] from bee_repakt2_get_tmp1_corr1($1,dtg.sn2_code, bdr.period) AS a),
				(select a[4] from bee_repakt2_get_tmp1_corr1($1,dtg.nn_code, bdr.period)  AS a)
				]) AS a)									 AS tot_tax_sum,
		(select sum (a) 
		   from unnest(ARRAY[
				(select a[5] from bee_repakt2_get_tmp1_corr1($1,dtg.vn_code, bdr.period)  AS a),
				(select a[5] from bee_repakt2_get_tmp1_corr1($1,dtg.sn1_code, bdr.period) AS a),	
				(select a[5] from bee_repakt2_get_tmp1_corr1($1,dtg.sn2_code, bdr.period) AS a),
				(select a[5] from bee_repakt2_get_tmp1_corr1($1,dtg.nn_code, bdr.period)  AS a)
				]) AS a)									 AS tot_sum_with_tax
	FROM bee_rep_dtg_rebuilt() AS dtg,
		 (SELECT name AS period FROM bee_docs_result WHERE linkid = $1 AND tar_typ = 1069 AND row_typ = 1071 GROUP BY name) AS bdr
	ORDER BY tarname_grp)
UNION 
	(SELECT
		23										as grp,  
		tarname_grp + 3 								as tarname_grp,
		replace(bdr.period,'корректировка за ','')::date 				as period,
		CASE
		     WHEN tarname_grp = 3
			THEN 'Электрическая энергия сверх социальной нормы потребления электрической энергии (мощности) <b>(население газ) </b>'
		     WHEN tarname_grp = 4
			THEN 'Электрическая энергия сверх социальной нормы потребления электрической энергии (мощности) <b>(население эл.плиты) </b>'
		     WHEN tarname_grp = 5
			THEN 'Электрическая энергия сверх социальной нормы потребления электрической энергии (мощности) <b>(население село) </b>'
		END 										as tar_name1,
		CASE
		     WHEN tarname_grp in (3,4,5)
			THEN 'Тариф сверх социальной нормы потребления электрической энергии (мощности) (одноставочный)'
		     ELSE ''
		END 										as tar_name2,
		(select a[1] from bee_repakt2_get_tmp2_corr1($1,dtg.vn_code,bdr.period) AS a) 			as vn_amount,
		(select a[2] from bee_repakt2_get_tmp2_corr1($1,dtg.vn_code,bdr.period) AS a) 			as vn_sum,
		(select a[3] from bee_repakt2_get_tmp2_corr1($1,dtg.vn_code,bdr.period) AS a) 			as vn_price,
		(select a[4] from bee_repakt2_get_tmp2_corr1($1,dtg.vn_code,bdr.period) AS a) 			as vn_tax_sum,
		(select a[5] from bee_repakt2_get_tmp2_corr1($1,dtg.vn_code,bdr.period) AS a) 			as vn_sum_with_tax,
		
		(select a[1] from bee_repakt2_get_tmp2_corr1($1,dtg.sn1_code,bdr.period) AS a) 			as sn1_amount,
		(select a[2] from bee_repakt2_get_tmp2_corr1($1,dtg.sn1_code,bdr.period) AS a) 			as sn1_sum,
		(select a[3] from bee_repakt2_get_tmp2_corr1($1,dtg.sn1_code,bdr.period) AS a) 			as sn1_price,
		(select a[4] from bee_repakt2_get_tmp2_corr1($1,dtg.sn1_code,bdr.period) AS a) 			as sn1_tax_sum,
		(select a[5] from bee_repakt2_get_tmp2_corr1($1,dtg.sn1_code,bdr.period) AS a) 			as sn1_sum_with_tax,
		
		(select a[1] from bee_repakt2_get_tmp2_corr1($1,dtg.sn2_code,bdr.period) AS a) 			as sn2_amount,
		(select a[2] from bee_repakt2_get_tmp2_corr1($1,dtg.sn2_code,bdr.period) AS a) 			as sn2_sum,
		(select a[3] from bee_repakt2_get_tmp2_corr1($1,dtg.sn2_code,bdr.period) AS a) 			as sn2_price,
		(select a[4] from bee_repakt2_get_tmp2_corr1($1,dtg.sn2_code,bdr.period) AS a) 			as sn2_tax_sum,
		(select a[5] from bee_repakt2_get_tmp2_corr1($1,dtg.sn2_code,bdr.period) AS a) 			as sn2_sum_with_tax,
		
		(select a[1] from bee_repakt2_get_tmp2_corr1($1,dtg.nn_code,bdr.period) AS a) 			as nn_amount,
		(select a[2] from bee_repakt2_get_tmp2_corr1($1,dtg.nn_code,bdr.period) AS a) 			as nn_sum,
		(select a[3] from bee_repakt2_get_tmp2_corr1($1,dtg.nn_code,bdr.period) AS a) 			as nn_price,
		(select a[4] from bee_repakt2_get_tmp2_corr1($1,dtg.nn_code,bdr.period) AS a) 			as nn_tax_sum,
		(select a[5] from bee_repakt2_get_tmp2_corr1($1,dtg.nn_code,bdr.period) AS a) 			as nn_sum_with_tax,
		
		(select sum (a) 
		   from unnest(ARRAY[
				(select a[2] from bee_repakt2_get_tmp2_corr1($1,dtg.vn_code,bdr.period) AS a),
				(select a[2] from bee_repakt2_get_tmp2_corr1($1,dtg.sn1_code,bdr.period) AS a),
				(select a[2] from bee_repakt2_get_tmp2_corr1($1,dtg.sn2_code,bdr.period) AS a),
				(select a[2] from bee_repakt2_get_tmp2_corr1($1,dtg.nn_code,bdr.period) AS a)
				]) AS a) 									as tot_sum,
		(select sum (a) 
		   from unnest(ARRAY[
				(select a[1] from bee_repakt2_get_tmp2_corr1($1,dtg.vn_code,bdr.period) AS a),
				(select a[1] from bee_repakt2_get_tmp2_corr1($1,dtg.sn1_code,bdr.period) AS a),
				(select a[1] from bee_repakt2_get_tmp2_corr1($1,dtg.sn2_code,bdr.period) AS a),
				(select a[1] from bee_repakt2_get_tmp2_corr1($1,dtg.nn_code, bdr.period) AS a)
				]) AS a) 									as tot_amount,
		(select sum (a) 
		   from unnest(ARRAY[
				(select a[4] from bee_repakt2_get_tmp2_corr1($1,dtg.vn_code,bdr.period) AS a),
				(select a[4] from bee_repakt2_get_tmp2_corr1($1,dtg.sn1_code,bdr.period) AS a),
				(select a[4] from bee_repakt2_get_tmp2_corr1($1,dtg.sn2_code,bdr.period) AS a),
				(select a[4] from bee_repakt2_get_tmp2_corr1($1,dtg.nn_code,bdr.period) AS a)
				]) AS a) 									as tot_tax_sum,
		(select sum (a) 
		   from unnest(ARRAY[
				(select a[5] from bee_repakt2_get_tmp2_corr1($1,dtg.vn_code,bdr.period) AS a),
				(select a[5] from bee_repakt2_get_tmp2_corr1($1,dtg.sn1_code,bdr.period) AS a),
				(select a[5] from bee_repakt2_get_tmp2_corr1($1,dtg.sn2_code,bdr.period) AS a),
				(select a[5] from bee_repakt2_get_tmp2_corr1($1,dtg.nn_code,bdr.period) AS a)
				]) AS a) 									as tot_sum_with_tax				
	FROM
		bee_rep_dtg_rebuilt() AS dtg,
		  (SELECT name AS period FROM bee_docs_result WHERE linkid = $1 AND tar_typ = 1069 AND row_typ = 1070 GROUP BY name) AS bdr
	WHERE 
		tarname_grp in (3,4,5)
	ORDER BY  tarname_grp)
ORDER BY  tarname_grp

$$;

comment on function bee_repakt2_get_intermediate_corr1(integer) is 'Акт (соц. норма). Используется в bee_repakt2_get_content(int)';

alter function bee_repakt2_get_intermediate_corr1(integer) owner to pgsql;

