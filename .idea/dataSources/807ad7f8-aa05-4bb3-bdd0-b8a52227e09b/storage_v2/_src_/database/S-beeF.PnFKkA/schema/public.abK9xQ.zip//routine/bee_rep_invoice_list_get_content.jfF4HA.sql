create function bee_rep_invoice_list_get_content(loc_id integer, dat1 date, dat2 date) returns SETOF bee_rep_invoice_list
    language sql
as
$$
/*
   add ito07 2018-10-24  bee_get_doc_tax
	add ito06 2015-02-27
	add ito06 2015-01-26
	add ito06 2014-11-17	
	add ito06 2013-10-25
	ito06 2011-12-28: Реестр счетов фактур
*/
	SELECT
		to_char($2,'DD.MM.YYYY') 			AS dat_start,
		to_char($3,'DD.MM.YYYY')		 	AS dat_end,
		mes.nam || ' ' || res.nam 			AS fil_name,
		to_char(bd.docdat,'DD.MM.YYYY') 		AS doc_dat,	
		bd.docnum||'/'||pref.element_name || '/40'   	AS docnum,
		sum(bdr.amount) 				AS amount,
		sum(bdr.sum_no_tax)				AS amount,
		case when bd.doctyp = 1618
		     then sum(bdr.sum_no_tax) * (1 + bee_get_doc_tax(1163,bd.rowid))
		     else bds.oper_debit
		end::numeric(20,2)				AS summ,		 
		urst.element_name || ' ' || cst.consum_name 	AS cst_name,
		amn.docnumber 					AS amn_docnumber,
		cst.consum_inn || '/' || kpp.item		AS inn_kpp
	FROM bee_docs AS bd
	   JOIN bee_docs_result AS bdr ON bd.rowid = bdr.linkid
	   JOIN bee_docs_sheet AS bds ON bd.rowid = bds.linkid2
	   JOIN dic_elements AS pref ON bd.pref = pref.rowid
      LEFT JOIN dic_tarif_group AS dtg ON bdr.tar_grp = dtg.rowid
	   JOIN agreement AS amn ON bd.linkid = amn.rowid
	   JOIN customer AS cst ON amn.abo_code = cst.abo_code
	   JOIN dic_elements AS urst ON cst.urstatus = urst.rowid
      LEFT JOIN customer_info AS kpp ON kpp.abo = cst.abo_code AND kpp.elrowid=84
	   JOIN denet AS res ON res.rowid=cst.locid
	   JOIN denet AS mes ON mes.kod = substring(res.kod from 1 for 6)
	  WHERE ((bd.doctyp = 1065 AND tar_typ IN (1068,1168,1734)) OR (bd.doctyp = 1618))
	    AND bd.docdat BETWEEN $2 AND $3 
	    AND amn.locid IN(SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1))
	GROUP BY docdat, docnum, cst_name, amn_docnumber, pref.element_name, inn_kpp, fil_name, bds.oper_debit, bd.doctyp,
	bd.rowid -- ito07 2018-10-24
	ORDER BY bd.docnum
$$;

comment on function bee_rep_invoice_list_get_content(integer, date, date) is 'Реестр счетов фактур. Используется в RepInvList.java';

alter function bee_rep_invoice_list_get_content(integer, date, date) owner to pgsql;

