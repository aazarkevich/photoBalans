create function bee_get_loadfil_list() returns character varying
    language plpgsql
as
$$
/*
	ito06 2015-12-24 Получить список филиалов, по ктр происходит загрузка смешанных/централизованных
*/
DECLARE
	Rec     RECORD;
	FilList varchar := '';
BEGIN

	FOR Rec IN (
		select DISTINCT kod, nam 
		  from bee_closed_info AS bci
	          join denet AS de ON de.rowid = bci.filloc AND (length(kod) = 6 OR length(kod) = 9 AND substring(kod, 5,2) = '66' )
                 where isload = true
                 order by kod DESC, nam DESC
	) 	    
	LOOP	
		FilList = Rec.nam || '|' ||  FilList; 
	END LOOP;
	
	IF length(FilList) <1 THEN FilList = NULL;
	END IF;	
	
	RETURN FilList;

END;
$$;

comment on function bee_get_loadfil_list() is 'Получить список филиалов, по ктр происходит загрузка смешанных/централизованных. Используется в AgreeJoinUni.java, AgreeJoinMix.java, AppUtils.java';

alter function bee_get_loadfil_list() owner to pgsql;

