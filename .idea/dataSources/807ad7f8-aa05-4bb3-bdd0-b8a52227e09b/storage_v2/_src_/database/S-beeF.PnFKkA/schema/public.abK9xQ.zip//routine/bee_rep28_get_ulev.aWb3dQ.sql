create function bee_rep28_get_ulev()
    returns TABLE(ul integer, ulev character varying)
    language sql
as
$$
/*
ito06 2013-01-18 для Приложения 1а
*/
SELECT 
    CASE WHEN rowid = 311  THEN 1
         WHEN rowid = 308  THEN 2
         WHEN rowid = 310  THEN 3
         WHEN rowid = 306  THEN 4
    END AS ul,
    CASE WHEN rowid = 311  THEN 'ВН (110-220 кВ)'
         WHEN rowid = 308  THEN 'СН-1 (35 кВ)'
         WHEN rowid = 310  THEN 'СН-2 (4-6 кВ)'
         WHEN rowid = 306  THEN 'НН (04 кВ)'
    END AS ulev 
FROM  dic_elements 
WHERE link = 72
ORDER BY ul;

$$;

comment on function bee_rep28_get_ulev() is 'для Приложения 1а. Используется в bee_rep_get_repdata28_get_en(int, date, int), bee_rep_get_repdata28_get_pow(int, date, int), bee_rep_get_repdata28_get_pow_tot(int, date, int)';

alter function bee_rep28_get_ulev() owner to postgres;

