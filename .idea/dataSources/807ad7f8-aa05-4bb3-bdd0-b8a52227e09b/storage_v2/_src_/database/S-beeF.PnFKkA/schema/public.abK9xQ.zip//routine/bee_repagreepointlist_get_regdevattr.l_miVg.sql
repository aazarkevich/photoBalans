create function bee_repagreepointlist_get_regdevattr() returns SETOF bee_repagreepointlist_regdevattr
    language sql
as
$$
/*
ito06 2011-12-01 Список устройств
add ito06 2012-07-30
*/
SELECT 
	attr.deviceid,
	rda122.element_name,					-- ток максимальный			*kol56*
	rda123.element_name,					-- вид энергии 				*kol53*
	rda124.element_name,					-- тип 					*kol52*
	rda125.element_name,					-- ток номинальный			*kol55*
	rda126.element_name,					-- номинальное напряжение		*kol54*
	rda143.element_name,					-- класс точности A			*kol19*
        rda146.element_name,					-- класс точности R			*kol20*
	rda148.element_name,					-- количество фаз			*kol21*
	rda157.valman,						-- номер в Госреестре 			*kol57*
        rda167.element_name::character varying(150),		-- срок службы				*kol26*
        CASE WHEN rda167.element_name IS NOT NULL THEN  rda167.element_name || ' year'  ELSE null
        END::interval ,		-- срок службы				*kol26y*
	rda170.valman,						-- ток чувствительности 		*kol58*
        rda171.element_name,					-- срок службы				*kol23*
	rda172.element_name,					-- выходной сигнал тип 			*kol59*
	rda173.valman,						-- стандарт исполнения			*kol60*
	rda174.valman,						-- количество импульсов			*kol61*
	rda175.element_name, 					-- температура минимальная		*kol62*
	rda176.element_name,					-- температура максимальная		*kol63*
	rda177.element_name, 					-- тип интерфейса 			*kol64*
	rda178.element_name, 					-- наличие журнала событий		*kol65*
	rda179.element_name, 					-- количество тарифов			*kol66*
	rda180.element_name, 					-- количество тарифных зон		*kol67*
	rda181.element_name, 					-- возможн. програм. искл. дней		*kol68*
	rda182.element_name, 					-- резервное питание			*kol69*
	rda183.element_name, 					-- хранение профиля нагрузки		*kol70*
	rda184.element_name, 					-- измерение в 2-х напр			*kol71*
	rda185.element_name 					-- наличие электронной			*kol72*
  FROM 
       ( SELECT deviceid FROM regdevattr 
          WHERE paramid in (122,123,124, 125,126, 143, 146, 148, 167, 171, 172, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185) 
          GROUP BY deviceid 
          ORDER BY deviceid 
       ) 							AS attr	
-- ток максимальный
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  122
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
       ) 							AS attr122	ON attr122.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 						AS rda122	ON rda122.rowid=attr122.valman::numeric
-- вид энергии
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  123
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr123	ON attr123.deviceid =  attr.deviceid
LEFT JOIN dic_elements 						AS rda123    	ON rda123.rowid=attr123.valman::numeric 
-- тип
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  124
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr124	ON attr124.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 						AS rda124	ON rda124.rowid=attr124.valman::numeric
-- ток номинальный
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
         WHERE paramid =  125
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
         ORDER BY deviceid, paramid
          ) 							AS attr125	ON attr125.deviceid =  attr.deviceid
LEFT JOIN dic_elements 						AS rda125    	ON rda125.rowid=attr125.valman::numeric 
-- номинальное напряжение
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  126
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
            ORDER BY deviceid, paramid
          ) 							AS attr126	ON attr126.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 						AS rda126	ON rda126.rowid=attr126.valman::numeric
-- класс точности A 
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  143
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr143	ON attr143.deviceid =  attr.deviceid
LEFT JOIN dic_elements 						AS rda143    	ON rda143.rowid=attr143.valman::numeric 
-- класс точности R
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  146
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr146	ON attr146.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 						AS rda146	ON rda146.rowid=attr146.valman::numeric
-- количество фаз
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  148
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
            ORDER BY deviceid, paramid
          ) 							AS attr148	ON attr148.deviceid =  attr.deviceid
LEFT JOIN dic_elements 						AS rda148    	ON rda148.rowid=attr148.valman::numeric 
-- межповерочный интервал год
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  167
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr167	ON attr167.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 						AS rda167	ON rda167.rowid=attr167.valman::numeric
-- срок служб
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  171
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr171	ON attr171.deviceid =  attr.deviceid
LEFT JOIN dic_elements 						AS rda171    	ON rda171.rowid=attr171.valman::numeric 
-- выходной сигнал тип
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  172
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr172	ON attr172.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 						AS rda172	ON rda172.rowid=attr172.valman::numeric
-- температура минимальная
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  175
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
            ORDER BY deviceid, paramid
          ) 							AS attr175	ON attr175.deviceid =  attr.deviceid
LEFT JOIN dic_elements 					AS rda175    	ON rda175.rowid=attr175.valman::numeric 
-- температура максимальная
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  176
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr176	ON attr176.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 					AS rda176	ON rda176.rowid=attr176.valman::numeric
-- тип интерфейса
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  177
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
            ORDER BY deviceid, paramid
          ) 							AS attr177	ON attr177.deviceid =  attr.deviceid
LEFT JOIN dic_elements 					AS rda177    	ON rda177.rowid=attr177.valman::numeric 
-- наличие журнала событий
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  178
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr178	ON attr178.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 					AS rda178	ON rda178.rowid=attr178.valman::numeric
-- количество тарифов  
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  179
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr179	ON attr179.deviceid =  attr.deviceid
LEFT JOIN dic_elements 					AS rda179    	ON rda179.rowid=attr179.valman::numeric 
-- количество тарифных зон
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  180
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr180	ON attr180.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 					AS rda180	ON rda180.rowid=attr180.valman::numeric
-- возможн. програм. искл. дней
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  181
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr181	ON attr181.deviceid =  attr.deviceid
LEFT JOIN dic_elements 					AS rda181    	ON rda181.rowid=attr181.valman::numeric 
-- резервное питание
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  182
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr182	ON attr182.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 					AS rda182	ON rda182.rowid=attr182.valman::numeric
-- хранение профиля нагрузки  
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  183
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
            ORDER BY deviceid, paramid
          ) 							AS attr183	ON attr183.deviceid =  attr.deviceid
LEFT JOIN dic_elements 					AS rda183    	ON rda183.rowid=attr183.valman::numeric 
-- измерение в 2-х напр
LEFT JOIN ( SELECT valman,deviceid FROM regdevattr 
             WHERE paramid =  184
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
          ) 							AS attr184	ON attr184.deviceid =  attr.deviceid	
LEFT JOIN dic_elements 					AS rda184	ON rda184.rowid=attr184.valman::numeric
-- наличие электронной   
LEFT JOIN ( SELECT valman, deviceid FROM regdevattr 
             WHERE paramid =  185
               AND valman <> '?'AND valman <>'-' AND valman <> '' 
               AND valman IS NOT NULL AND valman NOT LIKE '%,%'
             ORDER BY deviceid, paramid
       ) 							AS attr185	ON attr185.deviceid =  attr.deviceid
LEFT JOIN dic_elements 					AS rda185    	ON rda185.rowid=attr185.valman::numeric 
-- номер в Госреестре
   LEFT JOIN (SELECT * FROM regdevattr 
               WHERE paramid = 157 AND valman <> '?' AND valman <> '-' AND valman <> '' AND valman IS NOT NULL  
             ) 									AS rda157 	ON rda157.deviceid = attr.deviceid
--ток чувствительности
   LEFT JOIN (SELECT * FROM regdevattr
                  WHERE paramid = 170 AND valman <> '?' AND valman <> '-' AND valman <> '' AND valman IS NOT NULL
	     )									AS rda170 	ON rda170.deviceid = attr.deviceid
--стандарт исполнения
   LEFT JOIN (SELECT * FROM regdevattr 
               WHERE paramid = 173 AND valman <> '?' AND valman <> '-' AND valman <> '' AND valman IS NOT NULL
             ) 									AS rda173 	ON rda173.deviceid = attr.deviceid
--количество импульсов
   LEFT JOIN (SELECT * FROM regdevattr 
               WHERE paramid = 174 AND valman <>'?' AND valman <> '-' AND valman <> '' AND valman IS NOT NULL
             ) 									AS rda174 	ON rda174.deviceid = attr.deviceid
$$;

comment on function bee_repagreepointlist_get_regdevattr() is 'Список устройств, показания. Используется в bee_repagreepointlist_get_content(int, text)';

alter function bee_repagreepointlist_get_regdevattr() owner to postgres;

