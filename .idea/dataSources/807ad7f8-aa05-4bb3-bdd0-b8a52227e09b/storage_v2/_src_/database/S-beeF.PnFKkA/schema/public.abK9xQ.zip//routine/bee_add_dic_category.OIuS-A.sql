create function bee_add_dic_category(newcatcode integer, newcatname character varying) returns integer
    language plpgsql
as
$$
begin
insert into 
dic_category
(category_code,category_name)
 values  
(newcatcode,newcatname); 
return 0;
end;
$$;

comment on function bee_add_dic_category(integer, varchar) is 'Используется в Dicts.java, AppUtils.java';

alter function bee_add_dic_category(integer, varchar) owner to pgsql;

