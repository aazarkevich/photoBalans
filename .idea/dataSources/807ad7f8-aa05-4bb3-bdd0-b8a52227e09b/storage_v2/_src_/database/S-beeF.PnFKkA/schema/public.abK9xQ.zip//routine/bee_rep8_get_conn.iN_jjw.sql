create function bee_rep8_get_conn(pchain character varying) returns character varying
    language plpgsql
as
$$
DECLARE
  part character varying;
  pc   text[];
  len  int;
  code int;
  result character varying;
BEGIN
  IF pchain IS NULL THEN
    RETURN NULL;
  END IF;
  pc:=string_to_array(pchain,'+');
  len:=array_upper(pc,1);
  part:='';
  result:='';
  code:=0;
  FOR i IN 2..len LOOP
	part := part || '+' || pc[i];
	EXECUTE 'SELECT objtype FROM gis_traces WHERE pchain= '||quote_literal(part) ||' LIMIT 1' INTO code;
	IF code=11 THEN
	  RETURN pc[i];
	  EXIT;
	END IF;
  END LOOP;
  RETURN NULL;
END
$$;

comment on function bee_rep8_get_conn(varchar) is 'Используется в bee_rep_get_repdata8_0(int, varchar, varchar, varchar, varchar), bee_rep_get_repdata8_1(int, varchar, varchar, varchar, varchar), bee_rep_get_repdata8_2(int, varchar, varchar, varchar, varchar)';

alter function bee_rep8_get_conn(varchar) owner to postgres;

