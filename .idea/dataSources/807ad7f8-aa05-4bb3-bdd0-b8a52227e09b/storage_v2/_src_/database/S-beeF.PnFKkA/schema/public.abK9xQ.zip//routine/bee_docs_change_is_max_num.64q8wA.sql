create function bee_docs_change_is_max_num(_linkid integer) returns boolean
    language plpgsql
as
$$
/*
ito06 2012-03-26 Исправление в счете-фактуре
*/
 DECLARE num1 varchar;
 num2 varchar;
 BEGIN
   
select into num1 docnum from bee_docs where rowid = _linkid;

select into num2 max(docnum) from bee_docs AS bds 
JOIN (
select who from bee_docs_change As t
	WHERE  wher in(select wher from bee_docs_change As t1
			where t1.who = _linkid)
) AS a ON a.who = bds.rowid;

IF num1 <> num2 
THEN return false;
ELSE return true;
END IF;
END;
$$;

comment on function bee_docs_change_is_max_num(integer) is 'Исправление в счете-фактуре. Используется в DocsChange.java';

alter function bee_docs_change_is_max_num(integer) owner to pgsql;

