create function bee_rep_get_repdata29_tmp1_corr(loc_id integer, d_start date, d_end date, fil character varying) returns SETOF bee_repdata29_tmp
    language plpgsql
as
$$
/*
	add ito06 2016-05-30 берем потребление из таблиц bee_doc_calc (т.к. точки могут быть в другом договоре)
	add ito06 2016-03-03 добавляем параметр тип договора amntyp
	add ito06 2015-06-30
	ito06 2015-01-21 Сводная ведомость по объему услуг, выводит корректировку для всех групп для юр лиц с разбиением по тарифам
	для текущей базы
*/
DECLARE 
	tmp_kod VARCHAR;
	Rec bee_repdata29_tmp%rowtype;	
BEGIN
	SELECT into tmp_kod kod from denet AS de1 where de1.rowid = loc_id limit 1;
	FOR Rec IN (
	  SELECT * FROM (
		SELECT $4				 								AS fil,
		       d_end		 										AS dat,
		       amn.rowid 											AS amnid,      
		       amn.docnumber||', '||abo_name									AS doc_name, 
		       
		       CASE WHEN amn.accdir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp IN (139,140,141,138)
				THEN 11 --прочие потребители одноставочный
			    WHEN amn.accdir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp IN (142,144,147,148)
				THEN 121 --прочие потребители двуставочный мощность
			    WHEN amn.accdir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp IN (143,145,146,149)
				THEN 122 --прочие потребители двуставочный эл.эн
				
			    WHEN amn.accdir  IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp IN (139,140,141,138)
				THEN 21 --бюджетные потребители одноставочный
			    WHEN amn.accdir IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp IN (142,144,147,148)
				THEN 221 --бюджетные  потребители двуставочный мощность
			    WHEN amn.accdir  IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) AND bdc.tar_grp IN (143,145,146,149) 
				THEN 222 --бюджетные потребители двуставочный эл.эн	

			    WHEN bdc.tar_grp IN (150,156,154,155) AND con_sum = 850  
				THEN 311 --население и потребители приравненниые к населению 
			    WHEN bdc.tar_grp IN (150,156,154,155) AND con_sum = 1446    
				THEN 312 --население и потребители приравненниые к населению норма
			    WHEN bdc.tar_grp IN (150,156,154,155) AND con_sum = 1174    
				THEN 313 --население и потребители приравненниые к населению сверх нормы

			    WHEN bdc.tar_grp IN (152,159,157,158) AND con_sum = 850  	           
				THEN 321 --городское население эл. плиты
			    WHEN bdc.tar_grp IN (152,159,157,158) AND con_sum = 1446  	           
				THEN 322 --городское население эл. плиты норма
			    WHEN bdc.tar_grp IN (152,159,157,158) AND con_sum = 1174  	           
				THEN 323 --городское население эл. плиты сверх нормы

			    WHEN bdc.tar_grp IN (153,162,160,161) AND con_sum = 850
				THEN 331 -- население проживающее в сельских населенных пунктах
			    WHEN bdc.tar_grp IN (153,162,160,161) AND con_sum = 1446 
				THEN 332 -- население проживающее в сельских населенных пунктах норма
			    WHEN bdc.tar_grp IN (153,162,160,161) AND con_sum = 1174 
				THEN 333 -- население проживающее в сельских населенных пунктах сверх нормы
			   ELSE 5	  
			END											AS grp,
			
			----	
			null::numeric 										AS tot_amount,
			SUM(CASE WHEN bdc.tar_grp IN (139,142,143,150,152,153)
				   THEN bdc.quantity_amo
				 ELSE NULL
			    END) 										AS vn_amount,    
			SUM(CASE WHEN bdc.tar_grp IN (140,144,145,156,159,162)
				   THEN bdc.quantity_amo
				 ELSE NULL
			    END)   										AS sn1_amount,
			SUM(CASE WHEN bdc.tar_grp IN (141,147,146,154,157,160)
				   THEN bdc.quantity_amo
				 ELSE NULL
			    END)   										AS sn2_amount,
			SUM(CASE WHEN bdc.tar_grp IN (138,148,149,155,158,161)
				   THEN bdc.quantity_amo
				 ELSE NULL
			    END)   										AS nn_amount,
			----  
			null::numeric 										AS tot_sum,			
			SUM(CASE WHEN bdc.tar_grp IN (139,142,143,150,152,153)
				   THEN bdc.cost_no_tax
				 ELSE NULL
			    END) 										AS vn_sum,    
			SUM(CASE WHEN bdc.tar_grp IN (140,144,145,156,159,162)
				   THEN bdc.cost_no_tax
				 ELSE NULL
			    END)   										AS sn1_sum,
			SUM(CASE WHEN bdc.tar_grp IN (141,147,146,154,157,160)
				   THEN bdc.cost_no_tax
				 ELSE NULL
			    END)   										AS sn2_sum,
			SUM(CASE WHEN bdc.tar_grp IN (138,148,149,155,158,161)
				   THEN bdc.cost_no_tax
				 ELSE NULL
			    END)   										AS nn_sum  		    		      

		  FROM agreement AS amn
		  JOIN customer AS cust ON cust.abo_code = amn.abo_code
--** 2016-05-30
	          JOIN bee_docs AS bd ON bd.linkid = amn.rowid AND docdat BETWEEN $2 AND $3
  	          JOIN (        (select linkid1, linkid2, period, tar_grp_old AS tar_grp, 
		                       -quantity_old AS quantity_amo,  price_old AS price, -cost_old AS cost_no_tax, con_sum
				  from bee_docs_corr where quantity_old IS NOT NULL OR cost_old IS NOT NULL)
			UNION (select linkid1, linkid2, period, tar_grp_new AS tar_grp, 
			              quantity_new AS quantity_amo, price_new AS price, cost_new AS cost_no_tax, con_sum  
				  from bee_docs_corr where quantity_new IS NOT NULL OR cost_new IS NOT NULL)
		      ) AS bdc ON bdc.linkid2 = bd.rowid 
                  LEFT JOIN agreepoint AS apn ON apn.rowid = bdc.linkid1 AND apn.lid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
--**			
		WHERE (amn.docstatus = 79 OR amn.docstatus = 77 AND amn.closedate >= $2) --2015-06-30  
	          AND amn.doctype = 1910 --2016-03-03
		 GROUP BY amn.docnumber,  grp, bdc.price, amn.rowid, abo_name,con_sum, bdc.tar_grp
		 ORDER BY grp, doc_name) AS a
	 WHERE vn_amount>0 OR  sn1_amount>0 OR sn2_amount>0 OR nn_amount>0 OR vn_amount<0 OR  sn1_amount<0 OR sn2_amount<0 OR nn_amount<0)

	 LOOP 		
		RETURN NEXT Rec;
	 END LOOP;
END;
$$;

comment on function bee_rep_get_repdata29_tmp1_corr(integer, date, date, varchar) is 'Сводная ведомость по объему услуг. Используется в bee_rep_get_repdata29_tmpUr(integer, date, date)';

alter function bee_rep_get_repdata29_tmp1_corr(integer, date, date, varchar) owner to postgres;

