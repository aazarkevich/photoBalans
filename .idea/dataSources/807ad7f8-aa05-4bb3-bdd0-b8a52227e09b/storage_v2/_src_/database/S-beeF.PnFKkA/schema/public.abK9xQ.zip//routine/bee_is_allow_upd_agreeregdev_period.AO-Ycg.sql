create function bee_is_allow_upd_agreeregdev_period(_pointid integer, _paramid integer, _per date) returns integer
    language plpgsql
as
$$
/*
	ito06 2016-06-17 Запрет ввода/изменения уровеня напряжения с веденным тарифом за текущий период.
	
*/
DECLARE	
	_tarid integer;
BEGIN	
	IF  _paramid = 439 --"уровень напряжения*"
	   THEN 
		SELECT rowid FROM agreepoint_tarif WHERE pointid = _pointid AND period >= _per INTO _tarid;
		IF _tarid IS NOT NULL 
		   THEN RETURN -2; 
		   ELSE RETURN 1;			
		END IF;
	END IF;
	RETURN 1;	
END;
$$;

comment on function bee_is_allow_upd_agreeregdev_period(integer, integer, date) is 'Запрет ввода/изменения уровеня напряжения с веденным тарифом за текущий период. Используется в DeviceParamP.java, AppUtils.java';

alter function bee_is_allow_upd_agreeregdev_period(integer, integer, date) owner to pgsql;

