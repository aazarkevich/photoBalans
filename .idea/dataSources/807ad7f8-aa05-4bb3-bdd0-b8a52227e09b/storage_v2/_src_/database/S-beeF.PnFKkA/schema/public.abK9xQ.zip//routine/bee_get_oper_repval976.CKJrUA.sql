create function bee_get_oper_repval976(integer, integer, date, date) returns numeric
    language sql
as
$$
    -- 1 - pointid
  -- 2 - paramid
  -- 3 - operdate
  --
  --SELECT valman::numeric(12,3) FROM regdevoper976 
  SELECT round(valman::numeric,0) FROM regdevoper976 
  WHERE 
     linkid   = $1 AND
     paramid  = $2 AND 
     operdate BETWEEN $3 AND $4 AND
     valman   ~ E'^\\d{1,}'
  ;
$$;

comment on function bee_get_oper_repval976(integer, integer, date, date) is 'Используется в bee_rep_get_repdata1(int, date, date)';

alter function bee_get_oper_repval976(integer, integer, date, date) owner to pgsql;

