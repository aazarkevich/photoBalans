create function bee_get_agreeregdev_trans_param(_apnid integer, _type integer, _all boolean) returns SETOF vbee_agreeregdev_trans_param
    language plpgsql
as
$$
/*
	ito06 2020-04-29 Получить данные ТТ/ТН для указанного точки учета
*/
declare RowLine record;
       RowLine2 vbee_agreeregdev_trans_param%ROWTYPE;

begin
	if _all --1 показать все ТТ/ТН
	then --1
	    FOR RowLine IN (
			select * from agreeregdev_period as ardp 
	  		  join dic_elements as de on de.link = _type and de.element_code between 501 and 503 and  ardp.paramid  = de.rowid 		
			
 		     where ardp.linkid = _apnid
 		      order by ardp.paramid, ardp.period desc)
		LOOP   
		   return query (select RowLine.linkid, RowLine.rowid, Rowline.paramid, ('№ '||Rowline.paramval ||' от ' ||Rowline.period)::varchar, RowLine.rowid, RowLine.element_name::varchar, RowLine.refs, RowLine.element_code);
		   
		   FOR RowLine2 IN (select * from bee_get_device_real(RowLine.rowid, _type))
		   loop
		   
		     if RowLine2.refs is not null
		     then 
		   		 RowLine2.paramval = (select element_name from dic_elements where rowid = RowLine2.paramval::int);
		     end if;
				RETURN NEXT RowLine2;
			END LOOP;	
		end LOOP;
	
	
	
	else --1 показать, только последние введнные
		FOR RowLine IN (
			select * from agreeregdev_period as ardp 
			  join (select  max(period) as period, paramid from agreeregdev_period As ardp
	  		  join dic_elements as de on de.link = _type and de.element_code between 501 and 503 and  ardp.paramid  = de.rowid
	 		 where ardp.linkid = _apnid 
			 group by paramid
			 order by paramid, period desc) as tt on ardp.paramid  = tt.paramid and ardp.period = tt.period
			  join dic_elements as de1 on de1.rowid = ardp.paramid
 		     where ardp.linkid = _apnid  		      order by ardp.paramid, ardp.period desc
 		     )
		LOOP   
		
		   return query (select RowLine.linkid, RowLine.rowid, Rowline.paramid, ('№ '||Rowline.paramval ||' от ' ||Rowline.period)::varchar, RowLine.rowid, RowLine.element_name::varchar, RowLine.refs, RowLine.element_code);
		   
		   FOR RowLine2 IN (select * from bee_get_device_real(RowLine.rowid, _type))
		   loop
		   
		     if RowLine2.refs is not null
		     then 
		   		 RowLine2.paramval = (select element_name from dic_elements where rowid = RowLine2.paramval::int);
		     end if;
		    
				RETURN NEXT RowLine2;
			END LOOP;	
		end LOOP;	
	end if; --1

end;
$$;

comment on function bee_get_agreeregdev_trans_param(integer, integer, boolean) is 'Получить данные ТТ/ТН для указанного точки учета. Используется в AgreeByDevice.java в SessionBean1.java';

alter function bee_get_agreeregdev_trans_param(integer, integer, boolean) owner to postgres;

