create function bee_check_last_date_prov(apn_rowid integer) returns integer
    language plpgsql
as
$$
/*
	ito06 2021-02-04 Дата перидического параметра № акта (МС) соответствовать пост параметру дата последней проверки
*/
declare
	_lastdate varchar;
    BEGIN 
	 delete from agreeregdev where paramid = 824 and linkid = apn_rowid;
    select max(period)::varchar from agreeregdev_period where linkid = apn_rowid and paramid = 1722  limit 1 into _lastdate;
    if _lastdate is not null then
      
        insert into agreeregdev (linkid,  paramid, paramval) values (apn_rowid, 824, _lastdate);
      return 1;
    else return -1;
    end if;
   
END;

$$;

comment on function bee_check_last_date_prov(integer) is 'Дата перидического параметра № акта (МС) соответствовать пост параметру дата последней проверки, Используется в AktCheck.java';

alter function bee_check_last_date_prov(integer) owner to postgres;

