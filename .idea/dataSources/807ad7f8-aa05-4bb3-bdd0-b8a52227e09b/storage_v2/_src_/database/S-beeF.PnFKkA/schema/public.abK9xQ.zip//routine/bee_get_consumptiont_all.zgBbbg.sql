create function bee_get_consumptiont_all(dfrom date, dto date, id_external_pnt integer)
    returns TABLE(id_external_point integer, date_from date, date_to date, prev_value numeric, curr_value numeric, id_tariff_option integer, sosial_norm numeric, over_sosial_norm numeric, id_sys integer, is_legal integer, consumed_without_sub numeric, reporting_quantity numeric)
    language plpgsql
as
$$
declare

	BEGIN
return QUERY(
SELECT * 
		FROM dblink(
			'fs_beeu_f663',
			format(	'select * from public.bee_get_consumptiont(%L,%L,%L)',dfrom::date, dto::date, id_external_pnt::integer ))t
				(id_external_point integer, date_from date, date_to date, prev_value numeric, curr_value numeric, id_tariff_option integer, sosial_norm numeric, over_sosial_norm numeric,id_sys int, is_legal integer, consumed_without_sub NUMERIC, reporting_quantity numeric)
union SELECT
			* 
		FROM dblink(
			'fs_beef_f663',
			format(	'select * from public.bee_get_consumptiont(%L,%L,%L)',dfrom::date, dto::date, id_external_pnt::integer   ))t
				(id_external_point integer, date_from date, date_to date, prev_value numeric, curr_value numeric, id_tariff_option integer, sosial_norm numeric, over_sosial_norm numeric,id_sys int, is_legal integer, consumed_without_sub NUMERIC,reporting_quantity  NUMERIC ));
      end;
$$;

alter function bee_get_consumptiont_all(date, date, integer) owner to postgres;

