create function bee_docs_change_get_agreement_list(_locid integer) returns SETOF docs_change_agreement_list
    language plpgsql
as
$$
/*
	add ito06 2016-03-02 добавиля тип договора
	add ito06 2014-06-24
	ito06 2012-03-26 список договоров в "исправление в счете-фактуре" + "корректировка"
*/
DECLARE
	rec docs_change_agreement_list%rowtype;
 BEGIN
	FOR rec IN (
		 SELECT amn.rowid,
			amn.docnumber,
			amn.docdate,
			amn.abo_code,
			cust.consum_inn,
			cust.consum_name 
		   FROM agreement AS amn
		   JOIN customer As cust on amn.abo_code = cust.abo_code  
		  WHERE docstatus = 79 
		    --2016-03-02 AND transmit = true 
		    AND amn.doctype in (1910, 1911) --** 2016-03-02
		    AND amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1))
		  ORDER BY docnumber ASC)
	LOOP
		RETURN NEXT rec;
	END LOOP;
END;
$$;

comment on function bee_docs_change_get_agreement_list(integer) is 'Cписок договоров в "исправление в счете-фактуре" + "корректировка". Используется в DocsChange.java, DocsAdjustment.java, SessionBean1.java';

alter function bee_docs_change_get_agreement_list(integer) owner to pgsql;

