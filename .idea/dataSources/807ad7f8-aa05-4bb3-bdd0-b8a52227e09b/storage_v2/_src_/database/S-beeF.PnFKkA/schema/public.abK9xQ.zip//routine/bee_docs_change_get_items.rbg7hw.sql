create function bee_docs_change_get_items(_locid integer, _docdat text, _docs_linkid integer, _docid integer) returns SETOF bdc_items
    language plpgsql
as
$$
    /*	
            ito06 2012-03-26 Изменения счет-фактур
        add ito06 2013-10-09
        add ito06 2014-06-24
    */
	--
	DECLARE
	        RowLine bdc_items%rowtype;
	---  
	BEGIN
	---  
		FOR RowLine IN (
			SELECT
				t1.docdat,
				t1.docnum,
				bee_docs_corr.period,
				customer.consum_inn,
				customer.consum_name,
				agreement.docnumber,
				agreepoint.account,
				agreepoint.prodnumber,
				CASE 
                                    WHEN bee_docs_corr.con_sum = 850
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_new::integer)                                        
                                    WHEN bee_docs_corr.con_sum = 1446
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_new::integer) || '(в пределах соц. нормы)'
                                    WHEN bee_docs_corr.con_sum = 1174
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_new::integer) || '(сверх соц. нормы)'
                                END AS tar_grp_new_lab,
                                CASE 
                                    WHEN bee_docs_corr.con_sum = 850
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_old::integer)                                        
                                    WHEN bee_docs_corr.con_sum = 1446
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_old::integer) || '(в пределах соц. нормы)'                                    WHEN bee_docs_corr.con_sum = 1174
                                        THEN (SELECT name FROM dic_tarif_group WHERE rowid = tar_grp_old::integer) || '(сверх соц. нормы)'
                                END AS tar_grp_old_lab,
				bee_docs_corr.quantity_old,
				bee_docs_corr.price_old,
				bee_docs_corr.cost_old,
				bee_docs_corr.quantity_new,
				bee_docs_corr.price_new,
				bee_docs_corr.cost_new,
				bee_docs_corr.diff_kvt,
				bee_docs_corr.diff_sum,
				(SELECT usr FROM deusers WHERE rowid = bee_docs_corr.userid) AS usr,
				bee_docs_corr.rowid AS bdc_rowid,
				bee_docs.rowid AS bd_rowid,
				agreepoint.rowid AS ap_rowid,
				agreement.rowid AS agreeid

				FROM bee_docs_corr

				JOIN agreepoint ON bee_docs_corr.linkid1 = agreepoint.rowid
				JOIN bee_docs ON bee_docs_corr.linkid2 = bee_docs.rowid
				JOIN agreement ON agreepoint.linkid = agreement.rowid
				JOIN customer ON agreement.abo_code = customer.abo_code
				JOIN (SELECT 
					 bee_docs.docnum,bee_docs.docdat,
					 bee_docs.rowid,bee_docs_corr.period,bee_docs_corr.linkid2 --для проверки 
				     FROM
					 bee_docs
					JOIN agreement ON agreement.rowid=bee_docs.linkid   
					JOIN agreepoint ON agreepoint.linkid=agreement.rowid
					JOIN  bee_docs_corr  ON bee_docs_corr.linkid1=agreepoint.rowid 
					 
					 
				      WHERE bee_docs_corr.period=bee_docs.docdat  
					AND bee_docs.doctyp IN (1065,1705)
					AND bee_docs.linkid=_docs_linkid   -- выбранный договор 
				      GROUP BY bee_docs.docnum, bee_docs.docdat,bee_docs.rowid,bee_docs_corr.period,bee_docs_corr.linkid2 
			        ) AS t1 ON t1.linkid2=bee_docs_corr.linkid2

				WHERE agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = _locid)) 
				AND bee_docs.docdat = _docdat::DATE
				AND bee_docs.rowid = _docid
				ORDER BY agreement.docnumber,agreepoint.prodnumber, tar_grp_new_lab, bee_docs_corr.linkid1 ASC, bee_docs_corr.period ASC, bee_docs_corr.linkid2 ASC

		)
		LOOP
			RETURN NEXT RowLine; 
		END LOOP;
	--
	END;


$$;

comment on function bee_docs_change_get_items(integer, text, integer, integer) is 'Исправление счет-фактур. Используется в DocsChange.java, SessionBean1.java';

alter function bee_docs_change_get_items(integer, text, integer, integer) owner to pgsql;

