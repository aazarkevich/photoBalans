create function bee_rep_annex3_get_pow(amn_rowid integer, year1 character varying) returns SETOF bee_rep_annex3_pow_tab
    language sql
as
$$
/*
	ito06 2012-04-12 Приложение 1  (прочие) - печать из формы "договоры" 
*/
SELECT 
	ard_nam.paramval AS obj_name,
	CASE WHEN bpc.power_level = '311'
               THEN 0
             WHEN bpc.power_level = '308'
               THEN 1
             WHEN bpc.power_level = '310'
               THEN 2
             WHEN bpc.power_level = '306'
               THEN 3
        END AS ul,
	sum(bpc.m01) AS m01,
	sum(bpc.m02) AS m02,
	sum(bpc.m03) AS m03,
	sum(bpc.m04) AS m04,
	sum(bpc.m05) AS m05,
	sum(bpc.m06) AS m06,
	sum(bpc.m07) AS m07,
	sum(bpc.m08) AS m08,
	sum(bpc.m09) AS m09,
	sum(bpc.m10) AS m10,
	sum(bpc.m11) AS m11,
	sum(bpc.m12) AS m12,
	ard_maxpow.paramval AS max_pow,
	ard_addpow.paramval AS add_pow,
	ard_okved.paramval AS okved,
	null::text AS tg,
       
        (get_working_days($2)*(ard_tim.paramval::numeric))::bigint AS hours
     FROM agreement AS amn 
     JOIN customer AS cst ON amn.abo_code = cst.abo_code
     JOIN agreepoint AS apn ON apn.linkid = amn.rowid
     JOIN bee_points_consum_f AS bpc ON bpc.linkid2 = apn.rowid AND bpc.tarif_val=1042
     JOIN agreeregdev AS ard_nam ON ard_nam.linkid = apn.rowid AND ard_nam.paramid = 418
LEFT JOIN agreeregdev AS ard_tim ON ard_tim.linkid = apn.rowid AND ard_tim.paramid = 425
LEFT JOIN (SELECT linkid AS linkid, max(period) AS dat
             FROM agreeregdev_period 
            WHERE period <= ($2 || '-12-31')::date AND
                  paramid = 426
            GROUP BY linkid
           ) AS ard_maxpow_dat ON ard_maxpow_dat.linkid = apn.rowid
LEFT JOIN agreeregdev_period AS ard_maxpow ON ard_maxpow.linkid = apn.rowid AND ard_maxpow.paramid = 426 AND ard_maxpow.period = ard_maxpow_dat.dat
LEFT JOIN ( SELECT linkid AS linkid,
                   max(period) AS dat
             FROM  agreeregdev_period 
            WHERE  period <= ($2 || '-12-31')::date AND
                   paramid = 685
            GROUP BY linkid
          ) AS ard_addpow_dat ON ard_addpow_dat.linkid = apn.rowid
LEFT JOIN agreeregdev_period AS ard_addpow ON ard_addpow.linkid = apn.rowid AND ard_addpow.paramid = 685 AND ard_addpow.period = ard_addpow_dat.dat
LEFT JOIN agreeregdev AS ard_okved ON ard_okved.linkid = apn.rowid AND ard_okved.paramid = 1030
    WHERE amn.rowid=$1 AND
          to_char(bpc.period,'YYYY')=$2

    GROUP BY obj_name,ul,max_pow,add_pow,okved,hours, bpc.power_level, apn.account
    ORDER BY ul,obj_name;
$$;

comment on function bee_rep_annex3_get_pow(integer, varchar) is 'Приложение 1 (прочие) - печать. Используется в RepAnnex3.java';

alter function bee_rep_annex3_get_pow(integer, varchar) owner to postgres;

