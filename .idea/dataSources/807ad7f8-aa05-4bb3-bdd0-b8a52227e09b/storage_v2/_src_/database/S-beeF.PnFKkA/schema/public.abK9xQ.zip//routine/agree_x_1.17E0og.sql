create function agree_x_1(src_host character varying, dbn character varying, tagid integer, src_port character varying) returns void
    language plpgsql
as
$$
/*
	добавление трасс из филиала src_host в базу централизованных/смешнных
*/
DECLARE
	Agr RECORD; -- for agreement 
	Rec RECORD;
BEGIN
	-- add new gis_traces from remote database
	FOR Agr IN (SELECT docnumber FROM agreement)
	LOOP
		BEGIN
			FOR Rec IN (SELECT DISTINCT locid, period, pchain, objowner, objname, objcode, objtype, rowid, kod
			              FROM agree_get_traces(dbn,Agr.docnumber,tagid,src_host, src_port) x ) 
			LOOP
				IF NOT EXISTS(SELECT Rec.rowid FROM gis_traces) 
				   THEN INSERT INTO gis_traces 
					(     locid,     period,     pchain,     objowner,     objname,     objcode,     objtype,     rowid,     kod) VALUES
					( Rec.locid, Rec.period, Rec.pchain, Rec.objowner, Rec.objname, Rec.objcode, Rec.objtype, Rec.rowid, Rec.kod);
				END IF;
			END LOOP;
		EXCEPTION
			WHEN unique_violation THEN CONTINUE;
			WHEN others           THEN CONTINUE;
		END;
	END LOOP;
END;
$$;

comment on function agree_x_1(varchar, varchar, integer, varchar) is 'Добавление трасс из указанного филиала в базу централизованных/смешнных. Используется в agree_w(int, varchar, varchar), agree_x(varchar, int, varchar)';

alter function agree_x_1(varchar, varchar, integer, varchar) owner to pgsql;

