create function bee_get_device_phase(_type integer, _phase integer) returns SETOF list_dicelem
    language plpgsql
as
$$
DECLARE 
/*
	add ito06 2020-05-14 кроме даты следующей поверки (она расчиывается)
	ito06 2020-04-27 Выводит параметры ТТ/ТН для указанной фазы.
	_phase = -1 (фаза не выбрана) _phase = 0 (фаза А); _phase = 1  (фаза B); _phase = 2 (фаза C) Выводит параметры ТТ/ТН для указанной фазы.
	_type = 56 ТТ; _type = 61 ТН
*/
   _from int = 700;
   _end int = 799;
   rec list_dicelem%rowtype;
BEGIN
	IF _phase = 0  
	   THEN _from = 600 ; _end = 629;
	   ELSE IF _phase = 1  
	             THEN _from = 630 ; _end = 659;
				 ELSE IF _phase = 2  THEN _from = 660;  _end = 699;
                      END IF;
            END IF;
    END IF;
FOR rec IN (	
		SELECT 
		dic_elements.element_code,
		dic_elements.element_name,
		dic_elements.link,
		dic_elements.rowid,
		dic_elements.refs,
		dic_elements.element_type
	   FROM dic_elements
	  WHERE dic_elements.link = _type AND (dic_elements.element_code between _from AND _end)
	    AND dic_elements.element_code not in (612,642,672) --2020-05-14
 	 ORDER BY dic_elements.element_code)
	  LOOP 
	RETURN NEXT rec;
  END LOOP; 
END;
$$;

comment on function bee_get_device_phase(integer, integer) is 'Выводит параметры ТТ/ТН для указанной фазы. Используется в DevParamTT.java в SessionBean1.java';

alter function bee_get_device_phase(integer, integer) owner to pgsql;

