create function bee_add_dic_elements(newcode integer, newname character varying, parentid integer) returns integer
    language plpgsql
as
$$
begin
insert into 
dic_elements
(element_code,element_name,link)
 values  
(newcode,newname,parentid); 
return 0;
end;
$$;

comment on function bee_add_dic_elements(integer, varchar, integer) is 'Используется в Dicts.java, AppUtils.java';

alter function bee_add_dic_elements(integer, varchar, integer) owner to pgsql;

