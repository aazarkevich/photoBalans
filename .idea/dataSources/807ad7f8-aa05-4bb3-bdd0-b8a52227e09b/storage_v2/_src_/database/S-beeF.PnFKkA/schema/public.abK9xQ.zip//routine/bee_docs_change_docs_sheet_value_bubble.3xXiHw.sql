create function bee_docs_change_docs_sheet_value_bubble(agreeid integer, docid integer, docdate date) returns void
    language plpgsql
as
$$
    /*
    ito06 2012-03-26 Исправление счета-фактуры
    */
-- ПУЗЫРЁК -->
--         <--
--         --> 
-- agreeid  - agreement.rowid
-- docid    - bee_docs.rowid
-- docdate  - bee_docs.docdat 
--
DECLARE
   RecCurr  RECORD;
   RecNext RECORD;
   RIDS INTEGER[];
   Amo  INTEGER;
   DK NUMERIC;
   KK NUMERIC;
BEGIN
   --
   PERFORM bee_docs_change_docs_sheet_value_update(agreeid,docid,docdate);
   --
END;
$$;

comment on function bee_docs_change_docs_sheet_value_bubble(integer, integer, date) is 'Исправление счета-фактуры.  Создание записи в sheet. Используется в DocsChange.java, AppUtils.java';

alter function bee_docs_change_docs_sheet_value_bubble(integer, integer, date) owner to pgsql;

