create function bee_get_dic_item(elem integer) returns character varying
    language sql
as
$$
SELECT element_name FROM dic_elements WHERE rowid = $1 LIMIT 1;
$$;

comment on function bee_get_dic_item(integer) is 'Используется в Agreement.java, AgreeRegDev.java, AgreeRegExt.java, Customer.java, CustomerForm.java, DeviceParamA.java, DeviceParamP.java, AppUtils.java';

alter function bee_get_dic_item(integer) owner to pgsql;

