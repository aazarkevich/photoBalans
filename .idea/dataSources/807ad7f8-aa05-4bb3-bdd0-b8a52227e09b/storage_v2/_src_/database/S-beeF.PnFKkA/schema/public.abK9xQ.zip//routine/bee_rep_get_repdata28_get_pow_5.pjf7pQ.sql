create function bee_rep_get_repdata28_get_pow_5(amn_rowid integer, year1 date) returns SETOF bee_rep_tab28_pow
    language sql
as
$$
/*
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	ito06 2013-01-18 Приложение 1а, смешанные данные - мощность
*/
SELECT 
	ard_nam.paramval||', '|| apn.prodnumber 		AS obj_name,
        CASE WHEN ard.paramval::integer = 311  THEN 1
             WHEN ard.paramval::integer = 308  THEN 2
             WHEN ard.paramval::integer = 310  THEN 3
             WHEN ard.paramval::integer = 306  THEN 4
        END 							AS ul,
	null::varchar 						AS ulev,
        CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_1
	                  ELSE  bpc.m_1
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_1 
	                   ELSE  bpc.m_1
	            END
	END							AS m_1,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_2
	                  ELSE  bpc.m_2
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_2 
	                   ELSE  bpc.m_2
	            END
	END							AS m_2,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_3
	                  ELSE  bpc.m_3
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_3 
	                   ELSE  bpc.m_3
	            END
	END							AS m_3,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_4
	                  ELSE  bpc.m_4
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_4 
	                   ELSE  bpc.m_4
	            END
	END							AS m_4,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_5
	                  ELSE  bpc.m_5
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_5 
	                   ELSE  bpc.m_5
	            END
	END							AS m_5,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_6
	                  ELSE  bpc.m_6
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_6 
	                   ELSE  bpc.m_6
	            END
	END							AS m_6,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_7
	                  ELSE  bpc.m_7
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_7
	                   ELSE  bpc.m_7
	            END
	END							AS m_7,
        CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_8
	                  ELSE  bpc.m_8
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_8 
	                   ELSE  bpc.m_8
	            END
	END							AS m_8,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_9
	                  ELSE  bpc.m_9
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_9 
	                   ELSE  bpc.m_9
	            END
	END							AS m_9,
	
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_10
	                  ELSE  bpc.m_10
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_10 
	                   ELSE  bpc.m_10
	            END
	END							AS m_10,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_11
	                  ELSE  bpc.m_11
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_11 
	                   ELSE  bpc.m_11
	            END
	END							AS m_11,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN CASE WHEN pcmf.sum<>0  THEN  pcmf.m_12
	                  ELSE  bpc.m_12
	            END
               ELSE CASE WHEN pcm.sum<>0  THEN  pcm.m_12 
	                   ELSE  bpc.m_12
	            END
	END							AS m_12,
	ard_maxpow.paramval 					AS max_pow,
	ard_addpow.paramval 					AS add_pow,
	ard_okved.paramval 					AS okved,
	null::text 						AS tg,
	null::bigint 						AS hours
      
     FROM agreement AS amn 
     JOIN agreepoint AS apn ON apn.linkid = amn.rowid
     JOIN agreeregdev AS ard_nam ON ard_nam.linkid = apn.rowid AND ard_nam.paramid = 418
LEFT JOIN agreeregdev  AS ard2 ON apn.rowid = ard2.linkid AND ard2.paramid=690 AND is_date(ard2.paramval)
LEFT JOIN agreeregdev AS ard_okved ON ard_okved.linkid = apn.rowid AND ard_okved.paramid = 1030

LEFT JOIN bee_rep_get_ard_per_max(439) AS ard  ON apn.rowid = ard.linkid
LEFT JOIN bee_rep_get_ard_per_max(426) AS ard_maxpow  ON apn.rowid = ard_maxpow.linkid
LEFT JOIN bee_rep_get_ard_per_max(685) AS ard_addpow  ON apn.rowid = ard_addpow.linkid


LEFT JOIN (select * from bee_rep28_get_consum($1,$2,1043))   AS pcm ON pcm.pointid  = apn.rowid
LEFT JOIN (select * from bee_rep28_get_consum_f($1,$2,1043)) AS pcmf ON pcmf.pointid  = apn.rowid

LEFT JOIN (SELECT amnid AS amnid,
                  pointid As pointid,
                  sum(m_1*1000/744) AS m_1,
		  sum(m_2*1000/(24*(to_char($2,'YYYY-03-01')::date - to_char($2,'YYYY-02-01')::date))) AS m_2,
		  sum(m_3*1000/744) AS m_3,
		  sum(m_4*1000/720) AS m_4,
		  sum(m_5*1000/744) AS m_5,
		  sum(m_6*1000/720) AS m_6,
		  sum(m_7*1000/744) AS m_7,
		  sum(m_8*1000/744) AS m_8,
		  sum(m_9*1000/720) AS m_9,
		  sum(m_10*1000/744) AS m_10,
		  sum(m_11*1000/720) AS m_11,
		  sum(m_12*1000/744) AS m_12
             FROM bee_rep28_get_en_real($1, $2)
            GROUP BY  amnid,ul, pointid
           ) AS bpc  ON bpc.pointid = apn.rowid

    WHERE amn.rowid = $1
      AND (ard2.paramval IS NULL OR ard2.paramval::date >= to_char($2,'YYYY-mm-01')::date - '11 month'::interval) 
    ORDER BY ul,obj_name;
$$;

comment on function bee_rep_get_repdata28_get_pow_5(integer, date) is 'Приложение 1а, смешанные данные - мощность. Используется в bee_rep_get_repdata28_get_pow(int, date, int), bee_rep_get_repdata28_get_pow_tot(int, date, int), bee_rep_get_repdata28_get_pow_6(int, date)';

alter function bee_rep_get_repdata28_get_pow_5(integer, date) owner to postgres;

