create function bee_rep_pay_map_get_content_with_corr_cd_tot_all(bd_row integer) returns SETOF bee_rep_pay_map_tab_cd_tot
    language sql
as
$$
    /*	
        add ito06 2019-12-24 сумма по столбцу Потребление всего (v407) не правильно считалась
        add ito07 2018-10-24 bee_get_doc_tax(1163,$1)
        add ito06 2015-05-22
        add ito06 2014-11-17
        add ito06 2013-09-26 
        add ito06 2013-07-02 
        ito06 2011-10-11 13-55: Карта расхода ЦД
    */ 

	(
	   SELECT  
		  null::varchar 	   		AS sort_ul,
		  null::character varying  	AS fil,  
		  'ВСЕГО по '||ul 			AS ul,
		  sum(loss_tot) 	   		AS loss_tot,
		  sum(loss_n) 		   		AS loss_n,
		  sum(loss_l) 		   		AS loss_l,
		  sum(loss_h) 		   		AS loss_h,
		  sum(dopsum) 		   		AS tot_dopsum,
		  sum(v407) 		   		AS tot_v407,
		  sum(v850) 		   		AS tot_v850,
		  null::numeric 	   		AS tot_price,
		  sum(sum_no_tax) 			AS tot_sum_no_tax,
		  sum(sum_tax) 				AS tot_sum_tax,
		  sum(sum)		      		AS tot_sum,
		  6 			         	AS sort
	   FROM 
	      bee_rep_pay_map_get_content_with_corr_cd($1)
	   WHERE 
	      sum IS NOT NULL and 
	      ul  is not null AND 
	      amn_docnumber IS NOT NULL
	   GROUP BY ul 
	)

	UNION 
	(SELECT  
		   null::varchar 	    AS sort_ul,
		   null::character varying  AS fil,  
		  'ВСЕГО по '|| ul 	    AS ul,
		  sum(loss_tot) 	    AS loss_tot,
		  sum(loss_n) 		    AS loss_n,
		  sum(loss_l) 		    AS loss_l,
		  sum(loss_h) 		    AS loss_h,
		  sum(dopsum) 		    AS tot_dopsum,
		  sum(v407) 		    AS tot_v407,
		  sum(v850) 		    AS tot_v850,
		  null::numeric 	    AS tot_price,
		  sum(sum_no_tax) 	 AS tot_sum_no_tax,
		  sum(sum_tax) 		 AS tot_sum_tax,
		  sum(sum) 		       AS tot_sum,
		  6 			          AS sort
	   FROM 
	     bee_rep_pay_map_get_content_with_corr_cd($1)
	   WHERE 
	     sum IS NOT NULL and 
	     ul  is not null AND 
	     amn_docnumber IS NOT NULL
	   GROUP BY ul 
	)
	UNION 
	(SELECT  
		   null::varchar 	          AS sort_ul,
		   null::character varying  AS fil,  
		  --'ВСЕГО по ' || ul 	    AS ul,
		  'ВСЕГО ' || 'КОРРЕКТИРОВКА'    AS ul,
		  sum(loss_tot) 	    AS loss_tot,
		  sum(loss_n) 		    AS loss_n,
		  sum(loss_l) 		    AS loss_l,
		  sum(loss_h) 		    AS loss_h,
		  sum(dopsum) 		    AS tot_dopsum,
		  sum(v407) 		    AS tot_v407,
		  sum(v850) 		    AS tot_v850,
		  null::numeric 	    AS tot_price,
		  sum(sum_no_tax) 	 AS tot_sum_no_tax,
		  sum(sum_tax) 		 AS tot_sum_tax,
		  sum(sum) 		       AS tot_sum,
		  6 			          AS sort
	   FROM 
	     bee_rep_pay_map_get_content_with_corr_cd($1)
	   WHERE 
	     sum IS NOT NULL and 
	     ul  is null AND 
	     amn_docnumber IS NULL and
	     obj Ilike 'Корректировка%'
	   GROUP BY ul 
	)

	UNION 
	( SELECT 
	     null::varchar 					AS sort_ul,   
	     null::character varying 		AS fil,
	     'ВСЕГО нагрузочные потери '::character varying 	AS ul,
	     0::numeric 					AS loss_tot,
	     0::numeric 					AS loss_n,
	     0::numeric 					AS loss_l,
	     0::numeric 					AS loss_h,
	     0::numeric 					AS tot_dopsum,
	     sum(amount) 					AS tot_v407,
	     sum(amount) 					AS tot_v850,
	     price 						   AS tot_price,
	     -sum(sum_no_tax) 			AS tot_sum_no_tax,
	     -sum(tax_sum) 				AS tot_sum_tax,
	     -sum(sum_with_tax) 		AS tot_sum,
	      7 						      AS sort
	      FROM bee_docs_result 
		 WHERE linkid = $1 AND tar_typ = 1734
	      group by price
	)
	UNION 
	( select 
	     null::varchar 				AS sort_ul,
	     null::character varying 	AS fil,
	     'ВСЕГО ЭЛЕКТРОЭНЕРГИЯ:'::character varying 		AS ul,
	     a.loss_tot 					AS loss_tot,
	     a.loss_n 						AS loss_n,
	     a.loss_l 						AS loss_l,
	     a.loss_h 						AS loss_h,
	     a.tot_dopsum 				    AS tot_dopsum,
	     --c.amont 						AS tot_v407, 2019-12-24
	     a.tot_v407 					AS tot_v407,
	     c.amont 						AS tot_v850,
	     null::numeric 				AS tot_price,
	     b.sum_no_tax 				AS tot_sum_no_tax,
	     b.tax_sum 					AS tot_sum_tax,
	     b.sum_with_tax 				AS tot_sum,
	     8 AS sort 
	  from (
	        SELECT sum(loss_tot) AS loss_tot,
		           sum(loss_n) AS loss_n,
		           sum(loss_l) AS loss_l,
		           sum(loss_h) AS loss_h,
		           sum(dopsum) AS tot_dopsum,
		           sum(v407)   AS tot_v407,
		           sum(v850)   AS tot_v850
		     FROM bee_rep_pay_map_get_content_with_corr_cd($1) 
		    ) AS a,
		    (
		      select sum(sum_no_tax)   AS sum_no_tax,
		             sum(tax_sum)      AS tax_sum,
		             sum(sum_with_tax) AS sum_with_tax
		      from bee_docs_result WHERE linkid = $1
		    ) AS b,
		    (
		      select sum(amount) AS amont
		      from bee_docs_result WHERE linkid = $1 AND tar_grp IS NOT NULL
		    ) AS c
	) 
	UNION 
	(     select null::varchar 					AS sort_ul,
		           null::character varying 		AS fil,
		           'ВСЕГО НДС:'::character varying 			AS ul,
		           null::numeric 					AS loss_tot,
		           null::numeric 					AS loss_n,
		           null::numeric 					AS loss_l,
		           null::numeric 					AS loss_h,
		           null::numeric 					AS tot_dopsum,
		           null::numeric 					AS tot_v407,
		           null::numeric 					AS tot_v850,
		           null::numeric 					AS tot_price,
		           b.tax_sum 	   				AS tot_sum_no_tax,
		           null::numeric  					AS tot_sum_tax,
		           null::numeric  					AS tot_sum,
		           9 							      AS sort 
		    
		     FROM 
		       (
		        select 
		          sum(sum_no_tax)                                                       AS sum_no_tax,
		          CASE WHEN sum(tax_sum) <> 0
			            THEN (sum(sum_no_tax) * bee_get_doc_tax(1163,$1))::numeric(20,2) 
			            ELSE (sum(sum_no_tax) * bee_get_doc_tax(1163,$1))::numeric(20,2)
		          END 			                                                           AS tax_sum,
		          CASE WHEN sum(sum_with_tax) <> 0
			            THEN (sum(sum_no_tax) * (1 + bee_get_doc_tax(1163,$1)))::numeric(20,2)
			            ELSE (sum(sum_no_tax) * (1 + bee_get_doc_tax(1163,$1)))::numeric(20,2)
		          END			                                                           AS sum_with_tax           
		        from bee_docs_result WHERE linkid = $1
		      ) AS b
		      WHERE (select * FROM  bee_is_calc_nds_new($1))
   )     
	UNION 
	(     select null::varchar 					AS sort_ul,
		           null::character varying 				AS fil,
		           'ВСЕГО ЭЛЕКТРОЭНЕРГИЯ С НДС:'::character varying 	AS ul,
		           null::numeric 					AS loss_tot,
		           null::numeric 					AS loss_n,
		           null::numeric 					AS loss_l,
		           null::numeric 					AS loss_h,
		           null::numeric 					AS tot_dopsum,
		           null::numeric 					AS tot_v407,
		           null::numeric 					AS tot_v850,
		           null::numeric 					AS tot_price,
		           b.sum_with_tax					AS tot_sum_no_tax,
		           null::numeric 					AS tot_sum_tax,
		           null::numeric 					AS tot_sum,
		           10 							AS sort
		           
		      FROM  
		      (
		        select 
		           sum(sum_no_tax)    AS sum_no_tax,
		           CASE WHEN sum(tax_sum) <> 0
			             THEN (sum(sum_no_tax) * bee_get_doc_tax(1163,$1))::numeric(20,2) --sum(tax_sum)
			             ELSE (sum(sum_no_tax) * bee_get_doc_tax(1163,$1))::numeric(20,2)
		           END 		        AS tax_sum,
		           CASE WHEN sum(sum_with_tax) <> 0
			             THEN (sum(sum_no_tax) * (1 + bee_get_doc_tax(1163,$1)))::numeric(20,2) --sum(sum_with_tax)
			             ELSE (sum(sum_no_tax) * (1 + bee_get_doc_tax(1163,$1)))::numeric(20,2)
		           END			        AS sum_with_tax       
		        from bee_docs_result WHERE linkid = $1
		      ) AS b
		      WHERE (select * FROM  bee_is_calc_nds_new($1)))
	ORDER BY sort, ul;


$$;

comment on function bee_rep_pay_map_get_content_with_corr_cd_tot_all(integer) is 'Карта расхода ЦД. Используется в RepPayMapCD.java';

alter function bee_rep_pay_map_get_content_with_corr_cd_tot_all(integer) owner to postgres;

