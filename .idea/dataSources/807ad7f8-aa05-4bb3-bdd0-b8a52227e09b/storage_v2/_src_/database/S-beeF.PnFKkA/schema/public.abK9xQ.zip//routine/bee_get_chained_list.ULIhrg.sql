create function bee_get_chained_list(lid integer) returns refcursor
    language plpgsql
as
$$
    --
-- ПОЛУЧИТЬ СПИСОК УСТРОЙСТВ СУБАБОНЕНТОВ ПО LOCID (denet.rowid)
--
DECLARE
  rf REFCURSOR;
--
BEGIN
OPEN rf FOR   	
   SELECT 
         (select agreement.rowid from agreement where (
             agreement.rowid IN (
                 select linkid from agreepoint 
                      where rowid = agreeregdev.paramval::integer ))) 
                                       as pdocid, 
         (select agreement.abo_code from agreement where (
             agreement.rowid IN (
                 select linkid from agreepoint 
                      where rowid = agreeregdev.paramval::integer ))) 
                                       as paboid, 
         (select abo_name from customer where abo_code in ( 
           select agreement.abo_code from agreement where (
             agreement.rowid IN (
                 select linkid from agreepoint 
                      where rowid = agreeregdev.paramval::integer )))) 
                                       as paboname, 
         (select agreement.docnumber from agreement where (
             agreement.rowid IN (
                 select linkid from agreepoint 
                      where rowid = agreeregdev.paramval::integer ))) 
                                       as pdocnum, 
         agreeregdev.paramval::integer as pdevid,
         ----------------------------------------- 
         agreement.rowid               as cdocid,
	 agreement.abo_code	       as caboid,
         (select abo_name from customer where abo_code = agreement.abo_code)
                                       as caboname,                        		
         agreement.docnumber           as cdocnum,
         agreepoint.rowid              as cdevid,
	 agreepoint.prodnumber         as cdevnum
   FROM agreepoint
       LEFT JOIN agreement   ON agreepoint.linkid = agreement.rowid
       LEFT JOIN agreeregdev ON agreepoint.rowid = agreeregdev.linkid
   WHERE
       agreement.locid      = lid       AND
       agreeregdev.paramid  = 664       AND 
       agreeregdev.paramval IS NOT NULL AND 
      (agreeregdev.paramval::integer > 0);
--
RETURN rf; 
--
--
END;
--
--
$$;

alter function bee_get_chained_list(integer) owner to pgsql;

