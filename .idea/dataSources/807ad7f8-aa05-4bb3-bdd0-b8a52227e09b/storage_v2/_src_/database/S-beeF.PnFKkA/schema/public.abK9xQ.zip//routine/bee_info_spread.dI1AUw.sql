create function bee_info_spread(rid integer) returns void
    language plpgsql
as
$$
DECLARE
   CurDb   varchar;
   Rec     RECORD;
   HST     varchar;
   ExtHost varchar[] := array[
        'f51apps','f52apps','f55apps','f56apps', 
        'f60apps','f61apps','f63apps','f64apps',
        'f66apps0','f66apps1','f66apps2','f66apps3',
        'f67apps','f68apps', 
        'f70apps'
        ];   
   
BEGIN

   select current_database() limit 1 into CurDb;

   if (CurDb <> 'beeX') Then
       return;
   end if;

   SELECT rowid,tag,info,stamp FROM bee_info where rowid = $1 into Rec;

   CREATE EXTENSION if not exists postgres_fdw;

   FOREACH HST IN ARRAY ExtHost
   LOOP
   
     --RAISE NOTICE '%',HST;
     
     if HST = 'f51apps'  then 
        drop   server if exists               srv51 CASCADE;
        CREATE SERVER                         srv51 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f51apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv51 OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl51 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv51 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl51 where rowid = $1;  
                                  insert into tbl51 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv51 CASCADE;
        CREATE SERVER                         srv51 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f51apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv51  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl51 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv51 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl51 where rowid = $1;  
                                  insert into tbl51 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv51 CASCADE;
        CREATE SERVER                         srv51 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f51apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv51  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl51 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv51 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl51 where rowid = $1;  
                                  insert into tbl51 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv51 CASCADE;
     END IF;
     
     if HST = 'f52apps'  then 
        drop   server if exists               srv52 CASCADE;
        CREATE SERVER                         srv52 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f52apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv52 OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl52 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv52 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl52 where rowid = $1;  
                                  insert into tbl52 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv52 CASCADE;
        CREATE SERVER                         srv52 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f52apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv52  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl52 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv52 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl52 where rowid = $1;  
                                  insert into tbl52 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv52 CASCADE;
        CREATE SERVER                         srv52 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f52apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv52  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl52 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv52 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl52 where rowid = $1;  
                                  insert into tbl52 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv52 CASCADE;
     END IF;

     if HST = 'f55apps'  then 
        drop   server if exists               srv55 CASCADE;
        CREATE SERVER                         srv55 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f55apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv55 OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl55 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv55 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl55 where rowid = $1;  
                                  insert into tbl55 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv55 CASCADE;
        CREATE SERVER                         srv55 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f55apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv55  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl55 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv55 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl55 where rowid = $1;  
                                  insert into tbl55 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv55 CASCADE;
        CREATE SERVER                         srv55 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f55apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv55  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl55 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv55 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl55 where rowid = $1;  
                                  insert into tbl55 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv55 CASCADE;
     END IF;
     
     if HST = 'f56apps'  then 
        drop   server if exists               srv56 CASCADE;
        CREATE SERVER                         srv56 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f56apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv56 OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl56 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv56 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl56 where rowid = $1;  
                                  insert into tbl56 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv56 CASCADE;
        CREATE SERVER                         srv56 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f56apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv56  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl56 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv56 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl56 where rowid = $1;  
                                  insert into tbl56 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv56 CASCADE;
        CREATE SERVER                         srv56 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f56apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv56  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl56 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv56 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl56 where rowid = $1;  
                                  insert into tbl56 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv56 CASCADE;

     END IF;
     
     if HST = 'f60apps'  then 
        drop   server if exists               srv60 CASCADE;
        CREATE SERVER                         srv60 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f60apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv60 OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl60 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv60 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl60 where rowid = $1;  
                                  insert into tbl60 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv60 CASCADE;
        CREATE SERVER                         srv60 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f60apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv60  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl60 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv60 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl60 where rowid = $1;  
                                  insert into tbl60 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv60 CASCADE;
        CREATE SERVER                         srv60 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f60apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv60  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl60 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv60 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl60 where rowid = $1;  
                                  insert into tbl60 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv60 CASCADE;
     END IF;
     
     if HST = 'f61apps'  then 
        drop   server if exists               srv61 CASCADE;
        CREATE SERVER                         srv61 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f61apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv61 OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl61 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv61 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl61 where rowid = $1;  
                                  insert into tbl61 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv61 CASCADE;
        CREATE SERVER                         srv61 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f61apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv61  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl61 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv61 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl61 where rowid = $1;  
                                  insert into tbl61 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv61 CASCADE;
        CREATE SERVER                         srv61 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f61apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv61  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl61 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv61 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl61 where rowid = $1;  
                                  insert into tbl61 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv61 CASCADE; 
     END IF;
     
     if HST = 'f63apps'  then 
        drop   server if exists               srv63 CASCADE;
        CREATE SERVER                         srv63 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f63apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv63 OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl63 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv63 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl63 where rowid = $1;  
                                  insert into tbl63 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv63 CASCADE;
        CREATE SERVER                         srv63 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f63apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv63  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl63 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv63 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl63 where rowid = $1;  
                                  insert into tbl63 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv63 CASCADE;
        CREATE SERVER                         srv63 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f63apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv63  OPTIONS (user 'bee', password '123');
        CREATE FOREIGN TABLE IF NOT EXISTS    tbl63 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv63 OPTIONS (schema_name 'public', table_name 'bee_info');   

                                  delete from tbl63 where rowid = $1;  
                                  insert into tbl63 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv63 CASCADE; 
     END IF;
    
     if HST = 'f64apps'  then 
        drop   server if exists               srv64 CASCADE;
        CREATE SERVER                         srv64 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f64apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv64 OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl64 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv64 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl64 where rowid = $1;  
                                  insert into tbl64 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);            
        drop   server if exists               srv64 CASCADE;
        
        CREATE SERVER                         srv64 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f64apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv64  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl64 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv64 OPTIONS (schema_name 'public', table_name 'bee_info');     
                                 --ALTER SERVER srv64 OPTIONS (SET dbname 'beeF');
                                  delete from tbl64 where rowid = $1;  
                                  insert into tbl64 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
          
        drop   server if exists               srv64 CASCADE;
        CREATE SERVER                         srv64 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f64apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv64  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl64 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv64 OPTIONS (schema_name 'public', table_name 'bee_info');        
                                -- ALTER SERVER srv64 OPTIONS (SET dbname 'beeX');
                                  delete from tbl64 where rowid = $1;  
                                  insert into tbl64 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv64 CASCADE;
 
     END IF;
     
     if HST = 'f66apps0' then 
        drop   server if exists               srv660 CASCADE;
        CREATE SERVER                         srv660 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f66apps0', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv660 OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl660 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv660 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl660 where rowid = $1;  
                                  insert into tbl660 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv660 CASCADE;
        CREATE SERVER                         srv660 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f66apps0', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv660  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl660 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv660 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl660 where rowid = $1;  
                                  insert into tbl660 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv660 CASCADE;
        CREATE SERVER                         srv660 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f66apps0', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv660  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl660 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv660 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl660 where rowid = $1;  
                                  insert into tbl660 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv660 CASCADE;
 
     END IF;
     
     if HST = 'f66apps1' then 
        drop   server if exists               srv661 CASCADE;
        CREATE SERVER                         srv661 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f66apps1', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv661 OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl661 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv661 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl661 where rowid = $1;  
                                  insert into tbl661 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv661 CASCADE;
        CREATE SERVER                         srv661 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f66apps1', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv661  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl661 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv661 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl661 where rowid = $1;  
                                  insert into tbl661 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv661 CASCADE;
 
     END IF;
     
     if HST = 'f66apps2' then 
        drop   server if exists               srv662 CASCADE;
        CREATE SERVER                         srv662 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f66apps2', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv662 OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl662 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv662 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl662 where rowid = $1;  
                                  insert into tbl662 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv662 CASCADE;
        CREATE SERVER                         srv662 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f66apps2', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv662  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl662 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv662 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl662 where rowid = $1;  
                                  insert into tbl662 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv662 CASCADE;
        
     END IF;
     
     if HST = 'f66apps3' then 
        drop   server if exists               srv663 CASCADE;
        CREATE SERVER                         srv663 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f66apps3', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv663 OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl663 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv663 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl663 where rowid = $1;  
                                  insert into tbl663 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv663 CASCADE;

        CREATE SERVER                         srv663 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f66apps3', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv663  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl663 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
          SERVER srv663 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl663 where rowid = $1;  
                                  insert into tbl663 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv663 CASCADE;

     END IF;
     
     if HST = 'f67apps'  then 
        drop   server if exists               srv67 CASCADE;
        CREATE SERVER                         srv67 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f67apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv67 OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl67 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv67 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl67 where rowid = $1;  
                                  insert into tbl67 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv67 CASCADE;

        CREATE SERVER                         srv67 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f67apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv67  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl67 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv67 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl67 where rowid = $1;  
                                  insert into tbl67 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      

        drop   server if exists               srv67 CASCADE;
        CREATE SERVER                         srv67 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f67apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv67  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl67 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv67 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl67 where rowid = $1;  
                                  insert into tbl67 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv67 CASCADE;
     END IF;
     
     if HST = 'f68apps'  then 
        drop   server if exists               srv68 CASCADE;
        CREATE SERVER                         srv68 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f68apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv68 OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl68 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv68 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl68 where rowid = $1;  
                                  insert into tbl68 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv68 CASCADE;

        CREATE SERVER                         srv68 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f68apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv68  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl68 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv68 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl68 where rowid = $1;  
                                  insert into tbl68 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv68 CASCADE;

        CREATE SERVER                         srv68 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f68apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv68  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl68 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv68 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl68 where rowid = $1;  
                                  insert into tbl68 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv68 CASCADE;
     END IF;
     
     if HST = 'f70apps'  then 
        drop   server if exists               srv70 CASCADE;
        CREATE SERVER                         srv70 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f70apps', port '5432', dbname 'beeU');
        CREATE USER MAPPING FOR PUBLIC SERVER srv70 OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl70 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv70 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl70 where rowid = $1;  
                                  insert into tbl70 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv70 CASCADE;
        /*
        CREATE SERVER                         srv70 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f70apps', port '5432', dbname 'beeF');
        CREATE USER MAPPING FOR PUBLIC SERVER srv70  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl70 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv70 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl70 where rowid = $1;  
                                  insert into tbl70 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv70 CASCADE;

        CREATE SERVER                         srv70 FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host 'f70apps', port '5432', dbname 'beeX');
        CREATE USER MAPPING FOR PUBLIC SERVER srv70  OPTIONS (user 'bee', password '123');

        CREATE FOREIGN TABLE IF NOT EXISTS    tbl70 ( rowid integer, tag character varying, info text, stamp timestamp without time zone )
                                       SERVER srv70 OPTIONS (schema_name 'public', table_name 'bee_info');   
                                  delete from tbl70 where rowid = $1;  
                                  insert into tbl70 (rowid,tag,info,stamp) values (Rec.rowid,Rec.tag,Rec.info,Rec.stamp);      
        drop   server if exists               srv70 CASCADE;
        */
     END IF;

      
   END LOOP;

     
END;
--
--
$$;

comment on function bee_info_spread(integer) is 'Пополнение тем';

alter function bee_info_spread(integer) owner to pgsql;

