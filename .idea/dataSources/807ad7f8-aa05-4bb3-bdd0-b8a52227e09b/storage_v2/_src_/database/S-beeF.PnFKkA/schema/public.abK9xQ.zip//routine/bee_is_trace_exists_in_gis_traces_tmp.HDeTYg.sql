create function bee_is_trace_exists_in_gis_traces_tmp(oc integer, oo integer) returns boolean
    language plpgsql
as
$$
BEGIN
   RETURN EXISTS(SELECT 1 FROM gis_traces_tmp WHERE objcode = oc AND objowner = oo);
END;
$$;

comment on function bee_is_trace_exists_in_gis_traces_tmp(integer, integer) is 'Используется в GisTracesOwner.java';

alter function bee_is_trace_exists_in_gis_traces_tmp(integer, integer) owner to postgres;

