create function bee_get_gis_traces_connected_points(trace_rowid integer) returns SETOF gis_traces_connected_points
    language plpgsql
as
$$
DECLARE
  RowLine gis_traces_connected_points%rowtype;
  
BEGIN
  FOR RowLine IN (
       select docnumber, account, prodnumber, abo_name, element_name, agreepoint.rowid, denet.nam, a2.paramval, a3.paramval,  a4.paramval
		from agreepoint
		join agreement on agreepoint.linkid=agreement.rowid
		join customer on agreement.abo_code=customer.abo_code
		left join (select paramval,linkid from agreeregdev where paramid=189 and paramval::text != '?') as a1 on agreepoint.rowid=a1.linkid
		join dic_elements on a1.paramval::numeric=dic_elements.rowid
		join regdevconn on agreepoint.rowid=regdevconn.pointid
		join denet on denet.rowid=agreepoint.lid
		LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 417) AS a2 ON agreepoint.rowid=a2.linkid
		LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 642) AS a3 ON agreepoint.rowid=a3.linkid
		LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 640) AS a4 ON agreepoint.rowid=a4.linkid
		
		where traceid=trace_rowid
  )
  LOOP
     RETURN NEXT RowLine;
  END LOOP;
END;
$$;

comment on function bee_get_gis_traces_connected_points(integer) is 'Используется в GisTracesOwner.java, SessionBean1.java';

alter function bee_get_gis_traces_connected_points(integer) owner to postgres;

