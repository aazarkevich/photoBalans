create function bee_del_agreepointline(rid integer) returns integer
    language plpgsql
as
$$
/*
ito06 2012-08-27 Удаление линии у точки учета
*/
DECLARE NR INTEGER =-1;

 BEGIN
 NR = -1; 
 DELETE FROM agreepoint_line WHERE rowid = rid RETURNING 1 INTO NR;
 IF NR IS NOT NULL
    THEN  RETURN 1;
 ELSE RETURN -1;
 END IF;

END;
$$;

comment on function bee_del_agreepointline(integer) is 'Удаление линии у точки учета. Используется в DeviceParamL.java, AppUtils.java';

alter function bee_del_agreepointline(integer) owner to pgsql;

