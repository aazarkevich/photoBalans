create function bee_docs_sheet_value_bubble_loss(agreeid integer, docid integer, docdate date) returns void
    language plpgsql
as
$$
    -- ВСТАВКА ИЛИ ОБНОВЛЕНИЕ ТЕКУЩЕЙ ЗАПИСИ В bee_docs_sheet
--
-- agreeid  - agreement.rowid
-- docid    - bee_docs.rowid
-- docdate - bee_docs.docdat 
--
DECLARE
   SN      INTEGER; 
   RecPrev RECORD; 
   RecCurr RECORD;

   DKPrev  NUMERIC := 0; -- дебит на начало
   KKPrev  NUMERIC := 0; -- кредит на начало


   InD  NUMERIC := 0; -- дебит на начало
   InK  NUMERIC := 0; -- кредит на начало

   OD  NUMERIC  := 0; -- обороты по дебиту
   OK  NUMERIC  := 0; -- обороты по кредиту

   OuD  NUMERIC := 0; -- дебит на конец
   OuK  NUMERIC := 0; -- кредит на конец

   RID_Current  INTEGER;   -- rowid текущей записи
   RID_Previous INTEGER;   -- rowid предыдущей записи

BEGIN
   --
   OD = COALESCE((SELECT SUM(sum_with_tax) 
          FROM bee_docs_result r 
          WHERE r.linkid = docid),(SELECT -SUM(loss_sum * (1 + bee_get_doc_tax(1163,docid) ))
          FROM bee_docs_loss l 
          WHERE l.linkid1 = agreeid 
            AND l.linkid2 = docid
            AND l.period = docdate
            AND l.loss_typ = 1733));
   OK = 0;
   
   --
   -- предыдущая запись по документу договра 
   SELECT INTO RID_Previous rowid FROM bee_docs_sheet 
      WHERE 
         linkid1       = agreeid 
         AND linkid2   = docid 
         AND operdate  < docdate 
      ORDER BY operdate DESC LIMIT 1;

   -- PREVIOUS       
   IF RID_Previous <> NULL THEN
      SELECT INTO RecPrev  
         final_debit, 
         final_kredit 
      FROM  bee_docs_sheet
      WHERE rowid = RID_Previous;
      
      DKPrev = COALESCE(RecPrev.final_debit,0);
      KKPrev = COALESCE(RecPrev.final_kredit,0);

   ELSE
      DKPrev = 0;
      KKPrev = 0;      
   END IF;
   
   --
   -- текущая запись по документу договра 
   SELECT INTO RID_Current rowid FROM bee_docs_sheet 
      WHERE 
         linkid1      = agreeid 
         AND linkid2  = docid 
         AND operdate = docdate LIMIT 1; 

   SN := (SELECT COALESCE((SELECT MAX(npp)+1 FROM bee_docs_sheet WHERE operdate = docdate AND linkid1 = agreeid), 1));
   
   -- CURRENT
   IF RID_Current <> NULL THEN    
      SELECT INTO RecCurr  
         oper_debit  AS D, 
         oper_kredit AS K
      FROM  bee_docs_sheet
      WHERE rowid = RID_Current;

      OuD = DKPrev + RecCur.D - RecCur.K;
      IF OuD > 0 THEN
          OuD = OuD;
          OuK = 0; 
      ELSE
          OuD = 0;
          OuK = -OuD; 
      END IF; 

      UPDATE bee_docs_sheet SET 
         npp          = SN,
         start_debit  = DKPrev,
         start_kredit = KKPrev,
         oper_debit   = OD,
         oper_kredit  = OK,
         final_debit  = OuD,
         final_kredit = OuK
      WHERE rowid = RID_Current;
         
   ELSE
      
      OuD = 0;
      OuK = 0;
      INSERT INTO bee_docs_sheet (
         linkid1,       -- 1
         linkid2,       -- 2
         operdate,      -- 3 
         npp,           -- 4 
         account,
         start_debit,   -- 5
         start_kredit,  -- 6 
         oper_debit,    -- 7
         oper_kredit,   -- 8
         final_debit,   -- 9
         final_kredit   -- 10
      ) VALUES (
         agreeid,       -- 1 
         docid,         -- 2
         docdate,       -- 3
         SN,            -- 4
         0,  
         DKPrev,        -- 5
         KKPrev,        -- 6
         OD,            -- 7
         OK,            -- 8 
         OuD, -- 9
         OuK  -- 10  
      );
   END IF;

  
END;
$$;

comment on function bee_docs_sheet_value_bubble_loss(integer, integer, date) is 'Вставка или обновление текущей записи в bee_docs_sheet. Используется в LossRSK.java, AppUtils.java';

alter function bee_docs_sheet_value_bubble_loss(integer, integer, date) owner to pgsql;

