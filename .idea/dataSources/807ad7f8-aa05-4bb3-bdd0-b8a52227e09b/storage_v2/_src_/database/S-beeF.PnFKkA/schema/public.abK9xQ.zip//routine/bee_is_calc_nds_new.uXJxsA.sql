create function bee_is_calc_nds_new(bdrid integer) returns boolean
    language plpgsql
as
$$
/*
	ito06 2015-05-22 Считаем НДС по новому все вместе не учитывая уровень напряжения (с 2014-09-30) 
*/
DECLARE newform numeric = 0;	
	_docdat date;
BEGIN

	SELECT sum(sum_with_tax) FROM bee_docs_result where linkid =$1 INTO newform;	
	SELECT bd.docdat FROM bee_docs AS bd where  bd.rowid =$1 limit 1 INTO _docdat;	
        IF (newform = 0 ) 
		THEN RETURN true;
		ELSE IF _docdat>'2014-09-30' 
			THEN RETURN true;
			ELSE RETURN false;
		     END IF;
        END IF;   
END;
$$;

comment on function bee_is_calc_nds_new(integer) is 'Используется в RepPayMap.java; RepPayMapCD.java; RepPayMapCDChange.java';

alter function bee_is_calc_nds_new(integer) owner to pgsql;

