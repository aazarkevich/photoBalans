create function bee_rep_get_repdata15(loc integer, start_date date, end_date date) returns SETOF bee_rep_tab12
    language sql
as
$$
/*
ito16 
ito06 2012-02-09
Журнал задолженников
*/
SELECT
	docnumber,
	cst_name,
	CASE WHEN sd IS NULL
                 THEN s1d
             ELSE sd
        END AS sd,
        CASE WHEN sk IS NULL
                 THEN s1k
             ELSE sk
        END AS sk,
	od,
	ok,
	fd,
	fk,
	grp
   FROM ( SELECT amn.rowid AS rowid,
		 amn.docnumber AS docnumber,
		 cst.consum_name AS cst_name,
		 dic.element_name AS grp
	    FROM agreement AS amn
            JOIN customer AS cst ON cst.abo_code = amn.abo_code
            JOIN dic_elements AS dic ON dic.rowid=amn.accdir
           WHERE amn.locid = $1
           --ito06 2012-02-09 AND amn.transmit = true
        ) AS amn
-----------------------------------------------
LEFT JOIN ( SELECT s.linkid,
		   sd,	
		   sk,
		   od,
		   ok,
		   fd,
		   fk
              FROM ( SELECT linkid1 AS linkid,
			    sum(oper_debit) AS od,
			    sum(oper_kredit) AS ok
		       FROM bee_docs_sheet
		      WHERE operdate BETWEEN $2 AND $3
		      GROUP BY linkid1
		   ) AS o
	      JOIN ( SELECT bds.final_kredit AS fk,
			    bds.final_debit AS fd,
			    bds.linkid1 AS linkid
		       FROM bee_docs_sheet AS bds
                       JOIN ( SELECT bds.linkid1 AS linkid,
                                     bds.operdate AS operdate,
                                     max(bds.npp) AS sn
                                FROM bee_docs_sheet AS bds
                                JOIN ( SELECT linkid1 AS linkid,
                                              max(operdate) AS operdate
                                         FROM bee_docs_sheet
                                        WHERE operdate <= $3
                                        GROUP BY linkid
                                     ) AS a ON a.linkid=bds.linkid1 AND a.operdate=bds.operdate
                                 GROUP BY bds.linkid1, bds.operdate
                            ) AS a1 ON a1.sn=bds.npp AND a1.linkid = bds.linkid1 AND a1.operdate = bds.operdate
                    ) AS f ON f.linkid = o.linkid
               JOIN ( SELECT bds.start_kredit AS sk,
                             bds.start_debit AS sd,
                             bds.linkid1 AS linkid
                        FROM bee_docs_sheet AS bds
                        JOIN ( SELECT bds.linkid1 AS linkid,
                                      bds.operdate AS operdate,
                                      min(bds.npp) AS sn
                                 FROM bee_docs_sheet AS bds
                                 JOIN ( SELECT linkid1 AS linkid,
                                               min(operdate) AS operdate
                                          FROM bee_docs_sheet
                                         WHERE operdate >= $2
                                         GROUP BY linkid
                                      ) AS a ON a.linkid=bds.linkid1 AND a.operdate=bds.operdate
                                GROUP BY bds.linkid1, bds.operdate
                             ) AS a1 ON a1.sn=bds.npp AND a1.linkid = bds.linkid1 AND a1.operdate = bds.operdate
                     ) AS s ON f.linkid = s.linkid
           ) AS a ON a.linkid = amn.rowid
--------------------------------------------------------
LEFT JOIN ( SELECT bds.final_kredit AS s1k,
		   bds.final_debit AS s1d,
		   bds.linkid1 AS linkid
	      FROM bee_docs_sheet AS bds
              JOIN ( SELECT bds.linkid1 AS linkid,
			    bds.operdate AS operdate,
                            max(bds.npp) AS sn
                       FROM bee_docs_sheet AS bds
                       JOIN ( SELECT linkid1 AS linkid,
                                     max(operdate) AS operdate
                                FROM bee_docs_sheet
                               WHERE operdate <= $2
                               GROUP BY linkid
                            ) AS a ON a.linkid=bds.linkid1 AND a.operdate=bds.operdate
                      GROUP BY bds.linkid1, bds.operdate
                   ) AS a1 ON a1.sn=bds.npp AND a1.linkid = bds.linkid1 AND a1.operdate = bds.operdate
           ) AS s1 ON s1.linkid = amn.rowid
     WHERE fd>0;
$$;

comment on function bee_rep_get_repdata15(integer, date, date) is 'Журнал задолженников. Используется в RepCreate15.java';

alter function bee_rep_get_repdata15(integer, date, date) owner to pgsql;

