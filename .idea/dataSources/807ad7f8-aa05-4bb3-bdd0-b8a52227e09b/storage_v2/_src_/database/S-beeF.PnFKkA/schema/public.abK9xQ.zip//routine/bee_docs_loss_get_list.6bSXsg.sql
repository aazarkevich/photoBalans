create function bee_docs_loss_get_list(amnid integer)
    returns TABLE(linkid1 integer, linkid2 integer, period date, docdat date, docnum integer, loss_typ integer, loss_typ_nam character varying, loss_kvt integer, loss_tarif numeric, loss_sum numeric, userid character varying, locid integer, locnam character varying)
    language sql
as
$$
/*
	ito06 2016-04-20 добавили колонку locid
	Получение нагрузочных потерь для договора
*/

	     SELECT 
		bdl.linkid1, 
		bdl.linkid2, 
		bdl.period,
		bdl.docdat, 
		bdl.docnum, 
		bdl.loss_typ, 
		dic.element_name AS loss_typ_nam, 
		bdl.loss_kvt, 
		bdl.loss_tarif, 
		bdl.loss_sum, 
		bdl.userid, 
		bdl.locid,
		de.nam AS locnam
		 
	   FROM bee_docs_loss AS bdl
	   JOIN bee_docs AS bd ON bdl.linkid2 = bd.rowid 
	   JOIN dic_elements  AS dic ON dic.rowid = bdl.loss_typ
	   JOIn denet AS de ON de.rowid = bdl.locid
	  WHERE bdl.linkid1 = amnid 
	  ORDER BY bdl.period DESC, locid, bdl.loss_typ;

$$;

comment on function bee_docs_loss_get_list(integer) is 'Получение нагрузочных потерь для договора. Используется в LossRSK.java, SessionBean1.java';

alter function bee_docs_loss_get_list(integer) owner to pgsql;

