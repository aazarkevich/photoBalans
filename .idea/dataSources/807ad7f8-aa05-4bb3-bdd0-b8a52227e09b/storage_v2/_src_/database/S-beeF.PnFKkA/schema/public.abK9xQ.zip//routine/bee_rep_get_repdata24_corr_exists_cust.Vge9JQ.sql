create function bee_rep_get_repdata24_corr_exists_cust(loc_id integer, s_date date, e_date date, vn integer, sn1 integer, sn2 integer, nn integer) returns character varying
    language sql
as
$$
/*
	ito06 2013-10-21: Ведомость по объему услуг
*/

SELECT name
  FROM
		bee_rep_get_repdata24_corr3_norm_cust($1,$2,$3,$4,$5,$6,$7) AS norm      
      FULL JOIN bee_rep_get_repdata24_corr3_snorm_cust($1,$2,$3,$4,$5,$6,$7) AS snorm USING (dat,name)
          WHERE norm.tot_sum <>0 OR norm.tot_amount <>0 OR snorm.tot_sum <>0 OR snorm.tot_amount <>0 ;


$$;

comment on function bee_rep_get_repdata24_corr_exists_cust(integer, date, date, integer, integer, integer, integer) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24_cont_cust1(int, date, date)';

alter function bee_rep_get_repdata24_corr_exists_cust(integer, date, date, integer, integer, integer, integer) owner to pgsql;

