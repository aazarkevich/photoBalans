create function bee_get_customer_address(custid integer, isuro boolean) returns character varying
    language plpgsql
as
$$
DECLARE
  Rec RECORD;
  Tag VARCHAR;
  Res VARCHAR := '';
  Lab VARCHAR; 
  FLT VARCHAR; 
BEGIN
  -- 
  IF isuro THEN
     Tag = '%юр%адр%';
  ELSE
     Tag = '%факт%адр%';
  END IF; 
  --
  FOR Rec IN ( 
      SELECT elrowid,item FROM customer_info 
      WHERE 
          abo = custid AND
          item NOT IN ('-','?') AND
          elrowid IN (
             SELECT rowid FROM dic_elements 
             WHERE  link = 26 AND element_name LIKE Tag 
             ORDER BY element_code 
          )  
       ORDER BY rowid       
            
   ) LOOP
   
   Lab = (SELECT element_name FROM dic_elements WHERE rowid = Rec.elrowid LIMIT 1);
   Lab = replace(Lab,'юр.','');
   Lab = replace(Lab,'факт.','');
   Lab = replace(Lab,'адр.','');

   Res = Res || '|' || Lab || '~' || Rec.item ; 
   END LOOP; 
RETURN Res;
END;
$$;

comment on function bee_get_customer_address(integer, boolean) is 'Используется в RepAkt.java, RepAkt1.java, AppUtils.java';

alter function bee_get_customer_address(integer, boolean) owner to pgsql;

