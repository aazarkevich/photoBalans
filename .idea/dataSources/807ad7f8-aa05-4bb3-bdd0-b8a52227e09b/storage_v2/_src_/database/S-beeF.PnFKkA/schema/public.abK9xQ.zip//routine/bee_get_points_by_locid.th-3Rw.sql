create function bee_get_points_by_locid(_lid integer) returns integer[]
    language plpgsql
as
$$
    --
-- ИДЕНТИФИКАТОРЫ ТОЧЕК УЧЁТА ПОДКЛЮЧЕНИЯ ПО УЧАСТКУ
-- lid     : код участка
-- 
BEGIN
   RETURN ARRAY(
     SELECT agreepoint.rowid FROM agreepoint
     JOIN agreement ON agreepoint.linkid = agreement.rowid
     WHERE agreement.locid = _lid
   );
--
END;
$$;

comment on function bee_get_points_by_locid(integer) is 'Идентификаторы точек учета по участку. 
Используется в RepAkt.java, RepAkt11.java, RepAktHistory.java, AppUtils.java';

alter function bee_get_points_by_locid(integer) owner to pgsql;

