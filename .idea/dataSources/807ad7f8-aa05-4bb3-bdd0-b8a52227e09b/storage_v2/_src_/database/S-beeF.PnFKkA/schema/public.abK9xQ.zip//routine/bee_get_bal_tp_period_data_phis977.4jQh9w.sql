create function bee_get_bal_tp_period_data_phis977(date_from text, date_to text, locid integer) returns SETOF bal_tp_period_data_phis
    language plpgsql
as
$$
    --
--
DECLARE
  RowLine bal_tp_period_data_phis%rowtype;
---  
BEGIN
---  
  FOR RowLine IN (select 
			TP, -- колонка 2
			obj_code, -- для связки с данными из базы юр лиц
			objowner_code, --для связки с данными из базы юр лиц
			sum(potreb) as kol4 -- колонка 7
			  from
			  (select 
			   case when gis_traces.objtype=11 then family.son
				when gis_traces.objtype=10 or gis_traces.objtype=9 or gis_traces.objtype=8 then family.father
			   end as TP, 
			   case when gis_traces.objtype=11 then family.son_code
				when gis_traces.objtype=10 or gis_traces.objtype=9 or gis_traces.objtype=8 then family.father_code
			   end as obj_code,
			   case when gis_traces.objtype=11 then family.son_owner_code
				when gis_traces.objtype=10 or gis_traces.objtype=9 or gis_traces.objtype=8 then family.father_owner_code
			   end as objowner_code,
			   gis_traces.objtype,
			   case when a1.paramval='432' then sum(a3.valman)
			   end as potreb --потребление
			   from regdevconn
			   join agreepoint on regdevconn.pointid=agreepoint.rowid
			   join agreement on agreepoint.linkid=agreement.rowid
			   join gis_traces on regdevconn.traceid = gis_traces.rowid
			   join (select agreepoint.rowid as r1, t1.objname as son, t1.objcode as son_code, t1.objowner as son_owner_code,
				 t2.objname as father, t2.objcode as father_code,  t2.objowner as father_owner_code
				 from agreepoint 
				 join regdevconn on agreepoint.rowid=regdevconn.pointid 
				 join gis_traces t1 on regdevconn.traceid=t1.rowid 
				 join gis_traces t2 on t2.objcode=t1.objowner 
				) as family on regdevconn.pointid=family.r1 
			   left join (select paramval, linkid from agreeregdev where paramid=189 and paramval='432') as a1 on regdevconn.pointid=a1.linkid
			   left join (select sum(valman::float) as valman, linkid from regdevoper977 where paramid=407 and valman <> '-' and operdate between date_from::date and date_to::date group by linkid) as a3 on regdevconn.pointid=a3.linkid     
			   where agreement.locid = locid
			   group by TP, obj_code, objowner_code, a1.paramval, gis_traces.objtype
			   ) as tab 
			   group by tp, obj_code, objowner_code
			   order by TP
  )
  LOOP
     RETURN NEXT RowLine; 
  END LOOP;
---
RETURN;
--
END;

$$;

alter function bee_get_bal_tp_period_data_phis977(text, text, integer) owner to pgsql;

