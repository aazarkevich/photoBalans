create function bee_get_operlist1(pnt integer, per character varying) returns character varying
    language plpgsql
as
$$
/*
	ito06 2015-12-21 получить список показаний для точки учета дату per 
*/
DECLARE
  Rec     RECORD;
  DatList varchar := '';
---  
BEGIN
---  
  FOR Rec IN (
	SELECT DISTINCT operdate::varchar AS dat FROM regdevoper
	WHERE linkid =  pnt AND operdate::varchar LIKE per 
	ORDER BY dat
  ) 	    
  LOOP
     DatList = DatList || '|' || Rec.dat; 
  END LOOP;
---
RETURN DatList;
---
END;
$$;

comment on function bee_get_operlist1(integer, varchar) is 'Получить список показаний для точки учета дату per. Используется в RepAkt1.java, AppUtils.java';

alter function bee_get_operlist1(integer, varchar) owner to pgsql;

