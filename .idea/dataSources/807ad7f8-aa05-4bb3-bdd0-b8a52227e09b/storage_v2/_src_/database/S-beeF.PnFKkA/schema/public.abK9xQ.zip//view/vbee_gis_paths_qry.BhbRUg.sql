create view vbee_gis_paths_qry
            (loc, uch, tpid, owner_tp, hdrid, aboid, custnam, agreeid, agreenum, pointid, devnum, account, vid_id,
             vid_uch, hh, kz, dat1, pok_before, pok_curr, pok, koef, pok_koef, poteri_lin, poteri_hh, poteri_kz,
             dop_sum, otch_kol, sub, otch_bez_sub)
as
SELECT agreement.locid                                   AS loc,
       denet.nam                                         AS uch,
       CASE
           WHEN (gis_traces.objtype = 11) THEN family.son_id
           ELSE family.father_id
           END                                           AS tpid,
       de03.element_name                                 AS owner_tp,
       (ro33.paramval)::integer                          AS hdrid,
       customer.abo_code                                 AS aboid,
       customer.consum_name                              AS custnam,
       agreement.rowid                                   AS agreeid,
       agreement.docnumber                               AS agreenum,
       agreepoint.rowid                                  AS pointid,
       agreepoint.prodnumber                             AS devnum,
       agreepoint.account,
       de1.rowid                                         AS vid_id,
       de1.element_name                                  AS vid_uch,
       de02.element_name                                 AS hh,
       de01.element_name                                 AS kz,
       ro1.valman                                        AS dat1,
       (ro21.valman)::numeric                            AS pok_before,
       (ro22.valman)::numeric                            AS pok_curr,
       (ro2.valman)::numeric                             AS pok,
       (ro3.paramval)::numeric                           AS koef,
       ((ro2.valman)::numeric * (ro3.paramval)::numeric) AS pok_koef,
       (ro4.valman)::numeric                             AS poteri_lin,
       (ro5.valman)::numeric                             AS poteri_hh,
       (ro6.valman)::numeric                             AS poteri_kz,
       (ro7.valman)::numeric                             AS dop_sum,
       (ro8.valman)::numeric                             AS otch_kol,
       (ro9.valman)::numeric                             AS sub,
       (ro10.valman)::numeric                            AS otch_bez_sub
FROM (((((((((((((((((((((((((((agreepoint
    JOIN agreement ON ((agreement.rowid = agreepoint.linkid)))
    JOIN customer ON ((customer.abo_code = agreement.abo_code)))
    JOIN denet ON ((customer.locid = denet.rowid)))
    LEFT JOIN (SELECT agreeregdev.paramval,
                      agreeregdev.linkid
               FROM agreeregdev
               WHERE ((agreeregdev.paramid = 189) AND is_numeric(agreeregdev.paramval))
               ORDER BY agreeregdev.linkid) a1 ON ((agreepoint.rowid = a1.linkid)))
    LEFT JOIN dic_elements de1 ON (((a1.paramval)::numeric = (de1.rowid)::numeric)))
    LEFT JOIN (SELECT (regdevoper.valman)::date AS valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 194) AND
                      ((regdevoper.valman)::text ~~ '____-__-__'::text))) ro1 ON ((agreepoint.rowid = ro1.linkid)))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 196) AND is_numeric(regdevoper.valman))) ro21 ON (((ro1.linkid = ro21.linkid) AND (ro1.operdate = ro21.operdate))))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 195) AND is_numeric(regdevoper.valman))) ro22 ON (((ro1.linkid = ro22.linkid) AND (ro1.operdate = ro22.operdate))))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 198) AND is_numeric(regdevoper.valman))) ro2 ON (((ro1.linkid = ro2.linkid) AND (ro1.operdate = ro2.operdate))))
    LEFT JOIN (SELECT ard.linkid,
                      ard.paramval
               FROM (agreeregdev_period ard
                        JOIN (SELECT agreeregdev_period.linkid      AS link,
                                     max(agreeregdev_period.period) AS period
                              FROM (agreeregdev_period
                                       JOIN (SELECT regdevoper.linkid,
                                                    regdevoper.operdate
                                             FROM regdevoper
                                             WHERE (regdevoper.paramid = 194)) tab1
                                            ON ((agreeregdev_period.linkid = tab1.linkid)))
                              WHERE ((agreeregdev_period.paramid = 356) AND
                                     (agreeregdev_period.period <= tab1.operdate))
                              GROUP BY agreeregdev_period.linkid) ard_p
                             ON (((ard.linkid = ard_p.link) AND (ard.period = ard_p.period))))
               WHERE ((ard.paramid = 356) AND is_numeric(ard.paramval))) ro3 ON ((ro3.linkid = ro1.linkid)))
    LEFT JOIN (SELECT ard.linkid,
                      ard.paramval
               FROM (agreeregdev_period ard
                        JOIN (SELECT agreeregdev_period.linkid      AS link,
                                     max(agreeregdev_period.period) AS period
                              FROM (agreeregdev_period
                                       JOIN (SELECT regdevoper.linkid,
                                                    regdevoper.operdate
                                             FROM regdevoper
                                             WHERE (regdevoper.paramid = 194)) tab1
                                            ON ((agreeregdev_period.linkid = tab1.linkid)))
                              WHERE ((agreeregdev_period.paramid = 664) AND
                                     (agreeregdev_period.period <= tab1.operdate))
                              GROUP BY agreeregdev_period.linkid) sub
                             ON (((ard.linkid = sub.link) AND (ard.period = sub.period))))
               WHERE ((ard.paramid = 664) AND is_numeric(ard.paramval))) ro33 ON ((ro33.linkid = ro1.linkid)))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 919) AND is_numeric(regdevoper.valman))) ro4 ON (((ro1.linkid = ro4.linkid) AND (ro1.operdate = ro4.operdate))))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 918) AND is_numeric(regdevoper.valman))) ro5 ON (((ro1.linkid = ro5.linkid) AND (ro1.operdate = ro5.operdate))))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.rowid,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 917) AND is_numeric(regdevoper.valman))) ro6 ON (((ro1.linkid = ro6.linkid) AND (ro1.operdate = ro6.operdate))))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 199) AND is_numeric(regdevoper.valman))) ro7 ON (((ro1.linkid = ro7.linkid) AND (ro1.operdate = ro7.operdate))))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 407) AND is_numeric(regdevoper.valman))) ro8 ON (((ro1.linkid = ro8.linkid) AND (ro1.operdate = ro8.operdate))))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 849) AND is_numeric(regdevoper.valman))) ro9 ON (((ro1.linkid = ro9.linkid) AND (ro1.operdate = ro9.operdate))))
    LEFT JOIN (SELECT regdevoper.valman,
                      regdevoper.operdate,
                      regdevoper.linkid
               FROM regdevoper
               WHERE ((regdevoper.paramid = 850) AND is_numeric(regdevoper.valman))) ro10 ON (((ro1.linkid = ro10.linkid) AND (ro1.operdate = ro10.operdate))))
    LEFT JOIN (SELECT agreeregdev.paramval,
                      agreeregdev.linkid
               FROM agreeregdev
               WHERE ((agreeregdev.paramid = 1653) AND is_numeric(agreeregdev.paramval))) ard1 ON ((agreepoint.rowid = ard1.linkid)))
    LEFT JOIN dic_elements de01 ON (((ard1.paramval)::numeric = (de01.rowid)::numeric)))
    LEFT JOIN (SELECT agreeregdev.paramval,
                      agreeregdev.linkid
               FROM agreeregdev
               WHERE ((agreeregdev.paramid = 1654) AND is_numeric(agreeregdev.paramval))) ard2 ON ((agreepoint.rowid = ard2.linkid)))
    LEFT JOIN dic_elements de02 ON (((ard2.paramval)::numeric = (de02.rowid)::numeric)))
    LEFT JOIN (SELECT agreeregdev.paramval,
                      agreeregdev.linkid
               FROM agreeregdev
               WHERE ((agreeregdev.paramid = 1655) AND is_numeric(agreeregdev.paramval))) ard3 ON ((agreepoint.rowid = ard3.linkid)))
    LEFT JOIN dic_elements de03 ON (((ard3.paramval)::numeric = (de03.rowid)::numeric)))
    JOIN regdevconn ON ((agreepoint.rowid = regdevconn.pointid)))
    JOIN gis_traces ON ((regdevconn.traceid = gis_traces.rowid)))
         LEFT JOIN (SELECT agreepoint_1.rowid AS r1,
                           t1.rowid           AS son_id,
                           t2.rowid           AS father_id
                    FROM (((agreepoint agreepoint_1
                        JOIN regdevconn regdevconn_1 ON ((agreepoint_1.rowid = regdevconn_1.pointid)))
                        JOIN gis_traces t1 ON ((regdevconn_1.traceid = t1.rowid)))
                             LEFT JOIN gis_traces t2 ON ((t2.objcode = t1.objowner)))
                    GROUP BY agreepoint_1.rowid, t1.objname, t1.objcode, t1.objowner, t2.objname, t2.objcode, t1.rowid,
                             t2.rowid) family ON ((regdevconn.pointid = family.r1)))
WHERE (agreepoint.devtype = 644);

comment on view vbee_gis_paths_qry is 'Используется в bee_get_gis_path_info(int, int, date, date)';

alter table vbee_gis_paths_qry
    owner to postgres;

