create function bee_repakt12_get_tot_grp_sum(bd_rowid integer, grp1 character varying, dat date) returns SETOF bee_repakt2_tot_sum
    language plpgsql
as
$$
/*
	ito06 2021-02-02 Акт (сверх нормы) 	Всего стоимость по группам эл.эн.
*/
BEGIN 
RETURN QUERY EXECUTE'
	SELECT  MAX(period)::date,
		CASE 
		     WHEN '''||$2||''' = ''12,13'' OR '''||$2||''' = ''22,23'' OR '''||$2||''' = ''32,33''
                        THEN ''Всего стоимость по группе "Население и потребители, приравненные к населению" (без НДС) ''
                     WHEN '''||$2||''' = ''11,12,13'' OR '''||$2||''' = ''21,22,23'' OR '''||$2||''' = ''31,32,33''
                        THEN ''ВСЕГО стоимость услуг по передаче электрической энергии (без НДС)''  
                     WHEN '''||$2||''' = ''21,22,23,31,32,33'' 
                        THEN ''Итого корректировка стоимости услуг по передаче электрической энергии за {period}''  
                     WHEN '''||$2||''' = ''11,12,13,21,22,23,31,32,33'' 
                        THEN ''ВСЕГО стоимость услуг за {s_date} с учетом корректировки  (без НДС)''                  
                     ELSE NULL::varchar   
                END  				AS grp_name,    
		sum(vn_sum) 			AS grp_vn_sum,
		sum(sn1_sum) 			AS grp_sn1_sum,
		sum(sn2_sum) 			AS grp_sn2_sum,
		sum(nn_sum) 			AS grp_nn_sum,
		sum(tot_sum) 			AS grp_tot_sum,
		(select docdat from bee_docs where rowid = '||$1||' limit 1)
	   FROM bee_repakt12_get_content('||$1||')  
          WHERE grp in ('||$2||') AND ('''||$2||''' = ''11,12,13'' OR 
                                       '''||$2||''' = ''11,12,13,21,22,23,31,32,33'' OR 
                                       period='''||$3||''');';
END;
$$;

comment on function bee_repakt12_get_tot_grp_sum(integer, varchar, date) is 'Акт (сверх нормы) Всего стоимость по группам эл.эн. Используется в RepAkt12.java';

alter function bee_repakt12_get_tot_grp_sum(integer, varchar, date) owner to postgres;

