create function bee_is_allow_doc_create(amnid integer, docdat date) returns character varying
    language plpgsql
as
$$
/*
	add ito06 2019-12-05 добавили номер и л.с. головного абонента
    add ito06 2019-12-02 если база цент/смешанных то смотрим дату т.у., с какого момента он попал в договор смешанных/централизованных.
	add ito06 2019-11-18 если база цент/смешанных то смотрим дату для субб, с какого момента он попал в договор смешанных/централизованных.
    ito07 190717 номер централизованного договора - 1535 , уровень напряжения* - 439
    ito07 190201 введена проверка COALESCE, упорядочен текст функции
    add ito06 2016-06-17 если уровень напряжения не совпадает с тарифом, то нельзя ввести документ
    add ito06 2016-05-06 исправили сообщение об ошибке
    add ito06 2016-04-15 учитываем дату установки счетчика
    add ito06 2016-02-25 добавили в комментарий номер договора
    add ito06 2015-12-04 для расчета суммы потребления суббабонентов,должный учитываются счетчики, у которых дата снятия в месяце создания документа
    add ito06 2015-09-01 добавили разъяснение по т.у.
    add ito06 2015-08-05
    add ito06 2015-07-01
    ito06 2015 Разрешен ли ввод документа оплаты
*/
DECLARE 

    isMinesId    varchar = ''; 	-- номер счетчика, у ктр показания < 0
    countNotarId varchar = '';	-- номер счетчика без тарифа, но с показаниями >0
    isGolNullId  varchar = '';	-- номер счетчика  головного, у ктр у субб не введены показания (а головного есть показания) 2019-12-04
	isSubNullId  varchar = '';	-- номер счетчика  субабонента, у ктр не введены показания (а головного есть показания)	
    isMatchId    varchar = '';	-- номер счетчика  головной точки на договоре, не показания субабонента и головного
    result       varchar = ''; 

    fday_mon_docdat DATE := date_trunc('month', docdat::date);
    isMines   boolean = false; --у точки на договоре показания < 0
    isZero    boolean = true; --у всех точек на договоре показания не введены или = 0
    isSubNull boolean = false; -- у точки головной на договоре  введены показания субабонента
    isMatch   boolean = true; --сумма показаний субабонентов совпадает с параметром "потреблено субабонентами" у головного счетчика
    --
    AmoSum    NUMERIC = 0; --показания абонента 
    AmoSubSum NUMERIC = 0; --показания субабонентов у головного
    --
    SubSum    NUMERIC = 0.0000; --показания субабонента
    AllSubSum NUMERIC = 0; --показания всех субабонентов для головного
    subCount      int = 0; --количество субабонентов	
    tar           int = 0 ; --id тарифа
    countNotar    int = 0;  --количество точек без тарифа,но с показаниями >0
    --
    recApn record;
    recSub record;
    -- 2015-12-04 
    this_month_first_day DATE := (SELECT (date_trunc('month', docdat))::DATE limit 1); 
    -- 2016-02-25 
    _docnum       varchar := (SELECT docnumber FROM agreement where rowid = amnid limit 1);
    -- 2016-06-17
    isTarMatch    boolean = true; -- уровень напряжения совпадает с тарифом
    isTarMatchS   boolean = true; -- уровень напряжения совпадает с тарифом для субабонента
    isTarMatchId  varchar = '';   -- номер счетчика, у которого уровень напряжения не совпадает с тарифом
    isTarMatchIdS varchar = '';   -- номер счетчика субб, у которого уровень напряжения не совпадает с тарифом
	
	-- ito06 2019-12-05 добавили номер и л.с. головного абонента
    _tar              int = 0 ;
    _powlev           int = 0;   
	_dbase varchar := (SELECT * from current_database()); -- 2019-11-18 в какой базе
	_isUni varchar :=(select hostname from bee_closed_info where hostname = 'localhost'); -- 2019-11-18 находимся ли в базе централизованных
	_isSub boolean = true;
	_isActive boolean = true; -- ito06 2019-12-02
	_ardid int;
	
BEGIN	
	
    --цикл по не снятым счетчикам договора, у ктр введен "уровень напряжения" + учитываем дату установки счетчика
    --add ito06 2016-04-15 For recApn IN (select rowid from bee_get_agreepoint_counters(amnid, docdat)) 	
    For recApn IN (
       select apnc.rowid --	agreepoint(linkid,devid,account,prodnumber,devtype,rowid,deleted,lid,plevel)
       from bee_get_agreepoint_counters(amnid, docdat) AS apnc
       join agreeregdev AS ard ON 
            ard.linkid = apnc.rowid AND 
            ard.paramid = 154 and -- дата установки* 
            ( is_date(ard.paramval) and 
              ard.paramval::date <= docdat OR NOT is_date(ard.paramval)
            )
    ) LOOP --0
	
	--** ito06 2019-12-02 Проверяем с какого момента проверяемая точка попала в цент/смеш в договор, на ктр создается документ
	if (_dbase = 'beeX' AND _isUni IS NOT NULL) -- в базе централизованных
	  then  
	      select ard.rowid from agreeregdev_period  AS ard  
		    join agreement as amn on amn.docnumber = ard.paramval AND amn.rowid = amnid
		   where ard.paramid = 1535 AND ard.period <= docdat AND ard.linkid = recApn.rowid order by ard.period desc limit 1 INTO _ardid;
	      
		  IF ( _ardid IS NOT NULL)
		  then 	   
		  		_isActive  = true; -- до даты создания документа
		  else  _isActive = false; -- после даты создания документа
		  end if;
	end if;
		
	if (_dbase = 'beeX' AND _isUni IS NULL) -- в базе смешанных
	  then select ard.rowid from agreeregdev_period AS ard  
             join agreement as amn on amn.docnumber = ard.paramval AND amn.rowid = amnid
	        where ard.paramid = 1614 AND ard.period <= docdat  AND ard.linkid = recApn.rowid order by ard.period desc limit 1 INTO _ardid;
	     if ( _ardid IS NOT NULL)
			 then _isActive  = true; -- до даты создания документа
		  else  _isActive = false; -- после даты создания документа
		  end if;
	end if;
	--** 
	
	IF _isActive  -- 1 ito06 2019-12-02
	THEN -- 1
      subCount  = 0;
      AllSubSum = 0;
 
      SELECT 	
       SUM(CASE WHEN paramid = 850 -- потреблено без субабонентов
                THEN valman::numeric
                ELSE 0
                END),
        SUM(CASE WHEN paramid = 849 --  потреблено субабонентами 
                THEN valman::numeric
                ELSE 0
                END)    
		INTO AmoSum, AmoSubSum
		FROM regdevoper 
		WHERE 
		   linkid = recApn.rowid and 
		   paramid IN (849,850)  AND 
		   operdate between fday_mon_docdat and docdat;	

		AmoSum    := COALESCE(AmoSum,0);
		AmoSubSum := COALESCE(AmoSubSum,0);
    
     IF AmoSum > 0 THEN isZero = false;  END IF;		
   	 IF AmoSum < 0 -- 2
        THEN isMines = true;  -- 2
        isMinesId  =  (
            SELECT 'СЧ='|| prodnumber || ',ЛС='||account||';' 
            FROM agreepoint 
            where rowid  = recApn.rowid
        ) || isMinesId;
   	 END IF; -- 2 

		SELECT rowid 
		FROM agreepoint_tarif 
		WHERE pointid = recApn.rowid and 
		period <= docdat LIMIT 1 
		INTO tar;

		IF NOT isZero AND tar IS NULL THEN --3
		   countNotar = countNotar + 1; 
		   countNotarId  =  (
				SELECT 'СЧ='|| prodnumber || ', ЛС='||account||',ID=' || recApn.rowid || ';'
				FROM agreepoint 
				where rowid  = recApn.rowid
		   ) || countNotarId;

		END IF;	--3

    IF (AmoSum > 0) THEN -- 4 проверяем только тех головных, у которых введены показания! 2015-08-05           
        -- цикл по субабонентам т.у.
	
    FOR recSub --5
	  IN (SELECT a.linkid 
	 FROM 
	    ( SELECT ardp.linkid, ardp.paramval, ardp.period 
	      FROM agreeregdev_period AS ardp
	      JOIN 
	         (
	           SELECT linkid, max(a1.period) as period1
	           FROM (SELECT * FROM agreeregdev_period AS ardp
		         WHERE paramid = 664  -- счётчик головного абонента 
		         AND ardp.period <= docdat 
		   ) AS a1 GROUP BY  linkid
	         ) AS a2 ON ardp.linkid= a2.linkid AND ardp.period= a2.period1
	       WHERE ardp.paramval ~  E'^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$'
	         AND ardp.paramid = 664 --  счётчик головного абонента
	     ) AS a 
	 LEFT JOIN agreeregdev  AS ard ON 
	      ard.linkid = a.linkid  AND -- дата снятия (замены) счетчика
	      (ard.paramid = 690 and ard.paramval not like '___-__-__')
	 WHERE 
	    a.paramval::numeric = recApn.rowid AND 
	    ( length(ard.paramval)< 2 or 
	      ard.paramval IS null or 
	      ard.paramval::date > this_month_first_day
	    )
	     AND NOT bee_is_agreepoint_restrict(a.linkid,docdat::varchar) --2015-07-01
   ) LOOP --5
   
    --** ito06 2019-11-18 проверяем с какого момента субб попал в центрилизованный/смешаный
		
	if (_dbase = 'beeX' AND _isUni IS NOT NULL) -- в базе централизованных
	   then  --6
	    IF ((select rowid from agreeregdev_period where paramid = 1535 AND period <= docdat AND linkid =  recSub.linkid order by period desc limit 1) IS NOT NULL)
		  then 	 --7  
		  		_isSub  = true; -- до даты создания документа
		  else  _isSub = false; -- после даты создания документа
		  end if;	--7
    end if;--6
		
	if (_dbase = 'beeX' AND _isUni IS NULL) -- в базе смешанных
	 then --8
		 if ((select rowid from agreeregdev_period  where paramid = 1618 AND period <= docdat  AND linkid =  recSub.linkid order by period desc limit 1) IS NOT NULL)
			 then --9
			    _isSub  = true; -- до даты создания документа
		  else  _isSub = false; -- после даты создания документа
		  end if; --9
	end if; --8
	
	--**
   if  (_isSub) -- 10  субб учавствует в расчете
     then --10  
		subCount = subCount + 1;
		SELECT SUM(rdo.valman::numeric) INTO SubSum
			   FROM agreepoint AS apn
		LEFT JOIN regdevoper AS rdo ON 
			  apn.rowid  = rdo.linkid  
			  AND rdo.paramid = 407  -- отчетное количество эл. эн. 
			  AND rdo.valman ~ E'^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$' 
			  AND (rdo.operdate BETWEEN fday_mon_docdat AND docdat) 
		WHERE apn.rowid = recSub.linkid ; 

		IF SubSum IS NULL THEN --11
		   isSubNull = true;
		   isSubNullId = ( SELECT 'СЧ='|| prodnumber || ',ЛС=' || account || ';' FROM agreepoint where rowid = recSub.linkid limit 1) 
						|| coalesce(isSubNullId,'')   ; 
		   isSubNullId = coalesce(isSubNullId,'') ;
		   
		   isGolNullId = (
             SELECT 'СЧ='|| prodnumber || ', ЛС='||account||';' 
             FROM agreepoint 
             where rowid  = recApn.rowid
         ) || isGolNullId ;
		ELSE  --11
		   AllSubSum = AllSubSum + coalesce(SubSum,0.0000); 
		END IF; --11

		SELECT paramval::int 
		FROM agreeregdev_period 
		where 
		   linkid = recSub.linkid AND 
		   paramid = 439 -- уровень напряжения*
		   order by period desc limit 1 
		   INTO _powlev;

		SELECT voltage_level::int 
		FROM agreepoint_tarif AS apnt 
			  JOIN dic_tarif_group AS dtg On dtg.rowid  = apnt.tarifid 
			  where 
				 pointid = recSub.linkid 
			  order by period desc limit 1 
			  INTO _tar;

		IF _powlev <> _tar THEN	--12	   
			isTarMatchS = false; 
			isTarMatchIdS  =  (
				 SELECT 'СЧ='|| prodnumber || ',ЛС='||account||';' 
				 FROM agreepoint where rowid  = recSub.linkid
			) || isTarMatchIdS; 
		END IF; --12
    end if; --10
	
    END LOOP; --5
    END IF; --4
   
	    
	IF subCount > 0 AND AmoSubSum != AllSubSum THEN --14
         isMatch = false;  
         isMatchId = (
             SELECT 'СЧ='|| prodnumber || ', ЛС='||account||';' 
             FROM agreepoint 
             where rowid  = recApn.rowid
         ) || isMatchId ;
    END IF; --14

    SELECT paramval::int 
    FROM agreeregdev_period 
    where linkid = recApn.rowid AND 
          paramid = 439 -- уровень напряжения* 
          order by period desc limit 1 
    INTO _powlev;

    SELECT voltage_level::int 
    FROM agreepoint_tarif AS apnt 
    JOIN dic_tarif_group AS dtg On dtg.rowid  = apnt.tarifid 
    where 
       pointid = recApn.rowid 
    order by period desc limit 1 
    INTO _tar;
    
    IF _powlev <> _tar THEN	 --15	   
        isTarMatch = false; 
        isTarMatchId = (
            SELECT 'СЧ='|| prodnumber || ',ЛС='||account||';' 
            FROM agreepoint where rowid  = recApn.rowid
        ) || isTarMatchId; 
    END IF;	--15	
	END IF; -- 1 
    END LOOP; --0

    IF isZero THEN 
                                   result = 'ZZ0. У всех неснятых точек договора ' || coalesce(_docnum::text,'?') ||' нулевой расход или не хватает обязательных параметров ("дата установки счетчика", "уровень напряжения")!'; -- 2016-02-25, 2016-05-06
    ELSE 
        IF     isMines        THEN result = result     || 'ZZ1. У точек на договоре ' ||coalesce(_docnum::text,'?') || ' есть отрицательные показания! ' || ' ' || isMinesId::text; END IF; -- 2016-02-25
        IF     countNotar > 0 THEN result = result || 'ZZ2. Отсутствует тариф на точках учета : ' || coalesce(countNotarId::text,'?') ||''; END IF; 
		--
		-- ito06 2019-12-05 добавили номер и л.с. головного абонента
        IF     isSubNull      THEN result = result || 'ZZ3. У головного абонента ('|| coalesce(isGolNullId::text,'?') ||') не введены показания для субабонентов(' || ' ' || coalesce(isSubNullId::text,'?') || ')'; END IF; 
        IF NOT isMatch        THEN result = result || 'ZZ4. У головного абонента ('|| coalesce(isMatchId::text,'?') ||') не произведен расчет субабонента!' ; END IF; 
        IF NOT isTarMatch     THEN result = result || 'ZZ5. У счетчика ('|| coalesce(isTarMatchId::text,'?') ||') уровень напряжения не совпадает с тарифом!' ; END IF; 
        IF NOT isTarMatchS    THEN result = result || 'ZZ6  У субабонента ('|| coalesce(isTarMatchIdS::text,'?') ||') уровень напряжения не совпадает с тарифом!' ; END IF; 
    END IF; 	
    
    IF result = '' THEN 
       result = 'true'; 
    END IF;
    

   RETURN result;
END;
$$;

comment on function bee_is_allow_doc_create(integer, date) is 'Используется в DocMain.java, AppUtils.java';

alter function bee_is_allow_doc_create(integer, date) owner to pgsql;

