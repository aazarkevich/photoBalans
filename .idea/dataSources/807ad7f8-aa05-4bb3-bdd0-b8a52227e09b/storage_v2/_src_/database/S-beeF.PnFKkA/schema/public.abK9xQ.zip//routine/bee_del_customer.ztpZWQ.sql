create function bee_del_customer(lid integer, abocode integer) returns integer
    language plpgsql
as
$$
/*
ito06 2012-08-27 Удаление потребителя
*/
DECLARE NR INTEGER =-1;

 BEGIN
 NR = -1; 
  DELETE FROM customer WHERE locid = lid AND abo_code = abocode  RETURNING 1 INTO NR;
 IF NR IS NOT NULL
    THEN  RETURN 1;
 ELSE RETURN -1;
 END IF;

END;
$$;

comment on function bee_del_customer(integer, integer) is 'Удаление потребителя. Используется в Customer.java, AppUtils.java';

alter function bee_del_customer(integer, integer) owner to pgsql;

