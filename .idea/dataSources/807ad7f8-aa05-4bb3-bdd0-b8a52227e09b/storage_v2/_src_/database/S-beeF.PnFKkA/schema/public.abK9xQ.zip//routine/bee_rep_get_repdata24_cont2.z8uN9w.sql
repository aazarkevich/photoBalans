create function bee_rep_get_repdata24_cont2(loc_id integer, s_date date, e_date date) returns SETOF bee_repdata24
    language sql
as
$$
/*
ito06 2012-02-10
Ведомость по объему услуг
*/
SELECT
  round(grp/10)::integer AS grp,
  'bold'::text AS row_style,
  '1900-01-01'::date AS dat,
  grp::character varying AS nn,
  grp::character varying AS nn_tmp,
  CASE
    WHEN grp = 1
      THEN 'Прочие потребители, в т.ч.'
    WHEN grp = 2
      THEN 'Бюджетные потребители, в т.ч.'
    WHEN grp = 3
      THEN 'Население ВСЕГО, в т.ч.'
  END AS name,
  null::text AS doc_name,
  null::numeric,
  null::numeric,
  null::numeric,
  null::numeric,
  CASE WHEN sum(tot_amount) <> 0
    THEN sum(tot_sum) / sum(tot_amount)
    ELSE null
  END::numeric(12,6) AS tar_m_tot,
  CASE WHEN sum(vn_amount) <> 0
    THEN sum(vn_sum) / sum(vn_amount)
    ELSE null
  END::numeric(12,6) AS tar_m_vn,
  CASE WHEN sum(sn1_amount) <> 0
    THEN sum(sn1_sum) / sum(sn1_amount)
    ELSE null
  END::numeric(12,6) AS tar_m_sn1,
  CASE WHEN sum(sn2_amount) <> 0
    THEN sum(sn2_sum) / sum(sn2_amount)
    ELSE null
  END::numeric(12,6) AS tar_m_sn2,
  CASE WHEN sum(nn_amount) <> 0
    THEN sum(nn_sum) / sum(nn_amount)
    ELSE null
  END::numeric(12,6) AS tar_m_nn,
  sum(tot_amount) AS tot_amount,
  sum(vn_amount) AS vn_amount,
  sum(sn1_amount) AS sn1_amount,
  sum(sn2_amount) AS sn2_amount,
  sum(nn_amount) AS nn_amount,
  sum(tot_sum) AS tot_sum,
  sum(vn_sum) AS vn_sum,
  sum(sn1_sum) AS sn1_sum,
  sum(sn2_sum) AS sn2_sum,
  sum(nn_sum) AS nn_sum
FROM 
  bee_rep_get_repdata24_cont1($1,$2,$3)
GROUP BY grp;
$$;

comment on function bee_rep_get_repdata24_cont2(integer, date, date) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24(int, date, date), bee_rep_get_repdata24_all(int, date, date), bee_rep_get_repdata24_all_cust(int, date, date), bee_rep_get_repdata24_cust(int, date, date)';

alter function bee_rep_get_repdata24_cont2(integer, date, date) owner to pgsql;

