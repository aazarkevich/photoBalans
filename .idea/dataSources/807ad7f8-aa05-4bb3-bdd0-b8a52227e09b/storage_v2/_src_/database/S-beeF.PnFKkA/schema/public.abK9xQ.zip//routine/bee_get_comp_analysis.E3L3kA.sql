create function bee_get_comp_analysis(_top_locid integer, _df text, _dt text) returns SETOF comp_analysis
    language plpgsql
as
$$
    /*
        add ito06 2015-06-30 
        Сравнительный анализ данных сбыта и донэнерго
    */
	--
	DECLARE
	    RowLine comp_analysis%rowtype;
		_date_from date = _df::date;
		_date_to date = _dt::date;
	---  
	BEGIN
	---  	
		FOR RowLine IN (

			SELECT
			denet.nam AS kol1, --участок
			substring(pchain from 38) AS kol2, --Схема_подключения
			---------
			CASE
			WHEN gis_traces.objtype=11 THEN family.son
			ELSE family.father
			END AS kol3, --ТП
			---------
			docnumber AS kol4, --номер_договора
			account AS kol5, --лицевой_счет
			prodnumber AS kol6, --номер_счетчика
			abo_name AS kol7, --потребитель
			a6.paramval AS kol8, --запитанный_объект
			de1.element_name AS kol9, --тип_запитанного_объекта
			a7.paramval AS kol10, --адрес_запитанного_объекта
			a9.paramval AS kol11, --район
			a10.paramval AS kol12, --город
			a11.paramval AS kol13, --район_города
			a12.paramval AS kol14, --населенный_пункт
			a13.paramval AS kol15, --улица 
			a14.paramval AS kol16, --номер_дома
			a15.paramval AS kol17, --участок_обхода
			a18.paramval AS kol18, --ФИО_контролера
			de17.element_name AS kol19, --примечание_пост

			a19.paramval AS kol20, --дата_последней_проверки
			a20.paramval AS kol21, --дата_акта_замены_ввода
			a21.paramval AS kol22, --дата_акта_замены_прибора_учета
			a22.paramval AS kol23, --дата_акта_раздела_границ
			a23.paramval AS kol24, --дата__поверки

			de24.element_name AS kol25, --форма_собственности
			a25.paramval AS kol26, --количество_проживающих
			a26.paramval AS kol27, --количество_комнат
			a27.paramval AS kol28, --площадь_жилья

			a16.paramval AS kol29, --дата_снятия_замены,
			replace(a5.paramval, ',', '.')::numeric AS kol30, --значность

			a3.operdate AS kol31, -- дата_снятия_пред_показаний_ДЭС
			a2.operdate AS kol32, --дата_снятия_тек_показаний_ДЭС
			a3.valman::numeric(8,0) AS kol33, --пред_показания_ДЭС
			a2.valman::numeric(8,0) AS kol34, --тек_показания_ДЭС,

			------------
			(CASE
			WHEN (a2.valman::numeric > a3.valman::numeric) OR (a2.valman::numeric = a3.valman::numeric)
			THEN a2.valman::numeric - a3.valman::numeric
			ELSE (a2.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
			END) ::numeric(8,0) AS kol35, --Контрольный_расчет_по_показаниям,
			------------
			a4.valman::numeric(8,0) AS kol36, --расход_по_данным_ДЭС,

			CASE
			WHEN
			((CASE
			WHEN (a2.valman::numeric > a3.valman::numeric) OR (a2.valman::numeric = a3.valman::numeric)
			THEN a2.valman::numeric - a3.valman::numeric 
			ELSE (a2.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
			END)::numeric(8,0)
			- a4.valman::numeric(8,0)) < 0

			THEN  (CASE
			WHEN (a2.valman::numeric > a3.valman::numeric) OR (a2.valman::numeric = a3.valman::numeric)
			THEN a2.valman::numeric - a3.valman::numeric 
			ELSE (a2.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
			END)::numeric(8,0)
			- a4.valman::numeric(8,0)    

			ELSE '0'   
			END AS kol37, --ошибки_ДЭС_минус
			------------

			CASE
			WHEN
			((CASE
			WHEN (a2.valman::numeric > a3.valman::numeric) OR (a2.valman::numeric = a3.valman::numeric)
			THEN a2.valman::numeric - a3.valman::numeric 
			ELSE (a2.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
			END)::numeric(8,0)
			- a4.valman::numeric(8,0)) > 0

			THEN 

			(CASE
			WHEN (a2.valman::numeric > a3.valman::numeric) OR (a2.valman::numeric = a3.valman::numeric)
			THEN a2.valman::numeric - a3.valman::numeric 
			ELSE (a2.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
			END)::numeric(8,0)
			- a4.valman::numeric(8,0) 
			ELSE '0' 
			END AS kol38, --ошибки_ДЭС_плюс
			------------
			b1.valman AS kol39, --примечание (в оперативных показаниях ДЭ)
			a0.operdate AS kol40, --дата_снятия_пред_показаний_ДЭ
			a1.operdate AS kol41, --дата_снятия_тек_показаний_ДЭ
			a0.valman::numeric(8,0) AS kol42, --пред_показания_ДЭ
			a1.valman::numeric(8,0) AS kol43, --тек_показания_ДЭ

			------------
			(CASE
			WHEN (a1.valman::numeric(8,0) > a0.valman::numeric(8,0)) OR (a1.valman::numeric(8,0) = a0.valman::numeric(8,0))
			THEN a1.valman::numeric(8,0) - a0.valman::numeric(8,0)
			ELSE (a1.valman::numeric(8,0) + 10 ^a5.paramval::numeric(8,0)) - a0.valman::numeric(8,0)
			END)::numeric(8,0) AS kol44, --разность_показаний_ДЭ

			------------
			(CASE
			WHEN (a1.valman::numeric(8,0) > a3.valman::numeric(8,0)) OR (a1.valman::numeric(8,0) = a3.valman::numeric(8,0))
			THEN a1.valman::numeric(8,0) - a3.valman::numeric(8,0) 
			ELSE (a1.valman::numeric(8,0) + 10 ^ a5.paramval::numeric(8,0)) - a3.valman::numeric(8,0)
			END)::numeric(8,0) AS kol45, --разность_тек_ДЭ_минус_пред_ДЭС

			------------
			CASE 
			WHEN a1.valman is NOT NULL 
			THEN
		                CASE
				WHEN (COALESCE((CASE
				WHEN (a1.valman::numeric > a3.valman::numeric) OR (a1.valman::numeric = a3.valman::numeric)
				THEN a1.valman::numeric - a3.valman::numeric 
				ELSE '0'--(a1.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
				END)::numeric(8,0),'0') - COALESCE(a4.valman::numeric(8,0),'0')) > 0
				THEN
				COALESCE((CASE
				WHEN (a1.valman::numeric > a3.valman::numeric) OR (a1.valman::numeric = a3.valman::numeric)
				THEN a1.valman::numeric - a3.valman::numeric 
				ELSE '0'--(a1.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
				END)::numeric(8,0),'0') - COALESCE(a4.valman::numeric(8,0),'0') 
				ELSE '0'
                                END
			ELSE '0' 
				
			END AS kol46, --довыставление_плюс

			------------
			CASE
			WHEN (COALESCE((CASE
			WHEN (a1.valman::numeric > a3.valman::numeric) OR (a1.valman::numeric = a3.valman::numeric)
			THEN a1.valman::numeric - a3.valman::numeric 
			ELSE (a1.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
			END)::numeric(8,0),'0') - COALESCE(a4.valman::numeric(8,0),'0')) < 0
			THEN
			COALESCE((CASE
			WHEN (a1.valman::numeric > a3.valman::numeric) OR (a1.valman::numeric = a3.valman::numeric)
			THEN a1.valman::numeric - a3.valman::numeric 
			ELSE (a1.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
			END)::numeric(8,0),'0') - COALESCE(a4.valman::numeric(8,0),'0') 
			ELSE '0'
			END AS kol47, --довыставление_минус

			------------
			COALESCE(a4.valman::numeric(8,0),'0')
			+ 
			CASE 
			WHEN a1.valman is NOT NULL 
			THEN
				CASE
				WHEN (COALESCE((CASE
				WHEN (a1.valman::numeric > a3.valman::numeric) OR (a1.valman::numeric = a3.valman::numeric)
				THEN a1.valman::numeric - a3.valman::numeric 
				ELSE '0'--(a1.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
				END)::numeric(8,0),'0') - COALESCE(a4.valman::numeric(8,0),'0')) > 0
				THEN
				COALESCE((CASE
				WHEN (a1.valman::numeric > a3.valman::numeric) OR (a1.valman::numeric = a3.valman::numeric)
				THEN a1.valman::numeric - a3.valman::numeric 
				ELSE '0'--(a1.valman::numeric + 10 ^ a5.paramval::numeric) - a3.valman::numeric
				END)::numeric(8,0),'0') - COALESCE(a4.valman::numeric(8,0),'0') 
				ELSE '0'
				END
		       ELSE '0'	
            END AS kol48 --всего
		
			FROM agreepoint
			JOIN agreement ON agreepoint.linkid=agreement.rowid
			JOIN customer ON agreement.abo_code = customer.abo_code
			JOIN denet ON agreement.locid=denet.rowid
			LEFT JOIN regdevconn ON agreepoint.rowid=regdevconn.pointid
			LEFT JOIN gis_traces ON regdevconn.traceid=gis_traces.rowid

			------------
			--для выбора наименования ТП, не зависимо от подключения к ТП или к отходящей линии
			LEFT JOIN (SELECT agreepoint.rowid AS r1, t1.objname AS son, t1.objcode AS son_code, t1.objowner AS son_owner_code,
			t2.objname AS father, t2.objcode AS father_code
			FROM agreepoint 
			JOIN regdevconn ON agreepoint.rowid=regdevconn.pointid 
			JOIN gis_traces t1 ON regdevconn.traceid=t1.rowid 
			LEFT JOIN gis_traces t2 ON t2.objcode=t1.objowner 
			JOIN gis_traces_tmp ON t2.objcode=gis_traces_tmp.objcode and t2.objowner=gis_traces_tmp.objowner
			GROUP BY agreepoint.rowid, t1.objname, t1.objcode, t1.objowner, t2.objname, t2.objcode
			) AS family ON regdevconn.pointid=family.r1 

			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 168 
			      and position('''' in paramval) = 0 and  paramval != '-' AND paramval != '?') as a5 ON agreepoint.rowid=a5.linkid --значность
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 418) as a6 ON agreepoint.rowid=a6.linkid --запитанный объект
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 410) as a7 ON agreepoint.rowid=a7.linkid --адрес запитанного объекта
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 715) as a8 ON agreepoint.rowid=a8.linkid --тип запитанного объекта
			LEFT JOIN dic_elements de1 ON a8.paramval=de1.rowid::text and position('''' in a8.paramval) = 0--тип запитанного объекта
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 719) as a9 ON agreepoint.rowid=a9.linkid --район
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 720) as a10 ON agreepoint.rowid=a10.linkid --город
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 641) as a11 ON agreepoint.rowid=a11.linkid --район города
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 723) as a12 ON agreepoint.rowid=a12.linkid --населенный пункт
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 642) as a13 ON agreepoint.rowid=a13.linkid --улица
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 640) as a14 ON agreepoint.rowid=a14.linkid --номер дома
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 851) as a15 ON agreepoint.rowid=a15.linkid --участок обхода
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 690) as a16 ON agreepoint.rowid=a16.linkid --дата снятия счетчика 
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1015) as a17 ON agreepoint.rowid=a17.linkid --примечание (пост)
			LEFT JOIN dic_elements de17 ON a17.paramval=de17.rowid::text and position('''' in a17.paramval) = 0--примечание (пост)
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1016) as a18 ON agreepoint.rowid=a18.linkid --онтролер (ФИО)
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 824) as a19 ON agreepoint.rowid=a19.linkid --дата последней поверки
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1443) as a20 ON agreepoint.rowid=a20.linkid --дата ак замены ввода
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1444) as a21 ON agreepoint.rowid=a21.linkid --дата акта замены прибора учета
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1445) as a22 ON agreepoint.rowid=a22.linkid --дата акта раздела границ
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 155) as a23 ON agreepoint.rowid=a23.linkid --дата последней поверки
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 716 
			     AND position('''' in paramval) = 0 and  paramval != '?' AND paramval != '-') as a24 ON agreepoint.rowid=a24.linkid --форма собственности
			LEFT JOIN dic_elements de24 ON a24.paramval=de24.rowid::text  and position('''' in a24.paramval) = 0--форма собственности
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1410) as a25 ON agreepoint.rowid=a25.linkid --количество проживающих
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 1449) as a26 ON agreepoint.rowid=a26.linkid --количество комнат
			LEFT JOIN (SELECT * FROM agreeregdev WHERE paramid = 717) as a27 ON agreepoint.rowid=a27.linkid --площадь жилья

			--для выбора текущих показаний Донэнерго на максимальную дату в месяце формирования отчета
			LEFT JOIN (SELECT r1.linkid, r1.valman, r1.operdate FROM regdevoper AS r1 
			JOIN (SELECT MAX(operdate) AS operdate, linkid FROM regdevoper WHERE operdate BETWEEN _date_from AND _date_to GROUP BY linkid)
			AS r2 ON r1.linkid=r2.linkid AND r1.paramid=195
			     AND   position('''' in valman) = 0 and r1.valman != '-' AND r1.valman != '?' AND r1.operdate=r2.operdate
			) AS a1 ON agreepoint.rowid=a1.linkid

			--для выбора текущих показаний Донэнерго на максимальную дату, но не больше 1-го числа месяца формирования отчета
			--т.е. фактически это предыдущие показания, но могут не совпадать с предыдущими показаниями, если показания в одном месяце снимались дважды
			LEFT JOIN (SELECT r1.linkid, r1.valman, r1.operdate FROM regdevoper AS r1 
			JOIN (SELECT MAX(operdate) AS operdate, linkid FROM regdevoper WHERE operdate < _date_from GROUP BY linkid)
			AS r2 ON r1.linkid=r2.linkid AND r1.paramid=195 
			      and position('''' in valman) = 0  and r1.valman != '-' AND r1.valman != '?' AND r1.operdate=r2.operdate
			) AS a0 ON agreepoint.rowid = a0.linkid 

			--примечание из оперативных показаний ДЭ
			LEFT JOIN (SELECT * FROM regdevoper WHERE paramid = 1005 
			     AND position('''' in valman) = 0 and valman != '-' AND valman != '?' AND operdate BETWEEN _date_from AND _date_to) 
			AS b1 ON a1.linkid=b1.linkid AND a1.operdate=b1.operdate

			--для выбора текущих показаний ДЭС на максимальную дату в месяце формирования отчета
			LEFT JOIN (SELECT r975_1.linkid, r975_1.valman, r975_1.operdate FROM regdevoper975 r975_1 
			JOIN (SELECT MAX(operdate) AS operdate, linkid FROM regdevoper975 WHERE operdate BETWEEN _date_from AND _date_to GROUP BY linkid) 
			AS r975_2 ON r975_1.linkid=r975_2.linkid AND r975_1.paramid=195 
			      and position('''' in valman) = 0 and    r975_1.valman != '-' AND r975_1.valman != '?' AND r975_1.operdate=r975_2.operdate 
			ORDER BY linkid  
			) AS a2 ON agreepoint.rowid=a2.linkid

			--для выбора текущих показаний ДЭС на максимальную дату, но не больше 1-го числа месяца формирования отчета
			--т.е. фактически это предыдущие показания, но могут не совпадать с предыдущими показаниями, если показания в одном месяце снимались дважды
			LEFT JOIN (SELECT r975_1.linkid, r975_1.valman, r975_1.operdate FROM regdevoper975 r975_1 
			JOIN (SELECT MAX(operdate) AS operdate, linkid FROM regdevoper975 WHERE operdate < _date_from GROUP BY linkid) 
			AS r975_2 ON r975_1.linkid=r975_2.linkid AND r975_1.paramid=195 
			      and position('''' in valman) = 0 and   r975_1.valman != '-' AND r975_1.valman != '?' AND r975_1.operdate=r975_2.operdate 
			ORDER BY linkid             
			) AS a3 ON agreepoint.rowid=a3.linkid 
			--расход по данным ДЭС
			LEFT JOIN (SELECT linkid, SUM(valman::numeric(8,0)) AS valman FROM regdevoper975 
			WHERE paramid = 985
			    AND position('''' in valman) = 0 and  valman != '-' AND valman != '?' AND operdate BETWEEN _date_from AND _date_to
			GROUP BY linkid) 
			AS a4 ON agreepoint.rowid=a4.linkid 
			--заменить на код выбранного участка, если выбран МЭС или РЭС, то перечислять все подчиненные участки
			WHERE
			agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%')) 
			AND (agreement.docstatus=79 OR agreement.docstatus=77  AND agreement.closedate >= _date_from) --2015-06-30			
			ORDER BY nam, docnumber, account, prodnumber
			
	    )
	    LOOP
	       RETURN NEXT RowLine;
	    END LOOP;
	    RETURN;
	    
	END;

$$;

comment on function bee_get_comp_analysis(integer, text, text) is 'Используется в CompAnalysis.java, SessionBean1.java';

alter function bee_get_comp_analysis(integer, text, text) owner to pgsql;

