create function bee_get_last_transformer(_pointid integer, _type integer, _phase integer) returns integer
    language plpgsql
as
$$
/*	
	ito06 2020-04-27 Получить трансформатор ТТ/ТН последний введенный для указанной фазы
	_phase = -1 (фаза не выбрана) _phase = 0 (фаза А); _phase = 1  (фаза B); _phase = 2 (фаза C) Выводит параметры ТТ/ТН для указанной фазы.
	_type = 56 ТТ; _type = 61 ТН
*/
DECLARE
	_param int :=0;
	_elem_code int :=0;
	res int :=0;
BEGIN
	IF _phase = 0  
	   THEN _elem_code = 501;
	   ELSE IF _phase = 1  
	             THEN _elem_code = 502;
				 ELSE IF _phase = 2  THEN _elem_code = 503;
                      END IF;
            END IF;
    END IF;
	select rowid from dic_elements where link = _type AND element_code =_elem_code INTO _param;
	_param = coalesce(_param, 0);
	   
	select rowid from agreeregdev_period where linkid = _pointid and paramid  = _param order by period desc limit 1 INTO res;
	res = coalesce(res, 0);

	RETURN res;
END;
$$;

comment on function bee_get_last_transformer(integer, integer, integer) is 'Получить трансформатор ТТ/ТН последний введенный для указанной фазы. Используется в DevParamTT.java, DevParamTN.java, AppUtils.java';

alter function bee_get_last_transformer(integer, integer, integer) owner to pgsql;

