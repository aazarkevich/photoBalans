create function bee_rep_get_branches_structure() returns SETOF denet
    language plpgsql
as
$$
/*
	ito06 2015-03-03
	Получить список участков для филиала
*/
DECLARE

BEGIN RETURN QUERY (
	SELECT distinct de.* 
          FROM (SELECT de.kod FROM customer AS cust join denet AS de ON de.rowid = cust.locid GROUP BY kod) AS cust 
          JOIN denet AS de ON cust.kod like de.kod||'%' 
         WHERE char_length(cust.kod) > 6 AND char_length(de.kod) > 6 ORDER BY de.kod);
END;
$$;

comment on function bee_rep_get_branches_structure() is 'Получить список участков для филиала. Используется в BranchesStructure.java';

alter function bee_rep_get_branches_structure() owner to pgsql;

