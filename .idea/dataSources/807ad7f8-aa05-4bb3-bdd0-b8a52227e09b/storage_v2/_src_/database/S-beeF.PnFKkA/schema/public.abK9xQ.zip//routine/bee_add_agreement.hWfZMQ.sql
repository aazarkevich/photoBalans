create function bee_add_agreement(lid integer, tag boolean, docstat integer, docnum character varying, docdat character varying, accd integer, aboco integer, closedat character varying, doctyp integer, rsklossid integer) returns integer
    language plpgsql
as
$$
/*
  add ito07 181102
*/
DECLARE
   rid int     := -1;
   tmp int     := -1;
   val varchar := '-';
   abovi INT  := -1; 
BEGIN
    SELECT abo_vid from customer where abo_code = aboco limit 1 into abovi;
    INSERT INTO agreement
    (locid,valid, docstatus, docnumber, docdate,      abo_code, accdir, closedate,      doctype, abo_vid ) VALUES
    (lid,  tag,   docstat,   docnum,    docdat::date, aboco,    accd,   closedat::date, doctyp,  abovi  ) RETURNING rowid INTO rid ;
    IF rid IS NULL 
       THEN rid := -2;
    ELSE
       if rsklossid = 1914 then
          val = 'Нет';
       else 
          val = 'Да'; 
       end if;

       select bee_add_agreement_info(rid,rsklossid,val,docdat) into tmp ;

    END IF;

    RETURN rid;

END;
$$;

comment on function bee_add_agreement(integer, boolean, integer, varchar, varchar, integer, integer, varchar, integer, integer) is 'Добавление нового договора. Используется CustomerForm.java, AppUtils.java';

alter function bee_add_agreement(integer, boolean, integer, varchar, varchar, integer, integer, varchar, integer, integer) owner to pgsql;

