create function bee_repagreementlist_get_content(locid integer, filter_add text) returns SETOF bee_repagreementlist
    language plpgsql
as
$$
/*
	add ito06 2014-12-04
	add ito06 2012-12-18
	add ito06 2012-05-23
	ito06 2011-11-25 Список договоров
*/

DECLARE 
	RowLine bee_repagreementlist%RowType;	
BEGIN

RETURN QUERY EXECUTE'
SELECT 
	kol1,
	kol2,
	kol3,
	kol4,
	kol5,
	kol6,
	kol7,
	kol8,
	kol9,
	kol10,
	kol11,
	kol12,
	kol13,
	kol14,
	kol15,
	kol16,
	kol17,
	kol18,
	kol19,
	kol20,
	kol21,
	kol22,
	kol23,
	count(kol24) AS kol24
FROM
	(SELECT
		denet.nam									AS kol1,  --участок
		customer.consum_name								AS kol2,  -- потребитель,
		customer.consum_inn								AS kol3,  -- ИНН,
		c1.item										AS kol4,  --КПП,
		agreement.docnumber								AS kol5,  -- договор,
		agreement.docdate								AS kol6,  -- дата,
		dic_elements.element_name 							AS kol7,  -- направл_учета,
		d1[1]										AS kol8,  -- банк,
		d1[2]										AS kol9,  -- бик,
		d1[3]										AS kol10,  -- корр_счет,
		d1[4]										AS kol11, --  город_банка,
		d1[5]										AS kol12, --  расчетный_счет, 
		
		case
		   when a.item <> '||quote_literal(0)||'  and a.item <> '||quote_literal('?')||'  and a.item is not null
		     then a.item || '||quote_literal(', ')||' 
		   else '||quote_literal(' ')||'
		end ||
		case
		   when a0.item <> '||quote_literal(0)||'  and a0.item <> '||quote_literal('?')||'  and a0.item is not null
		     then a0.item || '||quote_literal(', ')||' 
		   else '||quote_literal(' ')||'
		end ||
		case
		   when a1.item <> '||quote_literal(0)||'  and a1.item <> '||quote_literal('?')||'  and a1.item is not null
		     then a1.item || '||quote_literal(', ')||' 
		   else '||quote_literal(' ')||' 
		end ||
		case 
		   when a2.item <> '||quote_literal(0)||'  and a2.item <> '||quote_literal('?')||'  and a2.item is not null 
		     then a2.item || '||quote_literal(', ')||' 
		   else '||quote_literal(' ')||' end ||
		case 
		   when a3.item <> '||quote_literal(0)||'  and a3.item <> '||quote_literal('?')||'  and a3.item is not null 
		     then a3.item
		   else '||quote_literal(' ')||' end ||
		case 
		   when a4.item <> '||quote_literal(0)||'  and a4.item <> '||quote_literal('?')||'  and a4.item is not null 
		     then '||quote_literal('/')||'  || a4.item
		   else '||quote_literal(' ')||' end ||
		case 
		   when a5.item <> '||quote_literal(0)||'  and a5.item <> '||quote_literal('?')||'  and a5.item is not null and a5.item <> '||quote_literal(' ')||' 
		     then '||quote_literal(', кв. ')||' || a5.item
		  else '||quote_literal(' ')||' 
		end											AS kol13, -- юр_адрес, 

		case 
		   when fa.item <> '||quote_literal(0)||'  and fa.item <> '||quote_literal('?')||'  and fa.item is not null 
		     then fa.item || '||quote_literal(', ')||' 
		   else '||quote_literal(' ')||' 
		end ||
		case 
		   when fa0.item <> '||quote_literal(0)||'  and fa0.item <> '||quote_literal('?')||'  and fa0.item is not null
		     then fa0.item || '||quote_literal(', ')||' 
		   else '||quote_literal(' ')||' 
		end ||
		case 
		   when fa1.item <> '||quote_literal(0)||'  and fa1.item <> '||quote_literal('?')||'  and fa1.item is not null
		     then fa1.item || '||quote_literal(', ')||'  
		   else '||quote_literal(' ')||' 
		end ||
		case 
		   when fa2.item <> '||quote_literal(0)||'  and fa2.item <> '||quote_literal('?')||'  and fa2.item is not null
		     then fa2.item || '||quote_literal(', ')||' 
		   else '||quote_literal(' ')||'
		end ||
		case 
		   when fa3.item <> '||quote_literal(0)||'  and fa3.item <> '||quote_literal('?')||'  and fa3.item is not null
		     then fa3.item
		   else '||quote_literal(' ')||'
		end ||
		case
		   when fa4.item <> '||quote_literal(0)||'  and fa4.item <> '||quote_literal('?')||'  and fa4.item is not null
		   then '||quote_literal('/')||'  || fa4.item
		   else '||quote_literal(' ' )||' 
		end ||
		case 
		   when fa5.item <> '||quote_literal(0)||'  and fa5.item <> '||quote_literal('?')||'  and fa5.item is not null and fa5.item <> '||quote_literal(' ')||'
		   then '||quote_literal(', кв.' )||'|| fa5.item  else '||quote_literal(' ')||'
		end											AS kol14, -- факт_адрес, 

		c3.item											AS kol15, --фио_руководителя, 
		c9.item											AS kol16, --фио гл. бухгалтера
		c10.item										AS kol17, --фио ответсвенного лица потребителя  
		c2.item											AS kol18, --телефон, 
		c4.paramval										AS kol19, --фио_договорника, 
		c8.paramval										AS kol20, --фио_расчетчика, 
		c5.item											AS kol21, --ОГРН,
		c6.item											AS kol22, --ОКПО,
		c7.item											AS kol23, --ОКВЭД
		agreepoint.linkid									AS kol24  -- кол-во точек учета
	   FROM agreement
	   JOIN denet ON agreement.locid=denet.rowid
      LEFT JOIN agreepoint ON agreement.rowid=agreepoint.linkid AND agreepoint.devtype=644
      LEFT JOIN agreeregdev  AS ard2 ON ard2.linkid=agreepoint.rowid AND ard2.paramid=690 
      LEFT JOIN bee_repagreementlist_get_bank_params(agreement.abo_code) AS d1 ON  d1 IS NOT NULL
           JOIN customer ON agreement.abo_code = customer.abo_code
           JOIN dic_elements on agreement.accdir=dic_elements.rowid

      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 84) AS c1 ON customer.abo_code = c1.abo
      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 85) AS c2 ON customer.abo_code = c2.abo
      LEFT JOIN (select item, abo from customer_info where elrowid = 647) as a on customer.abo_code=a.abo   
      LEFT JOIN (select item, abo from customer_info where elrowid = 377) as a0 on customer.abo_code=a0.abo 
      LEFT JOIN (select item, abo from customer_info where elrowid = 358) as a1 on customer.abo_code=a1.abo 
      LEFT JOIN (select item, abo from customer_info where elrowid = 361) as a2 on customer.abo_code=a2.abo 
      LEFT JOIN (select item, abo from customer_info where elrowid = 362) as a3 on customer.abo_code=a3.abo 
      LEFT JOIN (select item, abo from customer_info where elrowid = 363) as a4 on customer.abo_code=a4.abo 
      LEFT JOIN (select item, abo from customer_info where elrowid = 364) as a5 on customer.abo_code=a5.abo 
      
      LEFT JOIN (select item, abo from customer_info where elrowid = 648) as fa on customer.abo_code=fa.abo   
      LEFT JOIN (select item, abo from customer_info where elrowid = 379) as fa0 on customer.abo_code=fa0.abo 
      LEFT JOIN (select item, abo from customer_info where elrowid = 365) as fa1 on customer.abo_code=fa1.abo 
      LEFT JOIN (select item, abo from customer_info where elrowid = 366) as fa2 on customer.abo_code=fa2.abo 
      LEFT JOIN (select item, abo from customer_info where elrowid = 367) as fa3 on customer.abo_code=fa3.abo 
      LEFT JOIN (select item, abo from customer_info where elrowid = 368) as fa4 on customer.abo_code=fa4.abo
      LEFT JOIN (select item, abo from customer_info where elrowid = 369) as fa5 on customer.abo_code=fa5.abo 

      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 83) AS c3 ON customer.abo_code = c3.abo
      LEFT JOIN (SELECT agreement_info.linkid, agreement_info.paramval 
                   FROM agreement_info 
                   JOIN (SELECT linkid, MAX(period) as period FROM agreement_info GROUP BY linkid) AS ai 
                        ON agreement_info.linkid=ai.linkid AND agreement_info.period=ai.period
                  WHERE agreement_info.paramid = 1149) AS c4 ON agreement.rowid = c4.linkid

      LEFT JOIN (SELECT agreement_info.linkid, agreement_info.paramval 
                   FROM agreement_info 
                   JOIN (SELECT linkid, MAX(period) as period FROM agreement_info GROUP BY linkid) AS ai 
                             ON agreement_info.linkid=ai.linkid  AND agreement_info.period=ai.period
                          WHERE agreement_info.paramid = 1150
                 ) AS c8 ON agreement.rowid = c8.linkid
      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 1028) AS c5 ON customer.abo_code = c5.abo
      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 1029) AS c6 ON customer.abo_code = c6.abo
      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 1030) AS c7 ON customer.abo_code = c7.abo
      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 1470) AS c9 ON customer.abo_code = c9.abo
      LEFT JOIN (SELECT * FROM customer_info WHERE elrowid = 1144) AS c10 ON customer.abo_code = c10.abo
     WHERE agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = '||$1||'))   
       
        '||$2||'
     ) AS tab

GROUP BY kol1, kol2, kol3, kol4, kol5, kol6, kol7, kol8, kol9, kol10, kol11, kol12, kol13, kol14, kol15, kol16, kol17, kol18, kol19, kol20, kol21, kol22, kol23
ORDER BY kol1, kol5';

END;

$$;

comment on function bee_repagreementlist_get_content(integer, text) is 'Список договоров. Используется в RepAgreementList.java, SessionBean1.java';

alter function bee_repagreementlist_get_content(integer, text) owner to postgres;

