create function bee_get_locname(locid integer) returns character varying
    language sql
as
$$
SELECT nam FROM denet WHERE rowid = $1;
$$;

comment on function bee_get_locname(integer) is 'Используется в DeviceEdit.java, RepAkt5.java, AppUtils.java';

alter function bee_get_locname(integer) owner to pgsql;

