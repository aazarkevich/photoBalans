create view bee_tarif_not_linked(agrnum, agrtyp, pronum, pntid) as
SELECT DISTINCT agr.docnumber  AS agrnum,
                agr.doctype    AS agrtyp,
                pnt.prodnumber AS pronum,
                pnt.rowid      AS pntid
FROM ((((agreement agr
    JOIN agreepoint pnt ON (((agr.rowid = pnt.linkid) AND (agr.docstatus = 79))))
    JOIN agreeregdev par ON (((pnt.rowid = par.linkid) AND (par.paramid = 690) AND
                              ((par.paramval)::text !~~ '____-__-__'::text))))
    JOIN agreeregdev_period apr ON (((pnt.rowid = apr.linkid) AND (apr.paramid = 1535))))
         JOIN agreepoint_tarif atr ON ((NOT (EXISTS(SELECT 1
                                                    FROM agreepoint_tarif
                                                    WHERE (agreepoint_tarif.pointid = pnt.rowid))))))
WHERE ((current_database() <> 'beeF'::name) AND (agr.docstatus = 79) AND (agr.doctype = ANY (ARRAY [1614, 1910, 1911])))
ORDER BY agr.docnumber, pnt.prodnumber, agr.doctype;

alter table bee_tarif_not_linked
    owner to postgres;

