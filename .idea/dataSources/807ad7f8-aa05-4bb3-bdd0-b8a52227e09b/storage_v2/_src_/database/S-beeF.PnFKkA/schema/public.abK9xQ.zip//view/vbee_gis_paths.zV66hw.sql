create view vbee_gis_paths(locid, rowid, path, objname) as
SELECT gis_traces.locid,
       gis_traces.rowid,
       "substring"(gis_traces.pchain,
                   strpos(gis_traces.pchain, (string_to_array(gis_traces.pchain, '+'::text))[4])) AS path,
       gis_traces.objname
FROM gis_traces
WHERE (gis_traces.objtype = 11)
ORDER BY gis_traces.pchain;

comment on view vbee_gis_paths is 'Используется в LossDistr.java, SessionBean1.java';

alter table vbee_gis_paths
    owner to pgsql;

