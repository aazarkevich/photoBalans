create view v1(account, ls) as
SELECT t2.account,
       tm.ls
FROM ((agreepoint t2
    LEFT JOIN mar22d tm ON ((regexp_replace(tm.ls, '[^0-9]'::text, ''::text, 'g'::text) = (t2.account)::text)))
         LEFT JOIN agreeregdev t8 ON ((t2.rowid = t8.linkid)))
WHERE ((((t8.paramval)::text <> ''::text) IS NOT TRUE) OR
       ((char_length((t8.paramval)::text) < 4) AND (t8.paramid = 690)))
ORDER BY tm.ls;

alter table v1
    owner to postgres;

