create function bee_get_device_reading_history_head(pointid integer) returns SETOF device_reading_history_head
    language sql
as
$$
/*
	add io06 2014-12-02
	ito06 2013-11-28: История на договор шапка
*/

	SELECT  amn.rowid AS agreeid,
		amn.docnumber AS docNumber,        
		cust.consum_name AS consumName,
		apn.rowid AS pointid,
		apn.account AS account,
		apn.prodnumber AS prodNumber,
		amn.locid AS locid, --apn.lid 2014-12-02
		ard.paramval AS prodObject,
		current_database()::varchar AS base 
	 
	  FROM agreepoint  AS apn
	  JOIN agreement AS amn ON amn.rowid = apn.linkid
	  JOIN customer AS cust ON cust.abo_code  = amn.abo_code
     LEFT JOIN agreeregdev AS ard ON ard.linkid = apn.rowid AND ard.paramid = 418
     WHERE apn.rowid = $1;
$$;

comment on function bee_get_device_reading_history_head(integer) is 'История на договор шапка. Используется в RepAktHistory.java';

alter function bee_get_device_reading_history_head(integer) owner to bee;

