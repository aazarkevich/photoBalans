create function bee_rep_get_rephead_bee(loc integer, str_d date, end_d date) returns bee_rephead
    language sql
as
$$
/*
ito06 2011-11-10
Реестр банковских документов
*/
SELECT 		
  CASE 
    WHEN $1 = mes.rowid
      THEN mes.nam
      ELSE mes.nam || ' ' || res.nam
  END AS fil_name,
  TO_CHAR($2,'DD.MM.YYYY') AS s_dat,
  TO_CHAR($3,'DD.MM.YYYY') AS e_dat	
FROM
  denet AS res
  JOIN denet AS mes ON mes.kod = substring(res.kod from 1 for 6)
WHERE
  res.rowid = $1
$$;

comment on function bee_rep_get_rephead_bee(integer, date, date) is 'Используется в RepAdvList.java, RepAdvList2.java, RepInvList.java, RepOrdList.java, RepOrdList2.java, RepReestExpense.java';

alter function bee_rep_get_rephead_bee(integer, date, date) owner to pgsql;

