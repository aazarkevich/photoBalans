create function bee_repakt4_get_tot2(bd_rowid integer) returns SETOF bee_repakt4_tot_tab1
    language plpgsql
as
$$
/*
	add ito06 2014-11-26
	Акт (передача)
*/
DECLARE newform numeric = 0;
	rec record;
BEGIN 
	SELECT sum(sum_with_tax) FROM bee_docs_result where linkid =$1 INTO newform;	
	IF (newform  = 0 ) 
	   THEN FOR rec IN (SELECT null::numeric   										AS vn_tot_sum, 
				   null::numeric 										AS sn1_tot_sum, 
				   null::numeric   										AS sn2_tot_sum,
				   null::numeric   										AS nn_tot_sum,
				   (select sum (a) from unnest (ARRAY[cont.tot_sum_fsk, cont.tot_sum_rsk]) AS a)  		AS tot_sum,
				   null::numeric   										AS itog_sum_vn,
				   null::numeric   										AS itog_sum_sn1,
				   null::numeric   										AS itog_sum_sn2,
				   null::numeric   										AS itog_sum_nn,
				   (select sum (a) from unnest (ARRAY[vn.vn[1],sn1.sn1[1],sn2.sn2[1],nn.nn[1],
								-cont.tot_sum_fsk, -cont.tot_sum_rsk]) AS a)  			AS itog_sum
				FROM bee_repakt4_get_content2($1)  As cont,
				     bee_repakt4_get_tot_vn($1) AS vn,
				     bee_repakt4_get_tot_sn1($1) AS sn1,
				     bee_repakt4_get_tot_sn2($1) AS sn2,
				     bee_repakt4_get_tot_nn($1) AS nn)
		LOOP
			return next rec;
		END LOOP;
	    ELSE FOR rec IN (SELECT (select sum (a) from unnest (ARRAY[cont.vn_sum_fsk,cont.vn_sum_rsk]) AS a)   AS vn_tot_sum, 
				   (select sum (a) from unnest (ARRAY[cont.sn1_sum_fsk,cont.sn1_sum_rsk]) AS a) AS sn1_tot_sum, 
				       (select sum (a) from unnest (ARRAY[cont.sn2_sum_fsk,cont.sn2_sum_rsk]) AS a) AS sn2_tot_sum,
				       (select sum (a) from unnest (ARRAY[cont.nn_sum_fsk,cont.nn_sum_rsk]) AS a)   AS  nn_tot_sum,
				       (select sum (a) from unnest (ARRAY[cont.tot_sum_fsk, cont.tot_sum_rsk]) AS a)  AS tot_sum,
				       (select sum (a) from unnest (ARRAY[vn.vn[1],  -cont.vn_sum_fsk, -cont.vn_sum_rsk]) AS a)  AS itog_sum_vn,
				       (select sum (a) from unnest (ARRAY[sn1.sn1[1],-cont.sn1_sum_fsk,-cont.sn1_sum_rsk]) AS a)  AS itog_sum_sn1,
				       (select sum (a) from unnest (ARRAY[sn2.sn2[1],-cont.sn2_sum_fsk,-cont.sn2_sum_rsk]) AS a)  AS itog_sum_sn2,
				       (select sum (a) from unnest (ARRAY[nn.nn[1],  -cont.nn_sum_fsk,-cont.nn_sum_rsk]) AS a)  AS itog_sum_nn,
				       (select sum (a) from unnest (ARRAY[vn.vn[1],sn1.sn1[1],sn2.sn2[1],nn.nn[1],
									-cont.tot_sum_fsk, -cont.tot_sum_rsk]) AS a)  AS itog_sum
				FROM bee_repakt4_get_content2($1)  As cont,
				     bee_repakt4_get_tot_vn($1) AS vn,
				     bee_repakt4_get_tot_sn1($1) AS sn1,
				     bee_repakt4_get_tot_sn2($1) AS sn2,
				     bee_repakt4_get_tot_nn($1) AS nn)
		LOOP
			return next rec;
		END LOOP;
	END IF;
END;
$$;

comment on function bee_repakt4_get_tot2(integer) is 'Акт (передача). Используется в RepAkt4.java';

alter function bee_repakt4_get_tot2(integer) owner to pgsql;

