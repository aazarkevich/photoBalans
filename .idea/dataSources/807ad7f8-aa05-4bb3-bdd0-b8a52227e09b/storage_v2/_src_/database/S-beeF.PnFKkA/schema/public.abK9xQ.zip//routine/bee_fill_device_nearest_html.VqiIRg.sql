create function bee_fill_device_nearest_html(lid integer, curdat character varying, usr character varying, templ character varying) returns character varying
    language plpgsql
as
$$
    --
-- ОТЧЁТ СБОР ПОСЛЕДНИХ ПОКАЗАНИЙ ПО СЧЁТЧИКАМ
-- 
DECLARE
--
   per VARCHAR;
   Rec RECORD; 
   Bdy VARCHAR := ''; 
   Xrow VARCHAR := '';
   TdB VARCHAR := '<td>';
   TdE VARCHAR := '</td>';
   RoB VARCHAR := '<tr>';
   RoE VARCHAR := '</tr>';
   nn  INTEGER;
   c01 VARCHAR;
   c02 VARCHAR;
   c03 VARCHAR;
   c04 VARCHAR;
   c05 VARCHAR;
   c06 VARCHAR;
   c07 VARCHAR;
   c08 VARCHAR;
   c09 VARCHAR;
--   
BEGIN  
   --   
   nn  := 0;
   per = substring(curdat from '....-..');
   --
   FOR Rec IN ( 
      SELECT
         docnumber,
         abo_name,
         account,
         prodnumber,
         devname,
         feeded_object,
         feeded_object_address,
         registration_date_prev,
         registration_value_prev
      FROM 
         bee_rep_oper_registration 
      WHERE 
         locid   = lid AND 
         userid  = usr AND 
         substring(period from '....-..') = per 
      ORDER BY docnumber,account,prodnumber
   ) LOOP 
   ------------------------------------------------------
   nn := nn + 1;
   c01 = Rec.docnumber;
   c02 = Rec.abo_name;
   c03 = Rec.account;
   c04 = Rec.prodnumber;
   c05 = Rec.devname;
   c06 = Rec.feeded_object;
   c07 = Rec.feeded_object_address;
   c08 = Rec.registration_date_prev;
   c09 = Rec.registration_value_prev;
   --   
   IF  c01 IS NULL THEN c01 = ''; END IF;
   IF  c02 IS NULL THEN c02 = ''; END IF;
   IF  c03 IS NULL THEN c03 = ''; END IF;
   IF  c04 IS NULL THEN c04 = ''; END IF;
   IF  c05 IS NULL THEN c05 = ''; END IF;
   IF  c06 IS NULL THEN c06 = ''; END IF;
   IF  c07 IS NULL THEN c07 = ''; END IF;
   IF  c08 IS NULL THEN c08 = ''; END IF;
   IF  c09 IS NULL THEN c09 = '0'; END IF;
   --
   Xrow = TdB || nn  || TdE ||
          TdB || c01 || TdE ||
          TdB || c02 || TdE ||
          TdB || c03 || TdE ||
          TdB || c04 || TdE ||
          TdB || c05 || TdE ||
          TdB || c06 || TdE ||
          TdB || c07 || TdE || 
          TdB || c08 || TdE ||
          '<td style="text-align:right;">' || c09 || TdE ||
          TdB || TdE ||
          TdB || TdE;       

   Bdy = Bdy || RoB;   
   Bdy = Bdy || Xrow;
   Bdy = Bdy || RoE;
   ------------------------------------------------------  
   END LOOP;
   --    
RETURN Bdy; 

END;
$$;

alter function bee_fill_device_nearest_html(integer, varchar, varchar, varchar) owner to pgsql;

