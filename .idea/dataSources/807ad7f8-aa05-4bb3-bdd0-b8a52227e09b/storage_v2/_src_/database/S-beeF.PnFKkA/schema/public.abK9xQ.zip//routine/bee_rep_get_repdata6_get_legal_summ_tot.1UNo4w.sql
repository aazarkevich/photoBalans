create function bee_rep_get_repdata6_get_legal_summ_tot(digits character varying, code integer, date_start date, date_end date, filter1 integer, filter2 integer) returns SETOF bee_repdata6
    language plpgsql
as
$$
/*
ito06 2011-12-02
Баланс по ТП, итого по ТП юр лица
*/
DECLARE 
	RowLine bee_repdata6%RowType;
	filter_add text;
BEGIN
	filter_add = bee_rep_get_repdata6_get_legal_filters_summ($6);
RETURN QUERY 
EXECUTE
	'SELECT '||quote_literal('<b>Баланс по ТП</b>')||'::text AS name, 
		null::numeric AS control, 
		sum(p850.v) AS legal_all, 
		sum(p917.v) + sum(p918.v) AS legal1, 
		sum(p919.v) AS legal2, 
		null::numeric AS natural, 
		null::numeric AS all, 
		null::numeric AS not_balance, 
		null::numeric AS not_balance_perc 
           FROM gis_traces AS gis 
      LEFT JOIN regdevconn AS rdc ON rdc.traceid = gis.rowid 
      LEFT JOIN agreeregdev AS ard2 ON ard2.linkid=rdc.pointid AND ard2.paramid=715 
      LEFT JOIN agreeregdev AS ard ON ard.linkid = rdc.pointid AND ard.paramid = 189 AND ard.paramval = '||quote_literal(432)||' 
      LEFT JOIN (select linkid, sum(valman::numeric('||$1||')) as v 
                   from regdevoper 
                  where operdate BETWEEN '||quote_literal($3)||' AND ('||quote_literal($4)||')::date - '||quote_literal('1 day')||'::interval 
                    and paramid = 850 and is_pokazania(valman) 
                  group by linkid
                ) AS p850 ON p850.linkid = ard.linkid  
      LEFT JOIN (select linkid, sum(valman::numeric('||$1||')) as v 
                   from regdevoper 
                  where operdate BETWEEN '||quote_literal($3)||' AND ('||quote_literal($4)||')::date - '||quote_literal('1 day')||'::interval 
                    and paramid = 917 AND is_pokazania(valman) group by linkid
                ) AS p917 ON p917.linkid = ard.linkid  
      LEFT JOIN (select linkid, sum(valman::numeric('||$1||')) as v 
                   from regdevoper 
                  where operdate BETWEEN '||quote_literal($3)||' AND ('||quote_literal($4)||')::date - '||quote_literal('1 day')||'::interval 
                    and paramid = 918 AND is_pokazania(valman)  group by linkid
                ) AS p918 ON p918.linkid = ard.linkid  
      LEFT JOIN (select linkid, sum(valman::numeric('||$1||')) as v 
                   from regdevoper 
                  where operdate BETWEEN '||quote_literal($3)||' AND ('||quote_literal($4)||')::date - '||quote_literal('1 day')||'::interval 
                    and paramid = 919 AND is_pokazania(valman)  
                  group by linkid
                ) AS p919 ON p919.linkid = ard.linkid  
      LEFT JOIN agreeregdev AS ard690 ON ard690.linkid = rdc.pointid AND ard690.paramid=690 
          WHERE ( gis.objcode = '||$2||' 
                  OR gis.objowner = '||$2||' '|| filter_add ||') 
            AND (   (length(ard690.paramval) <> 10 OR ard690.paramval IS NULL)
                 OR (ard690.paramval::date > '||quote_literal($3)||')
                );';
      END;
$$;

comment on function bee_rep_get_repdata6_get_legal_summ_tot(varchar, integer, date, date, integer, integer) is 'Баланс по ТП, итого по ТП юр лица. Используется в RepCreate6.java';

alter function bee_rep_get_repdata6_get_legal_summ_tot(varchar, integer, date, date, integer, integer) owner to postgres;

