create function bee_rep_get_repdata24(loc_id integer, s_dat date, e_dat date) returns SETOF bee_repdata24
    language plpgsql
as
$$
/*
	add ito06 2015-08-06
	add ito06 2013-10-21
	ito06 2012-02-10: Ведомость по объему услуг
*/
BEGIN
	--** 2015-08-06
	DROP TABLE IF EXISTS bee_rep_get_repdata24_cont_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata24_cont_tmp AS
		(SELECT * FROM bee_rep_get_repdata24_cont($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));
		
	DROP TABLE IF EXISTS bee_rep_get_repdata24_cont1_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata24_cont1_tmp AS
		(SELECT * FROM bee_rep_get_repdata24_cont1($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));

	DROP TABLE IF EXISTS bee_rep_get_repdata24_cont3_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata24_cont3_tmp AS
		(SELECT * FROM bee_rep_get_repdata24_cont3($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));

	DROP TABLE IF EXISTS bee_rep_get_repdata24_tot_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata24_tot_tmp AS
		(SELECT * FROM bee_rep_get_repdata24_tot($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));						

	DROP TABLE IF EXISTS bee_rep_get_repdata24_cont_tot_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata24_cont_tot_tmp AS
		(SELECT * FROM bee_rep_get_repdata24_cont_tot($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));	
		
	DROP TABLE IF EXISTS bee_rep_get_repdata24_corr_tot_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata24_corr_tot_tmp AS
		(SELECT * FROM bee_rep_get_repdata24_corr_tot($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));

	DROP TABLE IF EXISTS bee_rep_get_repdata24_corr_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata24_corr_tmp AS
		(SELECT * FROM bee_rep_get_repdata24_corr($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));	

	DROP TABLE IF EXISTS bee_rep_get_repdata24_cont2_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata24_cont2_tmp AS
		(SELECT * FROM bee_rep_get_repdata24_cont2($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));

	DROP TABLE IF EXISTS bee_rep_get_repdata24_corr_all_tmp;
	CREATE TEMPORARY table bee_rep_get_repdata24_corr_all_tmp AS
		(SELECT * FROM bee_rep_get_repdata24_corr_all($1,$2,($3 + '1 month'::interval - '1 day'::interval)::date));				
	--**

RETURN QUERY( 		
	(SELECT grp,
		row_style,
		dat,
		CASE 
		    WHEN nn IN ('1','1.1','1.2','2','2.1','2.2','3','3.1','3.2','3.3')
			THEN nn
		    WHEN nn='1.2.1.1' 
			THEN '1.2.1'
		    WHEN nn='1.2.1.3'
			THEN '1.2.2'
		    WHEN nn='2.2.1.1' 
			THEN '2.2.1'
		    WHEN nn='2.2.1.3'
			THEN '2.2.2'
		    ELSE NULL
		END AS nn,
		nn AS nn_tmp, 
		"name",
		null::text AS doc_name,
		CASE 
		    WHEN nn IN ('1','1.1','1.2', '2', '2.1','2.2','3', '3.1', '3.2','3.3')
			    AND nn::numeric*10 IN (select grp from bee_rep_get_repdata24_corr_all_tmp)
			THEN null
		    ELSE tar_vn
		END,
		CASE 
		    WHEN nn IN ('1','1.1','1.2', '2', '2.1','2.2','3', '3.1', '3.2','3.3')
		            AND nn::numeric*10 IN (select grp from bee_rep_get_repdata24_corr_all_tmp)
			THEN null
		    ELSE tar_sn1
		END,
		CASE 
		    WHEN nn IN ('1','1.1','1.2', '2', '2.1','2.2','3', '3.1', '3.2','3.3')
		           AND nn::numeric*10 IN (select grp from bee_rep_get_repdata24_corr_all_tmp)
			THEN null
		    ELSE tar_sn2
		END,
		CASE 
		    WHEN nn IN ('1','1.1','1.2', '2', '2.1','2.2','3', '3.1', '3.2','3.3')
			    AND nn::numeric*10 IN (select grp from bee_rep_get_repdata24_corr_all_tmp)
			THEN null
		    ELSE tar_nn
		END,
		tar_m_tot::numeric(12,6),
		tar_m_vn::numeric(12,6),
		tar_m_sn1::numeric(12,6),
		tar_m_sn2::numeric(12,6),
		tar_m_nn::numeric(12,6),
		tot_amount,
		vn_amount,
		sn1_amount,
		sn2_amount,
		nn_amount,
		tot_sum,
		vn_sum,
		sn1_sum,
		sn2_sum,
		nn_sum 
	   FROM(
		(SELECT * FROM bee_rep_get_repdata24_cont_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont1_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont3_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont2_tmp)) AS a
	  WHERE (dat <'1900-12-31' AND (     nn_tmp IN ('0','1','2','3','1.1','2.1','3.1','3.2','3.3')
                                        OR ( nn_tmp IN ('2.2','1.2','1.2.1.1', '1.2.1.3','2.2',
                                                        '2.2.1.1', '2.2.1.3','3.1.2','3.1.3','3.2.2','3.2.3','3.3.2','3.3.3','30б','30в') 
                                             AND (tot_amount IS NOT NULL OR tot_sum IS NOT NULL ))				        
                                        OR (     nn_tmp NOT IN ('0','1','1.1','2.2','3.1','3.2','3.3',
                                                                '1.2','1.2.1.1', '1.2.1.3','2.2.1.1', '2.2.1.3','3.1.2','3.1.3','3.2.2','3.2.3','3.3.2','3.3.3','30б','30в') 
			                     AND (grp in (select grp from bee_rep_get_repdata24_corr_all_tmp)))
                                        ))
               OR ((dat BETWEEN '1900-12-31' AND '1999-12-31') AND (tot_amount IS NOT NULL OR tot_sum IS NOT NULL))   
	 ORDER BY nn, dat)
UNION	(SELECT grp,
		row_style,
		'2000-01-01' AS dat,
		CASE 
		    WHEN nn IN ('1','1.1','1.2','2','2.1','2.2','3','3.1','3.2','3.3')
			THEN nn
		    WHEN nn='1.2.1.1' 
			THEN '1.2.1'
		    WHEN nn='1.2.1.3'
			THEN '1.2.2'
		    WHEN nn='2.2.1.1' 
			THEN '2.2.1'
		    WHEN nn='2.2.1.3'
			THEN '2.2.2'
		    ELSE NULL
		END AS nn, 
		nn AS nn_tmp,
		'корректировка ' AS "name",
		null::TEXT AS doc_name,
		sum(tar_vn),
		sum(tar_sn1),
		sum(tar_sn2),
		sum(tar_nn),
		sum(tar_m_tot)::numeric(12,6),
		sum(tar_m_vn)::numeric(12,6),
		sum(tar_m_sn1)::numeric(12,6),
		sum(tar_m_sn2)::numeric(12,6),
		sum(tar_m_nn)::numeric(12,6),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	  FROM (
		(SELECT * FROM bee_rep_get_repdata24_cont_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont1_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont3_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont2_tmp)) AS a
	  WHERE (dat >'1999-12-31' AND (tot_amount <> 0 OR tot_sum <>0) AND nn_tmp NOT IN ('30г','30д', '3.1.4','3.1.5','3.2.4','3.2.5','3.3.4','3.3.5')) 
          GROUP BY  row_style, grp, nn, nn_tmp)
UNION 
	(SELECT grp,
		row_style,
		'2000-01-01' AS dat,
		CASE 
		    WHEN nn IN ('1','1.1','1.2','2','2.1','2.2','3','3.1','3.2','3.3')
			THEN nn
		    WHEN nn='1.2.1.1' 
			THEN '1.2.1'
		    WHEN nn='1.2.1.3'
			THEN '1.2.2'
		    WHEN nn='2.2.1.1' 
			THEN '2.2.1'
		    WHEN nn='2.2.1.3'
			THEN '2.2.2'
		    ELSE NULL
		END AS nn, 
		nn AS nn_tmp,
		'корректировка в пределах соц. нормы' AS "name",
		null::text AS doc_name,
		sum(tar_vn),
		sum(tar_sn1),
		sum(tar_sn2),
		sum(tar_nn),
		sum(tar_m_tot)::numeric(12,6),
		sum(tar_m_vn)::numeric(12,6),
		sum(tar_m_sn1)::numeric(12,6),
		sum(tar_m_sn2)::numeric(12,6),
		sum(tar_m_nn)::numeric(12,6),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	  FROM (
		(SELECT * FROM bee_rep_get_repdata24_cont_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont1_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont3_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont2_tmp)) AS a
	  WHERE (dat >'1999-12-31' AND (tot_amount <> 0 OR tot_sum <>0) AND nn_tmp IN ('30г', '3.1.4','3.2.4','3.3.4')) 
          GROUP BY  row_style, grp, nn, nn_tmp)	 
UNION 
	(SELECT grp,
		row_style,
		'2000-01-01' AS dat,
		CASE 
		    WHEN nn IN ('1','1.1','1.2','2','2.1','2.2','3','3.1','3.2','3.3')
			THEN nn
		    WHEN nn='1.2.1.1' 
			THEN '1.2.1'
		    WHEN nn='1.2.1.3'
			THEN '1.2.2'
		    WHEN nn='2.2.1.1' 
			THEN '2.2.1'
		    WHEN nn='2.2.1.3'
			THEN '2.2.2'
		    ELSE NULL
		END AS nn, 
		nn AS nn_tmp,
		'корректировка сверх соц. нормы' AS "name",
		null::text AS doc_name,
		sum(tar_vn),
		sum(tar_sn1),
		sum(tar_sn2),
		sum(tar_nn),
		sum(tar_m_tot)::numeric(12,6),
		sum(tar_m_vn)::numeric(12,6),
		sum(tar_m_sn1)::numeric(12,6),
		sum(tar_m_sn2)::numeric(12,6),
		sum(tar_m_nn)::numeric(12,6),
		sum(tot_amount),
		sum(vn_amount),
		sum(sn1_amount),
		sum(sn2_amount),
		sum(nn_amount),
		sum(tot_sum),
		sum(vn_sum),
		sum(sn1_sum),
		sum(sn2_sum),
		sum(nn_sum)
	  FROM (
		(SELECT * FROM bee_rep_get_repdata24_cont_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont1_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont3_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tot_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_corr_tmp) UNION ALL
		(SELECT * FROM bee_rep_get_repdata24_cont2_tmp)) AS a
	  WHERE (dat >'1999-12-31' AND (tot_amount <> 0 OR tot_sum <>0) AND nn_tmp IN ('30д', '3.1.5','3.2.5','3.3.5')) 
          GROUP BY  row_style, grp, nn, nn_tmp)
ORDER BY nn_tmp, dat);
END;
$$;

comment on function bee_rep_get_repdata24(integer, date, date) is 'Ведомость по объему услуг. Используется в RepCreate24.java';

alter function bee_rep_get_repdata24(integer, date, date) owner to pgsql;

