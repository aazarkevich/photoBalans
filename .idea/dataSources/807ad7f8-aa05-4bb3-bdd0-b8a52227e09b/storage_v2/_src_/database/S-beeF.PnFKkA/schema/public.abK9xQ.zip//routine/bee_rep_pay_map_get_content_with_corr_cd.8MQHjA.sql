create function bee_rep_pay_map_get_content_with_corr_cd(bd_rowid integer) returns SETOF bee_rep_pay_map_tab_cd
    language sql
as
$$
    /*
        add ito06 2015-06-24
        ito06 2011-09-19 Карта расхода ЦД
        ito07 170710 bee_doc.docdat
    */
	SELECT * FROM ( select '1000-1-1'::date AS dat1, 0 AS pos, * from bee_rep_pay_map_get_content_cd($1)) AS a
	UNION ALL
	  select dat1				AS dat1,
	  1				AS pos,
	  null::integer 			AS tar_grp,
	  null::varchar			AS s_date,
	  null::varchar			AS e_date,
	  apn_rowid			AS apn_rowid,
	  loc 				AS loc,  -- участок
	  fil 				AS fil,  -- филиал
	  null::varchar 		AS amn_docnumber,
	  null::varchar 		AS cst_name,
	  null::varchar 		AS prdnum,
	  account			AS account,
	  obj 				AS obj,
	  null::text 			AS ul,
	  null::numeric			AS v196,
	  null::numeric			AS v195,
	  null::numeric			AS v198,
	  null::text			AS koef,
	  null::numeric			AS loss_tot,
	  null::numeric			AS loss_n,
	  null::numeric			AS loss_l,
	  null::numeric			AS loss_h,
	  null::numeric			AS dopsum,
	  null::numeric			AS v407,
	  sum(v850)			AS v850,
	  null::integer			AS row850,
	  null::date 			AS dat,
	  price				AS price,
	  sum(sum_no_tax)			AS sum_no_tax,
	  sum(sum_tax)			AS sum_tax,
	  sum(sum)			AS sum 
	  from (
	      (SELECT
		 bdc.period 								AS dat1,
		 1									AS pos,			
		 apn.rowid 								AS apn_rowid,
		 denet.nam 								AS loc,	-- участок
		 dn.nam 								AS fil,	-- филиал			
		 apn.account 								AS account,
		 'Корректировка за ' || date_to_char_month_yyyy_ru(bdc.period)||'г.'	AS obj,			
		 bdc.quantity_old * -1 							AS v850,			
		 bdc.price_old 								AS price,
		 bdc.cost_old * -1							AS sum_no_tax,
		 bdc.tax_sum_old * -1							AS sum_tax,
		 bdc.cost_with_tax_old * -1						AS sum 
	       from bee_docs 
	       AS bd1
		  JOIN bee_docs 
		  AS bd2 
		  on 
		     bd2.linkid = bd1.linkid AND 
		     bd2.doctyp = 1618 AND 
		     --bd2.docdat = bd1.docdat
		     date_part('year', bd2.docdat) = date_part('year', bd1.docdat) and 
		     date_part('month', bd2.docdat) = date_part('month', bd1.docdat) 
		  JOIN agreepoint 
		  AS apn ON 
		     apn.linkid = bd1.linkid
		  JOIN denet 
		  ON 
		     apn.lid=denet.rowid
		  LEFT JOIN (SELECT nam, kod FROM denet WHERE length(kod)=6) as dn ON substring(denet.kod, 0, 7)=dn.kod
		  JOIN bee_docs_corr AS bdc 
		  ON 
		     bdc.linkid1 = apn.rowid AND 
		     bdc.linkid2 = bd2.rowid AND 
		     (bdc.diff_kvt <> 0 or bdc.diff_sum <> 0)
			  WHERE bd1.rowid = $1
		)
		UNION ALL
		( 
		  SELECT
		     bdc.period 								AS dat1,
		     2									AS pos,			
		     apn.rowid 								AS apn_rowid,
		     denet.nam 								AS loc,  -- участок
		     dn.nam 									AS fil,       -- филиал			
		     apn.account								AS account,
		     'Корректировка за ' || date_to_char_month_yyyy_ru(bdc.period)||'г.'	AS obj,				
		     bdc.quantity_new 							AS v850,
		     bdc.price_new 								AS price,
		     bdc.cost_new								AS sum_no_tax,
		     bdc.tax_sum_new								AS sum_tax,
		     bdc.cost_with_tax_new							AS sum
		 FROM bee_docs 
		 AS bd1
		    JOIN bee_docs AS bd2 
		    on 
			bd2.linkid = bd1.linkid AND bd2.doctyp = 1618 AND 
		       --bd2.docdat = bd1.docdat
	  	       date_part('year', bd2.docdat) = date_part('year', bd1.docdat) and 
		       date_part('month', bd2.docdat) = date_part('month', bd1.docdat) 
		    JOIN agreepoint AS apn 
		    ON 
		       apn.linkid = bd1.linkid
		    JOIN denet 
		    ON 
		       apn.lid=denet.rowid
		    LEFT JOIN (SELECT nam, kod FROM denet WHERE length(kod)=6) 
		    as dn 
		    ON 
		      substring(denet.kod, 0, 7) = dn.kod
		    JOIN bee_docs_corr AS bdc 
		    ON 
		       bdc.linkid1 = apn.rowid AND 
		       bdc.linkid2 = bd2.rowid AND 
		       (bdc.diff_kvt <> 0 or bdc.diff_sum <> 0)
		WHERE bd1.rowid = $1
		)  
	  ) AS roww
	group by dat1,apn_rowid,loc,fil,account,obj,price 
	ORDER BY fil,loc,account,apn_rowid, prdnum, dat1, pos, obj

$$;

comment on function bee_rep_pay_map_get_content_with_corr_cd(integer) is 'Карта расхода ЦД. Используется в RepPayMapCD.java; bee_rep_pay_map_get_content_with_corr_cd_tot(int, varchar)';

alter function bee_rep_pay_map_get_content_with_corr_cd(integer) owner to postgres;

