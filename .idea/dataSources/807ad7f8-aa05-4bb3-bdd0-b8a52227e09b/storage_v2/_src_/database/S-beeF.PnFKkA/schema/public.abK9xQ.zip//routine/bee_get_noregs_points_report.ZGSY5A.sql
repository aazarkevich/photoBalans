create function bee_get_noregs_points_report(_locid integer, dat1 date, dat2 date) returns SETOF noregs_report
    language plpgsql
as
$$
DECLARE 
   RowLine noregs_report%rowtype;
BEGIN
   FOR RowLine IN ( 
	SELECT  
		customer.abo_code AS aboid,
		agreepoint.rowid AS pointid,
		regexp_replace(pchain,E'\\+.{1,}?\\+.{1,}?\\+.{1,}?\\+',''),  --схема подключения
		docnumber,                                 --договор 
		account,                                   --лицевой счет
		prodnumber,                                --номер счетчика
		consum_name,                               --потребитель
		p418.paramval AS p418,                     --запитанный объект
		p410.paramval AS p410,                     --адрес запитанного объекта 
		p643.paramval AS p643,                     --место установки счетчика
		p417.paramval AS p417,                     --адрес установки счетчика 
		p641.paramval AS p641,                     --район города
		p723.paramval AS p723,                     --населенный пункт 
		p642.paramval AS p642,                     --улица
		p640.paramval AS p640,                     --номер дома
		p851.paramval AS p851,                     --участок
		p356.paramval AS p356,                     --расчетный коэффициент
		p168.paramval AS p168,                     --значность
		dic_elements.element_name AS element_name, --вид учета
		case when p850.valman  IS NOT NULL then p850.valman::numeric else 0 end  AS p850, -- за предыдущий месяц 
		case when p311.paramval='311' then '' else '-' end as p311,
		case when p308.paramval='308' then '' else '-' end as p308,
		case when p310.paramval='310' then '' else '-' end as p310,
		case when p306.paramval='306' then '' else '-' end as p306,	 
		case when agreement.doctype = 1910 then 'прямые' else 'исключить прямые' end as transmit,  	
		case when ((p1950.paramval is null) OR (p1950.paramval = '')) then '-' else p1950.paramval end as p1950 --мкд
		FROM agreepoint
			JOIN agreement ON agreepoint.linkid=agreement.rowid
			JOIN customer ON agreement.abo_code=customer.abo_code
			LEFT JOIN regdevconn ON agreepoint.rowid=regdevconn.pointid
			LEFT JOIN gis_traces ON regdevconn.traceid = gis_traces.rowid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid =418) AS p418 ON agreepoint.rowid=p418.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid =410) AS p410 ON agreepoint.rowid=p410.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid =643) AS p643 ON agreepoint.rowid=p643.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid =417) AS p417 ON agreepoint.rowid=p417.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid =641) AS p641 ON agreepoint.rowid=p641.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid =723) AS p723 ON agreepoint.rowid=p723.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid =642) AS p642 ON agreepoint.rowid=p642.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid =640) AS p640 ON agreepoint.rowid=p640.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid =1950) AS p1950 ON agreepoint.rowid=p1950.linkid
			LEFT JOIN (select a1.linkid, a1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 851) as a1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 851 group by linkid) 
					     as a2 on a1.linkid=a2.linkid and a1.period=a2.period
				 ) AS p851 ON agreepoint.rowid = p851.linkid
			LEFT JOIN (select b1.linkid, b1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 356) as b1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 356 group by linkid) 
					     as b2 on b1.linkid=b2.linkid and b1.period=b2.period
				 ) AS p356 ON agreepoint.rowid = p356.linkid

			LEFT JOIN (select c1.linkid, c1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 439) as c1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 439 group by linkid) 
					     as c2 on c1.linkid=c2.linkid and c1.period=c2.period
				 ) AS p311 ON agreepoint.rowid = p311.linkid

			LEFT JOIN (select d1.linkid, d1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 439) as d1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 439 group by linkid) 
					     as d2 on d1.linkid=d2.linkid and d1.period=d2.period
				 ) AS p308 ON agreepoint.rowid = p308.linkid

			LEFT JOIN (select e1.linkid, e1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 439) as e1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 439 group by linkid) 
					     as e2 on e1.linkid=e2.linkid and e1.period=e2.period
				 ) AS p310 ON agreepoint.rowid = p310.linkid

			LEFT JOIN (select f1.linkid, f1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 439) as f1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 439 group by linkid) 
					     as f2 on f1.linkid=f2.linkid and f1.period=f2.period
				 ) AS p306 ON agreepoint.rowid = p306.linkid

			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid = 168) AS p168 ON agreepoint.rowid=p168.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid = 690) AS p690 ON agreepoint.rowid=p690.linkid
			LEFT JOIN (SELECT paramval::numeric, linkid FROM agreeregdev WHERE paramid = 189 AND paramval <> '?' AND paramval <> '-' 
                                                                                                         AND paramval IS NOT NULL AND paramval <> ''
                                  ) AS p189 ON agreepoint.rowid=p189.linkid
			LEFT JOIN dic_elements ON p189.paramval=dic_elements.rowid
			
                        LEFT JOIN ( select r.linkid, r.valman 
                                      from regdevoper  as r
                                      join (select linkid, max(operdate) AS operdate
                                              from regdevoper 
                                             where (operdate between ((to_char(dat1,'YYYY-MM') || '-01')::date - '1 month'::interval)::date 
			                             and ((to_char(dat1,'YYYY-MM') || '-01')::date - '1 day'::interval)::date) 
			                       and paramid = 850
			                     group by linkid) AS a   on  a.linkid = r.linkid and r.operdate = a.operdate                  
                                     where paramid = 850     
                                  ) AS p850 ON agreepoint.rowid = p850.linkid 
                        
		WHERE
			agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = _locid)) AND
			docstatus = 79 AND
			((p690.paramval IS NULL) OR (length(trim(p690.paramval)) < 4)) AND
			agreepoint.rowid NOT IN (SELECT distinct linkid FROM regdevoper WHERE operdate BETWEEN dat1::date AND dat2::date)
		ORDER BY  docnumber --2014-05-27
   )
   LOOP
      RETURN NEXT RowLine; 
   END LOOP;
	
   RETURN;   
END
$$;

comment on function bee_get_noregs_points_report(integer, date, date) is 'Акт снятия показаний приборов учета. Используется в RepAkt3.java, SessionBean.java';

alter function bee_get_noregs_points_report(integer, date, date) owner to pgsql;

