create view vbee_check_fin
            (locid, aboid, agreeid, pointid, uch, abo_name, docnumber, prodnumber, doc_dat, cal_sum, dev_sum) as
SELECT vvv.locid,
       vvv.aboid,
       vvv.agreeid,
       vvv.pointid,
       vvv.uch,
       vvv.abo_name,
       vvv.docnumber,
       vvv.prodnumber,
       vvv.doc_dat,
       vvv.cal_sum,
       vvv.dev_sum
FROM (SELECT foo.locid,
             foo.aboid,
             foo.agreeid,
             foo.pointid,
             foo.uch,
             foo.abo_name,
             foo.docnumber,
             foo.prodnumber,
             foo.doc_dat,
             (sum(foo.cal_sum) / (foo.n)::double precision) AS cal_sum,
             (sum(foo.dev_sum) / (foo.n)::double precision) AS dev_sum
      FROM (SELECT agr.locid,
                   cst.abo_code                                               AS aboid,
                   agr.rowid                                                  AS agreeid,
                   bdc.linkid2                                                AS pointid,
                   dnt.nam                                                    AS uch,
                   cst.abo_name,
                   agr.docnumber,
                   agp.prodnumber,
                   "substring"(((bdo.docdat)::character varying)::text, 1, 7) AS doc_dat,
                   count(bdo.docdat)                                          AS n,
                   sum((bdc.quantity_amo)::double precision)                  AS cal_sum,
                   sum((rdo.valman)::double precision)                        AS dev_sum
            FROM ((((((bee_docs_calc bdc
                JOIN bee_docs bdo ON ((bdo.rowid = bdc.linkid1)))
                JOIN regdevoper rdo ON ((rdo.linkid = bdc.linkid2)))
                JOIN agreepoint agp ON ((rdo.linkid = agp.rowid)))
                JOIN agreement agr ON ((agp.linkid = agr.rowid)))
                JOIN customer cst ON ((agr.abo_code = cst.abo_code)))
                     JOIN denet dnt ON ((agr.locid = dnt.rowid)))
            WHERE ((rdo.paramid = 850) AND (agr.doctype = 1910) AND
                   (date_part('year'::text, bdo.docdat) = date_part('year'::text, rdo.operdate)) AND
                   (date_part('month'::text, bdo.docdat) = date_part('month'::text, rdo.operdate)))
            GROUP BY agr.locid, cst.abo_code, agr.rowid, bdc.linkid2, dnt.nam, cst.abo_name, agr.docnumber,
                     agp.prodnumber, bdc.quantity_amo, ("substring"(((bdo.docdat)::character varying)::text, 1, 7)),
                     ("substring"(((rdo.operdate)::character varying)::text, 1, 7))
            HAVING ((bdc.quantity_amo)::double precision <> sum((rdo.valman)::double precision))
            ORDER BY ("substring"(((bdo.docdat)::character varying)::text, 1, 7)) DESC, agr.docnumber, bdc.linkid2) foo
      GROUP BY foo.locid, foo.aboid, foo.agreeid, foo.pointid, foo.uch, foo.abo_name, foo.docnumber, foo.prodnumber,
               foo.doc_dat, foo.n) vvv
GROUP BY vvv.locid, vvv.aboid, vvv.agreeid, vvv.pointid, vvv.uch, vvv.abo_name, vvv.docnumber, vvv.prodnumber,
         vvv.doc_dat, vvv.cal_sum, vvv.dev_sum
HAVING (vvv.cal_sum <> vvv.dev_sum);

comment on view vbee_check_fin is 'Используется в Menu.java, SessionBean1.java';

alter table vbee_check_fin
    owner to pgsql;

