create function bee_get_noregs_points_report_akt3sub(_locid integer, dat1 date, dat2 date, _pointid integer) returns SETOF noregs_report
    language plpgsql
as
$$
/*
        ito06 2014-06-26 Акт снятия показаний приборов учета
*/
DECLARE 
   RowLine noregs_report%rowtype;
BEGIN
   FOR RowLine IN ( 
	SELECT  
		cust.abo_code 						AS aboid,
		apn.rowid 						AS pointid,
		null::text                      			AS pchain,	--схема подключения
		docnumber						AS docnumber, 	--договор 
		account 						AS account,     --лицевой счет
		prodnumber						AS prodnumber,	--номер счетчика
		consum_name						AS consum_name, --потребитель
		null::text 						AS p418,        --запитанный объект
		null::text 						AS p410,	--адрес запитанного объекта 
		p643.paramval 						AS p643,	--место установки счетчика
		p417.paramval 						AS p417,        --адрес установки счетчика 
		null::text 						AS p641,        --район города
		null::text 						AS p723,        --населенный пункт 
		null::text 						AS p642,        --улица
		null::text 						AS p640,        --номер дома
		null::text 						AS p851,        --участок
		p356.paramval 						AS p356,        --расчетный коэффициент
		null::text 						AS p168,        --значность
		null::text 						AS element_name,--вид учета
		case when p850.valman  IS NOT NULL 
		     then p850.valman::numeric else 0 end  		AS p850, 	-- за текущий месяц 
		case when p311.paramval='311'  
		     then case when p850.valman IS NOT NULL then p407.valman else '' end
		     else '-' end 	AS p311,
		case when p308.paramval='308' 
		     then case when p850.valman IS NOT NULL then p407.valman else '' end  
		     else '-'  end 	AS p308,
		case when p310.paramval='310' 
		      then case when p850.valman IS NOT NULL then p407.valman else '' end
		      else '-' end 	AS p310,
		case when p306.paramval='306' 
		      then case when p850.valman IS NOT NULL then p407.valman else '' end 
		     else '-' end 	AS p306,
		null::text 						AS transmit 
		
		FROM agreepoint AS apn
			JOIN agreement AS amn ON apn.linkid=amn.rowid 		
			JOIN customer  AS cust ON amn.abo_code=cust.abo_code		
					
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid = 643) AS p643 ON apn.rowid=p643.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid = 417) AS p417 ON apn.rowid=p417.linkid
			LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid = 690) AS p690 ON apn.rowid=p690.linkid
			
			LEFT JOIN (select b1.linkid, b1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 356) as b1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 356 group by linkid) 
					     as b2 on b1.linkid=b2.linkid and b1.period=b2.period
				 ) AS p356 ON apn.rowid = p356.linkid

			LEFT JOIN (select c1.linkid, c1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 439) as c1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 439 group by linkid) 
					     as c2 on c1.linkid=c2.linkid and c1.period=c2.period
				 ) AS p311 ON apn.rowid = p311.linkid

			LEFT JOIN (select d1.linkid, d1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 439) as d1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 439 group by linkid) 
					     as d2 on d1.linkid=d2.linkid and d1.period=d2.period
				 ) AS p308 ON apn.rowid = p308.linkid

			LEFT JOIN (select e1.linkid, e1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 439) as e1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 439 group by linkid) 
					     as e2 on e1.linkid=e2.linkid and e1.period=e2.period
				 ) AS p310 ON apn.rowid = p310.linkid

			LEFT JOIN (select f1.linkid, f1.paramval from
					     (select linkid, paramval, period from agreeregdev_period where paramid = 439) as f1
					     join (select linkid, max(period) as period from agreeregdev_period where paramid = 439 group by linkid) 
					     as f2 on f1.linkid=f2.linkid and f1.period=f2.period
				 ) AS p306 ON apn.rowid = p306.linkid

			
			
						
                        LEFT JOIN ( select r.linkid, r.valman 
                                      from regdevoper  as r
                                      join (select linkid, max(operdate) AS operdate
                                              from regdevoper 
                                             where (operdate between ((to_char(dat1,'YYYY-MM') || '-01')::date)::date 
			                             and ((to_char(dat1,'YYYY-MM') || '-01')::date  + '1 month'::interval- '1 day'::interval)::date) 
			                       and paramid = 850
			                     group by linkid) AS a   on  a.linkid = r.linkid and r.operdate = a.operdate                  
                                     where paramid = 850     
                                  ) AS p850 ON apn.rowid = p850.linkid 
                        LEFT JOIN ( select r.linkid, r.valman
                                      from regdevoper  as r
                                      join (select linkid, max(operdate) AS operdate
                                              from regdevoper 
                                             where (operdate between ((to_char(dat1,'YYYY-MM') || '-01')::date)::date 
			                             and ((to_char(dat1,'YYYY-MM') || '-01')::date  + '1 month'::interval- '1 day'::interval)::date) 
			                       and paramid = 407
			                     group by linkid) AS a   on  a.linkid = r.linkid and r.operdate = a.operdate                  
                                     where paramid = 407     
                                  ) AS p407 ON apn.rowid = p407.linkid 
                        
		WHERE
			amn.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = _locid)) 
  		    AND docstatus = 79 
  		    AND ((p690.paramval IS NULL) OR (length(trim(p690.paramval)) < 4))   		   
		    AND apn.rowid = _pointid
		ORDER BY  docnumber
   )
   LOOP
      RETURN NEXT RowLine; 
   END LOOP;
   -- 
   RETURN;
   --
END
--
--      
$$;

comment on function bee_get_noregs_points_report_akt3sub(integer, date, date, integer) is 'Акт снятия показаний приборов учета. Используется в RepAkt3.java';

alter function bee_get_noregs_points_report_akt3sub(integer, date, date, integer) owner to pgsql;

