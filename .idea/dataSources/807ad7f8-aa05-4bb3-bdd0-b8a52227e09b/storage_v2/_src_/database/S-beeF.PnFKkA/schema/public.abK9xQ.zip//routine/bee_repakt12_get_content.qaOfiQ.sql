create function bee_repakt12_get_content(bd_rowid integer) returns SETOF bee_repakt2_tab
    language plpgsql
as
$$
/*
	
	ito06 2021-02-02: Акт (соц. норма)	
*/
BEGIN
	RETURN QUERY SELECT * from tmp_repakt12_content;
END;

$$;

comment on function bee_repakt12_get_content(integer) is 'Акт (соц. норма) без корр. Используется в RepAkt12.java';

alter function bee_repakt12_get_content(integer) owner to postgres;

