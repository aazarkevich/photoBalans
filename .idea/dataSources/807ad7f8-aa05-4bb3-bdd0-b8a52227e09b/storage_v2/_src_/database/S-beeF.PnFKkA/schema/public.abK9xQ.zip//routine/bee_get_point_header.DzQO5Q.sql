create function bee_get_point_header(_pointid integer) returns integer
    language plpgsql
as
$$
    --
--
-- ПОЛУЧИТЬ ГОЛОВНОЙ СЧЁТЧИК
-- 2011-08-02 by ito07
--
DECLARE
BEGIN
   RETURN (
   SELECT rowid FROM agreepoint
   JOIN ( 
      SELECT paramval AS ref FROM agreeregdev_period
      WHERE
         agreeregdev_period.linkid = _pointid AND
         paramid = 664
      ORDER by period DESC LIMIT 1  
   ) AS ap ON ap.ref =  agreepoint.rowid::text   
   );
--
END;
--
$$;

comment on function bee_get_point_header(integer) is 'Получить головной счетчик. Используется в LossDistr.java, AppUtils.java';

alter function bee_get_point_header(integer) owner to pgsql;

