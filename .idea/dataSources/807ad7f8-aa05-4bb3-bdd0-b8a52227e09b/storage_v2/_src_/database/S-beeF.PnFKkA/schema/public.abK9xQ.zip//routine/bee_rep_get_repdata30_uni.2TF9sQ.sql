create function bee_rep_get_repdata30_uni(_host character varying) returns SETOF bee_repdata30
    language plpgsql
as
$$
/*
    ito07 2019-05-17  sum_with_tax
    add ito06 2015-09-30 Изменили названия колонок для  разделителя
    add ito06 2015-05-12
    ito06 2015-02-02: Сводная реализация электроэнергии, развернутая по централизованным
*/
DECLARE RowLine bee_repdata30%rowtype;
BEGIN     
    FOR RowLine IN (
	    (SELECT * 						
	       FROM bee_rep_get_repdata30($1) AS row)
	  UNION (SELECT 'norm' 							AS row_style,
		null::varchar 						AS nn,
		'300' 							AS nn1,
		CASE 
		    WHEN npp = 1 
		    THEN  doc_num||', '||abo_num 
		    WHEN npp = 2 
		    THEN  'в т.ч. юр.лица'
		    WHEN npp = 3 
		    THEN  'в т.ч. население в пределах соц. нормы' 
		    WHEN npp = 4 
		    THEN  'в т.ч. население свыше соц. нормы'   
		END     						AS name, 
		d_start_sum 						AS d_start_sum, 
		k_start_sum 						AS k_start_sum,  
		amount  						AS amount,   
		amount1 						AS amount1,  
		amount2 						AS amount2,  

		sum_with_tax /* sum_no_tax * 1.18 */        AS sum_with_tax,
		sum_no_tax 						            AS sum_no_tax,

		sum_with_tax1068 /*sum_no_tax1068 * 1.18*/	AS sum_with_tax1068, 
		sum_no_tax1068						        AS sum_no_tax1068,

		sum_with_tax1069 /*sum_no_tax1069 * 1.18*/  AS sum_with_tax1069,
		sum_no_tax1069 						        AS sum_no_tax1069,

		tar 							    AS tar, 
		fact_all_sum 						AS fact_all_sum,
		payed_sum 							AS payed_sum,
		retrest_sum 						AS retrest_sum,
		disc_sum 							AS disc_sum,
		d_end_sum 							AS d_end_sum,
		k_end_sum 							AS k_end_sum,
		pay_all_sum 						AS pay_all_sum,
		fact_adv_sum 						AS fact_adv_sum,
		ext_sum 							AS ext_sum,
		_host							AS host,
		accdir 							AS accdir,
		null::int						AS loc,
		doc_num||', '||abo_num || ', ' ||npp  			AS ord
	       FROM bee_rep_get_repdata30_tmp 
	      WHERE npp=1 AND host like _host AND host IN ('beex', 'localhost'))			   			  
	ORDER BY nn1, ord)
        LOOP             
	RETURN  NEXT RowLine;
    END LOOP;	
END;
$$;

comment on function bee_rep_get_repdata30_uni(varchar) is 'Сводная реализация эл эн. развернуть по централизованным. Используется в bee_rep_get_repdata30_all(int, date, date, varchar) ';

alter function bee_rep_get_repdata30_uni(varchar) owner to pgsql;

