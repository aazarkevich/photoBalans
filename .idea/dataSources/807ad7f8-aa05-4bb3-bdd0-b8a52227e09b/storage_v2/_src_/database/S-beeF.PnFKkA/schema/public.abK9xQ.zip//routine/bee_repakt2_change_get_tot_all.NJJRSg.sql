create function bee_repakt2_change_get_tot_all(bd_rowid integer, diff boolean, _tartyp character varying) returns SETOF numeric[]
    language plpgsql
as
$$
/*
   ito07 181107 bee_get_doc_tax 
    add ito06 2015-12-10  добавили входной параметр _tartyp
    ito06 2015-07-09: Акт (соц. норма) для исправления или корректировки
*/
DECLARE newform numeric = 0;
BEGIN 
    SELECT sum(sum_with_tax) FROM bee_docs_result where linkid =$1 INTO newform;	
    IF (newform  = 0 )  
       THEN  RETURN QUERY EXECUTE('SELECT 
	    ARRAY[  sum(sum_no_tax), 
		(sum(sum_no_tax) *      bee_get_doc_tax(1163,' || bd_rowid || ')::numeric(20,2)),
		(sum(sum_no_tax) * (1 + bee_get_doc_tax(1163,' || bd_rowid || '))::numeric(20,2))
            ]				
	   FROM bee_docs_result
	  WHERE linkid = '||$1||' 
	    AND tar_typ IN ('||$3||') AND (row_typ = 1070 OR '||$2||' )
	    AND tar_grp IS NOT NULL');
       ELSE RETURN QUERY EXECUTE('SELECT 
	    ARRAY[  sum(sum_no_tax), 				
		sum(tax_sum),  
		sum(sum_with_tax)]       
	   FROM bee_docs_result
	  WHERE linkid = '||$1||' 
	    AND tar_typ IN ('||$3||') AND (row_typ = 1070 OR '||$2||' )
	    AND tar_grp IS NOT NULL');
    END IF;
END;
$$;

comment on function bee_repakt2_change_get_tot_all(integer, boolean, varchar) is 'Акт (соц норма) для исправления или корректировки. Используется в bee_repakt2_change_get_tot(int,boolean, int)';

alter function bee_repakt2_change_get_tot_all(integer, boolean, varchar) owner to pgsql;

