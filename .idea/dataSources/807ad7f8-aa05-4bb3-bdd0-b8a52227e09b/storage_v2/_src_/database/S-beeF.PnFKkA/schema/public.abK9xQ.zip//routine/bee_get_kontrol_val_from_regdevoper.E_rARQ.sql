create function bee_get_kontrol_val_from_regdevoper(ap_rowid integer, _df text, _dt text) returns numeric
    language plpgsql
as
$$
    /*
        ito05 2012-05-28, 
        add ito06 2014-10-27
    */
	--
	DECLARE
		_date_from DATE = _df::DATE;
		_date_to DATE = _dt::DATE;
		val numeric;
	---  
	BEGIN
	---  	
		val := (select regdevoper.valman::numeric from agreement
				join agreepoint on agreement.rowid=agreepoint.linkid
				join regdevoper on regdevoper.linkid=agreepoint.rowid
				where
					agreement.docstatus=79 and
					agreement.accdir=538 and
					agreepoint.rowid = ap_rowid and
					regdevoper.valman <> '-'  and
					regdevoper.paramid=850 and
					regdevoper.operdate BETWEEN _date_from AND _date_to
				order by regdevoper.operdate desc -- 2014-10-27
				limit 1	);

		RETURN val;
	---
	END;

$$;

comment on function bee_get_kontrol_val_from_regdevoper(integer, text, text) is 'Используется в RepNetIncome.java';

alter function bee_get_kontrol_val_from_regdevoper(integer, text, text) owner to pgsql;

