create function bee_rep_get_repdata28_get_pow(amn_rowid integer, year1 date, typ integer) returns SETOF bee_rep_tab28_pow
    language plpgsql
as
$$
/*
ito06 2013 Приложение 1a
typ: 1 - Реальные данные
     2 - Реальные данные с заполнением пустых ячеек средним
     3 - Пустая таблица
     4 - Договорные данные
     5 - Смешанные данные
     6 - Смешанные данные с заполнением пустых ячеек средним
*/

BEGIN
 RETURN QUERY EXECUTE 
	'SELECT 
	        obj_name,
		res.ul,
		res.ulev,
		m_1,
		m_2,
		m_3,
		m_4,
		m_5,
		m_6,
		m_7,
		m_8,
		m_9,
		m_10,
		m_11,
		m_12,
		max_pow,
		add_pow,
		okved,
		tg,
		hours
	   FROM bee_rep_get_repdata28_get_pow_'||typ||'('||$1||', '||quote_literal($2)||') AS pow
            LEFT JOIN bee_rep28_get_ulev() AS res ON res.ul = pow.ul
          ORDER BY res.ul, obj_name';
END;
$$;

comment on function bee_rep_get_repdata28_get_pow(integer, date, integer) is 'Приложение 1a. Используется в RepCreate28.java';

alter function bee_rep_get_repdata28_get_pow(integer, date, integer) owner to postgres;

