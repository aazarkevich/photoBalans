create function agree_x_33(dbn character varying, agr_num character varying, tagid integer, src_host character varying, src_port character varying) returns void
    language plpgsql
as
$$
/*
	add ito06 2020-02-07 сделали как agreeregdev_period
	добавление/изменение тарифов точки учета из филиала src_host в базу централизованных/смешнных для договора agr_num
*/
DECLARE
		Pnt RECORD; -- for agreepoint
		Rec RECORD;
		XRec RECORD;
BEGIN
    ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_audit;
    ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_trig;

	-- SCAN POINTS
	FOR Pnt IN (SELECT DISTINCT rowid FROM agree_get_agreepoint(dbn,agr_num,tagid,src_host, src_port) ORDER BY rowid)
	LOOP -- SCAN PARAMS RECORDS in agreepoint_tarif
	
	--** 2020-02-07 делаем как agreeregdev_period
	 BEGIN
        DELETE FROM agreepoint_tarif WHERE pointid = Pnt.rowid;
        END;
        -- INSERT NEW ONE
	     FOR XRec IN  (SELECT rowid, tarifid, pointid, period  FROM agree_get_agreepoint_tarif(dbn,agr_num,tagid,src_host, src_port) x
			     WHERE x.pointid = Pnt.rowid) 
         LOOP
        BEGIN    		   
		   INSERT INTO agreepoint_tarif 
					(    /* rowid,*/     tarifid,     pointid,     period) VALUES
					(/*XRec.rowid,*/XRec.tarifid,XRec.pointid,XRec.period);
        EXCEPTION
           WHEN unique_violation THEN
              CONTINUE;
           WHEN others           THEN
              CONTINUE;
        END;
        END LOOP;
        ------------------------------------------
     END LOOP;
	 
		/*FOR Rec IN (SELECT rowid, tarifid, pointid, period
                              FROM agree_get_agreepoint_tarif(dbn,agr_num,tagid,src_host, src_port) x
			     WHERE x.pointid = Pnt.rowid) 
		LOOP
					
			
			-- IF RECORD WAS CHANGED (DELETE+INSERT rowid is different) 
			UPDATE agreepoint_tarif 
			   SET tarifid = Rec.tarifid, rowid = Rec.rowid
			 WHERE pointid  =  Pnt.rowid
			   AND period   =  Rec.period
			   AND rowid   <>  Rec.rowid;

                        BEGIN
			-- IF RECORD WAS CHANGED (UPDATE)
			UPDATE agreepoint_tarif
			   SET pointid = Pnt.rowid, period = Rec.period
			 WHERE rowid    =  Rec.rowid
			   AND ((pointid <> Pnt.rowid) OR (period  <> Rec.period));
                        EXCEPTION
				WHEN unique_violation THEN CONTINUE;
				WHEN others           THEN CONTINUE;
                        END;
		END LOOP;

		-- ADD NEW ONE
		FOR XRec IN (SELECT rowid,tarifid,pointid,period
			       FROM agree_get_agreepoint_tarif(dbn,agr_num,tagid,src_host, src_port) x
			      WHERE pointid = Pnt.rowid
				AND x.rowid NOT IN (SELECT rowid FROM agreepoint_tarif WHERE pointid = Pnt.rowid)) 
		LOOP   
			BEGIN
				INSERT INTO agreepoint_tarif 
					(     rowid,     tarifid,     pointid,     period) VALUES
					(XRec.rowid,XRec.tarifid,XRec.pointid,XRec.period);
			EXCEPTION
				WHEN unique_violation THEN CONTINUE;
				WHEN others           THEN CONTINUE;
			END;
		END LOOP;
		----------------------------------------------------------------
	END LOOP;*/
	ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_audit;
   ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_trig;

END;
$$;

comment on function agree_x_33(varchar, varchar, integer, varchar, varchar) is 'Добавление/изменение тарифов точки учета из указанного филиала в базу централизованных/смешнных для указанного договора. Используется в agree_w(int, varchar, varchar), agree_x(varchar, int, varchar)';

alter function agree_x_33(varchar, varchar, integer, varchar, varchar) owner to pgsql;

