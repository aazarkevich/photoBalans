create function bee_docs_loss_add(agreeid integer, prefix integer, docnumber integer, docperiod date, docdate date, k_ens integer, k_rsk integer, k_all integer, t_ens character varying, t_rsk character varying, t_all character varying, s_ens character varying, s_rsk character varying, s_all character varying, usr character varying, _locid integer) returns integer
    language plpgsql
as
$$
/*
	add ito06 2016-04-20 добавили колонку locid
	Добавление записи в таблицу bee_docs_loss (потери РСК)
*/
DECLARE
	NR int = - 1;
	NR1 int = - 1;
	NR2 int = - 1;
	NR3 int = - 1;
BEGIN
     BEGIN
      	  INSERT INTO bee_docs 
                              (linkid,  pref,   docnum,    doctyp, docdat,  docvid, edit,  doc_tag) VALUES 
                              (agreeid, prefix, docnumber, 1730,   docperiod, NULL,   false, false) RETURNING rowid INTO NR;
          IF NR IS NULL THEN NR =-2; END IF;
          IF NR > 0 
             THEN
                 --add ito06 2016-04-20
                 INSERT INTO bee_docs_loss 
                             (linkid1, linkid2, period,    docdat, docnum,    loss_typ, loss_kvt, loss_tarif,           loss_sum,             userid, locid) VALUES 
                             (agreeid, NR,      docperiod, docdate,docnumber, 1731,     k_ens,    t_ens::numeric(13,11),s_ens::numeric(12,2), usr,   _locid) 
		 RETURNING rowid INTO NR1;

                 INSERT INTO bee_docs_loss 
                             (linkid1, linkid2, period,    docdat,  docnum,    loss_typ, loss_kvt, loss_tarif,           loss_sum,             userid, locid) VALUES 
                             (agreeid, NR,      docperiod, docdate, docnumber, 1732,     k_rsk,    t_rsk::numeric(13,11), s_rsk::numeric(12,2), usr,   _locid)
                 RETURNING rowid INTO NR2; 

                          
                 INSERT INTO bee_docs_loss 
                             (linkid1, linkid2, period,    docdat,  docnum,    loss_typ, loss_kvt, loss_tarif,           loss_sum,             userid, locid) VALUES 
                             (agreeid, NR,      docperiod, docdate, docnumber, 1733,     k_all,    t_all::numeric(13,11), s_all::numeric(12,2),usr,   _locid) 
                 RETURNING rowid INTO NR3;

          END IF;                            
     EXCEPTION
               WHEN UNIQUE_VIOLATION THEN
               RETURN -1;
   END;
   RETURN NR;
END;
$$;

comment on function bee_docs_loss_add(integer, integer, integer, date, date, integer, integer, integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer) is 'Ввод нагрузочных потерь. Используется в LossRSK.java, AppUtils.java';

alter function bee_docs_loss_add(integer, integer, integer, date, date, integer, integer, integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer) owner to pgsql;

