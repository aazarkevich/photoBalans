create function bee_rep21_get_rdo977(locid integer, start_date date, end_date date, n integer) returns SETOF bee_repakt7_rdo
    language sql
as
$$
/*
ito06 2012-02-02
Сводный баланс за период
*/
SELECT 
  gis.objcode AS code,
  sum(rdo.valman::numeric) AS valman
FROM  bee_rep_get_dats_for13($2,$3) AS dats 

  JOIN tmp_gis_traces_for_rep21 AS gis ON dats IS NOT NULL
  JOIN tmp_gis_traces_for_rep21 AS gis_child ON gis.objcode = gis_child.objowner OR gis_child.objcode = gis.objcode
  JOIN regdevconn AS rdc ON rdc.traceid = gis_child.rowid
  JOIN agreeregdev AS ard ON ard.linkid = rdc.pointid AND ard.paramid=189 AND ard.paramval='432'
  JOIN regdevoper977  AS rdo ON rdo.linkid = ard.linkid
  JOIN agreepoint AS apn ON apn.rowid = ard.linkid
  JOIN agreement AS amn ON amn.rowid = apn.linkid
  WHERE
    amn.locid IN(SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1)) AND
    gis.objtype = 11 AND 
    gis.objowner IN(select objcode FROM gis_traces WHERE objtype IN(9,8,1000)) AND
    rdo.operdate BETWEEN dats.dats[$4][1] AND dats.dats[$4][2] AND
    rdo.paramid = 407 AND
    rdo.valman ~ E'^[\\d{1,},\\-]' AND
    rdo.valman <> '-'
  GROUP BY code
$$;

comment on function bee_rep21_get_rdo977(integer, date, date, integer) is 'Сводный баланс за период. Используется в bee_rep_get_repdata21_nat977(int, date, date, boolean, boolean)';

alter function bee_rep21_get_rdo977(integer, date, date, integer) owner to pgsql;

