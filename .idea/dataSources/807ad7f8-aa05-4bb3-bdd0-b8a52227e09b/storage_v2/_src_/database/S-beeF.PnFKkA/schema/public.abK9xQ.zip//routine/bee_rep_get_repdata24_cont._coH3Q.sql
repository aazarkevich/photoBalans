create function bee_rep_get_repdata24_cont(loc_id integer, start_d date, end_d date) returns SETOF bee_repdata24
    language sql
as
$$
    /*
        add ito06 2013-12-11
        add ito06 2013-10-21
        ito06 2012-02-10:Ведомость по объему услуг	
    */
--11 потребление за отчётный период (1.1.1)
	(SELECT 
		11 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-01'		 						AS dat,
		'1.1.1' 								AS "n/n",
		'1.1.1' 								AS "n/n_tmp",
		'потребление за отчётный период' 					AS name,
		null::text 								AS doc_name,
		sum(tar_vn.summ) 							AS tar_vn,
		sum(tar_sn1.summ) 							AS tar_sn1,
		sum(tar_sn2.summ) 							AS tar_sn2,
		sum(tar_nn.summ) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
			    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null 
		END::numeric(12,6)							AS tar_m_tot,		    
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2] 									AS nn_sum
          FROM (SELECT 1)    AS a
     LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=139
     LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=140
     LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=141
     LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=138
              ,bee_rep_get_repdata24_tmp1(139,$2,$3,$1) AS vn 
              ,bee_rep_get_repdata24_tmp1(140,$2,$3,$1) AS sn1
              ,bee_rep_get_repdata24_tmp1(141,$2,$3,$1) AS sn2 
              ,bee_rep_get_repdata24_tmp1(138,$2,$3,$1) AS nn
        GROUP BY nn,vn,sn1,sn2)
 
UNION -- 11 корректировка  (1.1.2)
	(SELECT
		11 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
		                 WHEN sn1.period IS NULL
				     THEN CASE 
		                              WHEN sn2.period IS NULL
			                          THEN nn.period
			                      ELSE sn2.period
		                          END
		                 ELSE sn1.period
		             END
	             ELSE vn.period
		END 									AS dat,
		'1.1.2' 								AS "n/n",
		'1.1.2' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
		        THEN CASE
			         WHEN sn1.period IS NULL
			             THEN CASE
			 	              WHEN sn2.period IS NULL
				                  THEN to_char(nn.period,'YYYY-MM')
				           ELSE to_char(sn2.period,'YYYY-MM')
			                END
			         ELSE to_char(sn1.period,'YYYY-MM')
			      END
		     ELSE to_char(vn.period,'YYYY-MM')
		END 									AS name,
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount 								AS sn1_amount,
		sn2.amount 								AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr1(139,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr1(140,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr1(141,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr1(138,$2,$3,$1) AS nn USING (period)
          WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
                (sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION -- 11 плата за мощность (1.2.1.1)
	(SELECT
		12 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-01'  								AS dat,
		'1.2.1.1'  								AS "n/n",
		'1.2.1.1'  								AS "n/n_tmp",
		' -плата за мощность (руб.кВт*мес)' 					AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ) 							AS tar_vn,
		sum(tar_sn1.summ) 							AS tar_sn1,
		sum(tar_sn2.summ) 							AS tar_sn2,
		sum(tar_nn.summ) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
		        THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
		            /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6)  							AS tar_m_vn,
		sn1[3]::numeric(12,6)  							AS tar_m_sn1,
		sn2[3]::numeric(12,6)  							AS tar_m_sn2,
		nn[3]::numeric(12,6)   							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1]   								AS vn_amount,
		sn1[1]   								AS sn1_amount,
		sn2[1]   								AS sn2_amount,
		nn[1]  									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2] AS vn_sum,
		sn1[2] AS sn1_sum,
		sn2[2] AS sn2_sum,
		nn[2] AS nn_sum
	    FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=142
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=144
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=147
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=148
	       ,bee_rep_get_repdata24_tmp1(142,$2,$3,$1) AS vn 
	       ,bee_rep_get_repdata24_tmp1(144,$2,$3,$1) AS sn1
	       ,bee_rep_get_repdata24_tmp1(147,$2,$3,$1) AS sn2 
	       ,bee_rep_get_repdata24_tmp1(148,$2,$3,$1) AS nn
	  GROUP BY nn,vn,sn1,sn2)
UNION -- 12 корректировка (1.2.1.2)
	(SELECT
		12 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
		        THEN CASE
		                 WHEN sn1.period IS NULL
			             THEN CASE
			                      WHEN sn2.period IS NULL
				                  THEN nn.period
				              ELSE sn2.period
			                  END
			         ELSE sn1.period
			     END
		    ELSE vn.period
		END 									AS dat,
		'1.2.1.2' 								AS "n/n",
		'1.2.1.2' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
			         WHEN sn1.period IS NULL
			             THEN CASE
				              WHEN sn2.period IS NULL
				                  THEN to_char(nn.period,'YYYY-MM')
				              ELSE to_char(sn2.period,'YYYY-MM')
			                  END
			         ELSE to_char(sn1.period,'YYYY-MM')
			     END
		    ELSE to_char(vn.period,'YYYY-MM')
		END 									AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric  								AS tar_sn2,
		null::numeric  								AS tar_nn,
		null::numeric(12,6)  							AS tar_m_tot,
		null::numeric(12,6)  							AS tar_m_vn,
		null::numeric(12,6)  							AS tar_m_sn1,
		null::numeric(12,6)  							AS tar_m_sn2,
		null::numeric(12,6)  							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount  								AS sn1_amount,
		sn2.amount  								AS sn2_amount,
		nn.amount  								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum  								AS vn_sum,
		sn1.sum  								AS sn1_sum,
		sn2.sum  								AS sn2_sum,
		nn.sum  								AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr1(142,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr1(144,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr1(147,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr1(148,$2,$3,$1) AS nn USING (period)
	  WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
	        (sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION -- 12 плата за энергию (1.2.1.3)
	(SELECT
		12 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-01' 								AS dat,
		'1.2.1.3' 								AS "n/n",
		'1.2.1.3' 								AS "n/n_tmp",
		' -плата за энергию' 							AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ) 							AS tar_vn,
		sum(tar_sn1.summ) 							AS tar_sn1,
		sum(tar_sn2.summ) 							AS tar_sn2,
		sum(tar_nn.summ) 							AS tar_nn,
		CASE
	            WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
	                THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
	                    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
	            ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1]  								AS sn1_amount,
		sn2[1]  								AS sn2_amount,
		nn[1]  									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2]  									AS vn_sum,
		sn1[2]  								AS sn1_sum,
		sn2[2]  								AS sn2_sum,
		nn[2] 									AS nn_sum
           FROM
	        (SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=143
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=145
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=146
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=149
	       ,bee_rep_get_repdata24_tmp1(143,$2,$3,$1) AS vn 
	       ,bee_rep_get_repdata24_tmp1(145,$2,$3,$1) AS sn1
	       ,bee_rep_get_repdata24_tmp1(146,$2,$3,$1) AS sn2 
	       ,bee_rep_get_repdata24_tmp1(149,$2,$3,$1) AS nn
	 GROUP BY nn,vn,sn1,sn2)
UNION -- 12 корректировка (1.2.1.4)
	(SELECT
		12 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
                                 WHEN sn1.period IS NULL
                                     THEN CASE
                                              WHEN sn2.period IS NULL
                                                  THEN nn.period
                                              ELSE sn2.period
                                          END
                                 ELSE sn1.period
                             END
                    ELSE vn.period
		END 									AS dat,  
		'1.2.1.4' 								AS "n/n",
		'1.2.1.4' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
                                 WHEN sn1.period IS NULL
				     THEN CASE
                                              WHEN sn2.period IS NULL
                                                  THEN to_char(nn.period,'YYYY-MM')
                                              ELSE to_char(sn2.period,'YYYY-MM')
                                          END
                                 ELSE to_char(sn1.period,'YYYY-MM')
                             END
                    ELSE to_char(vn.period,'YYYY-MM')
		END 									AS name,    
		null::text								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount							 	AS sn1_amount,
		sn2.amount							 	AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr1(143,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr1(145,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr1(146,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr1(149,$2,$3,$1) AS nn USING (period)
          WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
                (sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION -- 21 потребление за отчётный период (2.1.1)
	(SELECT
		21 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-01' 								AS dat,
		'2.1.1' 								AS "n/n",
		'2.1.1' 								AS "n/n_tmp",
		'потребление за отчётный период' 					AS name,    
		null::text								AS doc_name,
		sum(tar_vn.summ) 							AS tar_vn,
		sum(tar_sn1.summ) 							AS tar_sn1,
		sum(tar_sn2.summ) 							AS tar_sn2,
		sum(tar_nn.summ) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)/(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2] 									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=139
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=140
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=141
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=138
               ,bee_rep_get_repdata24_tmp2(139,$2,$3,$1) AS vn 
               ,bee_rep_get_repdata24_tmp2(140,$2,$3,$1) AS sn1
               ,bee_rep_get_repdata24_tmp2(141,$2,$3,$1) AS sn2 
               ,bee_rep_get_repdata24_tmp2(138,$2,$3,$1) AS nn
         GROUP BY nn,vn,sn1,sn2) 
UNION -- 21 корректировка (2.1.2)
	(SELECT
		21 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
				 WHEN sn1.period IS NULL
				     THEN CASE
                                              WHEN sn2.period IS NULL
                                                  THEN nn.period
                                              ELSE sn2.period
                                          END
                                  ELSE sn1.period
                             END
                    ELSE vn.period
		END 									AS dat,
		'2.1.2' 								AS "n/n",
		'2.1.2' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
		        THEN CASE
			         WHEN sn1.period IS NULL
			             THEN CASE
				              WHEN sn2.period IS NULL
				                  THEN to_char(nn.period,'YYYY-MM')
				              ELSE to_char(sn2.period,'YYYY-MM')
			                  END
			         ELSE to_char(sn1.period,'YYYY-MM')
			     END
		    ELSE to_char(vn.period,'YYYY-MM')
		END 									AS name,
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6)  							AS tar_m_sn2,
		null::numeric(12,6)  							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount  								AS sn1_amount,
		sn2.amount  								AS sn2_amount,
		nn.amount  								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum  								AS vn_sum,
		sn1.sum  								AS sn1_sum,
		sn2.sum  								AS sn2_sum,
		nn.sum  								AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr2(139,$2,$3,$1) AS vn  
      FULL JOIN bee_rep_get_repdata24_corr2(140,$2,$3,$1) AS sn1 USING (period) 
      FULL JOIN bee_rep_get_repdata24_corr2(141,$2,$3,$1) AS sn2 USING (period) 
      FULL JOIN bee_rep_get_repdata24_corr2(138,$2,$3,$1) AS nn USING (period))
UNION -- 22 плата за мощность (2.2.1.1)
	(SELECT
		22 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-01' 								AS dat,
		'2.2.1.1' 								AS "n/n",
		'2.2.1.1' 								AS "n/n_tmp",
		' -плата за мощность (руб.кВт*мес)' 					AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ) 							AS tar_vn,
		sum(tar_sn1.summ) 							AS tar_sn1,
		sum(tar_sn2.summ) 							AS tar_sn2,
		sum(tar_nn.summ) 							AS tar_nn,
		CASE
		WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
			    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2] 									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=142
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=144
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=147
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=148
	       ,bee_rep_get_repdata24_tmp2(142,$2,$3,$1) AS vn 
	       ,bee_rep_get_repdata24_tmp2(144,$2,$3,$1) AS sn1
	       ,bee_rep_get_repdata24_tmp2(147,$2,$3,$1) AS sn2 
	       ,bee_rep_get_repdata24_tmp2(148,$2,$3,$1) AS nn
	 GROUP BY nn,vn,sn1,sn2)
UNION -- 22 корректировка (2.2.1.2)
	(SELECT
		22 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
				 WHEN sn1.period IS NULL
				     THEN CASE
					      WHEN sn2.period IS NULL
						  THEN nn.period
					      ELSE sn2.period
                                          END
                                 ELSE sn1.period
                             END
		    ELSE vn.period
		END 									AS dat,
		'2.2.1.2'								AS "n/n",
		'2.2.1.2'								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
				 WHEN sn1.period IS NULL
				     THEN CASE
					      WHEN sn2.period IS NULL
						  THEN to_char(nn.period,'YYYY-MM')
			                      ELSE to_char(sn2.period,'YYYY-MM')
					  END
				 ELSE to_char(sn1.period,'YYYY-MM')
			     END
		    ELSE to_char(vn.period,'YYYY-MM')
		END 									AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) AS tar_m_tot,
		null::numeric(12,6) AS tar_m_vn,
		null::numeric(12,6) AS tar_m_sn1,
		null::numeric(12,6) AS tar_m_sn2,
		null::numeric(12,6) AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount 								AS sn1_amount,
		sn2.amount 								AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr2(142,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr2(144,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr2(147,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr2(148,$2,$3,$1) AS nn USING (period)
	  WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
	        (sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION -- 22 плата за энергию (2.2.1.3)
	(SELECT
		22 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-01' 								AS dat,
		'2.2.1.3' 								AS "n/n",
		'2.2.1.3' 								AS "n/n_tmp",
		' -плата за энергию' 							AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ) 							AS tar_vn,
		sum(tar_sn1.summ) 							AS tar_sn1,
		sum(tar_sn2.summ) 							AS tar_sn2,
		sum(tar_nn.summ) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
			    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2] 									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=143
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=145
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=146
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=149
	       ,bee_rep_get_repdata24_tmp2(143,$2,$3,$1) AS vn 
	       ,bee_rep_get_repdata24_tmp2(145,$2,$3,$1) AS sn1
	       ,bee_rep_get_repdata24_tmp2(146,$2,$3,$1) AS sn2 
	       ,bee_rep_get_repdata24_tmp2(149,$2,$3,$1) AS nn
	 GROUP BY nn,vn,sn1,sn2)
UNION -- 22 корректировка (2.2.1.4)
	(SELECT
		22 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
				 WHEN sn1.period IS NULL
				     THEN CASE
					      WHEN sn2.period IS NULL
				                  THEN nn.period
					      ELSE sn2.period
				          END
				 ELSE sn1.period
			     END
		    ELSE vn.period
		END 									AS dat,
		'2.2.1.4' 								AS "n/n",
		'2.2.1.4' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
			         WHEN sn1.period IS NULL
				     THEN CASE
				              WHEN sn2.period IS NULL
				                  THEN to_char(nn.period,'YYYY-MM')
				              ELSE to_char(sn2.period,'YYYY-MM')
			                  END
			          ELSE to_char(sn1.period,'YYYY-MM')
			      END
		    ELSE to_char(vn.period,'YYYY-MM')
		END 									AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount 								AS sn1_amount,
		sn2.amount 								AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr2(143,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr2(145,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr2(146,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr2(149,$2,$3,$1) AS nn USING (period)
	  WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
		(sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION -- 31 потребление за отчетный период (3.1.1)
	(SELECT
		31 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-01' 								AS dat,
		'3.1.1' 								AS "n/n",
		'3.1.1' 								AS "n/n_tmp",
		'потребление за отчетный период' 					AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2]									AS vn_sum,
		sn1[2]									AS sn1_sum,
		sn2[2]							 		AS sn2_sum,
		nn[2] 									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=150
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=156
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=154
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=155
	       ,bee_rep_get_repdata24_tmp3(150,$2,$3,$1) AS vn 
	       ,bee_rep_get_repdata24_tmp3(156,$2,$3,$1) AS sn1
	       ,bee_rep_get_repdata24_tmp3(154,$2,$3,$1) AS sn2 
	       ,bee_rep_get_repdata24_tmp3(155,$2,$3,$1) AS nn
	 WHERE (SELECT * FROM bee_rep_get_repdata24_corr_exists($1, $2,$3,150,156,154,155)) IS TRUE     
	 GROUP BY nn,vn,sn1,sn2)
		
UNION -- 31 потреблено в пределах социальной нормы (3.1.2)
	(SELECT
		31 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-02' 								AS dat,
		'3.1.2' 								AS "n/n",
		'3.1.2' 								AS "n/n_tmp",
		'потреблено в пределах социальной нормы' 				AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ) 							AS tar_vn,
		sum(tar_sn1.summ) 							AS tar_sn1,
		sum(tar_sn2.summ) 							AS tar_sn2,
		sum(tar_nn.summ) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
			    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2]									AS vn_sum,
		sn1[2]									AS sn1_sum,
		sn2[2]							 		AS sn2_sum,
		nn[2] 									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=150
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=156
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=154
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=155
	       ,bee_rep_get_repdata24_tmp3_norm(150,$2,$3,$1) AS vn 
	       ,bee_rep_get_repdata24_tmp3_norm(156,$2,$3,$1) AS sn1
	       ,bee_rep_get_repdata24_tmp3_norm(154,$2,$3,$1) AS sn2 
	       ,bee_rep_get_repdata24_tmp3_norm(155,$2,$3,$1) AS nn
	 GROUP BY nn,vn,sn1,sn2) 
UNION -- 31 потреблено сверх социальной нормы (3.1.3)
	(SELECT
		31 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-03' 								AS dat,
		'3.1.3'								AS "n/n",
		'3.1.3' 								AS "n/n_tmp",
		'потреблено сверх социальной нормы' 					AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ1) 							AS tar_vn,
		sum(tar_sn1.summ1) 							AS tar_sn1,
		sum(tar_sn2.summ1) 							AS tar_sn2,
		sum(tar_nn.summ1) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
			    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2]									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2] 									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=150
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=156
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=154
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=155
               ,bee_rep_get_repdata24_tmp3_snorm(150,$2,$3,$1) AS vn 
               ,bee_rep_get_repdata24_tmp3_snorm(156,$2,$3,$1) AS sn1
               ,bee_rep_get_repdata24_tmp3_snorm(154,$2,$3,$1) AS sn2 
               ,bee_rep_get_repdata24_tmp3_snorm(155,$2,$3,$1) AS nn
	 GROUP BY nn,vn,sn1,sn2) 
UNION -- 31 корректировка в пределах социальной нормы  (3.1.4)
	(SELECT
		31 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
			         WHEN sn1.period IS NULL
			             THEN CASE
				              WHEN sn2.period IS NULL
				                  THEN nn.period
				              ELSE sn2.period
			                  END
			         ELSE sn1.period
			     END
		    ELSE vn.period
		END 									AS dat,
		'3.1.4' 								AS "n/n",
		'3.1.4' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN  CASE
			         WHEN sn1.period IS NULL
			             THEN CASE
                		       	      WHEN sn2.period IS NULL
						  THEN to_char(nn.period,'YYYY-MM')
				              ELSE to_char(sn2.period,'YYYY-MM')
			                  END
			         ELSE to_char(sn1.period,'YYYY-MM')
			     END
		    ELSE to_char(vn.period,'YYYY-MM')
		END ||' в пределах соц нормы'						AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 							 	AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount 								AS sn1_amount,
		sn2.amount 								AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr3_norm(150,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr3_norm(156,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_norm(154,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_norm(155,$2,$3,$1) AS nn USING (period)
	  WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
		(sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION -- 31 корректировка  сверх социальной нормы (3.1.5)
	(SELECT
		31 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
			         WHEN sn1.period IS NULL
			             THEN CASE
				              WHEN sn2.period IS NULL
				                  THEN nn.period
				              ELSE sn2.period
			                  END
			         ELSE sn1.period
			     END
		    ELSE vn.period
		END 									AS dat,
		'3.1.5' 								AS "n/n",
		'3.1.5' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN  CASE
			         WHEN sn1.period IS NULL
			             THEN CASE
                		       	      WHEN sn2.period IS NULL
						  THEN to_char(nn.period,'YYYY-MM')
				              ELSE to_char(sn2.period,'YYYY-MM')
			                  END
			         ELSE to_char(sn1.period,'YYYY-MM')
			     END
		    ELSE to_char(vn.period,'YYYY-MM')
		END ||' сверх соц нормы'						AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 							 	AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount 								AS sn1_amount,
		sn2.amount 								AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr3_snorm(150,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr3_snorm(156,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_snorm(154,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_snorm(155,$2,$3,$1) AS nn USING (period)
	  WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
		(sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION -- 32 потребление за отчетный период (3.2.1)
	(SELECT
		32 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-01' 								AS dat,
		'3.2.1' 								AS "n/n",
		'3.2.1' 								AS "n/n_tmp",
		'потребление за отчетный период' 					AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2]								 	AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=152
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=159
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=157
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=158
               ,bee_rep_get_repdata24_tmp3(152,$2,$3,$1) AS vn 
               ,bee_rep_get_repdata24_tmp3(159,$2,$3,$1) AS sn1
               ,bee_rep_get_repdata24_tmp3(157,$2,$3,$1) AS sn2 
               ,bee_rep_get_repdata24_tmp3(158,$2,$3,$1) AS nn
	 WHERE (SELECT * FROM bee_rep_get_repdata24_corr_exists($1, $2,$3,152,159,157,158)) IS TRUE    
	 GROUP BY nn,vn,sn1,sn2)
UNION -- 32 потреблено в пределах социальной нормы (3.2.2)
	(SELECT
		32 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-02' 								AS dat,
		'3.2.2' 								AS "n/n",
		'3.2.2' 								AS "n/n_tmp",
		'потреблено в пределах социальной нормы' 				AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ) 							AS tar_vn,
		sum(tar_sn1.summ) 							AS tar_sn1,
		sum(tar_sn2.summ) 							AS tar_sn2,
		sum(tar_nn.summ) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
			    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2]								 	AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=152
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=159
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=157
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=158
               ,bee_rep_get_repdata24_tmp3_norm(152,$2,$3,$1) AS vn 
               ,bee_rep_get_repdata24_tmp3_norm(159,$2,$3,$1) AS sn1
               ,bee_rep_get_repdata24_tmp3_norm(157,$2,$3,$1) AS sn2 
               ,bee_rep_get_repdata24_tmp3_norm(158,$2,$3,$1) AS nn
	 GROUP BY nn,vn,sn1,sn2)
UNION -- 32 потреблено сверх социальной нормы (3.2.3)
	(SELECT
		32 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-03' 								AS dat,
		'3.2.3' 								AS "n/n",
		'3.2.3' 								AS "n/n_tmp",
		'потреблено сверх социальной нормы' 					AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ1) 							AS tar_vn,
		sum(tar_sn1.summ1) 							AS tar_sn1,
		sum(tar_sn2.summ1) 							AS tar_sn2,
		sum(tar_nn.summ1) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
			    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6)							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2]									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=152
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=159
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=157
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=158
	       ,bee_rep_get_repdata24_tmp3_snorm(152,$2,$3,$1) AS vn 
	       ,bee_rep_get_repdata24_tmp3_snorm(159,$2,$3,$1) AS sn1
	       ,bee_rep_get_repdata24_tmp3_snorm(157,$2,$3,$1) AS sn2 
	       ,bee_rep_get_repdata24_tmp3_snorm(158,$2,$3,$1) AS nn
	 GROUP BY nn,vn,sn1,sn2)
UNION -- 32 корректировка в пределах социальной нормы (3.2.4) 
	(SELECT
		32 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
				 WHEN sn1.period IS NULL
			             THEN CASE
				              WHEN sn2.period IS NULL
				                  THEN nn.period
				              ELSE sn2.period
			                  END
				 ELSE sn1.period
			      END
		    ELSE vn.period
		END									AS dat,
		'3.2.4' 								AS "n/n",
		'3.2.4' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
				 WHEN sn1.period IS NULL
				      THEN CASE
				              WHEN sn2.period IS NULL
						  THEN to_char(nn.period,'YYYY-MM')
					      ELSE to_char(sn2.period,'YYYY-MM')
					   END
				 ELSE to_char(sn1.period,'YYYY-MM')
			END
		    ELSE to_char(vn.period,'YYYY-MM')
		END ||' в пределах соц нормы'						AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount 								AS sn1_amount,
		sn2.amount 								AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr3_norm(152,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr3_norm(159,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_norm(157,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_norm(158,$2,$3,$1) AS nn USING (period)
	 WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
	       (sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION -- 32 корректировка сверх социальной нормы (3.2.5)
	(SELECT
		32 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
				 WHEN sn1.period IS NULL
			             THEN CASE
				              WHEN sn2.period IS NULL
				                  THEN nn.period
				              ELSE sn2.period
			                  END
				 ELSE sn1.period
			      END
		    ELSE vn.period
		END									AS dat,
		'3.2.5' 								AS "n/n",
		'3.2.5' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
				 WHEN sn1.period IS NULL
				      THEN CASE
				              WHEN sn2.period IS NULL
						  THEN to_char(nn.period,'YYYY-MM')
					      ELSE to_char(sn2.period,'YYYY-MM')
					   END
				 ELSE to_char(sn1.period,'YYYY-MM')
			END
		    ELSE to_char(vn.period,'YYYY-MM')
		END ||' сверх соц нормы'						AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount 								AS vn_amount,
		sn1.amount 								AS sn1_amount,
		sn2.amount 								AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr3_snorm(152,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr3_snorm(159,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_snorm(157,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_snorm(158,$2,$3,$1) AS nn USING (period)
	 WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
	       (sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION -- 33 потребление за отчетный период (3.3.1)
	(SELECT
		33 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-01' 								AS dat,
		'3.3.1' 								AS "n/n",
		'3.3.1' 								AS "n/n_tmp",
		'потребление за отчетный период' 					AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6) 							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2] 									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=153
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=162
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=160
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=161
	        ,bee_rep_get_repdata24_tmp3(153,$2,$3,$1) AS vn 
	        ,bee_rep_get_repdata24_tmp3(162,$2,$3,$1) AS sn1
	        ,bee_rep_get_repdata24_tmp3(160,$2,$3,$1) AS sn2 
	        ,bee_rep_get_repdata24_tmp3(161,$2,$3,$1) AS nn
	 WHERE (SELECT * FROM bee_rep_get_repdata24_corr_exists($1, $2,$3,153,162,160,161)) IS TRUE    

	  GROUP BY nn,vn,sn1,sn2)
UNION -- 33 потреблено в пределах социальной нормы (3.3.2)
	(SELECT
		33 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-02' 								AS dat,
		'3.3.2' 								AS "n/n",
		'3.3.2' 								AS "n/n_tmp",
		'потреблено в пределах социальной нормы' 				AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ) 							AS tar_vn,
		sum(tar_sn1.summ) 							AS tar_sn1,
		sum(tar_sn2.summ) 							AS tar_sn2,
		sum(tar_nn.summ) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
			    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2] 									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=153
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=162
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=160
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=161
	        ,bee_rep_get_repdata24_tmp3_norm(153,$2,$3,$1) AS vn 
	        ,bee_rep_get_repdata24_tmp3_norm(162,$2,$3,$1) AS sn1
	        ,bee_rep_get_repdata24_tmp3_norm(160,$2,$3,$1) AS sn2 
	        ,bee_rep_get_repdata24_tmp3_norm(161,$2,$3,$1) AS nn
	  GROUP BY nn,vn,sn1,sn2)
UNION -- 33 потреблено сверх социальной нормы (3.3.3)
	(SELECT
		33 									AS grp,
		'norm'::text 								AS row_style,
		'1900-01-03' 								AS dat,
		'3.3.3' 								AS "n/n",
		'3.3.3' 								AS "n/n_tmp",
		'потреблено сверх социальной нормы' 					AS name,    
		null::text 								AS doc_name,
		sum(tar_vn.summ1) 							AS tar_vn,
		sum(tar_sn1.summ1) 							AS tar_sn1,
		sum(tar_sn2.summ1) 							AS tar_sn2,
		sum(tar_nn.summ1) 							AS tar_nn,
		CASE
		    WHEN (select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) <> 0
			THEN (select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a)
			    /(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a)
		    ELSE null
		END::numeric(12,6) 							AS tar_m_tot,
		vn[3]::numeric(12,6) 							AS tar_m_vn,
		sn1[3]::numeric(12,6) 							AS tar_m_sn1,
		sn2[3]::numeric(12,6) 							AS tar_m_sn2,
		nn[3]::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn[1],sn1[1],sn2[1],nn[1]]) AS a) 	AS tot_amount,
		vn[1] 									AS vn_amount,
		sn1[1] 									AS sn1_amount,
		sn2[1] 									AS sn2_amount,
		nn[1] 									AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn[2],sn1[2],sn2[2],nn[2]]) AS a) 	AS tot_sum,
		vn[2] 									AS vn_sum,
		sn1[2] 									AS sn1_sum,
		sn2[2] 									AS sn2_sum,
		nn[2] 									AS nn_sum
	   FROM
		(SELECT 1) AS a
      LEFT JOIN dic_tarif_sum AS tar_vn ON tar_vn.period = $2 AND tar_vn.tarifid=153
      LEFT JOIN dic_tarif_sum AS tar_sn1 ON tar_sn1.period = $2 AND tar_sn1.tarifid=162
      LEFT JOIN dic_tarif_sum AS tar_sn2 ON tar_sn2.period = $2 AND tar_sn2.tarifid=160
      LEFT JOIN dic_tarif_sum AS tar_nn ON tar_nn.period = $2 AND tar_nn.tarifid=161
	       ,bee_rep_get_repdata24_tmp3_snorm(153,$2,$3,$1) AS vn 
	       ,bee_rep_get_repdata24_tmp3_snorm(162,$2,$3,$1) AS sn1
	       ,bee_rep_get_repdata24_tmp3_snorm(160,$2,$3,$1) AS sn2 
	       ,bee_rep_get_repdata24_tmp3_snorm(161,$2,$3,$1) AS nn
	 GROUP BY nn,vn,sn1,sn2)
UNION --корректировка 33 пределах соц. нормы (3.3.5)
	(SELECT
		33 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
                                 WHEN sn1.period IS NULL
                                     THEN CASE
                                              WHEN sn2.period IS NULL
                                                  THEN nn.period
                                              ELSE sn2.period
                                          END
                                 ELSE sn1.period
                             END
		    ELSE vn.period
		END 									AS dat,
		'3.3.4'								 	AS "n/n",
		'3.3.4' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
		                 WHEN sn1.period IS NULL
		                     THEN CASE
			                      WHEN sn2.period IS NULL
			                          THEN to_char(nn.period,'YYYY-MM')
			                      ELSE to_char(sn2.period,'YYYY-MM')
		                          END
		                 ELSE to_char(sn1.period,'YYYY-MM')
		              END
		    ELSE to_char(vn.period,'YYYY-MM')
		END ||' в пределах соц нормы'						AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6)							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount								AS vn_amount,
		sn1.amount 								AS sn1_amount,
		sn2.amount 								AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr3_norm(153,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr3_norm(162,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_norm(160,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_norm(161,$2,$3,$1) AS nn USING (period)
	  WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
	        (sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL))
UNION --корректировка 33 сверх соц. нормы (3.3.5)
	(SELECT
		33 									AS grp,
		'norm'::text 								AS row_style,
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
                                 WHEN sn1.period IS NULL
                                     THEN CASE
                                              WHEN sn2.period IS NULL
                                                  THEN nn.period
                                              ELSE sn2.period
                                          END
                                 ELSE sn1.period
                             END
		    ELSE vn.period
		END 									AS dat,
		'3.3.5'								 	AS "n/n",
		'3.3.5' 								AS "n/n_tmp",
		'корректировка за '||
		CASE
		    WHEN vn.period IS NULL
			THEN CASE
		                 WHEN sn1.period IS NULL
		                     THEN CASE
			                      WHEN sn2.period IS NULL
			                          THEN to_char(nn.period,'YYYY-MM')
			                      ELSE to_char(sn2.period,'YYYY-MM')
		                          END
		                 ELSE to_char(sn1.period,'YYYY-MM')
		              END
		    ELSE to_char(vn.period,'YYYY-MM')
		END ||' сверх соц нормы'						AS name,    
		null::text 								AS doc_name,
		null::numeric 								AS tar_vn,
		null::numeric 								AS tar_sn1,
		null::numeric 								AS tar_sn2,
		null::numeric 								AS tar_nn,
		null::numeric(12,6)							AS tar_m_tot,
		null::numeric(12,6) 							AS tar_m_vn,
		null::numeric(12,6) 							AS tar_m_sn1,
		null::numeric(12,6) 							AS tar_m_sn2,
		null::numeric(12,6) 							AS tar_m_nn,
		(select sum (a) from unnest(ARRAY[vn.amount,sn1.amount,sn2.amount,nn.amount]) AS a) AS tot_amount,
		vn.amount								AS vn_amount,
		sn1.amount 								AS sn1_amount,
		sn2.amount 								AS sn2_amount,
		nn.amount 								AS nn_amount,
		(select sum (a) from unnest(ARRAY[vn.sum,sn1.sum,sn2.sum,nn.sum]) AS a) AS tot_sum,
		vn.sum 									AS vn_sum,
		sn1.sum 								AS sn1_sum,
		sn2.sum 								AS sn2_sum,
		nn.sum 									AS nn_sum
	   FROM
		bee_rep_get_repdata24_corr3_snorm(153,$2,$3,$1) AS vn 
      FULL JOIN bee_rep_get_repdata24_corr3_snorm(162,$2,$3,$1) AS sn1 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_snorm(160,$2,$3,$1) AS sn2 USING (period)
      FULL JOIN bee_rep_get_repdata24_corr3_snorm(161,$2,$3,$1) AS nn USING (period)
	  WHERE (vn.m_tar IS NOT NULL) OR (sn1.m_tar IS NOT NULL) OR 
	        (sn2.m_tar IS NOT NULL) OR (nn.m_tar IS NOT NULL)) 
ORDER BY "n/n";
$$;

comment on function bee_rep_get_repdata24_cont(integer, date, date) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24(int, date, date), bee_rep_get_repdata24_all(int, date, date) bee_rep_get_repdata24_cont1(int, date, date), bee_rep_get_repdata24_cont3(int, date, date), bee_rep_get_repdata24_cont_cust(int, date, date), bee_rep_get_repdata24_cont_tot(int, date, date), bee_rep_get_repdata24_corr(int, date, date), bee_rep_get_repdata24_corr_all(int, date, date),bee_rep_get_repdata24_corr_tot(int, date, date), bee_rep_get_repdata24_tot(int, date, date)';

alter function bee_rep_get_repdata24_cont(integer, date, date) owner to pgsql;

