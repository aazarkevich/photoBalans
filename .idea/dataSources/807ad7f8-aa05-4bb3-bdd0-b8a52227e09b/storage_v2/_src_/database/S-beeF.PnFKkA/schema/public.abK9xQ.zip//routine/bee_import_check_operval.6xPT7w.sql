create function bee_import_check_operval(paramvals character varying) returns character varying
    language plpgsql
as
$$
DECLARE
   -- paramvals = 'locid,code_des,  fio  ,docnumber,docdate,account,prodnumber';
   vals text[];
   rowKey integer;   
BEGIN
   vals = string_to_array(paramvals,',');
   --****************************************
   IF array_upper(vals,1) <> 7 THEN
      --RAISE NOTICE '>>>%===%',vals, array_upper(vals,1);
      RETURN 'fields';
   END IF; 
   --****************************************
   IF NOT (EXISTS (SELECT locid FROM customer 
      WHERE locid = vals[1]::integer)) THEN
      RETURN 'locid';
   END IF;
   --
   IF NOT (EXISTS (SELECT 1 FROM customer 
      WHERE locid = vals[1]::integer AND 
            code_des = vals[2])) THEN
      RETURN 'code_des';
   END IF; 
   --
   -- vals[3] fio  
   -- 
   rowKey = (SELECT abo_code FROM customer 
             WHERE locid = vals[1]::integer AND 
                   code_des = vals[2] LIMIT 1);

   IF NOT (EXISTS (SELECT 1 FROM agreement 
      WHERE locid = vals[1]::integer AND 
            abo_code = rowKey AND 
            docnumber = vals[4])) THEN
      RETURN 'docnumber';
   END IF; 
   --
   IF vals[5] NOT LIKE '____-__-__' THEN
      RETURN 'docdate-';
   END IF; 
   --
   IF NOT (EXISTS (SELECT 1 FROM agreement 
      WHERE 
          locid     = vals[1]::integer AND 
          abo_code  = rowKey AND 
          docnumber = vals[4] AND 
          docdate   = vals[5]::date)) 
          THEN
      RETURN 'docdate';
   END IF; 
   --
   rowKey = (SELECT rowid FROM agreement WHERE 
             locid     = vals[1]::integer AND 
             abo_code  = rowKey AND 
             docnumber = vals[4] AND 
             docdate   = vals[5]::date LIMIT 1);

   IF NOT (EXISTS (SELECT 1 FROM agreepoint 
      WHERE linkid  = rowKey AND 
            account = vals[6])) THEN
      RETURN 'account';
   END IF; 
   --
   IF NOT (EXISTS (SELECT 1 FROM agreepoint 
      WHERE 
         linkid     = rowKey AND 
         account    = vals[6] AND 
         prodnumber = vals[7])) THEN
      RETURN 'prodnumber';
   END IF; 
   --
   IF vals[8] NOT LIKE '____-__-__' THEN
      RETURN 'operdate';
   END IF; 

   IF vals[9] !~ E'^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$' THEN
      RETURN 'operval';
   END IF; 

   RETURN 'OK';
   -- 
END;
$$;

alter function bee_import_check_operval(varchar) owner to pgsql;

