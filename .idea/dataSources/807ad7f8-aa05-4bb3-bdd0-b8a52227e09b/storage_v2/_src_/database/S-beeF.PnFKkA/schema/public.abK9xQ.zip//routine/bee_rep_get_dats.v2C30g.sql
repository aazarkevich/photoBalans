create function bee_rep_get_dats(str_date date, end_date date) returns bee_rep_dats_tab
    cost 1000
    language plpgsql
as
$$
/*
ito06 2011
*/
 DECLARE
   dats date[][] ='{{null,null},{null,null},{null,null},{null,null},{null,null},{null,null},'||
                    '{null,null},{null,null},{null,null},{null,null},{null,null},{null,null},'||
                    '{null,null}}';
   tmp_date1 date;
   tmp_date2 date;
   start_date date=(to_char(str_date,'YYYY-MM') || '-01')::date;
   end_dat date=(to_char(end_date,'YYYY-MM') || '-01')::date + '1 month'::interval - '1 day'::interval;
   result bee_rep_dats_tab%ROWTYPE;
   n integer;
 BEGIN
   FOR i IN 1..13 LOOP
     tmp_date1 = (end_dat + '1 day'::interval) - (i || ' month')::interval;
     tmp_date2 = tmp_date1 + '1 month'::interval - '1 day'::interval;
     IF tmp_date1>=start_date
       THEN
         dats[14-i][1] = tmp_date1;
         dats[14-i][2] = tmp_date2;
         n=i;
       ELSE
         EXIT;
     END IF;
   END LOOP;
   result.dats=dats;
   result.dat_not_null=n;   
   RETURN result;
 END;
$$;

comment on function bee_rep_get_dats(date, date) is 'Используется в RepAkt7.java, SessionBean1.java; bee_repakt7_get_rdo(date, date, int), bee_repakt7_get_rdo_975(date, date, int), bee_repakt7_get_rdo_for_last(date, date), bee_repakt7_get_rdo_for_last_975(date, date), bee_repakt7_get_vals(int, date, date, boolean), bee_repakt7_get_vals_975(int, date, date, boolean)';

alter function bee_rep_get_dats(date, date) owner to pgsql;

