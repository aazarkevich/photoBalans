create function bee_is_counter_head(pointid integer) returns boolean
    language plpgsql
as
$$
/*
	2011-07-21 by ito07
	Являетя ли данное устройство головным?
	pointid - код точки учёта по договору
	проверка наличия устройств ссылающихся на pointid 
*/
BEGIN


   RETURN EXISTS( SELECT rowid 
                    FROM agreepoint 
		    JOIN (SELECT paramval FROM agreeregdev_period WHERE paramid = 664) AS a1 ON a1.paramval = agreepoint.rowid::text
                   WHERE rowid = pointid
                   LIMIT 1);
	END;

$$;

comment on function bee_is_counter_head(integer) is 'Являетя ли данное устройство головным. Используется в LossDist.java, AppUtils.java';

alter function bee_is_counter_head(integer) owner to pgsql;

