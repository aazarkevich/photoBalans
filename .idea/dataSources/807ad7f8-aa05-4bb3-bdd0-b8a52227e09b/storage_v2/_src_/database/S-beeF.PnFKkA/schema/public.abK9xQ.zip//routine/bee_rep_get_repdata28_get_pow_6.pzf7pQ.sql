create function bee_rep_get_repdata28_get_pow_6(amn_rowid integer, year1 date) returns SETOF bee_rep_tab28_pow
    language plpgsql
as
$$
/*
ito06 2013-01-18 
Приложение 1а, смешанные данные с заполнение пустых ячеек средним - мощность
*/
DECLARE
  rec bee_rep_tab28_en%rowtype;
  sum numeric(13,4);
  coun integer;
  middle numeric(13,4);
  dat_sn date;
  dat_yst date;

BEGIN
FOR rec IN(SELECT * FROM bee_rep_get_repdata28_get_pow_5($1,$2))
    LOOP
        SELECT  paramval 
          FROM  agreeregdev 
         WHERE  linkid = rec.pointid
           AND  paramid = 690
           AND  is_date(paramval)
           AND length(paramval) > 9
          INTO dat_sn;
          
           IF dat_sn IS NULL THEN dat_sn = to_char($2,'YYYY-12-01')::date;
         END IF;
           
        SELECT  paramval 
          FROM  agreeregdev 
         WHERE  linkid = rec.pointid
           AND  paramid = 154
           AND  is_date(paramval)
           AND length(paramval) > 9
          INTO dat_yst;

            IF dat_yst IS NULL THEN dat_yst = to_char($2,'YYYY-01-01')::date;
           END IF;
        
        IF rec.sum IS NULL OR rec.sum=0 
        THEN
		RETURN NEXT rec;
	ELSE
		sum=rec.sum;
		coun=0;
		middle=0;

		IF rec.m_1 IS NOT NULL AND rec.m_1<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_2 IS NOT NULL AND rec.m_2<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_3 IS NOT NULL AND rec.m_3<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_4 IS NOT NULL AND rec.m_4<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_5 IS NOT NULL AND rec.m_5<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_6 IS NOT NULL AND rec.m_6<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_7 IS NOT NULL AND rec.m_7<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_8 IS NOT NULL AND rec.m_8<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_9 IS NOT NULL AND rec.m_9<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_10 IS NOT NULL AND rec.m_10<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_11 IS NOT NULL AND rec.m_11<>0
		   THEN coun=coun+1;
		END IF;

		IF rec.m_12 IS NOT NULL AND rec.m_12<>0
		   THEN coun=coun+1;
		END IF;
		
		IF coun<12 THEN
			middle=rec.sum/coun;

			IF (rec.m_1 IS NULL OR rec.m_1=0) AND  dat_sn >= to_char($2,'YYYY-01-01')::date 
			                                  AND  dat_yst <= to_char($2,'YYYY-01-01')::date 
			   THEN rec.m_1=middle;
			END IF;

			IF (rec.m_2 IS NULL OR rec.m_2=0) AND dat_sn >= to_char($2,'YYYY-02-01')::date
							  AND dat_yst <= to_char($2,'YYYY-02-01')::date 
			   THEN  rec.m_2=middle;
			END IF;

			IF (rec.m_3 IS NULL OR rec.m_3=0) AND dat_sn >= to_char($2,'YYYY-03-01')::date
							  AND dat_yst <= to_char($2,'YYYY-03-01')::date
			   THEN rec.m_3=middle;
			END IF;

			IF (rec.m_4 IS NULL OR rec.m_4=0) AND dat_sn >= to_char($2,'YYYY-04-01')::date
							  AND dat_yst <= to_char($2,'YYYY-04-01')::date
			   THEN rec.m_4=middle;
			END IF;

			IF (rec.m_5 IS NULL OR rec.m_5=0) AND dat_sn >= to_char($2,'YYYY-05-01')::date
							  AND dat_yst <= to_char($2,'YYYY-05-01')::date
			   THEN rec.m_5=middle;
			END IF;

			IF (rec.m_6 IS NULL OR rec.m_6=0) AND dat_sn >= to_char($2,'YYYY-06-01')::date
							  AND  dat_yst <= to_char($2,'YYYY-06-01')::date
			   THEN rec.m_6=middle;
			END IF;

			IF (rec.m_7 IS NULL OR rec.m_7=0) AND dat_sn >= to_char($2,'YYYY-07-01')::date
							  AND dat_yst <= to_char($2,'YYYY-07-01')::date
			   THEN rec.m_7=middle;
			END IF;

			IF (rec.m_8 IS NULL OR rec.m_8=0) AND dat_sn >= to_char($2,'YYYY-08-01')::date
							  AND  dat_yst <= to_char($2,'YYYY-08-01')::date
			   THEN rec.m_8=middle;
			END IF;
                        
			IF (rec.m_9 IS NULL OR rec.m_9=0) AND dat_sn >= to_char($2,'YYYY-09-01')::date
							  AND dat_yst <= to_char($2,'YYYY-09-01')::date
			   THEN  rec.m_9=middle;
			END IF;
		        
			IF (rec.m_10 IS NULL OR rec.m_10=0) AND dat_sn >= to_char($2,'YYYY-10-01')::date
							  AND  dat_yst <= to_char($2,'YYYY-10-01')::date
			   THEN rec.m_10=middle;
			END IF;

			IF (rec.m_11 IS NULL OR rec.m_11=0) AND dat_sn >= to_char($2,'YYYY-11-01')::date
							    AND dat_yst <= to_char($2,'YYYY-11-01')::date
			   THEN  rec.m_11=middle;
			END IF;

			IF (rec.m_12 IS NULL OR rec.m_12=0) AND dat_sn >= to_char($2,'YYYY-12-01')::date
							    AND dat_yst <= to_char($2,'YYYY-12-01')::date
			   THEN rec.m_12=middle;
			END IF;   

			select sum(a) from  unnest(ARRAY[rec.m_1,rec.m_2,rec.m_3,rec.m_4,rec.m_5,rec.m_6,rec.m_7,rec.m_8,rec.m_9,rec.m_10,rec.m_11,rec.m_12])
                        AS a INTO rec.sum;  

			RETURN NEXT rec;
		ELSE 
		    RETURN NEXT rec;
		END IF;
	END IF;
   END LOOP;
 END;
$$;

comment on function bee_rep_get_repdata28_get_pow_6(integer, date) is 'Приложение 1а, смешанные данные с заполнение пустых ячеек средним - мощность. Используется в bee_rep_get_repdata28_get_pow(int, date, int), bee_rep_get_repdata28_get_pow_tot(int, date, int)';

alter function bee_rep_get_repdata28_get_pow_6(integer, date) owner to postgres;

