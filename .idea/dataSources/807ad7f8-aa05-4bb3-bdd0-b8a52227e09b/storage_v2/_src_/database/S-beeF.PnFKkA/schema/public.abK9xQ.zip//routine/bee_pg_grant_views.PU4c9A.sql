create function bee_pg_grant_views(schema_name character varying, login_name character varying) returns text
    language plpgsql
as
$$
declare
	rw record; 
	msg text;
	s_oid int;
	st varchar;
begin

select oid::int into s_oid from pg_namespace where lower(nspname) = lower(schema_name);
	raise notice 'schema oid: %', s_oid;
	raise notice 'login_name: %', login_name;

	for rw in  
		select --oid as ID, 
		--proname as Name --, oidvectortypes(proargtypes) as Arguments 
                viewname  
		from pg_views 
		where schemaname = $1 --s_oid and  prolang >16
	loop
		st:= rw.viewname; --|| '(' || rw.Arguments ||')';
		raise notice 'routine name: % ', st;
		--execute 'revoke all on function ' || st || ' from public';
		--execute 'revoke all on function ' || st || ' from group "' || login_name ||'"';
		execute 'grant all on table ' || st || ' to group "'|| login_name||'"';
	end loop;
	
	return s_oid::varchar ;
end;
$$;

alter function bee_pg_grant_views(varchar, varchar) owner to pgsql;

