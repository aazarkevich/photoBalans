create function bee_get_oper_regdevval(integer, integer) returns character varying
    language sql
as
$$
    -- 1 - pointid
  -- 2 - paramid
  -- 3 - operdate
  --
  --SELECT valman::numeric(12,3) FROM regdevoper 
  SELECT paramval FROM agreeregdev 
  WHERE 
     linkid   = $1 AND
     paramid  = $2
  ;
$$;

comment on function bee_get_oper_regdevval(integer, integer) is 'Используется в RepCreate5.java; bee_rep_get_repdata(int, date, date), bee_rep_get_repdata1(int, date, date), bee_rep_get_repdata11(int, date, date),  bee_rep_get_repdata4(int, date), bee_rep_get_repdata5(int, date, date),  bee_rep_get_repdata5_not0(int, date, date), bee_rep_get_repdata5_posit(int, date, date)';

alter function bee_get_oper_regdevval(integer, integer) owner to pgsql;

