create function bee_get_noregs_points_akt5_1(_locid integer, sdate character varying, edate character varying, v642 character varying) returns SETOF noregs_akt51
    language plpgsql
as
$$
/*	
	add ito06 2015-12-29 добавили колонку p195 (показания пред. съема) + из where убрали NOT IN select (для убыстрения)
	add ito07 2014-07-10 (_locid numeric -> _locid int)
	add ito06 2014-06-24
	add ito06 2014-06-02
	add ito06 2012-05-23 
	    ito05 - ПЕЧАТЬ АКТОВ СЪЁМА ПОКАЗАНИЙ ПРИБОРОВ УЧЁТА (ФИЗЛИЦА)
*/
DECLARE 
   	RowLine noregs_akt51%rowtype;
   
BEGIN
   IF (sdate = '2001-01-01' AND edate = '2001-01-01') THEN --ito06 2014-07-10
	FOR RowLine IN ( 
	        SELECT  null::text,
			null::text, 
			null::text, 
			null::text,
			null::text,
			null::text,
			null::text,
			null::text AS p150,
			null::text AS p155,
			null::text AS p156,
			null::text AS p417,
			null::text AS p640,
			null::text AS p642,
			null::text AS p690,
			null::text AS p715,
			null::text AS p723,
			null::text AS p851,
			null::text AS p970,
			null::text AS p971,
			null::text AS p1015,
			null::text AS p717,
			null::text AS p1410,
			null::text AS p1449,
			null::text AS p1443,
			null::text AS p1444,
			null::text AS p1445,
			null::text AS p168,
			null::text AS p641,
			null::text AS p195,
			null::date AS p194,
			null::text AS sb195,
			null::date AS sb194
		   FROM agreepoint LIMIT 1)
	LOOP
	      RETURN NEXT RowLine; 
	END LOOP;
    ELSE
	IF (v642::text = '%'::text) THEN
	    FOR RowLine IN ( 
                  SELECT
			customer.abo_code::text,
			agreepoint.rowid::text, 
			agreepoint.devid::text, 
			agreement.docnumber::text,
			agreepoint.account::text,
			agreepoint.prodnumber::text,
			customer.abo_name::text,
			COALESCE((select pchain from gis_traces where rowid = 
			(select traceid from regdevconn where pointid = agreepoint.rowid limit 1) limit 1), '''') AS pntp,
			(select element_name from dic_elements where rowid = agreepoint.devid limit 1) AS p35,
			(select element_name from dic_elements where rowid::text = (select paramval from agreeregdev_period 
				                                                     where linkid = p150.linkid and paramid = 150 and period = p150.period
				                                                   )::text) AS p150,
			p155.paramval::text AS p155,
			(select paramval from agreeregdev_period where linkid = p156.linkid and paramid = 156 and period = p156.period)::text AS p156,
			p417.paramval::text AS p417,
			p640.paramval::text AS p640,
			p642.paramval::text AS p642,
			p690.paramval::text AS p690,
			(select element_name from dic_elements where rowid::text = p715.paramval::text) AS p715,
			p723.paramval::text AS p723,
			(select paramval from agreeregdev_period where linkid = p851.linkid and paramid = 851 and period = p851.period)::text AS p851,
			(select paramval from agreeregdev_period where linkid = p970.linkid and paramid = 970 and period = p970.period)::text AS p970,
			p971.paramval::text AS p971,
			(select element_name from dic_elements where rowid::text = (select paramval from agreeregdev_period 
		                                                              where linkid = p1015.linkid and paramid = 1015 and period = p1015.period)::text) AS p1015,

			p717.paramval::text AS p717,
			p1410.paramval::text AS p1410,
			p1449.paramval::text AS p1449,		

			p1443.paramval::text AS p1443,
			p1444.paramval::text AS p1444,
			p1445.paramval::text AS p1445,		

			p168.paramval::text AS p168,
			p641.paramval::text AS p641,
			
			p195.valman::text AS sb195, --2015-12-29
			p194.valman::date AS p194,

			sb195.valman::text AS sb195,
			sb194.valman::date AS sb194
		 
	           FROM agreepoint
		   JOIN agreement ON agreepoint.linkid  = agreement.rowid
		   JOIN customer  ON agreement.abo_code = customer.abo_code 

	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 150 group by linkid) AS p150 ON agreepoint.rowid = p150.linkid
	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 155) AS p155 ON agreepoint.rowid = p155.linkid

	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 156 group by linkid) AS p156 ON agreepoint.rowid = p156.linkid
	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 417) AS p417 ON agreepoint.rowid = p417.linkid
	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 640) AS p640 ON agreepoint.rowid = p640.linkid
	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 642) AS p642 ON agreepoint.rowid = p642.linkid
	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 690) AS p690 ON agreepoint.rowid = p690.linkid
	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 715) AS p715 ON agreepoint.rowid = p715.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 723) AS p723 ON agreepoint.rowid = p723.linkid

  	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 851 group by linkid) AS p851 ON agreepoint.rowid = p851.linkid

  	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 970 group by linkid) AS p970 ON agreepoint.rowid = p970.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 971) AS p971 ON agreepoint.rowid = p971.linkid

  	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 1015 group by linkid) AS p1015 ON agreepoint.rowid = p1015.linkid

  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 717 ) AS p717  ON agreepoint.rowid = p717.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1410) AS p1410 ON agreepoint.rowid = p1410.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1449) AS p1449 ON agreepoint.rowid = p1449.linkid

  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1443)  AS p1443 ON agreepoint.rowid = p1443.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1444)  AS p1444 ON agreepoint.rowid = p1444.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1445)  AS p1445 ON agreepoint.rowid = p1445.linkid
		 
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 168)  AS p168 ON agreepoint.rowid = p168.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 641)  AS p641 ON agreepoint.rowid = p641.linkid
  	      FULL JOIN (select r1.linkid, r1.valman, r1.operdate from regdevoper AS r1
				join (select linkid, max(operdate)  AS operdate from regdevoper
				       where paramid = 194 and operdate::date<=edate::date 
				       group by linkid
				     ) AS r2 on r1.linkid = r2.linkid and r1.operdate = r2.operdate
		            where paramid = 194 )  AS p194 ON agreepoint.rowid = p194.linkid
	      LEFT JOIN regdevoper  AS p195 ON p195.paramid = 195 AND agreepoint.rowid = p195.linkid AND p195.operdate = p194.operdate --2015-12-29

  	      /*LEFT JOIN (select r1.linkid, r1.valman from regdevoper975 AS r1
				join (select linkid, max(operdate)  AS operdate from regdevoper975
				       where paramid = 195 and operdate::date<=edate::date 
				       group by linkid
				     ) AS r2 on r1.linkid = r2.linkid and r1.operdate = r2.operdate
		            where paramid = 195 ) AS sb195 ON agreepoint.rowid = sb195.linkid*/
		            
  	      LEFT JOIN (select r1.linkid, r1.valman, r1.operdate from regdevoper975 AS r1
				join (select linkid, max(operdate)  AS operdate from regdevoper975
				       where paramid = 194 and operdate::date<=edate::date 
				       group by linkid
				     ) AS r2 on r1.linkid = r2.linkid and r1.operdate = r2.operdate
		            where paramid = 194 )  AS sb194 ON agreepoint.rowid = sb194.linkid   
	      LEFT JOIN regdevoper975  AS sb195 ON sb195.paramid = 195 AND agreepoint.rowid = sb195.linkid AND sb195.operdate = sb194.operdate --2015-12-29
	      LEFT JOIN regdevoper AS rdo ON agreepoint.rowid = rdo.linkid AND rdo.operdate::text BETWEEN ''|| sdate ||'' AND ''|| edate ||''  --2015-12-29	             
		 
	          WHERE
	                agreement.locid = _locid  AND
			agreement.valid       = TRUE AND
			agreement.docstatus   = 79   AND
			((p690.paramval IS NULL) OR (length(trim(p690.paramval)) < 4)) AND
			--2015-12-29 agreepoint.rowid NOT IN (SELECT linkid FROM regdevoper WHERE operdate::text BETWEEN ''|| sdate ||'' AND ''|| edate ||'')
			rdo.linkid IS NULL 
		  ORDER BY 5,6
	   )
	   LOOP
	      RETURN NEXT RowLine; 
	   END LOOP;
	ELSE
	   FOR RowLine IN ( 
		SELECT
			customer.abo_code::text,
			agreepoint.rowid::text, 
			agreepoint.devid::text, 
			agreement.docnumber::text,
			agreepoint.account::text,
			agreepoint.prodnumber::text,
			customer.abo_name::text,
			COALESCE((select pchain from gis_traces where rowid = 
			(select traceid from regdevconn where pointid = agreepoint.rowid limit 1) limit 1), '''') AS pntp,
			(select element_name from dic_elements where rowid = agreepoint.devid limit 1) AS p35,
			(select element_name from dic_elements where rowid::text = (select paramval from agreeregdev_period 
		                                         where linkid = p150.linkid and paramid = 150 and period = p150.period)::text) AS p150,
			p155.paramval::text AS p155,
			(select paramval from agreeregdev_period where linkid = p156.linkid and paramid = 156 and period = p156.period)::text AS p156,
			p417.paramval::text AS p417,
			p640.paramval::text AS p640,
			p642.paramval::text AS p642,
			p690.paramval::text AS p690,
			(select element_name from dic_elements where rowid::text = p715.paramval::text) AS p715,
			p723.paramval::text AS p723,
			(select paramval from agreeregdev_period where linkid = p851.linkid and paramid = 851 and period = p851.period)::text AS p851,
			(select paramval from agreeregdev_period where linkid = p970.linkid and paramid = 970 and period = p970.period)::text AS p970,
			p971.paramval::text AS p971,
			(select element_name from dic_elements where rowid::text = (select paramval from agreeregdev_period 
		                                      where linkid = p1015.linkid and paramid = 1015 and period = p1015.period)::text) AS p1015,

 
			p717.paramval::text AS p717,
			p1410.paramval::text AS p1410,
			p1449.paramval::text AS p1449,
		 
			p1443.paramval::text AS p1443,
			p1444.paramval::text AS p1444,
			p1445.paramval::text AS p1445,
		 
			p168.paramval::text AS p168,
			p641.paramval::text AS p641,
			p195.valman::text AS sb195, --2015-12-29
			p194.valman::date AS p194,
			sb195.valman::text AS sb195,
			sb194.valman::date AS sb194

	           FROM agreepoint
		   JOIN agreement ON agreepoint.linkid  = agreement.rowid
		   JOIN customer  ON agreement.abo_code = customer.abo_code 

  	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 150 group by linkid) AS p150 ON agreepoint.rowid = p150.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 155) AS p155 ON agreepoint.rowid = p155.linkid

  	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 156 group by linkid) AS p156 ON agreepoint.rowid = p156.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 417) AS p417 ON agreepoint.rowid = p417.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 640) AS p640 ON agreepoint.rowid = p640.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 642) AS p642 ON agreepoint.rowid = p642.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 690) AS p690 ON agreepoint.rowid = p690.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 715) AS p715 ON agreepoint.rowid = p715.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 723) AS p723 ON agreepoint.rowid = p723.linkid

  	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 851 group by linkid) AS p851 ON agreepoint.rowid = p851.linkid

  	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 970 group by linkid) AS p970 ON agreepoint.rowid = p970.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 971) AS p971 ON agreepoint.rowid = p971.linkid

  	      FULL JOIN (select linkid,max(period) as period from agreeregdev_period where paramid = 1015 group by linkid) AS p1015 ON agreepoint.rowid = p1015.linkid

  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 717 ) AS p717  ON agreepoint.rowid = p717.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1410) AS p1410 ON agreepoint.rowid = p1410.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1449) AS p1449 ON agreepoint.rowid = p1449.linkid

  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1443)  AS p1443 ON agreepoint.rowid = p1443.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1444)  AS p1444 ON agreepoint.rowid = p1444.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 1445)  AS p1445 ON agreepoint.rowid = p1445.linkid

  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 168)  AS p168 ON agreepoint.rowid = p168.linkid
  	      FULL JOIN (select linkid,paramval from agreeregdev where paramid = 641)  AS p641 ON agreepoint.rowid = p641.linkid

  	      FULL JOIN (select r1.linkid, r1.valman, r1.operdate from regdevoper AS r1
				join (select linkid, max(operdate)  AS operdate from regdevoper
				       where paramid = 194 and operdate::date <=  edate::date 
				       group by linkid
				     ) AS r2 on r1.linkid = r2.linkid and r1.operdate = r2.operdate
		            where paramid = 194 )  AS p194 ON agreepoint.rowid = p194.linkid

	      LEFT JOIN regdevoper  AS p195 ON p195.paramid = 195 AND agreepoint.rowid = p195.linkid AND p195.operdate = p194.operdate --2015-12-29

  	      /*LEFT JOIN (select r1.linkid, r1.valman from regdevoper975 AS r1
				join (select linkid, max(operdate)  AS operdate from regdevoper975
				       where paramid = 195 and operdate::date<=edate::date 
				       group by linkid
				     ) AS r2 on r1.linkid = r2.linkid and r1.operdate = r2.operdate
		            where paramid = 195 )  AS sb195 ON agreepoint.rowid = sb195.linkid*/
		            
  	      LEFT JOIN (select r1.linkid, r1.valman, r1.operdate from regdevoper975 AS r1
				join (select linkid, max(operdate)  AS operdate from regdevoper975
				       where paramid = 194 and operdate::date<=edate::date 
				       group by linkid
				     ) AS r2 on r1.linkid = r2.linkid and r1.operdate = r2.operdate
		            where paramid = 194 )  AS sb194 ON agreepoint.rowid = sb194.linkid 
		              
	      LEFT JOIN regdevoper975  AS sb195 ON sb195.paramid = 195 AND agreepoint.rowid = sb195.linkid AND sb195.operdate = sb194.operdate --2015-12-29
	      LEFT JOIN regdevoper AS rdo ON  agreepoint.rowid = rdo.linkid AND rdo.operdate::text BETWEEN ''|| sdate ||'' AND ''|| edate ||'' --2015-12-29
	      
		 
	           WHERE
	                agreement.locid = _locid   AND
			agreement.valid       = TRUE AND
			agreement.docstatus   = 79   AND
			((p690.paramval IS NULL) OR (length(trim(p690.paramval)) < 4)) AND
			
			-- 2015-12-29 agreepoint.rowid NOT IN (SELECT linkid FROM regdevoper WHERE operdate::text BETWEEN ''|| sdate ||'' AND ''|| edate ||'') AND
			rdo.linkid IS NULL AND
			p642.paramval ilike ''|| v642 ||''
	          ORDER BY 5,6
	   )
	   LOOP
	      RETURN NEXT RowLine; 
	   END LOOP;
	END IF; 
   END IF;
   RETURN;
END

$$;

comment on function bee_get_noregs_points_akt5_1(integer, varchar, varchar, varchar) is 'Печать актов съёма показаний приборов учёта (физлица). Используется в RepAkt5.java, SessionBean.java';

alter function bee_get_noregs_points_akt5_1(integer, varchar, varchar, varchar) owner to bee;

