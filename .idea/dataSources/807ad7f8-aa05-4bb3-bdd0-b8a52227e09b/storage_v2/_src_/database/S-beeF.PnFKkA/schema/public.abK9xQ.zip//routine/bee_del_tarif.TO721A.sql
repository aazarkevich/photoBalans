create function bee_del_tarif(pid integer, per date) returns integer
    language plpgsql
as
$$
/*
	add ito06 2019-11-12 Не удаляем тариф, если есть документ выставления
	ito06 2012-08-27 Удаление тарифа на точку учета
*/
DECLARE NR INTEGER =-1;
		bd_rid INTEGER =-1;

 BEGIN
 	NR = -1; 
	-- 2019-11-12
	select bd.rowid from bee_docs AS bd
		   join agreement AS amn ON amn.rowid = bd.linkid
		   join agreepoint as apn ON apn.linkid = amn.rowid 	   
		  where bd.doctyp = 1065 AND  bd.docdat >= per  AND apn.rowid = pid limit 1 INTO bd_rid;
	--**
	 IF bd_rid IS NOT NULL  --1 есть документ выставления?
	   THEN --1 да
	  		RETURN -1;
	   ELSE  --1 нет
	   	DELETE FROM agreepoint_tarif where pointid = pid and period = per RETURNING 1 INTO NR;
 			IF NR IS NOT NULL --2
    		THEN  RETURN 1;
 			ELSE RETURN -1;
 		END IF; --2
	 END IF; --1
	
END;
$$;

comment on function bee_del_tarif(integer, date) is 'Удаление тарифа на точку учета. Используется в TarifPoint.java, AppUtils.java';

alter function bee_del_tarif(integer, date) owner to pgsql;

