create function bee_is_change_exists(docid integer) returns boolean
    language plpgsql
as
$$
/*
	ito06 2015-07-09 Существует ли исправление по документу
*/
DECLARE rid integer;
BEGIN
	select who from bee_docs_change where wher = docid into rid;
	IF rid IS NULL 
	   THEN	RETURN false;
	   ELSE RETURN true;
	END IF;
END;
$$;

comment on function bee_is_change_exists(integer) is 'Существует ли исправление по документу. Используется в DocMain.java, AppUtils.java';

alter function bee_is_change_exists(integer) owner to pgsql;

