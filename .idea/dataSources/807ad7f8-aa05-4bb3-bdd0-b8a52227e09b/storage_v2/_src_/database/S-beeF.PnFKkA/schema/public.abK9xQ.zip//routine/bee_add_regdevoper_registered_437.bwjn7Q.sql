create function bee_add_regdevoper_registered_437(pointid integer, opdate date, val199 character varying, snorm character varying, over_snorm character varying, akt character varying) returns integer
    language plpgsql
as
$$
/*
   add ito07 2018-10-15 bee_header_recalc(pointid,opdate::date) перерасчёт головного; 
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2014-12-08 Для прямых договоров не вводить/сохраннять показания если параметр “потребление без суббабонентов” (850) отрицательный
	add ito06 2013-12-12
	add ito06 2013-11-05
	add ito06 2013-09-20
	add ito07 2012-10-25 Лашин ВА (15.3 --> 15.4)
	
	РАСЧЁТ ПО СУММЕ
	ЗАПОЛНЕНИЕ ПАРАМЕТРОВ в regdevoper 
	pointid  - код точки подключения по договору
	opdate   - дата занесения показаний
	val199   - допсумма   
	snorm     - соц норма
	over_snorm - свыше соц нормы

*/
DECLARE

   -- проверка на соответствие числу
   NUMBER_EXPR CONSTANT TEXT := E'^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$';

   -- *** ОПЕРАТИВНЫЕ ПАРАМЕТРЫ СЧЁТЧИКА
   OPER_CALC_TAG  CONSTANT INTEGER := 193;  -- paramid = 193 val = 99 valman = 437
   OPER_CALC_REF  CONSTANT TEXT    := '99';
   OPER_CALC_VID  CONSTANT TEXT    := '437';
   -- 
   OPER_ADD_SUM       CONSTANT INTEGER := 199; -- допсумма
   
   --** add ito06 2013-09-20
   OPER_SOC_NORM      CONSTANT INTEGER := 1446; -- соц.норма
   Oper_Soc_Norm_Val           INTEGER := 0; 

   OPER_OVER_SNORM    CONSTANT INTEGER := 1174; -- сверх соц.нормы
   Oper_Over_SNorm_Val         INTEGER  := 0;  
   --**

   OPER_CUR_DATE      CONSTANT INTEGER := 194; -- дата снятия показаний
   OPER_CUR_REGS      CONSTANT INTEGER := 195; -- текущие показания
   OPER_REP_AMO       CONSTANT INTEGER := 407; -- отчетное количество эл. эн.   
   OPER_SUB_SUM       CONSTANT INTEGER := 849; -- потреблено субабонентами   
   OPER_OWN_SUM       CONSTANT INTEGER := 850; -- потреблено без субабонентов   
   --
   DevI 	INTEGER; -- 
   OpCurrDat    DATE;    -- дата текущих    показаний 
   --
   SubAboSum   NUMERIC(15,4) := 0; -- потреблено субабонентами 
   OwnAboSum   NUMERIC(15,4) := 0; -- потреблено без субабонентов  
   AgreePower  NUMERIC(15,4) := 0; -- разрешённая мощность по ТУ
   --
   v202   varchar;
   v257   varchar;
   v637   varchar;
   v1005  varchar;
   _transmit boolean = false; --** 2014-12-08
   --
   tmp_id integer = 0; 
   --
BEGIN
   --
   -- SAVE
   
   v202  = (SELECT valman FROM regdevoper WHERE linkid = pointid AND operdate = opdate AND paramid = 202  LIMIT 1);
   v257  = (SELECT valman FROM regdevoper WHERE linkid = pointid AND operdate = opdate AND paramid = 257  LIMIT 1);
   v637  = (SELECT valman FROM regdevoper WHERE linkid = pointid AND operdate = opdate AND paramid = 637  LIMIT 1);
   v1005 = (SELECT valman FROM regdevoper WHERE linkid = pointid AND operdate = opdate AND paramid = 1005 LIMIT 1);

   -- потреблено субабонентами
   SubAboSum = COALESCE(bee_get_subabo_sum_1(pointid, opdate::text),0);
   --** 2014-12-08   SubAboSum = COALESCE(bee_set_subabo_sum_1(pointid, opdate::text),0);

   


   -- потреблено без субабонентов 
   OwnAboSum = COALESCE(val199::numeric,0) - SubAboSum;

   --** 2014-12-08
   SELECT doctype in (1910, 1911) FROM agreement AS amn join agreepoint AS apn ON apn.linkid = amn.rowid AND apn.rowid = pointid  INTO _transmit;  --** 2016-04-25   
   IF _transmit IS NULL THEN _transmit = false; END IF;

   IF  OwnAboSum < -0.50 AND _transmit
	THEN IF SubAboSum >  0 
	        THEN RETURN -7; 
	        ELSE RETURN -6; 
	      END IF;
   END IF;
   --**
   
   DevI = (SELECT devid FROM agreepoint WHERE rowid = pointid LIMIT 1);

    -- соц норма 2013-09-20
   Oper_Soc_Norm_Val := snorm::numeric; 
   Oper_Soc_Norm_Val := COALESCE(Oper_Soc_Norm_Val,0);


   -- сверх соц нормы 2013-09-20
   Oper_Over_SNorm_Val := over_snorm::numeric; 
   Oper_Over_SNorm_Val := COALESCE(Oper_Over_SNorm_Val,0);
   
   IF ((Oper_Soc_Norm_Val <> 0 OR Oper_Over_SNorm_Val <> 0) 
   AND ((OwnAboSum)::integer <> Oper_Soc_Norm_Val + Oper_Over_SNorm_Val)) THEN
        return -5;
           
   END IF;    
             
   --**   

   IF NOT EXISTS(SELECT 1 FROM regdevoper WHERE linkid = pointid AND operdate = opdate LIMIT 1) THEN
   INSERT INTO regdevoper 
       (linkid, operdate, paramid, ed,
          val, valman, timeperiod)  
       (SELECT pointid,opdate, paramid, ed,
       CASE -- val
          WHEN paramid = OPER_CALC_TAG THEN '99'
          WHEN paramid = 1005          THEN '121' 
          ELSE val
       END,	
       CASE -- valman 	
	  WHEN  paramid = OPER_CALC_TAG      THEN  OPER_CALC_VID            -- вид расчёта
          WHEN  paramid = OPER_CUR_DATE      THEN  opdate::text             -- дата снятия показани
	  WHEN  paramid = OPER_REP_AMO       THEN  ROUND(val199::numeric,0)::text    -- отчётное кол-во эл.энергии
          WHEN  paramid = OPER_ADD_SUM       THEN  val199::text             --  допсумм
          WHEN  paramid = OPER_SOC_NORM      THEN  Oper_Soc_Norm_Val::text  --  соц норма
          WHEN  paramid = OPER_OVER_SNORM    THEN  Oper_Over_SNorm_Val::text -- сверх соц нормы
          WHEN  paramid = OPER_CUR_REGS      THEN  '0'                      -- текущие показания
          WHEN  paramid = OPER_SUB_SUM       THEN  ROUND(SubAboSum,0)::text -- потреблено субабонентами  
          WHEN  paramid = OPER_OWN_SUM       THEN  ROUND(OwnAboSum,0)::text -- потреблено без субабонентов  

	  ELSE  CASE WHEN valman IS NULL THEN '-'
	            ELSE valman END
       END,
       timeperiod 
       FROM regdevattr 
       WHERE 
          deviceid = DevI AND
          (paramid  IN (
              SELECT rowid FROM dic_elements 
              WHERE 
                 link = 38 AND 
                 element_code::text LIKE '3%'
          )
          ) AND
          (paramid  NOT IN (
              SELECT paramid FROM regdevoper 
              WHERE 
                 linkid    = pointid AND 
                 operdate  = opdate
              )
         )
   );      
   ELSE
      UPDATE regdevoper SET 
         val = 
             CASE
                WHEN paramid = OPER_CALC_TAG THEN '99'
                WHEN paramid = 1005          THEN '121' 
                ELSE val
             END,	
         valman =   
             CASE 	
                WHEN  paramid = OPER_CALC_TAG      THEN  OPER_CALC_VID            -- вид расчёта
                WHEN  paramid = OPER_CUR_DATE      THEN  opdate::text             -- дата снятия показани
	        WHEN  paramid = OPER_REP_AMO       THEN  ROUND(val199::numeric,0)::text    -- отчётное кол-во эл.энергии
                WHEN  paramid = OPER_ADD_SUM       THEN  val199::text             --  допсумм
                WHEN  paramid = OPER_SOC_NORM      THEN  Oper_Soc_Norm_Val::text  --  соц норма
		WHEN  paramid = OPER_OVER_SNORM    THEN  Oper_Over_SNorm_Val::text -- сверх соц нормы
                WHEN  paramid = OPER_CUR_REGS      THEN  '0'                      -- текущие показания
                WHEN  paramid = OPER_SUB_SUM       THEN  ROUND(SubAboSum,0)::text -- потреблено субабо  
                WHEN  paramid = OPER_OWN_SUM       THEN  ROUND(OwnAboSum,0)::text -- потреблено без субабо  
             ELSE 
                valman
       END
       WHERE linkid = pointid AND operdate = opdate;     
   END IF;

   -- RESORE
   IF  v202 IS NOT NULL THEN 
	UPDATE regdevoper SET valman = v202  WHERE linkid = pointid AND operdate = opdate AND paramid = 202;
   END IF;
   IF  v257 IS NOT NULL THEN 
	UPDATE regdevoper SET valman = v257  WHERE linkid = pointid AND operdate = opdate AND paramid = 257;
   END IF;
   
	UPDATE regdevoper SET valman = v637  WHERE linkid = pointid AND operdate = opdate AND paramid = 637;
  
   IF  v1005 IS NOT NULL THEN 	
	UPDATE regdevoper SET valman = v1005 WHERE linkid = pointid AND operdate = opdate AND paramid = 1005;
   END IF;
   --   
   select bee_header_recalc(pointid,opdate::date) into tmp_id;
   --
RETURN 0;
--
END;
--
$$;

comment on function bee_add_regdevoper_registered_437(integer, date, varchar, varchar, varchar, varchar) is 'Расчет по сумме заполнение параметров в regdevoper. Используется в AgreeRegDev.java, AppUtils.java';

alter function bee_add_regdevoper_registered_437(integer, date, varchar, varchar, varchar, varchar) owner to pgsql;

