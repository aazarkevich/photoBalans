create function bee_rep_get_repdata31_fils_load(loc_id integer, showall boolean)
    returns TABLE(fil_kod text, fil_name character varying)
    language plpgsql
as
$$
/*	
	ito06 2015-12-08: Список филиалов в "Сводный акт первичного учета эл.эн.; по абонентам ВСЕГО по филиалу".
*/	

BEGIN
	
	IF loc_id = 693	AND showall   
	      THEN --РГЭС
		RETURN QUERY((SELECT '%' AS fil_kod, nam AS fil_name 
		               from denet  where rowid = loc_id)
		               UNION (SELECT 'f66apps0' AS fil_kod, 'Восточный РЭС')
		               UNION (SELECT 'f66apps1' AS fil_kod, 'Южный РЭС' )
		               UNION (SELECT 'f66apps2' AS fil_kod, 'Северный РЭС')
		               UNION (SELECT 'f66apps3' AS fil_kod, 'Западный РЭС')
		               order by fil_kod);	
	         
	   ELSIF loc_id = 644 AND showall   
	     THEN RETURN QUERY(
	     	   (       SELECT '%' AS fil_kod, nam AS fil_name from denet  where rowid = loc_id)
		    UNION (select 'f'||substring(kod, 5,2)||'apps%' AS fil_kod, nam AS fil_name from denet where length(kod) = 6 and kod like 'g10m%' order by kod)
		    order by fil_kod);    	 
	   ELSE 
		RETURN QUERY(SELECT '%' AS fil_kod, nam AS fil_name from denet where rowid = loc_id  order by fil_kod limit 1);			     
	END IF;
	  
END;
$$;

comment on function bee_rep_get_repdata31_fils_load(integer, boolean) is 'Список филиалов в "Сводный акт первичного учета эл.эн.; по абонентам ВСЕГО по фидиалу". Используется в RepCreate31.java, RepCreate32.java';

alter function bee_rep_get_repdata31_fils_load(integer, boolean) owner to pgsql;

