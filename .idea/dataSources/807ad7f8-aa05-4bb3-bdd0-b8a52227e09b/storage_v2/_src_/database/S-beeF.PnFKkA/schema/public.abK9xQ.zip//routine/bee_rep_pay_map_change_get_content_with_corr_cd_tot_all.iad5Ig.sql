create function bee_rep_pay_map_change_get_content_with_corr_cd_tot_all(bd_row integer) returns SETOF bee_rep_pay_map_tab_cd_tot
    language sql
as
$$
    /*
       add ito07 2018-11-07 bee_get_doc_tax
        add ito06 2015-05-22
        add ito06 2014-11-17
        ito06 2013-07-04: Карта расхода ЦД исправление
    */   
		(SELECT null::varchar AS sort_ul,
			null::character varying AS fil,  
			'ВСЕГО по '||ul AS ul,
			sum(loss_tot) AS loss_tot,
			sum(loss_n) AS loss_n,
			sum(loss_l) AS loss_l,
			sum(loss_h) AS loss_h,
			sum(dopsum) AS tot_dopsum,
			sum(v407) AS tot_v407,
			sum(v850) AS tot_v850,
			null::numeric AS tot_price,
			
			sum(sum_no_tax)::numeric AS tot_sum_no_tax,
			sum(sum_tax)::numeric    AS tot_sum_tax,
			sum(sum)::numeric        AS tot_sum,
			
			3 AS sort
		   FROM bee_rep_pay_map_change_get_content_with_corr_cd($1)
		   WHERE sum IS NOT NULL and ul is not null
		   GROUP BY ul)
	UNION   (SELECT null::varchar AS sort_ul,
			null::character varying AS fil,
			'ВСЕГО нагрузочные потери'::character varying AS ul,
			0::numeric AS loss_tot,
			0::numeric AS loss_n,
			0::numeric AS loss_l,
			0::numeric AS loss_h,
			0::numeric AS tot_dopsum,
			amount AS tot_v407,
			amount AS tot_v850,
			price AS tot_price,
			loss.sum_w_tax::numeric AS tot_sum_no_tax,
			loss.tax_sum::numeric   AS tot_sum_tax,
			loss.sum::numeric       AS tot_sum,
			4 AS sort            
		  FROM (SELECT period   As dat,
		               linkid1  AS  linkid1, 
		               sum(loss_kvt) As amount,
		               loss_tarif AS price,
		               sum(loss_sum * bee_get_doc_tax(1163,$1))::numeric       As tax_sum,
		               sum(loss_sum)::numeric                                  As sum_w_tax,
		               sum(loss_sum * (1 + bee_get_doc_tax(1163,$1)))::numeric As sum
		          FROM bee_docs_loss 
		         WHERE date_trunc('month',  period) <> date_trunc('month',  docdat)
		           AND loss_typ = 1733
		         GROUP BY period,linkid1,loss_tarif) AS loss 
		          JOIN bee_docs_change AS bdc ON bdc.who = $1
		          JOIN bee_docs AS bd ON loss.linkid1 = bd.linkid AND bd.rowid = bdc.wher AND loss.dat = bd.docdat)
	UNION (  SELECT null::varchar AS sort_ul, 
			null::character varying AS fil,
			'ВСЕГО ЭЛЕКТРОЭНЕРГИЯ:'::character varying AS ul,
			a.loss_tot AS loss_tot,
			a.loss_n AS loss_n,
			a.loss_l AS loss_l,
			a.loss_h AS loss_h,
			a.tot_dopsum AS tot_dopsum,
			b.amont AS tot_v407,
			b.amont AS tot_v850,
			null::numeric AS tot_price,
			b.sum_no_tax::numeric   AS tot_sum_no_tax,
			b.tax_sum::numeric      AS tot_sum_tax,
			b.sum_with_tax::numeric AS tot_sum,
			5 AS sort 
		  FROM ( select sum(loss_tot) AS loss_tot,
				sum(loss_n) AS loss_n,
		                sum(loss_l) AS loss_l,
		                sum(loss_h) AS loss_h,
		                sum(dopsum) AS tot_dopsum,
		                sum(v407) AS tot_v407,
		                sum(v850) AS tot_v850
		           from bee_rep_pay_map_change_get_content_with_corr_cd($1)) AS a,
		        (select sum(bdr.amount) AS amont, 
		                CASE WHEN loss.sum_no_tax IS NOT NULL 
		                        THEN sum(bdr.sum_no_tax) + loss.sum_no_tax
		                     ELSE sum(bdr.sum_no_tax)
		                END AS sum_no_tax,
		                CASE WHEN loss.tax_sum IS NOT NULL 
		                        THEN sum(bdr.tax_sum) + loss.tax_sum
		                     ELSE sum(bdr.tax_sum)
		                END AS tax_sum,
		                CASE WHEN loss.sum_with_tax IS NOT NULL 
		                        THEN sum(bdr.sum_with_tax) + loss.sum_with_tax
		                     ELSE sum(bdr.sum_with_tax)
		                END AS sum_with_tax  
		           from bee_docs_result AS bdr,
		                (
		                   SELECT amount AS amount,
		                        -bdl.sum_w_tax AS sum_no_tax,
		                        -bdl.tax_sum AS tax_sum,
		                        -bdl.sum AS sum_with_tax
		                   FROM (
		                          SELECT period   AS dat,
		                             linkid1  AS  linkid1, 
		                             sum(loss_kvt) As amount,
		                             loss_tarif AS price,
		                             sum(loss_sum * bee_get_doc_tax(1163,$1)) As tax_sum,
		                             sum(loss_sum) As sum_w_tax,
		                             sum(loss_sum * (1 + bee_get_doc_tax(1163,$1))) As sum
		                          FROM bee_docs_loss 
		                          WHERE date_trunc('month',  period) <> date_trunc('month',  docdat)
		                             AND loss_typ = 1733
		                          GROUP BY period,linkid1,loss_tarif
		                      ) AS bdl 
		                 LEFT JOIN bee_docs_change AS bdc ON bdc.who = $1
		                 LEFT JOIN bee_docs AS bd ON bdl.linkid1 = bd.linkid AND bd.rowid = bdc.wher AND bdl.dat = bd.docdat
		                ) AS loss
		          where bdr.linkid = $1 and bdr.row_typ = 1070
		          group by loss.amount, loss.sum_no_tax, loss.tax_sum, loss.sum_with_tax) AS b)
	UNION (  SELECT null::varchar 					AS sort_ul, 
			null::character varying 			AS fil,
		        'ВСЕГО НДС:'::character varying 		AS ul,
			null::numeric 			AS loss_tot,
			null::numeric 			AS loss_n,
			null::numeric 			AS loss_l,
			null::numeric 			AS loss_h,
			null::numeric 			AS tot_dopsum,
			null::numeric 			AS tot_v407,
			null::numeric 			AS tot_v850,
			null::numeric 			AS tot_price,
			b.tax_sum::numeric	AS tot_sum_no_tax,
		   null::numeric			AS tot_sum_tax,
		   null::numeric			AS tot_sum,
			6 AS sort 
		  FROM (select case when sum(tax_sum) <> 0
			              then CASE WHEN loss.sum_no_tax IS NOT NULL 
		                                THEN sum(bdr.tax_sum) + loss.sum_no_tax * bee_get_doc_tax(1163,$1)
		                                ELSE sum(bdr.tax_sum)
		                           END 
			             else CASE WHEN loss.sum_no_tax IS NOT NULL 
		                                THEN (sum(bdr.sum_no_tax) + loss.sum_no_tax) * bee_get_doc_tax(1163,$1)
		                                ELSE sum(bdr.sum_no_tax) * bee_get_doc_tax(1163,$1)
		                           END 
			        end 				 AS tax_sum
		         from bee_docs_result AS bdr,
		              (SELECT  -bdl.sum_w_tax AS sum_no_tax
		                 FROM (SELECT period   				 AS dat,
		                             linkid1  				    AS linkid1, 
		                             sum(loss_kvt) 			 AS amount,
		                             loss_tarif 			    AS price,                                     
		                             sum(loss_sum)::numeric AS sum_w_tax                                     
		                        FROM bee_docs_loss 
		                       WHERE date_trunc('month', period) <> date_trunc('month',  docdat)
		                         AND loss_typ = 1733
		                       GROUP BY period,linkid1,loss_tarif
		                      ) AS bdl 
		                 LEFT JOIN bee_docs_change AS bdc ON bdc.who = $1
		                 LEFT JOIN bee_docs AS bd ON bdl.linkid1 = bd.linkid AND bd.rowid = bdc.wher AND bdl.dat = bd.docdat
		              ) AS loss
		        WHERE bdr.linkid = $1 and bdr.row_typ = 1070
		        GROUP BY  loss.sum_no_tax
		    ) AS b WHERE (SELECT sum(sum_with_tax) FROM bee_docs_result where linkid =$1) = 0)
		    
	UNION (  SELECT 	null::varchar AS sort_ul, 
				null::character varying AS fil,
				'ВСЕГО ЭЛЕКТРОЭНЕРГИЯ С НДС:'::character varying 	AS ul,
				null::numeric 						AS loss_tot,
				null::numeric						AS loss_n,
				null::numeric 						AS loss_l,
				null::numeric 						AS loss_h,
				null::numeric 						AS tot_dopsum,
				null::numeric 						AS tot_v407,
				null::numeric 						AS tot_v850,
				null::numeric 						AS tot_price,
				b.sum_with_tax::numeric			AS tot_sum_no_tax,
				null::numeric 						AS tot_sum_tax,
				null::numeric 						AS tot_sum,              
				7 AS sort 
		   FROM (select case when sum(sum_with_tax) <> 0
			              then CASE WHEN loss.sum_no_tax IS NOT NULL 
		                                THEN sum(bdr.sum_with_tax) + loss.sum_no_tax*bee_get_doc_tax(1163,$1)
		                                ELSE sum(bdr.sum_with_tax)
		                           END 
			             else CASE WHEN loss.sum_no_tax IS NOT NULL 
		                                THEN (sum(bdr.sum_no_tax) + loss.sum_no_tax)*(1+bee_get_doc_tax(1163,$1))
		                                ELSE sum(bdr.sum_no_tax) * (1 + bee_get_doc_tax(1163,$1))
		                           END 
			        end   					AS sum_with_tax
		           from bee_docs_result AS bdr,
					(SELECT  -bdl.sum_w_tax AS sum_no_tax
					   FROM (SELECT period   		 AS dat,
						     linkid1  				    AS linkid1, 
						     sum(loss_kvt) 			 AS amount,
						     loss_tarif 			    AS price,                                     
						     sum(loss_sum)::numeric AS sum_w_tax                                     
						FROM bee_docs_loss 
					       WHERE date_trunc('month', period) <> date_trunc('month',  docdat)
						 AND loss_typ = 1733
					       GROUP BY period,linkid1,loss_tarif
					      ) AS bdl 
					 LEFT JOIN bee_docs_change AS bdc ON bdc.who = $1
					 LEFT JOIN bee_docs AS bd ON bdl.linkid1 = bd.linkid AND bd.rowid = bdc.wher AND bdl.dat = bd.docdat
					) AS loss
		          where bdr.linkid = $1 and bdr.row_typ = 1070
		          group by loss.sum_no_tax) AS b 
		       WHERE (select * FROM  bee_is_calc_nds_new($1)))
	ORDER BY sort_ul, sort, ul;

$$;

comment on function bee_rep_pay_map_change_get_content_with_corr_cd_tot_all(integer) is 'ito06 2013-07-04 Карта расхода ЦД исправление';

alter function bee_rep_pay_map_change_get_content_with_corr_cd_tot_all(integer) owner to postgres;

