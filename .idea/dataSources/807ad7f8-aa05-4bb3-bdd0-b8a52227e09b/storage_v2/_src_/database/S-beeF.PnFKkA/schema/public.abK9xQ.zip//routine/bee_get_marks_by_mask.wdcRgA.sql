create function bee_get_marks_by_mask(mask character varying) returns character varying
    language plpgsql
as
$$
    -- 100326
-- ОТБОР МАРКИ УСТРОЙСТВ ПО МАСКЕ
--
-- lid : код места обработки
-- mask: фильтр
-- 
DECLARE
  ResultList VARCHAR := '';
  Rec        RECORD;
--
BEGIN
    FOR Rec IN ( SELECT rowid FROM dic_elements
    WHERE 
      element_name
      ILIKE 
      --SIMILAR TO 
      mask
    ) 
    LOOP
       ResultList = ResultList || Rec.rowid || '|';
    END LOOP;   	
--
RETURN ResultList;
--
END;
$$;

comment on function bee_get_marks_by_mask(varchar) is 'Используется в AgreeRegDev.java, AppUtils.java';

alter function bee_get_marks_by_mask(varchar) owner to pgsql;

