create function bee_get_parent_counter(pointid integer) returns integer
    language plpgsql
as
$$
    -- ito07, add ito06 2012-06-28
-- ЗАПИТАНО ЛИ ДАННОЕ УСТРОЙСТВО ОТ ДРУГОГО
-- pointid - код устройства
-- возврат - код головного
--
DECLARE
   PID VARCHAR;
BEGIN
   SELECT INTO PID ard.paramval 
     FROM  bee_rep_get_ard_per_max(664)  AS ard
          WHERE
            linkid        = pointid       AND   
            paramval     IS NOT NULL      AND 
            paramval NOT IN ('?','-','0') AND
            paramval     ~ E'^\\d{1,}'    
           LIMIT 1;
   IF PID IS NULL THEN
      RETURN -1; 
   ELSE
      RETURN PID::integer;
   END IF;   

END;
--
--
$$;

comment on function bee_get_parent_counter(integer) is 'Запитано ли данное устройство от другого. Используется в AgreeByDevice.java, AppUtils.java';

alter function bee_get_parent_counter(integer) owner to pgsql;

