create function bee_rep_get_repdata6_shablon(tt text) returns text
    language plpgsql
as
$$
/*
ito06 2011-12-02
*/   
   BEGIN
	return regexp_replace(tt,E'.{1,}?\\+.{1,}?\\+.{1,}?\\+','');
    END;
$$;

comment on function bee_rep_get_repdata6_shablon(text) is 'Используется в bee_rep_get_repdata6_get_transsubst(dat date)';

alter function bee_rep_get_repdata6_shablon(text) owner to postgres;

