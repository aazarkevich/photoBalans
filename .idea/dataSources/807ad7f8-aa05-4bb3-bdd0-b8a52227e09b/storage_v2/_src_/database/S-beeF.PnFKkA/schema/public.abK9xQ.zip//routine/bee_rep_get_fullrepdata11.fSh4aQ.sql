create function bee_rep_get_fullrepdata11(locid integer, strdate date, enddate date) returns SETOF bee_repfull_tab11
    language sql
as
$$
/*
	add ito06 2021-02-15 должны попадать расторгнутые
	ito16 Формирование сравнительной ведомости по показаниям АО Донэнерго и ПАО ТНС энерго Ростов-на-Дону в разрезе схем подключения
*/
SELECT DISTINCT
	bee_rep11_get_pch(gis.pchain) AS pch,
	apn.rowid			      AS ardlink,
	replace((ard.paramval || ', '|| cst.abo_name),E'\\','/') AS adrfio, 
	apn.account                           AS accoun, 
	(SELECT ard.paramval
          FROM agreeregdev                    AS ard
          WHERE ard.paramid = 715 
          AND ard.linkid = apn.rowid)         AS grp,
          ---------- 
        bee_get_oper_repval1(apn.rowid, 993, rdo.operdate) AS strval, 
        bee_get_oper_repval1(apn.rowid, 992, rdo.operdate) AS endval, 
        bee_get_oper_repval1(apn.rowid, 991, rdo.operdate) AS contval, 
        bee_get_oper_repval1(apn.rowid, 990, rdo.operdate) AS accval, 
        bee_get_oper_repval1(apn.rowid, 988, rdo.operdate) AS consval1,
        bee_get_oper_repval1(apn.rowid, 199, rdo.operdate) AS dopval,
		bee_get_oper_repval1(apn.rowid, 989, rdo.operdate) AS consval2,
        bee_get_oper_repval1(apn.rowid, 986, rdo.operdate) AS dovval,
        bee_get_oper_repval1(apn.rowid, 407, rdo.operdate) AS totval
          
FROM customer               as cst
        JOIN agreement      as amn ON cst.abo_code = amn.abo_code
        JOIN agreepoint     as apn ON amn.rowid    = apn.linkid 
        JOIN agreeregdev    as ard ON apn.rowid    = ard.linkid
        JOIN regdevoper977  as rdo ON apn.rowid    = rdo.linkid
        LEFT JOIN regdevconn as rdc ON rdc.pointid=apn.rowid
        LEFT JOIN gis_traces as gis ON gis.rowid=rdc.traceid
WHERE 
	rdo.paramid IN (993,992,991,990,988,199,989,986,407) AND
        ard.paramid   = 417 AND
        cst.locid     = $1  AND
        rdo.operdate BETWEEN $2 AND $3 AND 
        --ito06 2021-02-15 amn.docstatus = 79 AND
		amn.docstatus in (77, 79) AND
        (bee_get_oper_regdevval_date(apn.rowid,690) IS NULL OR
         bee_get_oper_regdevval_date(apn.rowid,690) > $2)
        
        
GROUP BY amn.docnumber, ard.paramval, cst.abo_name, apn.account,apn.rowid,rdo.operdate,pch
ORDER BY pch,adrfio, accoun;
$$;

comment on function bee_rep_get_fullrepdata11(integer, date, date) is 'Формирование сравнительной ведомости по показаниям АО Донэнерго и ПАО ТНС энерго Ростов-на-Дону в разрезе схем подключения
 Используется в RepCreate11.java';

alter function bee_rep_get_fullrepdata11(integer, date, date) owner to postgres;

