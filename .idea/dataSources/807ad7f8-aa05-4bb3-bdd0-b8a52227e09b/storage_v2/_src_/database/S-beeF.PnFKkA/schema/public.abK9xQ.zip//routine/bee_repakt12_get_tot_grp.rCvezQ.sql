create function bee_repakt12_get_tot_grp(bd_rowid integer, grp1 character varying, dat date) returns SETOF bee_repakt2_tot_amount
    language plpgsql
as
$$
/*
	ito06 2021-02-02 Акт (сверх нормы) Сумма кВт*ч по группам эл.эн.
*/
BEGIN 
RETURN QUERY EXECUTE'
	SELECT  max(period)::date,
		CASE 
		     WHEN '''||$2||''' = ''12'' OR '''||$2||''' = ''22'' OR '''||$2||''' = ''32''
                        THEN ''Электрическая энергия в пределах социальной нормы''
                     WHEN '''||$2||''' = ''13'' OR '''||$2||''' = ''23'' OR '''||$2||''' = ''33''
                        THEN ''Электрическая энергия сверх социальной нормы'' 
                     WHEN '''||$2||''' = ''12,13'' OR '''||$2||''' = ''22,23'' OR '''||$2||''' = ''32,33''
                        THEN ''Население и потребители, приравненные к населению. Электрическая энергия, всего'' 
                     ELSE NULL::varchar   
                END  				AS grp_name,      
		sum(vn_amount) 			AS grp_vn_amount,
		sum(sn1_amount) 		AS grp_sn1_amount,
		sum(sn2_amount) 		AS grp_sn2_amount,
		sum(nn_amount) 			AS grp_nn_amount,
		sum(tot_amount) 		AS grp_tot_amount
	   FROM bee_repakt12_get_content('||$1||')
          WHERE grp in ('||$2||') AND period='''||$3||''';';
END;
$$;

comment on function bee_repakt12_get_tot_grp(integer, varchar, date) is 'Акт (сверх нормы) Сумма кВт*ч по группам эл.эн. Используется в RepAkt12.java';

alter function bee_repakt12_get_tot_grp(integer, varchar, date) owner to postgres;

