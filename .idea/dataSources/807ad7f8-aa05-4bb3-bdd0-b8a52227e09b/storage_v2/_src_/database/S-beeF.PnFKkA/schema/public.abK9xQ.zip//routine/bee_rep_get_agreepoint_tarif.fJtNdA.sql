create function bee_rep_get_agreepoint_tarif(apn_rowid integer, str_date date, end_date date) returns SETOF bee_rep_ard_periods
    language plpgsql
as
$$
/*
   ito06 2013-10-11: Сводный акт первичного учета эл.эн.; по абонентам; в разрезе лицевых счетов
*/
DECLARE
  result_row bee_rep_ard_periods % ROWTYPE;
  rec        bee_rep_ard_per_paramval_period % ROWTYPE;
  i int :=1;
  is_first boolean := true;
BEGIN
  result_row.str_date = str_date;
  result_row.ul='';
  FOR rec IN (SELECT tarifid AS paramval, period FROM agreepoint_tarif WHERE pointid = apn_rowid AND period BETWEEN str_date AND end_date ORDER BY period)  
  LOOP

    IF (NOT is_first)
      THEN
        EXIT WHEN (rec.period >= end_date) OR (rec.period <= str_date);
        result_row.end_date = rec.period;
        RETURN NEXT result_row;
        result_row.str_date = rec.period;
        result_row.ul = rec.paramval;
      ELSE
        result_row.ul = rec.paramval;
        is_first = false;
    END IF;
  END LOOP;
  IF (result_row.ul = '')
    THEN
      FOR rec IN (SELECT tarifid As paramval,  period FROM agreepoint_tarif WHERE pointid = apn_rowid AND period <= end_date ORDER BY period DESC)  
      LOOP
        result_row.ul = rec.paramval;
        is_first = false;
        EXIT;
      END LOOP;
  END IF;      
  result_row.end_date = end_date;
  RETURN NEXT result_row;
END;
$$;

comment on function bee_rep_get_agreepoint_tarif(integer, date, date) is 'Сводный акт первичного учета эл.эн.; по абонентам; в разрезе лицевых счетов. Используется в bee_rep_get_repdata3_info(int, date, date)';

alter function bee_rep_get_agreepoint_tarif(integer, date, date) owner to pgsql;

