create function bee_rep_get_repdata30(host character varying) returns SETOF bee_repdata30
    language plpgsql
as
$$
/*
	add ito06 2015-09-30 Изменили названия колонок для  разделителя
	add ito06 2015-05-12
	ito06 2015-02-02: Сводная реализация электроэнергии, суммарные строки по всем группам потребителей
	
*/
DECLARE RowLine bee_repdata30%rowtype;
BEGIN     
 FOR RowLine IN (
			(SELECT 'bold' 						AS row_style,
				null::varchar 					AS nn,
				'01' 						AS nn1,
				'ВСЕГО'  					AS name,
				row.*,
				null::smallint					AS accdir,
				null::int					AS loc,
				'ВСЕГО'  					AS ord
			   FROM bee_rep_get_repdata30_summ(0, $1) AS row)
		  UNION (SELECT 'bold' 						AS row_style,
				'1' 						AS nn,
				'10' 						AS nn1,
				'Прочие потребители'  				AS name,
				row.*,
				null::smallint					AS accdir,
				null::int					AS loc,
				'Прочие потребители'  				AS ord
			   FROM bee_rep_get_repdata30_summ(10,$1) AS row)
		   UNION (SELECT 'bold' 					AS row_style,
				'2' 						AS nn,
				'20' 						AS nn1,
				'Бюджетные потребители' 			AS name,  
				row.*,
				null::smallint					AS accdir,
				null::int					AS loc,
				'Бюджетные потребители'				AS ord
			   FROM bee_rep_get_repdata30_summ(20,$1) AS row)
		   UNION (SELECT 'bold' 					AS row_style,
				'2.1'  						AS nn,
				'21'  						AS nn1,
				'-федеральный бюджет'  				AS name,
				row.*,
				null::smallint					AS accdir,
				null::int					AS loc,
				'-федеральный бюджет'  				AS ord
			   FROM bee_rep_get_repdata30_summ(21,$1) AS row)
		  UNION (SELECT 'bold' 						AS row_style,
				'2.2' 						AS nn,
				'22' 						AS nn1,
				'-областной бюджет'  				AS name,
				row.*,
				null::smallint					AS accdir,
				null::int					AS loc,
				'-областной бюджет'  				AS ord
			   FROM bee_rep_get_repdata30_summ(22,$1) AS row)
		  UNION (SELECT 'bold' 						AS row_style,
				'2.3' 						AS nn,
				'23' 						AS nn1,
				'-местный бюджет'  				AS name,
				row.*,
				null::smallint					AS accdir,
				null::int					AS loc,
				'-местный бюджет'  				AS ord
			   FROM bee_rep_get_repdata30_summ(23,$1) AS row)
		  UNION (SELECT 'bold' 						AS row_style,
				'2.3.1' 					AS nn,
				'231' 						AS nn1,
				'--юр. организации'  				AS name,
				row.*,
				null::smallint					AS accdir,
				null::int					AS loc,
				'--юр. организации'  				AS ord
			   FROM bee_rep_get_repdata30_summ(231,$1) AS row)
		  UNION (SELECT 'bold' 						AS row_style,
				'2.3.2' 					AS nn,
				'232' 						AS nn1,
				'--уличное освещение'  				AS name,
				row.*,
				null::smallint 					AS accdir,
				null::int					AS loc,
				'--уличное освещение'  				AS ord
			    FROM bee_rep_get_repdata30_summ(232,$1) AS row)			   
		  UNION (SELECT 'bold' 						AS row_style,
				'3' 						AS nn,
				'3' 						AS nn1,
				'Централизованные договоры' 			AS name,
				row.*,
				null::smallint					AS accdir,
				null::int					AS loc,
				'Централизованные договоры' 			AS ord
			FROM bee_rep_get_repdata30_summ(3,$1) AS row)	
		ORDER BY nn1, ord)
        LOOP              
		IF RowLine.amount <> 0 OR RowLine.nn1<>'3'  THEN RETURN  NEXT RowLine;                    
		END IF;
		
	END LOOP;	
END;
$$;

comment on function bee_rep_get_repdata30(varchar) is 'Сводная реализация электроэнергии. Используется в bee_rep_get_repdata30_all(int, date, date, boolean, boolean, boolean)';

alter function bee_rep_get_repdata30(varchar) owner to pgsql;

