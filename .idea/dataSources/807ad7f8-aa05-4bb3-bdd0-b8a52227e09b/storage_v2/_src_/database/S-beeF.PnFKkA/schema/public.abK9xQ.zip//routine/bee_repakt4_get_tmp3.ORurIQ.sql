create function bee_repakt4_get_tmp3(bd_rowid integer, _rowtyp integer) returns numeric[]
    language plpgsql
as
$$
/*
   ito07 181108 bee_get_doc_tax
    add ito06 2015-06-05 Акт (передача)
*/
DECLARE newform numeric = 0;
    dat date;
BEGIN 
    SELECT sum(sum_with_tax) FROM bee_docs_result where linkid =$1 INTO newform;	
    SELECT docdat FROM bee_docs WHERE rowid = bd_rowid INTO dat;
    IF (newform <> 0)
       THEN RETURN(
	  SELECT ARRAY[sum(amount), sum(sum_no_tax) ,price, sum(tax_sum), sum(sum_with_tax)] AS m_tar
	    FROM bee_docs_result
	   WHERE  linkid = $1 AND row_typ = $2 
	   GROUP BY price);
       ELSE RETURN(
	   SELECT ARRAY[
	    sum(amount), 
	    sum(sum_no_tax),
	    price, 
	    sum(sum_no_tax) * bee_get_doc_tax(1163, bd_rowid),
	    sum(sum_no_tax) * (1 + bee_get_doc_tax(1163, bd_rowid))
	    ] AS m_tar
	    FROM bee_docs_result
	   WHERE linkid = $1 AND row_typ = $2 
	   GROUP BY price);
    END IF;	  
END;
$$;

comment on function bee_repakt4_get_tmp3(integer, integer) is 'Акт (передача).Используется в bee_repakt4_get_content2(int)';

alter function bee_repakt4_get_tmp3(integer, integer) owner to pgsql;

