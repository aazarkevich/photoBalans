create function bee_rep_pay_map_get_content_with_corr_cd_tot(bd_row integer, fil character varying) returns SETOF bee_rep_pay_map_tab_cd_tot
    language sql
as
$$
    /*
        add ito06 2016-04-21 добавили потери РСК по филиально
        add ito06 2013-09-26 
        add ito06 2013-07-02 
        ito06 2011-09-19: Карта расхода ЦД
    */
	
		(SELECT
			null::varchar 			AS sort_ul,
			CASE WHEN fil IS NOT null
			    THEN 'Итого по '||fil 
			    ELSE null
			END 				AS fil,
			null::character varying 	AS ul,
			sum(a.loss_tot) 			AS loss_tot,
			sum(a.loss_n) 			AS loss_n,
			sum(a.loss_l) 			AS loss_l,
			sum(a.loss_h) 			AS loss_h,
			sum(a.dopsum) 			AS tot_dopsum,
			sum(a.v407) 			AS tot_v407,
			sum(a.v850) 			AS tot_v850,
			null::numeric 			AS tot_price,
			(SELECT sum(c) from unnest(ARRAY[sum(a.sum_no_tax), b.sum_no_tax]) as c) 		AS tot_sum_no_tax,
			sum(a.sum_tax) 			AS tot_sum_tax,
			sum(a.sum) 			AS tot_sum,
			4 				AS sort
		   FROM bee_rep_pay_map_get_content_with_corr_cd($1) AS a,
		   --** 2016-04-21
			(select sum(sum_no_tax) AS sum_no_tax,
				sum(tax_sum) AS sum_tax,
				sum(sum_with_tax) AS sum              
			   FROM bee_docs_result AS bdr 
			   JOIN bee_docs AS bd ON bd.rowid = bdr.linkid
			   JOIN bee_docs_loss AS bdl ON bdl.linkid1 = bd.linkid AND bdl.loss_kvt = bdr.amount AND bdl.loss_typ =  bdr.row_typ
			   JOIN denet AS net ON net.rowid = bdl.locid
			  WHERE bdr.linkid = $1 AND bdr.tar_typ = 1734 AND net.nam = $2) AS b 		   
		  WHERE fil = $2  AND a.sum IS NOT NULL AND amn_docnumber IS NOT NULL
		  GROUP BY fil, b.sum_no_tax)	  
	UNION
		(SELECT  
			ul 				AS sort_ul,
			null  				AS fil,    
			'Итого по '||ul 		AS ul,
			sum(loss_tot) 			AS loss_tot,
			sum(loss_n) 			AS loss_n,
			sum(loss_l)			AS loss_l,
			sum(loss_h) 			AS loss_h,
			sum(dopsum) 			AS tot_dopsum,
			sum(v407) 			AS tot_v407,
			sum(v850) 			AS tot_v850,
			null::numeric 			AS tot_price,
			sum(sum_no_tax) 		AS tot_sum_no_tax,
			sum(sum_tax) 			AS tot_sum_tax,
			sum(sum) 			AS tot_sum,
			1 				AS sort
		   FROM bee_rep_pay_map_get_content_with_corr_cd($1)
		   WHERE fil = $2  AND sum IS NOT NULL AND ul IS NOT null AND amn_docnumber IS NOT NULL
		   GROUP BY ul ) 
	UNION
		(SELECT 
			ul 				AS sort_ul, 
			null  				AS fil,    
			obj 				AS ul,
			sum(loss_tot) 			AS loss_tot,
			sum(loss_n) 			AS loss_n,
			sum(loss_l) 			AS loss_l,
			sum(loss_h) 			AS loss_h,
			sum(dopsum) 			AS tot_dopsum,
			sum(v407)			AS tot_v407,
			sum(v850) 			AS tot_v850,
			null::numeric 			AS tot_price,
			sum(sum_no_tax) 		AS tot_sum_no_tax,
			sum(sum_tax) 			AS tot_sum_tax,
			sum(sum) 			AS tot_sum,
			2 				AS sort
		   FROM bee_rep_pay_map_get_content_with_corr_cd($1)
		   WHERE fil = $2  AND sum IS NOT NULL AND ul IS NOT null AND amn_docnumber IS NULL
		   GROUP BY ul, obj)   
	UNION
		(SELECT 
			null::varchar 			AS sort_ul,  
			'Корректировка' 	        AS fil,    
			null 				AS ul,
			sum(loss_tot) 			AS loss_tot,
			sum(loss_n) 			AS loss_n,
			sum(loss_l) 			AS loss_l,
			sum(loss_h) 			AS loss_h,
			sum(dopsum) 			AS tot_dopsum,
			sum(v407) 			AS tot_v407,
			sum(v850) 			AS tot_v850,
			null::numeric 			AS tot_price,
			sum(sum_no_tax) 		AS tot_sum_no_tax,
			sum(sum_tax) 			AS tot_sum_tax,
			sum(sum) 			AS tot_sum,
			5 				AS sort
		   FROM bee_rep_pay_map_get_content_with_corr_cd($1)
		   WHERE fil = $2  AND sum IS NOT NULL AND ul IS null
		   GROUP BY ul) 
	UNION --2016-04-21
		(SELECT
			null::varchar 			AS sort_ul,
			null::character varying		AS fil,
			'ВСЕГО нагрузочные потери' 	AS ul,
			null::numeric 			AS loss_tot,
			null::numeric 			AS loss_n,
			null::numeric 			AS loss_l,
			null::numeric 			AS loss_h,
			null::numeric 			AS tot_dopsum,
			sum(amount) 			AS tot_v407,
			sum(amount) 			AS tot_v850,
			price 				AS tot_price,
			-sum(sum_no_tax) 		AS tot_sum_no_tax,
			-sum(tax_sum) 			AS tot_sum_tax,
			-sum(sum_with_tax) 		AS tot_sum,
			3 				AS sort
		   FROM bee_docs_result AS bdr 
		   JOIN bee_docs AS bd ON bd.rowid = bdr.linkid
		   JOIN bee_docs_loss AS bdl ON bdl.linkid1 = bd.linkid AND bdl.loss_kvt = bdr.amount AND bdl.loss_typ =  bdr.row_typ
		   JOIN denet AS net ON net.rowid = bdl.locid
		  WHERE bdr.linkid = $1 AND bdr.tar_typ = 1734 AND net.nam =  $2
		  GROUP BY price)
		   
	ORDER BY sort_ul, sort, ul;

$$;

comment on function bee_rep_pay_map_get_content_with_corr_cd_tot(integer, varchar) is 'Карта расхода ЦД. Используется в RepPayMapCD.java';

alter function bee_rep_pay_map_get_content_with_corr_cd_tot(integer, varchar) owner to postgres;

