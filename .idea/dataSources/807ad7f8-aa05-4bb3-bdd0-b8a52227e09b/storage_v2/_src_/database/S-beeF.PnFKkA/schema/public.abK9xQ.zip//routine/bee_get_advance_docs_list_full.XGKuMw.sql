create function bee_get_advance_docs_list_full(_docid integer) returns SETOF advance_docs_list_full
    language plpgsql
as
$$
/*
	ito06 2014-12-01
	Расшифровка по документу: счет на предоплату
*/
DECLARE
  RowLine advance_docs_list_full%rowtype;
---  
BEGIN
---  
  FOR RowLine IN ((SELECT
			apn.account,
			apn.prodnumber,
			(select element_name from dic_elements where rowid = dtg.voltage_level) AS plevel,
			dtg.name 								AS tarif_name,
			bda.quantity_fact,
			bda.quantity_plan,
			bda.quantity_max,
			bda.percent_ava,
			bda.quantity_amo,
			bda.price,
			bda.cost_no_tax,
			bda.tax_rate,
			bda.tax_sum,
			bda.cost_with_tax 
		   from bee_docs_advance AS bda  
		   join agreepoint AS apn on bda.linkid2 = apn.rowid 
		   join dic_tarif_group As dtg on bda.tar_grp = dtg.rowid
		   where bda.linkid1 = _docid)
	UNION (SELECT
			null::varchar 								AS account,
			null::varchar 								AS prodnumber,
			(select element_name from dic_elements where rowid = dtg.voltage_level) AS plevel,
			dtg.name 								AS tarif_name,
			bdat.quantity_fact,
			bdat.quantity_plan,
			bdat.quantity_max,
			bdat.percent_ava,
			bdat.quantity_amo,
			bdat.price,
			bdat.cost_no_tax,
			bdat.tax_rate,
			bdat.tax_sum,
			bdat.cost_with_tax 
		   from bee_docs_advance_t AS bdat 
		   join dic_tarif_group As dtg on bdat.tar_grp = dtg.rowid  
		   where bdat.linkid1 = _docid
	          ))
  LOOP
     RETURN NEXT RowLine; 
  END LOOP;
---
RETURN;
--
END;
$$;

comment on function bee_get_advance_docs_list_full(integer) is 'Используется в AdvanceDocs.java, SessionBean1.java';

alter function bee_get_advance_docs_list_full(integer) owner to pgsql;

