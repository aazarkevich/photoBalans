create function bee_get_agreements_by_locid(_lid integer) returns integer[]
    language plpgsql
as
$$
    --
-- 
BEGIN
   RETURN ARRAY(
     SELECT rowid FROM agreement
     WHERE locid = _lid AND docstatus = 79
     ORDER BY docnumber
   );
--
END;
$$;

alter function bee_get_agreements_by_locid(integer) owner to pgsql;

