create function bee_is_point_connected(pid integer) returns boolean
    language plpgsql
as
$$
    --
--
-- УСТРОЙСТВО ПОДКЛЮЧЕНО
-- pid : agreepoint.rowid - точка учёта 
-- 
BEGIN
   RETURN EXISTS( SELECT 1 FROM regdevconn WHERE pointid = pid); 
END;
--
--
$$;

comment on function bee_is_point_connected(integer) is 'Устройство подключено. Используется в AgreeRegDev.java, RepAkt3.java, RepAkt6.java, RepAkt8.java, RepAkt9.java, AppUtils.java, bee_agree_by_device';

alter function bee_is_point_connected(integer) owner to pgsql;

