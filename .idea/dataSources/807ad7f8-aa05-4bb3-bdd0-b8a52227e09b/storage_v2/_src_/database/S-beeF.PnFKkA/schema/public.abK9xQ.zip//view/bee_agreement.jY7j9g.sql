create view bee_agreement
            (docnumber, valid, docdate, docstatus, abo_code, accdir, locid, rowid, abo_name, locnam, doctype, type_name,
             abo_vid, agridf)
as
SELECT amn.docnumber,
       amn.valid,
       amn.docdate,
       amn.docstatus,
       amn.abo_code,
       amn.accdir,
       amn.locid,
       amn.rowid,
       cust.abo_name,
       deamn.nam       AS locnam,
       amn.doctype,
       de.element_name AS type_name,
       amn.abo_vid,
       amn.agridf
FROM (((agreement amn
    JOIN customer cust ON ((amn.abo_code = cust.abo_code)))
    LEFT JOIN denet deamn ON ((deamn.rowid = amn.locid)))
         JOIN dic_elements de ON ((de.rowid = amn.doctype)))
ORDER BY cust.consum_name, cust.abo_name, amn.docnumber;

comment on view bee_agreement is 'Используется в Agreement.java, SessionBean1.java';

alter table bee_agreement
    owner to postgres;

