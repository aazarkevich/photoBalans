create function bee_rep_get_repdata31_tot(loc_id integer, str_date date, end_date date, fil character varying) returns SETOF bee_repdata31_tot
    language plpgsql
as
$$
/*	
	ito06 2015-12-08: Сводный акт первичного учета эл.эн.; по абонентам ВСЕГО по филиалу. Итоговые строки
*/	
DECLARE RowLine bee_repdata31_tot%rowtype;

BEGIN 
	DROP TABLE IF EXISTS bee_rep_get_repdata31_tmp; 
	PERFORM bee_rep_get_repdata31_create_tmp_table($1,$2,$3, $4);

	FOR RowLine IN (SELECT rep850.*, 
			       rep1446.total 		AS total_1446, 
			       rep1446.vn		AS vn_1446,
			       rep1446.sn1		AS sn1_1446,
			       rep1446.sn2		AS sn2_1446,
			       rep1446.nn		AS nn_1446,	       
			       rep1174.total		AS total_1174, 
			       rep1174.vn		AS vn_1174,
			       rep1174.sn1		AS sn1_1174, 
			       rep1174.sn2		AS sn2_1174,
			       rep1174.nn		AS nn_1174
			  FROM bee_rep_get_repdata31_tmp AS rep850
		     LEFT JOIN bee_rep_get_repdata31_tmp AS rep1446 on rep850.apn_rowid = rep1446.apn_rowid and rep1446.rdo_param = 1446
		     LEFT JOIN bee_rep_get_repdata31_tmp AS rep1174 on rep850.apn_rowid = rep1174.apn_rowid and rep1174.rdo_param = 1174
			 WHERE rep850.rdo_param = 850)
        LOOP              
		RETURN  NEXT RowLine;
	END LOOP;

      	DROP TABLE IF EXISTS bee_rep_get_repdata31_tmp; 

END;
$$;

comment on function bee_rep_get_repdata31_tot(integer, date, date, varchar) is 'Сводный акт первичного учета эл.эн.; по абонентам ВСЕГО по филиалу. Используется в RepCreate31.java, RepCreate32.java';

alter function bee_rep_get_repdata31_tot(integer, date, date, varchar) owner to pgsql;

