create function bee_get_last_day(date) returns date
    immutable
    strict
    language sql
as
$$
SELECT (date_trunc('MONTH', $1) + INTERVAL '1 MONTH - 1 day')::DATE;
$$;

comment on function bee_get_last_day(date) is 'Расчет по показаниям. Используется в AgreeRegDev.java, OperVal.java, AppUtils.java';

alter function bee_get_last_day(date) owner to postgres;

