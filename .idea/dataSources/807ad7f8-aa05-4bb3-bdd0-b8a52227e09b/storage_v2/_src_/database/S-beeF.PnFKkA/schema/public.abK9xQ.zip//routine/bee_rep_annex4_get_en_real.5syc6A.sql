create function bee_rep_annex4_get_en_real(amnid integer, strdat date) returns SETOF bee_rep_annex4_en_tab
    language plpgsql
as
$$
/*
	add ito06 2019-12-23 (если нет параметра 410 (адрес запитанного объекта*) все равно добавляем точку учета в табл
	показания берутся за месяц (раньше по 1 число след месяца)
	ito06 2012-10-16  Приложение 1 (факт), реальные данные из формы "договоры" 
*/
DECLARE
  rec bee_rep_annex4_en_tab%rowtype;
  mon1_s date;    mon1_e date;
  mon2_s date;    mon2_e date;
  mon3_s date;    mon3_e date;
  mon4_s date;    mon4_e date;
  mon5_s date;    mon5_e date;
  mon6_s date;    mon6_e date;
  mon7_s date;    mon7_e date;
  mon8_s date;    mon8_e date;
  mon9_s date;    mon9_e date;
  mon10_s date;   mon10_e date;
  mon11_s date;   mon11_e date;
  mon12_s date;   mon12_e date;
  dat date; 
  dat_sn date; 

  
BEGIN

IF strdat::date >= (now())::date
  THEN  dat = to_char(now(),'YYYY-mm-01')::date;
  ELSE dat = strdat;
END IF;

IF to_char(dat,'YYYY-01-01')::date < dat                  
  THEN mon1_s  = to_char(dat,'YYYY-01-01')::date; mon1_e  = ((to_char(dat,'YYYY-02-01'))::date - '1 day'::interval)::date;      
  ELSE mon1_s  = (to_char(dat,'YYYY-01-01')::date  -'1 year'::interval)::date ; mon1_e  = (((to_char(dat,'YYYY-02-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF;  

IF to_char(dat,'YYYY-02-01')::date < dat   
  THEN mon2_s  = to_char(dat,'YYYY-02-01')::date; mon2_e  = ((to_char(dat,'YYYY-03-01'))::date - '1 day'::interval)::date;    
  ELSE mon2_s  = (to_char(dat,'YYYY-02-01')::date  -'1 year'::interval)::date ; mon2_e  = (((to_char(dat,'YYYY-03-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF; 

IF to_char(dat,'YYYY-03-01')::date < dat   
  THEN mon3_s  = to_char(dat,'YYYY-03-01')::date; mon3_e  = ((to_char(dat,'YYYY-04-01'))::date - '1 day'::interval)::date;   
  ELSE mon3_s  = (to_char(dat,'YYYY-03-01')::date  -'1 year'::interval)::date ; mon3_e  = (((to_char(dat,'YYYY-04-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF; 
IF to_char(dat,'YYYY-04-01')::date < dat   
  THEN mon4_s  = to_char(dat,'YYYY-04-01')::date; mon4_e  = ((to_char(dat,'YYYY-05-01'))::date - '1 day'::interval)::date;   
  ELSE mon4_s  = (to_char(dat,'YYYY-04-01')::date  -'1 year'::interval)::date ; mon4_e  = (((to_char(dat,'YYYY-05-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF; 
IF to_char(dat,'YYYY-05-01')::date < dat   
  THEN mon5_s  = to_char(dat,'YYYY-05-01')::date; mon5_e  = ((to_char(dat,'YYYY-06-01'))::date - '1 day'::interval)::date;   
  ELSE mon5_s  = (to_char(dat,'YYYY-05-01')::date  -'1 year'::interval)::date ; mon5_e  = (((to_char(dat,'YYYY-06-01'))::date -'1 year'::interval)::date  - '1 day'::interval)::date;
END IF; 
IF to_char(dat,'YYYY-06-01')::date < dat   
  THEN mon6_s  = to_char(dat,'YYYY-06-01')::date; mon6_e  = ((to_char(dat,'YYYY-07-01'))::date - '1 day'::interval)::date;   
  ELSE mon6_s  = (to_char(dat,'YYYY-06-01')::date  -'1 year'::interval)::date ; mon6_e  = (((to_char(dat,'YYYY-07-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF; 
IF to_char(dat,'YYYY-07-01')::date < dat   
  THEN mon7_s  = to_char(dat,'YYYY-07-01')::date; mon7_e  = ((to_char(dat,'YYYY-08-01'))::date - '1 day'::interval)::date;   
  ELSE mon7_s  = (to_char(dat,'YYYY-07-01')::date  -'1 year'::interval)::date ; mon7_e  = (((to_char(dat,'YYYY-08-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF; 
IF to_char(dat,'YYYY-08-01')::date < dat   
  THEN mon8_s  = to_char(dat,'YYYY-08-01')::date; mon8_e  = ((to_char(dat,'YYYY-09-01'))::date - '1 day'::interval)::date;   
  ELSE mon8_s  = (to_char(dat,'YYYY-08-01')::date  -'1 year'::interval)::date ; mon8_e  = (((to_char(dat,'YYYY-09-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF; 
IF to_char(dat,'YYYY-09-01')::date < dat   
  THEN mon9_s  = to_char(dat,'YYYY-09-01')::date; mon9_e  = ((to_char(dat,'YYYY-10-01'))::date - '1 day'::interval)::date;   
  ELSE mon9_s  = (to_char(dat,'YYYY-09-01')::date  -'1 year'::interval)::date ; mon9_e  = (((to_char(dat,'YYYY-10-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF;
IF to_char(dat,'YYYY-10-01')::date < dat   
  THEN mon10_s  = to_char(dat,'YYYY-10-01')::date; mon10_e  = ((to_char(dat,'YYYY-11-01'))::date - '1 day'::interval)::date;   
  ELSE mon10_s  = (to_char(dat,'YYYY-10-01')::date  -'1 year'::interval)::date ; mon10_e  = (((to_char(dat,'YYYY-11-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF;
IF to_char(dat,'YYYY-11-01')::date < dat   
  THEN mon11_s  = to_char(dat,'YYYY-11-01')::date; mon11_e  = ((to_char(dat,'YYYY-12-01'))::date - '1 day'::interval)::date;   
  ELSE mon11_s  = (to_char(dat,'YYYY-11-01')::date  -'1 year'::interval)::date ; mon11_e  = (((to_char(dat,'YYYY-12-01'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF;
IF to_char(dat,'YYYY-12-01')::date <= dat   
  THEN mon12_s  = to_char(dat,'YYYY-12-01')::date; mon12_e  = ((to_char(dat,'YYYY-12-31'))::date - '1 day'::interval)::date;   
  ELSE mon12_s  = (to_char(dat,'YYYY-12-01')::date  -'1 year'::interval)::date ; mon12_e  = (((to_char(dat,'YYYY-12-31'))::date -'1 year'::interval)::date - '1 day'::interval)::date ;
END IF;

FOR rec IN (
  SELECT 
	  amn.docnumber 		AS docnumber,
          amn.docdate 			AS docdate, 
	  cust.abo_name  		AS cstname,
	  apn.rowid 			AS pointid,
	  ard.paramval::numeric(3) 	AS ulev,
	  null::numeric(13,3)		AS summ,
	  summ1.sum::numeric(13,3) 	AS summ1,
	  summ2.sum::numeric(13,3) 	AS summ2,
	  summ3.sum::numeric(13,3) 	AS summ3,
	  summ4.sum::numeric(13,3) 	AS summ4,
	  summ5.sum::numeric(13,3) 	AS summ5,
	  summ6.sum::numeric(13,3) 	AS summ6,
	  summ7.sum::numeric(13,3) 	AS summ7,
	  summ8.sum::numeric(13,3) 	AS summ8,
	  summ9.sum::numeric(13,3) 	AS summ9,
	  summ10.sum::numeric(13,3) 	AS summ10,
	  summ11.sum::numeric(13,3) 	AS summ11,
	  summ12.sum::numeric(13,3) 	AS summ12
	 
     FROM customer AS cust 	  
     JOIN agreement   AS amn  ON amn.abo_code = cust.abo_code   
     JOIN agreepoint  AS apn  ON amn.rowid = apn.linkid AND apn.devtype=644
     JOIN bee_rep_get_ard_per_max(439) AS ard  ON apn.rowid = ard.linkid
     JOIN dic_elements AS de ON de.rowid = ard.paramval::numeric(3)
     JOIN agreeregdev AS ard3 ON ard3.linkid=apn.rowid AND ard3.paramid=418 
-- 2019-12-23 JOIN agreeregdev AS ard4 ON ard4.linkid=apn.rowid AND ard4.paramid=410
LEFT JOIN agreeregdev AS ard4 ON ard4.linkid=apn.rowid AND ard4.paramid=410
LEFT JOIN agreeregdev AS ard5 ON ard5.linkid=apn.rowid AND ard5.paramid=685 AND ard5.paramval~E'^\\d{1,}' 
LEFT JOIN agreeregdev AS ard6 ON ard6.linkid=apn.rowid AND ard6.paramid=426 AND ard6.paramval~E'^\\d{1,}' 

     JOIN denet ON apn.lid=denet.rowid
LEFT JOIN (SELECT nam, kod FROM denet WHERE length(kod)=6) as dn ON substring(denet.kod, 0, 7)=dn.kod
     JOIN agreeregdev  AS ard1 ON apn.rowid = ard1.linkid AND ard1.paramid = 189 AND ard1.paramval='432'
LEFT JOIN agreeregdev  AS ard2 ON apn.rowid = ard2.linkid AND ard2.paramid = 690 AND is_date(ard2.paramval) AND length(ard2.paramval)>9

LEFT JOIN bee_rep_annex4_get_month_en($1,mon1_s, mon1_e) AS summ1 ON summ1.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon2_s, mon2_e) AS summ2 ON summ2.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon3_s, mon3_e) AS summ3 ON summ3.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon4_s, mon4_e) AS summ4 ON summ4.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon5_s, mon5_e) AS summ5 ON summ5.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon6_s, mon6_e) AS summ6 ON summ6.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon7_s, mon7_e) AS summ7 ON summ7.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon8_s, mon8_e) AS summ8 ON summ8.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon9_s, mon9_e) AS summ9 ON summ9.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon10_s, mon10_e) AS summ10 ON summ10.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon11_s, mon11_e) AS summ11 ON summ11.id=apn.rowid
LEFT JOIN bee_rep_annex4_get_month_en($1,mon12_s, mon12_e) AS summ12 ON summ12.id=apn.rowid

WHERE  (ard2.paramval IS NULL OR ard2.paramval::date >= to_char(dat,'YYYY-mm-01')::date - '11 month'::interval) 
 AND amn.rowid = $1
ORDER BY  docnumber         
) LOOP 

  SELECT paramval INTO dat_sn 
          FROM agreeregdev 
          WHERE true
            AND paramid = 690   
            AND is_date(paramval)
            AND length(paramval)> 9
            AND linkid = rec.pointid;
    
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-01-01')::date
      THEN rec.m01 = null::numeric(13,3);
   END IF;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-02-01')::date
      THEN rec.m02 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-03-01')::date
      THEN rec.m03 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-04-01')::date
      THEN rec.m04 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-05-01')::date
      THEN rec.m05 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-06-01')::date
      THEN rec.m06 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-07-01')::date
      THEN rec.m07 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-08-01')::date
      THEN rec.m08 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-09-01')::date
      THEN rec.m09 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-10-01')::date
      THEN rec.m10 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-11-01')::date
      THEN rec.m11 = null::numeric(13,3);
   END IF ;
   IF dat_sn IS NOT NULL AND to_char(dat_sn,'YYYY-mm-01')::date < to_char(dat,'YYYY-12-01')::date
      THEN rec.m12 = null::numeric(13,3);
   END IF ;
    select sum(a) from  unnest(ARRAY[rec.m01,rec.m02,rec.m03,rec.m04,rec.m05,rec.m06,rec.m07,rec.m08,rec.m09,rec.m10,rec.m11,rec.m12]) AS a INTO rec.sum;  
RETURN NEXT rec;
END LOOP;
END;
$$;

comment on function bee_rep_annex4_get_en_real(integer, date) is 'Приложение 1 (факт) - печать из формы "договоры" . Используется в bee_rep_annex4_get_en_mid_real(int, date)';

alter function bee_rep_annex4_get_en_real(integer, date) owner to pgsql;

