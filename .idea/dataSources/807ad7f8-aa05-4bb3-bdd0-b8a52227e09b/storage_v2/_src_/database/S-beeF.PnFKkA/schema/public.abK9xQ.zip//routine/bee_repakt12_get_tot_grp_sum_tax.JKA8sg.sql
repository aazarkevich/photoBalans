create function bee_repakt12_get_tot_grp_sum_tax(bd_rowid integer, grp1 character varying, dat date) returns SETOF bee_repakt2_tot_sum
    language plpgsql
as
$$
/*
	ito06 2021-02-02 Акт (сверх нормы) НДС по группам эл.эн.
*/
DECLARE 
	flag boolean = true; 
BEGIN 
	flag = (select grp from bee_repakt12_get_content(bd_rowid) WHERE period > '1000-01-01' limit 1) IS NOT NULL; --если ли корректировка
	IF flag THEN 
		RETURN QUERY EXECUTE'	       
			SELECT  MAX(period)::date,
				''НДС ''::varchar			AS grp_name,    
				null::numeric	 			AS grp_vn_sum,
				null::numeric	 			AS grp_sn1_sum,
				null::numeric	 			AS grp_sn2_sum,
				null::numeric	 			AS grp_nn_sum,
				sum(tot_tax_sum) 			AS grp_tot_sum,
				(select docdat from bee_docs where rowid = '||$1||' limit 1)
			   FROM bee_repakt12_get_content('||$1||')
			  WHERE grp in ('||$2||') AND ('''||$2||''' = ''11,12,13'' OR 	
						       '''||$2||''' = ''11,12,13,21,22,23,31,32,33'' OR period='''||$3||''')';
	END IF;
END;
$$;

comment on function bee_repakt12_get_tot_grp_sum_tax(integer, varchar, date) is 'Акт (сверх нормы) НДС по группам эл.эн. Используется в RepAkt12.java';

alter function bee_repakt12_get_tot_grp_sum_tax(integer, varchar, date) owner to postgres;

