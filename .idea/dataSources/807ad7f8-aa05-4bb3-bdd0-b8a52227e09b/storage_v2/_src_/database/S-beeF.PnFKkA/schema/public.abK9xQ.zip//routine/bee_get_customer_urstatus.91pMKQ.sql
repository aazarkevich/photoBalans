create function bee_get_customer_urstatus(integer) returns character varying
    language sql
as
$$
    --
--
-- СТАТУС ПОТРЕБИТЕЛЯ
-- 
SELECT element_name FROM dic_elements 
WHERE rowid = (SELECT urstatus FROM customer WHERE abo_code = $1 LIMIT 1) 
LIMIT 1;
--
$$;

comment on function bee_get_customer_urstatus(integer) is 'Статус потребителя. Используется в Agreement.java, RepAkt.java, RepAkt1.java, RepAkt3.java, RepAkt6.java, RepAkt8.java, AppUtils.java';

alter function bee_get_customer_urstatus(integer) owner to pgsql;

