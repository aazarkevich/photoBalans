create view vbee_agreeregdev_period(element_code, element_name, link, rowid, refs, element_type) as
SELECT dic_elements.element_code,
       dic_elements.element_name,
       dic_elements.link,
       dic_elements.rowid,
       dic_elements.refs,
       dic_elements.element_type
FROM (dic_elements
         JOIN agreeregdev_paramids ON ((dic_elements.rowid = agreeregdev_paramids.paramid)))
WHERE ((dic_elements.link = 38) AND (agreeregdev_paramids.const = false))
ORDER BY dic_elements.element_code;

comment on view vbee_agreeregdev_period is 'Используется в AgreeRegDev.java, DeviceParamP.java, SessionBean1.java';

alter table vbee_agreeregdev_period
    owner to pgsql;

