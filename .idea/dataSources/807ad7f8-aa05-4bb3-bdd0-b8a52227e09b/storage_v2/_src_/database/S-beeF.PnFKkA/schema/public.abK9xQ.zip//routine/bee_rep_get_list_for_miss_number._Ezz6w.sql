create function bee_rep_get_list_for_miss_number(sdat date, edat date, dtyp integer, dtyp2 integer) returns SETOF integer
    language plpgsql
as
$$
/*
    add ito06 2016-04-19 т.к у "централизованных непрямых" договоров может быть пустой номер документа, то добавили условие
    add ito06 2013-04-08 с пропущенных номеров
*/
DECLARE
        -- так как  с 1 числа каждого года нумерация начинается с 1
    priv_month DATE := (TO_CHAR($1,'YYYY') || '-01'|| '-01')::date;	
    next_month DATE := (TO_CHAR($2,'YYYY') || '-12'|| '-31')::date;
       
        mon integer := (TO_CHAR($2,'mm'));
        rowLine integer;
    tmp integer:=-1;
    max_docnum integer:=0;
    min_docnum integer:=0;
BEGIN
        -- denet.kod g10m56 (ГУКОВО) g10m64 (НОВОШАХТИНСК) 
         if (exists(select 1 from denet where (kod = 'g10m56' or kod = 'g10m64') )) THEN                 
        -- так как  с 1 марта 2017 года нумерация начинается с 1
        IF  TO_CHAR($2,'mm') = '03' AND TO_CHAR($2,'YYYY') = '2017' THEN  priv_month = $1;
        END IF;
            IF  TO_CHAR($2,'mm') = '03'  AND TO_CHAR($2,'YYYY') = '2017' THEN  next_month = $2;
        END IF;
         end if;
        
    SELECT max(docnum) 
	FROM bee_docs WHERE (doctyp = $3 OR doctyp = $4)
	AND docdat >= priv_month
	AND docdat < $1 
	AND docnum IS NOT NULL --2016-04-19
	GROUP BY docdat, docnum
	ORDER BY docnum DESC
	LIMIT 1 INTO max_docnum;

    IF max_docnum IS NULL THEN 
        max_docnum = 0;       
    END IF;
    

    IF (
          SELECT max(docnum) 
          FROM bee_docs  WHERE (doctyp = $3 OR doctyp = $4)
           AND docdat >= priv_month
           AND docdat <= $1 
           AND docnum IS NOT NULL --2016-04-19
         GROUP BY docdat, docnum
         ORDER BY docnum DESC
         LIMIT 1
        ) IS NULL THEN tmp = 0;
    END IF;
        
        IF tmp = 0 THEN 
      RETURN NEXT tmp;
        END IF;
          

        FOR rowLine IN (
               
	(SELECT DISTINCT
	    docnum 
	   FROM bee_docs 
	  WHERE 
	        (doctyp = $3 OR doctyp = $4)
	    AND docdat between $1 and $2
	    AND docnum IS NOT NULL --2016-04-19
	    AND docnum::integer > max_docnum
	  ORDER BY docnum
	  ) 
               
               
           UNION
	(SELECT max(docnum) 
	   FROM bee_docs 
	  WHERE 
	        (doctyp = $3 OR doctyp = $4)
	    AND docdat >= priv_month
	    AND docdat < $1 
	    AND docnum IS NOT NULL --2016-04-19
	  GROUP BY docdat, docnum
	  ORDER BY docnum DESC LIMIT 1
	  )
	 
	   
           UNION
	(SELECT min(docnum) 
	   FROM bee_docs 
	  WHERE (doctyp = $3 OR doctyp = $4)
	    AND docdat > $2 
	    AND docdat <= next_month
	    AND docnum IS NOT NULL --2016-04-19
	  GROUP BY docdat, docnum
	  ORDER BY docnum LIMIT 1
	  ) 		  
           ORDER BY  docnum
           
    )
   LOOP
      RETURN NEXT RowLine;
   END LOOP;								
END;
$$;

comment on function bee_rep_get_list_for_miss_number(date, date, integer, integer) is 'Cписок пропущенных номеров. Используется в AdvanceInvoices.java, DocMain.java, DocsAdjustment.java';

alter function bee_rep_get_list_for_miss_number(date, date, integer, integer) owner to pgsql;

