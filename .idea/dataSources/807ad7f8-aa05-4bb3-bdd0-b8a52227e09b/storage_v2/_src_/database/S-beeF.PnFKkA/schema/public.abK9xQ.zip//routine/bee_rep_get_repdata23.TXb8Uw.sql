create function bee_rep_get_repdata23(loc integer, str_d date, end_d date) returns SETOF bee_reptab23
    language sql
as
$$
/*
ito06 2011-06-17
Сводный акт учета эл.эн. по договорам купли продажи
*/
SELECT * FROM bee_rep_get_repdata23_tmp1($1,$2,$3)
UNION ALL(SELECT * FROM bee_rep_get_repdata23_tmp2($1,$2,$3))
ORDER BY  kod, doc_nam, prodnumber

$$;

comment on function bee_rep_get_repdata23(integer, date, date) is 'Сводный акт учета эл.эн. по договорам купли продажи. Используется в RepCreate23.java';

alter function bee_rep_get_repdata23(integer, date, date) owner to pgsql;

