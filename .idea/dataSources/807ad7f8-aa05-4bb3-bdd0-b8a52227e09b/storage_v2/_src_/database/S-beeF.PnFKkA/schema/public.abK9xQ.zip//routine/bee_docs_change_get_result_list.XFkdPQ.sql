create function bee_docs_change_get_result_list(_docid integer) returns SETOF docs_adjustment_result_list
    language plpgsql
as
$$
/*
ito06 2012-03-26 Исправления счетов-фактур
*/

DECLARE
  rec docs_adjustment_result_list%rowtype;

BEGIN
   FOR rec IN (
      SELECT
	   dtg.name,         -- тариф,
	   dic.element_name, -- вид_расчета,
	   bdr.name,         -- товар,
	   bdr.amount,       -- колич,
	   bdr.price,        -- цена,
	   bdr.sum_no_tax,   -- без_налога,
	   bdr.tax_rate,     -- ставка,
	   bdr.tax_sum,      -- налог,
	   bdr.sum_with_tax, -- с_налогом,

	   agreement.docnumber,
	   doc.linkid,
	   doc.rowid,
	   doc.doctyp,
	   bdr.linkid,
	   bdr.tar_typ,
	   doc.docdat

	  FROM 
		bee_docs_result AS bdr
		JOIN bee_docs AS doc ON doc.rowid=bdr.linkid
		JOIN dic_tarif_group AS dtg ON bdr.tar_grp=dtg.rowid
		JOIN dic_elements AS dic ON bdr.tar_typ=dic.rowid  
		JOIN agreement ON agreement.rowid=doc.linkid 
	  WHERE doc.rowid=_docid
		AND bdr.tar_typ=1707
	  ORDER BY doc.docdat DESC
   )
   LOOP
	RETURN NEXT rec;
   END LOOP;
   --
END;
--
$$;

comment on function bee_docs_change_get_result_list(integer) is 'Исправления счетов-фактур. Используется в DocsChange.java, SessionBean1.java';

alter function bee_docs_change_get_result_list(integer) owner to pgsql;

