create function bee_add_regdevoper_registered_435(_pointid integer, opdate date, operval character varying, akt character varying) returns integer
    language plpgsql
as
$$
/*
    add ito06 2016-04-25 убираем поле transmit из таблицы agreement
    add ito06 2015-11-18 проверка на снятый счетчик, действующий договор
    add ito06 2014-12-08 Для прямых договоров не вводить/сохраннять показания если параметр “потребление без суббабонентов” (850) отрицательный
    add ito06 2013-11-05 
    add ito06 2013-09-20 
    add ito06 2013-08-05 
    add ito07 2012-10-25 Лашин ВА (15.3 --> 15.4)
    add ito07 2011-09-22 Лашин ВА (add TRANSACTION)
    add ito07 2011-05-03 Лашин ВА (add+update)
    add ito07 2011-03-13 Лашин значность 3-8
    add ito03,ito02 2010-12-29 Будогянц Д.В. Никитина С.П. отрицательное отчетное количество
    add ito03 2010-12-20 Будогянц Д.В. изменения в расчете потерь по НчМЭС

    РАСЧЁТ ПО ПОКАЗАНИЯМ
    ЗАПОЛНЕНИЕ ПАРАМЕТРОВ в regdevoper 
    _pointid  - код точки подключения по договору
    opdate   - дата занесения показаний
    val      - показания на текущую дату   
*/
DECLARE
   NR INTEGER;
   -- фильтр числового значения
   NUMBER_EXPR     CONSTANT TEXT := E'^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$';
   --
   HAS_POWER_TRAFO BOOLEAN := FALSE; -- признак наличия силового трансформатора
   --
   TmpVal       NUMERIC(15,4);
   TmpStr1      VARCHAR;
   TmpStr2      VARCHAR;
   -- 
   DevI 	INTEGER;
   OpPrevDat    DATE;          -- дата предыдущих показаний
   OpCurrDat    DATE;          -- дата текущих    показаний 
   OpPrevReg    NUMERIC(15,4); -- предыдущие показания 
   OpRepVal     NUMERIC(15,4); -- отчётное кол-во эл.энергии (407)
   --
   CalcKoef     NUMERIC(15,4); -- расчетный коэффициент     (356)
   LineLossProz NUMERIC(15,4); -- процент потерь в линии    (408)
   LoadLossProz NUMERIC(15,4); -- процент потерь в нагрузке (688)
   -- 
   PosLen       NUMERIC(2,1); -- значность (168)
   IntPart      INTEGER;
   OpPart       INTEGER;
   DecPart      INTEGER;
   --
   OpDiff       NUMERIC(15,4); -- разница с учётом перехода
   BAS          INTEGER;
   
   -- *** СПРАВОЧНЫЕ ПАРАМЕТРЫ СИЛОВОГО ТР-РА
   DIC_LOSS_XX   CONSTANT INTEGER := 925; -- потери холостого хода
   DIC_LOSS_SHCR CONSTANT INTEGER := 926; -- потери короткого замыкания
   DIC_POW_NOM   CONSTANT INTEGER := 927; -- номинальная мощность
   
   -- *** ДОГОВРНЫЕ ПАРАМЕТРЫ СЧЁТЧИКА
   ATTR_TRANS_POW    CONSTANT INTEGER := 929; -- силовой тр-р
   
   ATTR_DIGIT_FORMAT CONSTANT INTEGER := 168; -- значность (разрядность)*
   ATTR_DIGIT_FORMAT_DEFAULT CONSTANT TEXT := '5.3'; -- значность (разрядность)*
   ATTR_CALC_KOEF    CONSTANT INTEGER := 356; -- расчётныё коэф
   ATTR_LOSS_LINP    CONSTANT INTEGER := 408; -- потери в линиях (%)
   ATTR_LOSS_XX      CONSTANT INTEGER := 419; -- потери хх
   ATTR_LOSS_LOAP    CONSTANT INTEGER := 688; -- нагрузоч. потери (%)

   ATTR_HOUR         CONSTANT INTEGER := 425; --количество часов работы в сутки
   Attr_hour_val     NUMERIC(3,1);

   ATTR_CNT_INSTALL_DATE    CONSTANT INTEGER := 154; -- дата установки счётчика
   ATTR_CNT_INSTALL_REGS    CONSTANT INTEGER := 192; -- показания при установке счётчика
   
   -- *** ОПЕРАТИВНЫЕ ПАРАМЕТРЫ СЧЁТЧИКА
   OPER_CALC_TAG  CONSTANT INTEGER := 193; -- paramid = 193 val = 99 valman = 435
   OPER_CALC_REF  CONSTANT TEXT    := '99';
   OPER_CALC_VID  CONSTANT TEXT    := '435';
   --
   -- 
   Oper_Diff_Days          INTEGER;        -- разнича в днях между снятиями показаний
   OPER_CUR_DATE  CONSTANT INTEGER := 194; -- дата снятия показаний
   OPER_CUR_REGS  CONSTANT INTEGER := 195; -- текущие показания
   OPER_PREV_REGS CONSTANT INTEGER := 196; -- предыдущие показания
   OPER_PREV_DATE CONSTANT INTEGER := 197; -- дата снятия пред-х показаний
   OPER_DIFF_REGS CONSTANT INTEGER := 198; -- разность показаний
   
   OPER_ADD_SUM   CONSTANT INTEGER := 199; -- дополнительная сумма кВт*ч
   Oper_Add_Sum_Val        NUMERIC(15,4) := 0; 

   --** add ito06 2013-09-20
   OPER_SOC_NORM   CONSTANT INTEGER := 1446; -- соц.норма
   OPER_OVER_SNORM   CONSTANT INTEGER := 1174; -- сверх соц.нормы
   --**


   OPER_REP_AMO   CONSTANT INTEGER := 407; -- отчетное количество эл. эн.
   
   OPER_LOSS_LINE CONSTANT INTEGER := 919; -- потери в линиях
   Oper_Loss_Line_Val      NUMERIC(15,4);  -- 
   
   OPER_LOSS_XX   CONSTANT INTEGER := 918;     -- потери хх
   Oper_Los_Xx_Val         NUMERIC(15,4) := 0; -- потери хх
   
   OPER_LOSS_LOAD CONSTANT INTEGER := 917;     -- нагрузоч-е потери
   Oper_Loss_Load_Val      NUMERIC(15,4) := 0; -- нагрузоч-е потери

   OPER_KOS_FI   CONSTANT INTEGER := 934;      -- косинус фи
   Oper_Kos_Fi_Val        NUMERIC(15,4) := 0.85;  -- косинус фи

   OPER_TRANS_OFF CONSTANT INTEGER := 920;     -- кол-во часов отключ-я сил-го тр-ра 
   Oper_Trans_Off_Val      NUMERIC(15,4) := 0; -- кол-во часов откл. сил. тр-ра
   --  
   Rec      RECORD; 
   --
   OPER_RESTORE_CNT_DATE  CONSTANT INTEGER := 202;  --  
   OPER_RESTORE_CNT_VALUE CONSTANT INTEGER := 257;
   PrevCalcVid INTEGER;
   --
   OPER_AKT_NUM CONSTANT INTEGER := 637;  --  
   --
   v637   varchar;
   v1005  varchar; 
   
   SubSum_Val NUMERIC;		    --** 2014-12-08
   _transmit boolean = false; 	--** 2014-12-08
   tmp_id integer = 0;          --** 2015-11-16
   --
   ERR_CODE  INTEGER = 0;
   --
BEGIN  
   --** ito06 2015-11-16
   select apn.rowid from agreepoint  As apn
       left join agreeregdev AS ard ON apn.rowid = ard.linkid and ard.paramid = 690
        join agreement AS amn ON amn.rowid = apn.linkid 
       where amn.docstatus = 79 and (ard.paramval IS NULL OR ard.paramval NOT LIKE '____-__-__')
         and apn.rowid = _pointid	
   INTO tmp_id;

       
   IF  tmp_id IS NULL then
     ERR_CODE = -8;
     RETURN ERR_CODE; 
   END IF;   
   --**

    
   v637  = (SELECT valman FROM regdevoper WHERE linkid = _pointid AND operdate = opdate AND paramid = 637  LIMIT 1);
   v1005 = (SELECT valman FROM regdevoper WHERE linkid = _pointid AND operdate = opdate AND paramid = 1005 LIMIT 1);
   -- 
   PosLen = (
      SELECT paramval::numeric FROM agreeregdev 
      WHERE 
         linkid  = _pointid AND 
         paramid = ATTR_DIGIT_FORMAT     AND
         paramval ~ NUMBER_EXPR   
      LIMIT 1
   ); 
   
   -- исправление параметра значность разрядность
   IF (PosLen IS NULL) OR (PosLen > 8) OR (PosLen < 3) THEN
      PosLen := 5.3;
      UPDATE agreeregdev SET paramval = PosLen::text
      WHERE  linkid = _pointid AND paramid = ATTR_DIGIT_FORMAT;    
   END IF;   

   -- проверка  ввода размера показаний
   IntPart := (split_part(PosLen::text,'.',1))::integer; -- количество знакоместа допустимого
   OpPart  := length(split_part(operval,'.',1));         -- число знаков в целой части показаний
   IF IntPart < OpPart then
       ERR_CODE = -1;
       RETURN ERR_CODE;
   END IF;

   -- предыдущий вид расчёта
   PrevCalcVid := (
      SELECT valman::integer FROM regdevoper 
      WHERE 
         linkid    = _pointid       AND
         operdate  < opdate        AND 
         paramid   = OPER_CALC_TAG AND -- вид расчёта
         val       = OPER_CALC_REF 
      ORDER BY operdate DESC 
      LIMIT 1
   );

   IF PrevCalcVid IS NULL THEN  
      OpPrevDat := (SELECT paramval::date FROM agreeregdev 
          WHERE linkid = _pointid AND paramid = ATTR_CNT_INSTALL_DATE LIMIT 1);--opdate;

      OpPrevReg := (SELECT paramval::numeric FROM agreeregdev 
          WHERE linkid = _pointid AND paramid = ATTR_CNT_INSTALL_REGS LIMIT 1);--0;

      OpPrevReg := COALESCE(OpPrevReg,0);

      IF OpPrevReg < 0.001 THEN
         OpPrevReg := 0; 
      END IF; 
   END IF; -- NULL

   --  наличие в предыдущем периоде расчёта по сумме или по мощности
   IF (PrevCalcVid = 436 OR PrevCalcVid = 437) THEN
      OpPrevDat := (SELECT operdate FROM regdevoper 
         WHERE 
            linkid    = _pointid       AND
            operdate  < opdate        AND 
            paramid   = OPER_CALC_TAG AND -- вид расчёта
            val       = OPER_CALC_REF 
         ORDER BY operdate DESC 
         LIMIT 1
      );
      --
      TmpStr1 = (SELECT valman FROM regdevoper 
         WHERE linkid = _pointid 
            AND operdate = OpPrevDat
            AND paramid  = OPER_RESTORE_CNT_DATE -- дата восстановления работы счётчика
            AND (valman   LIKE '____-__-__' OR valman LIKE '__/__/____' OR valman LIKE '__-__-____')
         LIMIT 1);
      IF TmpStr1 IS NULL then
          ERR_CODE = -2;
          RETURN ERR_CODE; 
      END IF; 
      --
      TmpStr2 = (SELECT valman FROM regdevoper
         WHERE linkid = _pointid 
            AND operdate = OpPrevDat
            AND paramid  = OPER_RESTORE_CNT_VALUE -- показания при восстановлени работы счётчика
            AND valman   ~ NUMBER_EXPR 
         LIMIT 1);    
      IF TmpStr2 IS NULL then
          ERR_CODE = -3;
          RETURN ERR_CODE; 
      END IF; 
      --     
      UPDATE regdevoper SET valman = TmpStr1 WHERE linkid = _pointid AND operdate = opdate AND paramid = OPER_PREV_DATE;   
      UPDATE regdevoper SET valman = TmpStr2 WHERE linkid = _pointid AND operdate = opdate AND paramid = OPER_PREV_REGS;   

      OpPrevDat = TmpStr1::date;
      OpPrevReg = TmpStr2::numeric;

   END IF; -- PrevCalcVid = 436 OR PrevCalcVid = 437


   IF PrevCalcVid = 435 THEN
      OpPrevDat := (
      SELECT operdate FROM regdevoper 
      WHERE 
         linkid    = _pointid       AND
         operdate  < opdate        AND 
         paramid   = OPER_CALC_TAG AND -- вид расчёта
         val       = OPER_CALC_REF AND
         valman    = OPER_CALC_VID     -- расчёт по показаниям
      ORDER BY operdate DESC 
      LIMIT 1
      );
   
      IF OpPrevDat IS NULL THEN -- отсутствуют
      OpPrevDat := (SELECT paramval::date    FROM agreeregdev 
          WHERE linkid = _pointid AND paramid = ATTR_CNT_INSTALL_DATE LIMIT 1);--opdate;
      OpPrevReg := (SELECT paramval::numeric FROM agreeregdev 
          WHERE linkid = _pointid AND paramid = ATTR_CNT_INSTALL_REGS LIMIT 1);--0;
      ELSE -- имеются
         OpPrevReg := (
         SELECT valman::numeric FROM regdevoper 
         WHERE 
            linkid   = _pointid       AND --
            paramid  = OPER_CUR_REGS AND -- текущие показания (в предыдущем периоде)
            operdate = OpPrevDat     AND -- предыдущий период
            valman   ~ NUMBER_EXPR          
         LIMIT 1
         );    
      END IF;
      OpPrevReg := COALESCE(OpPrevReg,0);
        IF OpPrevReg < 0.001 THEN
         OpPrevReg := 0; 
      END IF; 
   END IF; -- 435
     
   -- РАЗНОСТЬ ПОКАЗАНИЙ
   OpDiff := operval::numeric - OpPrevReg;   
   -- коррекция перехода через ноль
   IF OpDiff < 0 THEN
       BAS := 1; 
       FOR i IN 1..IntPart LOOP
                BAS := BAS * 10;
       END LOOP;
       OpDiff := BAS - OpPrevReg + operval::numeric;  
   END IF;
   IF OpDiff < 0.001 THEN
      OpDiff := 0;
   END IF;

   -- доп сумма
   Oper_Add_Sum_Val := (
      SELECT valman::numeric FROM regdevoper 
      WHERE 
         linkid   = _pointid      AND --
         paramid  = OPER_ADD_SUM  AND -- доп показания 
         operdate = opdate        AND -- текущий период
         valman   ~ NUMBER_EXPR        
      LIMIT 1
   ); 
  
   Oper_Add_Sum_Val := COALESCE(Oper_Add_Sum_Val,0); 
      
   --
   -- наличие силового тр-ра
   --
   HAS_POWER_TRAFO := EXISTS(
       SELECT 1 FROM agreeregdev_period 
       WHERE 
      linkid        = _pointid 
      AND paramid   = ATTR_TRANS_POW 
      AND paramval  ~ NUMBER_EXPR
          AND period    <= opdate
      ORDER BY period DESC
   );


   -- расчётный коэффициент
   CalcKoef = (
      SELECT paramval::numeric FROM agreeregdev_period 
      WHERE 
             linkid   = _pointid        
         AND paramid  = ATTR_CALC_KOEF 
         AND paramval ~ NUMBER_EXPR
         AND period   <= opdate     
      ORDER BY period DESC
      LIMIT 1
   ); 
   IF CalcKoef IS NULL THEN
      CalcKoef := 1; 
   END IF; 

   
   -- процент потерь в линиях
   LineLossProz = (
      SELECT paramval::numeric FROM agreeregdev_period 
      WHERE 
             linkid   = _pointid        
         AND paramid  = ATTR_LOSS_LINP 
         AND paramval ~ NUMBER_EXPR
         AND period   <= opdate        
      ORDER BY period DESC
      LIMIT 1
   ); 
   IF LineLossProz IS NULL THEN
      LineLossProz := 0;
   END IF; 
   --
   --
   LoadLossProz = (
      SELECT paramval::numeric FROM agreeregdev_period 
      WHERE 
         linkid  = _pointid        
         AND paramid  = ATTR_LOSS_LOAP 
         AND paramval ~ NUMBER_EXPR     
         AND period   <= opdate      
      ORDER BY period DESC
      LIMIT 1
   ); 

   IF LoadLossProz IS NULL THEN
      LoadLossProz := 0;
   END IF; 


   
   IF NOT HAS_POWER_TRAFO THEN
      -- не силовой тр-р 
      Oper_Los_Xx_Val := (SELECT paramval::numeric FROM agreeregdev_period
                 WHERE 
	        linkid   = _pointid       
	    AND paramid  = ATTR_LOSS_XX  
	    AND paramval ~ NUMBER_EXPR
	    AND period   <= opdate 
                 ORDER BY period DESC
                 LIMIT 1 
      );    

      Oper_Los_Xx_Val := COALESCE(Oper_Los_Xx_Val,0); 
      Oper_Loss_Load_Val := OpDiff * CalcKoef * LoadLossProz / 100;

   ELSE
       -- силовой тр-р
       DECLARE
          CosFi   NUMERIC;
          TmpVal  NUMERIC;
          LossVal NUMERIC; -- значение параметра
          LossSHC NUMERIC; -- значение параметра потери КЗ 
          NomPow  NUMERIC; -- номинальная мощность
          DID     INTEGER; -- ид устройства
       BEGIN
          DID := (SELECT paramval::integer FROM agreeregdev_period
	  WHERE 
	     linkid   = _pointid        
	     AND paramid  = ATTR_TRANS_POW 
	     AND paramval ~ NUMBER_EXPR 
                     AND period   <= opdate
                  ORDER BY period DESC
                  LIMIT 1    
          );   
          
          -- справочная номинальная мощность
          NomPow := (SELECT valman::numeric FROM regdevattr
              WHERE
                     deviceid = DID          AND
                     paramid  = DIC_POW_NOM  AND
                     valman   ~ NUMBER_EXPR
                  LIMIT 1
          );
          NomPow := COALESCE(NomPow,0);          
          
          -- справочные потери короткого замыкания
          LossSHC := (SELECT valman::numeric FROM regdevattr
              WHERE
                     deviceid = DID           AND
                     paramid  = DIC_LOSS_SHCR  AND
                     valman   ~ NUMBER_EXPR
                  LIMIT 1
          );
          LossSHC := COALESCE(LossSHC,0);          
          
          -- справочные потери холстого хода
          LossVal := (SELECT valman::numeric FROM regdevattr
              WHERE
                     deviceid = DID          AND
                     paramid  = DIC_LOSS_XX  AND
                     valman   ~ NUMBER_EXPR
                  LIMIT 1
          );
          LossVal := COALESCE(LossVal,0);
                    
          Oper_Diff_Days :=  (opdate - OpPrevDat);
          
          Oper_Trans_Off_Val := (
          SELECT valman::numeric FROM regdevoper
             WHERE
	linkid   = _pointid        AND 
                paramid  = OPER_TRANS_OFF AND
                operdate = opdate      AND
                valman   ~ NUMBER_EXPR    
             LIMIT 1    
          );
          Oper_Trans_Off_Val := COALESCE(Oper_Trans_Off_Val,0);

          Oper_Los_Xx_Val := LossVal * (Oper_Diff_Days * 24 - Oper_Trans_Off_Val);

          Oper_Kos_Fi_Val := (
          SELECT valman::numeric FROM regdevoper
             WHERE
	linkid   = _pointid     AND 
                paramid  = OPER_KOS_FI AND
                operdate = opdate      AND
                valman   ~ NUMBER_EXPR 
             LIMIT 1    
          );
          Oper_Kos_Fi_Val := COALESCE(Oper_Kos_Fi_Val,0.85);

          
          TmpVal := NomPow * Oper_Kos_Fi_Val * (Oper_Diff_Days * 24 - Oper_Trans_Off_Val);
          IF TmpVal < 0.001 THEN
	TmpVal := 0;
          ELSE
	TmpVal := (OpDiff * CalcKoef) / TmpVal;
          END IF;  
          Oper_Loss_Load_Val :=  (Oper_Diff_Days * 24 - Oper_Trans_Off_Val) * (TmpVal*TmpVal) * LossSHC;
                     
       END; -- силовой тр-р
   END IF;
   
   
   -- количество часов работы в сутки
   Attr_hour_val = (
      SELECT paramval::numeric FROM agreeregdev_period 
      WHERE 
             linkid   = _pointid        
         AND paramid  = ATTR_HOUR 
         AND paramval ~ NUMBER_EXPR
         AND period   <= opdate        
      ORDER BY period DESC
      LIMIT 1
   ); 
   IF Attr_hour_val IS NULL THEN
      Attr_hour_val := 24;
   END IF; 
   --

   -- разница в днях между снятием показаний
   Oper_Diff_Days :=  (opdate - OpPrevDat);
   --

   -- ПОТЕРИ В ЛИНИИ
   IF NOT EXISTS(SELECT 1 FROM agreepoint_line 
             WHERE agreepoint_line.pointid  = _pointid) 
   THEN 
      Oper_Loss_Line_Val = (OpDiff * CalcKoef + Oper_Loss_Load_Val + Oper_Los_Xx_Val) * LineLossProz / 100;
   ELSE
      BEGIN 
      SELECT INTO Oper_Loss_Line_Val 0.003 /(1.73^2) * ((OpDiff * CalcKoef) ^ 2)/ (Oper_Diff_Days * Attr_hour_val) * 
         (SELECT SUM(po * linlen / (voltage*voltage))::numeric as poteri FROM
         (SELECT atr.valman::numeric as po, agreepoint_line.linlen, agreepoint_line.voltage  
         FROM agreepoint_line 
         JOIN (select * from regdevattr where paramid = 1197) AS atr ON agreepoint_line.lineid=atr.deviceid
         WHERE agreepoint_line.pointid = _pointid) as tab);
      EXCEPTION
         WHEN division_by_zero THEN Oper_Loss_Line_Val = 0;
         WHEN others THEN Oper_Loss_Line_Val = 0;
      END;     
   END IF;
   
   -- отчётное кол-во
   OpRepVal := OpDiff * CalcKoef + 
               Oper_Loss_Line_Val + 
               Oper_Los_Xx_Val  + 
               Oper_Loss_Load_Val +
               Oper_Add_Sum_Val; 
    
   OpRepVal := round(CAST (OpRepVal AS numeric), 4);

   --** 2014-12-08
   SubSum_Val = bee_get_subabo_sum_1(_pointid,opdate::text); 
   SELECT doctype in (1910, 1911) FROM agreement AS amn join agreepoint AS apn ON apn.linkid = amn.rowid AND apn.rowid =_pointid  INTO _transmit;   --** 2016-04-25   
   IF _transmit IS NULL THEN _transmit = false; END IF;

   IF  OpRepVal - SubSum_Val < -0.50 AND _transmit THEN 
         IF SubSum_Val >  0  THEN 
            ERR_CODE = -7;
            RETURN ERR_CODE; 
            else
               ERR_CODE = -6;
               RETURN ERR_CODE; 
         END IF;
           
   END IF;
   --**
   
   --   
   DevI := (SELECT devid FROM agreepoint WHERE rowid = _pointid LIMIT 1);   
   ------------------------------------
   BEGIN -- TRANS   
      LOCK TABLE regdevoper IN SHARE MODE;

      
   
      IF NOT EXISTS(SELECT 1 FROM regdevoper WHERE linkid = _pointid AND operdate = opdate LIMIT 1) THEN
      
      FOR Rec IN (SELECT 
                  _pointid AS linkid,
                  opdate   AS operdate,   
                  paramid, 
                  ed,
       CASE -- val
          WHEN paramid = OPER_CALC_TAG THEN '99'
          WHEN paramid = 1005          THEN '121' 
          ELSE val
       END AS val,	
       CASE -- valman 	
      WHEN  paramid = OPER_CALC_TAG   THEN  OPER_CALC_VID            	-- вид расчёта
          WHEN  paramid = OPER_CUR_DATE   THEN  opdate::text             	-- дата снятия показаний
      WHEN  paramid = OPER_CUR_REGS   THEN  operval                  	-- текущие показания
      WHEN  paramid = OPER_PREV_REGS  THEN  OpPrevReg::text          	-- предыдущие показания 
          WHEN  paramid = OPER_PREV_DATE  THEN  OpPrevDat::text          	-- дата снятия пред. показаний 
      WHEN  paramid = OPER_DIFF_REGS  THEN  OpDiff::text             	-- разность показаний
      WHEN  paramid = OPER_LOSS_LINE  THEN  Oper_Loss_Line_Val::text 	-- потери в линиях
      WHEN  paramid = OPER_LOSS_XX    THEN  Oper_Los_Xx_Val::text    	-- потери хх
      WHEN  paramid = OPER_LOSS_LOAD  THEN  Oper_Loss_Load_Val::text 	-- нагрузочные потери 
      WHEN  paramid = OPER_KOS_FI     THEN  Oper_Kos_Fi_Val::text    	-- косинус фи
          WHEN  paramid = OPER_ADD_SUM    THEN  Oper_Add_Sum_Val::text   	-- дополнительная сумма кВт*ч
          WHEN  paramid = OPER_SOC_NORM   THEN  '0'    			 	-- соц. норма кВт*ч
          WHEN  paramid = OPER_OVER_SNORM THEN  '0'    				-- сверх соц. нормы кВт*ч
      WHEN  paramid = OPER_REP_AMO    THEN  ROUND(OpRepVal, 0)::text 	-- отчётное кол-во эл.энергии
      WHEN  paramid = OPER_TRANS_OFF  THEN  Oper_Trans_Off_Val::text 	-- кол-во час-ов откл-я сил-го тр-ра
          WHEN  paramid = 1005            THEN '-'
          WHEN  paramid = OPER_AKT_NUM    THEN  COALESCE(akt,'0')
      ELSE CASE WHEN valman IS NULL THEN '-'
                ELSE valman END     
       END AS valman,
       timeperiod
       FROM regdevattr
       WHERE 
          deviceid = DevI AND
          (paramid  IN (
              SELECT rowid FROM dic_elements 
              WHERE 
                 link = 38 AND 
                 element_code::text LIKE '3%'
          )
          ) AND
          (paramid  NOT IN (
              SELECT paramid FROM regdevoper
              WHERE 
                 linkid    = _pointid AND
                 operdate  = opdate
              )
         )
      ) LOOP 
             INSERT INTO regdevoper     (linkid,     operdate,     paramid,     ed,     val,     valman,     timeperiod)  
                             values (Rec.linkid, Rec.operdate, Rec.paramid, Rec.ed, Rec.val, Rec.valman, Rec.timeperiod) RETURNING rowid into NR;
             IF NR IS NULL then
                ERR_CODE = -4; 
                RETURN ERR_CODE; 
             END IF;                                             
          END LOOP;
      ELSE 
       FOR REC IN  (SELECT rowid,
                           CASE -- val
                              WHEN paramid = OPER_CALC_TAG THEN '99'
                              WHEN paramid = 1005          THEN '121'
                                 ELSE val
                           END AS val,
                           CASE -- valman 	
                          WHEN  paramid = OPER_CALC_TAG  THEN  OPER_CALC_VID            -- вид расчёта
	          WHEN  paramid = OPER_CUR_DATE  THEN  opdate::text             -- дата снятия показаний
	          WHEN  paramid = OPER_CUR_REGS  THEN  operval                  -- текущие показания
	          WHEN  paramid = OPER_PREV_REGS THEN  OpPrevReg::text          -- предыдущие показания 
	          WHEN  paramid = OPER_PREV_DATE THEN  OpPrevDat::text          -- дата снятия пред. показаний 
	          WHEN  paramid = OPER_DIFF_REGS THEN  OpDiff::text             -- разность показаний
	          WHEN  paramid = OPER_LOSS_LINE THEN  Oper_Loss_Line_Val::text -- потери в линиях
	          WHEN  paramid = OPER_LOSS_XX   THEN  Oper_Los_Xx_Val::text    -- потери хх
	          WHEN  paramid = OPER_LOSS_LOAD THEN  Oper_Loss_Load_Val::text -- нагрузочные потери 
	          WHEN  paramid = OPER_KOS_FI    THEN  Oper_Kos_Fi_Val::text    -- косинус фи
	          WHEN  paramid = OPER_ADD_SUM   THEN  Oper_Add_Sum_Val::text   -- дополнительная сумма кВт*ч
	          WHEN  paramid = OPER_SOC_NORM   THEN '0'  		    -- соц. норма кВт*ч
                              WHEN  paramid = OPER_OVER_SNORM THEN '0'    		    -- сверх соц. нормы кВт*ч
	          WHEN  paramid = OPER_REP_AMO   THEN  ROUND(OpRepVal, 0)::text -- отчётное кол-во эл.энергии
	          WHEN  paramid = OPER_TRANS_OFF THEN  Oper_Trans_Off_Val::text -- кол-во час-ов откл-я сил-го тр-ра
	          WHEN  paramid = 1005           THEN '-'
	          WHEN  paramid = OPER_AKT_NUM   THEN  COALESCE(akt,'0')
                            ELSE  valman
                           END from regdevoper
                            WHERE linkid = _pointid AND operdate = opdate)
        LOOP 
            UPDATE regdevoper SET val = Rec.val, valman = Rec.valman WHERE rowid = Rec.rowid RETURNING rowid into NR;
            IF NR IS NULL then
               ERR_CODE = -4;
               RETURN ERR_CODE; 
            END IF;  
        END LOOP;    
       
      END IF;
   --
   END; -- TRANS    
   ------------
   PERFORM bee_set_subabo_sum_1(_pointid,opdate::text);  
   --   
   UPDATE regdevoper SET valman = v637  WHERE linkid = _pointid AND operdate = opdate AND paramid = 637;
  
   IF v1005 IS NOT NULL THEN 
    UPDATE regdevoper SET valman = v1005 WHERE linkid = _pointid AND operdate = opdate AND paramid = 1005;
   END IF;
  
RETURN ERR_CODE;
--
END;

$$;

comment on function bee_add_regdevoper_registered_435(integer, date, varchar, varchar) is 'Расчет по показаниям. Используется в AgreeRegDev.java, LossDistr.java, AppUtils.java; bee_reload_external(), copy_points_to(varchar), external_meko_import_rows(), external_meko_import_rows(inet)';

alter function bee_add_regdevoper_registered_435(integer, date, varchar, varchar) owner to pgsql;

