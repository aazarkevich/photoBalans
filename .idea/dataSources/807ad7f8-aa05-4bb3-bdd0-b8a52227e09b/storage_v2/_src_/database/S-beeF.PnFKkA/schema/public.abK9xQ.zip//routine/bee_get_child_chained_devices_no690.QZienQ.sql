create function bee_get_child_chained_devices_no690(xlid integer, pid integer) returns refcursor
    language plpgsql
as
$$
/*
	ito07, add ito06 2014-06-26, add 2014-10-21
	ПОЛУЧИТЬ СПИСОК УСТРОЙСТВ СУБАБОНЕНТОВ (не отключенных)
	lid LOCID (denet.rowid)
	pid POINTID (agreepoint.rowid идентификатор устройсва по договору)
	pid запитывающее устройство
*/
DECLARE
	rf REFCURSOR;
--
BEGIN
	OPEN rf FOR   	
	   SELECT apn.rowid,apn.prodnumber 
	     FROM agreepoint AS apn
	LEFT JOIN agreement AS amn  ON apn.linkid = amn.rowid
	     JOIN bee_rep_get_ard_per_max(664) AS ard ON ard.linkid = apn.rowid 
                  AND paramval IS NOT NULL AND paramval NOT IN ('?','-','0') AND paramval ~ E'^\\d{1,}'   
                  AND ard.paramval::integer = pid
        LEFT JOIN (SELECT paramval, linkid FROM agreeregdev WHERE paramid = 690) AS p690 ON apn.rowid=p690.linkid    
	    WHERE amn.locid           IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = xlid))             
	      AND apn.prodnumber    IS NOT NULL      
	      AND ((p690.paramval IS NULL) OR (length(trim(p690.paramval)) < 4)) 
	       AND  docstatus = 79        
	     GROUP BY apn.rowid, apn.prodnumber
	     ORDER BY apn.prodnumber;
RETURN rf; 
END;
$$;

comment on function bee_get_child_chained_devices_no690(integer, integer) is 'Получить список устройств субабонентов (не отключенных). Используется в RepAkt3.java, AppUtils.java';

alter function bee_get_child_chained_devices_no690(integer, integer) owner to pgsql;

