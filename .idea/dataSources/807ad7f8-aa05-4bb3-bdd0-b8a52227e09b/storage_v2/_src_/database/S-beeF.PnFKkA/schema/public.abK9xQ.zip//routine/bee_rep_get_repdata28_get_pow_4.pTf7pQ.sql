create function bee_rep_get_repdata28_get_pow_4(amn_rowid integer, year1 date) returns SETOF bee_rep_tab28_pow
    language sql
as
$$
/*
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	ito06 2013-01-18 Приложение 1а, договорные данные - мощность
*/
SELECT 
	ard_nam.paramval||', '|| apn.prodnumber AS obj_name,

	CASE WHEN ard.paramval::integer = 311  THEN 1
             WHEN ard.paramval::integer = 308  THEN 2
             WHEN ard.paramval::integer = 310  THEN 3
             WHEN ard.paramval::integer = 306  THEN 4
        END AS ul,
	null::varchar AS ulev,
        CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_1
	       ELSE pcm.m_1	
	END					AS m_1,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_2
	       ELSE pcm.m_2	
	END					AS m_2,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_3
	       ELSE pcm.m_3	
	END					AS m_3,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_4
	       ELSE pcm.m_4	
	END					AS m_4,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_5
	       ELSE pcm.m_5	
	END					AS m_5,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_6
	       ELSE pcm.m_6	
	END					AS m_6,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_7
	       ELSE pcm.m_7	
	END					AS m_7,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_8
	       ELSE pcm.m_8	
	END					AS m_8,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_9
	       ELSE pcm.m_9	
	END					AS m_9,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_10
	       ELSE pcm.m_10	
	END					AS m_10,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_11
	       ELSE pcm.m_11	
	END					AS m_11,
	CASE WHEN amn.doctype in (1909, 1911) --** 2016-04-25
	       THEN pcmf.m_12
	       ELSE pcm.m_12	
	END					AS m_12,
	ard_maxpow.paramval AS max_pow,
	ard_addpow.paramval AS add_pow,
	ard_okved.paramval AS okved,
	null::text AS tg,
	null::bigint AS hours
      
     FROM agreement   AS amn 
     JOIN agreepoint  AS apn ON apn.linkid = amn.rowid
     JOIN agreeregdev AS ard_nam ON ard_nam.linkid = apn.rowid AND ard_nam.paramid = 418
LEFT JOIN agreeregdev AS ard2 ON apn.rowid = ard2.linkid AND ard2.paramid=690 AND is_date(ard2.paramval)
LEFT JOIN agreeregdev AS ard_okved ON ard_okved.linkid = apn.rowid AND ard_okved.paramid = 1030
LEFT JOIN bee_rep_get_ard_per_max(439) AS ard  ON apn.rowid = ard.linkid
LEFT JOIN bee_rep_get_ard_per_max(426) AS  ard_maxpow  ON apn.rowid =  ard_maxpow.linkid
LEFT JOIN bee_rep_get_ard_per_max(685) AS  ard_addpow  ON apn.rowid =  ard_addpow.linkid

LEFT JOIN (select * from bee_rep28_get_consum($1,$2,1043))   AS pcm ON pcm.pointid  = apn.rowid
LEFT JOIN (select * from bee_rep28_get_consum_f($1,$2,1043)) AS pcmf ON pcmf.pointid  = apn.rowid

    WHERE amn.rowid = $1
      AND (ard2.paramval IS NULL OR ard2.paramval::date >= to_char($2,'YYYY-mm-01')::date - '11 month'::interval) 
    ORDER BY ul,obj_name;
$$;

comment on function bee_rep_get_repdata28_get_pow_4(integer, date) is 'Приложение 1а, договорные данные - мощность. Используется в bee_rep_get_repdata28_get_pow(int, date, int), bee_rep_get_repdata28_get_pow_tot(int, date, int)';

alter function bee_rep_get_repdata28_get_pow_4(integer, date) owner to postgres;

