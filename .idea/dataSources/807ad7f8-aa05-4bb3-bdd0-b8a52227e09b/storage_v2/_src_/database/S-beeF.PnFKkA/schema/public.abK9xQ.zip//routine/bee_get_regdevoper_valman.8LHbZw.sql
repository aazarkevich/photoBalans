create function bee_get_regdevoper_valman(pointid integer, dat date, pid integer) returns character varying
    language plpgsql
as
$$
BEGIN
   RETURN 
      (SELECT valman FROM regdevoper 
      WHERE 
         operdate = dat     AND  
         linkid   = pointid AND
         paramid  = pid     
         LIMIT 1);
END;
$$;

comment on function bee_get_regdevoper_valman(integer, date, integer) is 'Используется в vbee_get_opervalues_buf';

alter function bee_get_regdevoper_valman(integer, date, integer) owner to postgres;

