create function bee_rep_pay_map_change_get_content_cd(bd_rowid integer) returns SETOF bee_rep_pay_map_cd
    language sql
as
$$
    /*
        Карта расхода ЦД исправление
    */
	     SELECT 
		    bdc.tar_grp, -----
		    '01'||to_char(bd.docdat,'.MM.YYYY') AS s_date,
		    to_char((to_char(bd.docdat+'1 month'::interval,'YYYY-MM')||'-01')::date -'1 day'::interval,'DD.MM.YYYY') AS e_date,
		    func.*,
	  
		    bdc.price,
		    sum(bdc.cost_no_tax),
		    sum(bdc.tax_sum),
		    sum(bdc.cost_with_tax)
	       FROM bee_rep_map_change_info_get_content_cd
		    ((SELECT linkid FROM bee_docs WHERE rowid=$1),
		    (to_char((SELECT doc.docdat FROM bee_docs_change AS bdc
		                JOIN bee_docs AS doc ON doc.rowid = bdc.wher WHERE bdc.who = $1
		             ),'YYYY-MM')||'-01')::date,
		    ((to_char((SELECT doc.docdat FROM bee_docs_change AS bdc
		                 JOIN bee_docs AS doc ON doc.rowid = bdc.wher WHERE bdc.who = $1
		              )+'1 month'::interval,'YYYY-MM')||'-01')::date -'1 day'::interval)::date) AS func
	       JOIN bee_docs_change AS bdch ON bdch.who = $1
	       JOIN bee_docs AS doc1 ON doc1.rowid = bdch.wher       
	  LEFT JOIN bee_docs_calc AS bdc ON bdc.linkid2 = func.apn_rowid AND bdc.linkid1 = doc1.rowid AND func.row850=bdc.quantity_id
	  LEFT JOIN bee_docs AS bd ON bd.rowid = $1
	  GROUP BY loc, fil, amn_docnumber, cst_name, obj, prdnum, account, ul, v198, v196, v195, v407, v850, loss_h, loss_tot, loss_l, loss_n, koef, dopsum, bd.docdat, bdc.tar_grp, bdc.price, apn_rowid, row850, dat
	ORDER BY account, dat


$$;

comment on function bee_rep_pay_map_change_get_content_cd(integer) is 'ito06 2013-07-04 Карта расхода ЦД исправление. Используется в bee_rep_pay_map_change_get_content_with_corr_cd(int)';

alter function bee_rep_pay_map_change_get_content_cd(integer) owner to pgsql;

