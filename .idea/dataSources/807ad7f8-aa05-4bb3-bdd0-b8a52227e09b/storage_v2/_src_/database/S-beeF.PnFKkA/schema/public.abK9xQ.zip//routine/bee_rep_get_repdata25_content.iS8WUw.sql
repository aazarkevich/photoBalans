create function bee_rep_get_repdata25_content(loc_id integer, start_d date, end_d date) returns SETOF bee_repdata25_content
    language plpgsql
as
$$
/*
 2021-09-16 
 2021-05-17 добавили RowLine.sum_with_tax ( В случае дебеторской задолженности и перевод кредиторской задолженности меняем расчет для столбца 17)
 2021-04-22 by ito06 Для увеличения скорости отчета.
                     Добавили условие проверять только документы в заданном периоде + у которых есть начельное или конечное сальдо
 2021-04-21 by ito06 случай когда нет выставления только корректировки (для Волгодонска)
 2021-03-23 by ito06 В случае дебеторской задолженности и перевод кредиторской задолженности меняем расчет для столбца 17
 2021-02-11 by ito06  расчитывает столбец 17 для случая RowLine.d_start_sum = 0 AND RowLine.k_start_sum = 0  RowLine.sum_with_tax = 0
 2020-09-23 by ito06 Если потребителю выставлен только корректировочный счет-фактура, договор расторгнут и выставление счет-фактуры в расчетном периоде не произведено, 
                     нужно учитывать сумму корр и для расчета Объем услуг
 2020-08-07 by ito06 исправлена неточность
 2020-08-04 by ito06 сумма с НДС должна считаться за квартал суммой за каждый месяц (так же как в ОБОРОТНО Сальдовой)
 2020-03-19 by ito06 Если задолженность дебиторская, то погашено авансов (19: ext_sum) = 0, если заполнено в result берем из result
 2020-02-04 by ito06 Если потребителю выставлен только корректировочный счет-фактура, договор расторгнут и выставление счет-фактуры в расчетном периоде не произведено, 
                     нужно учитывать сумму корр
 2019-11-12 by ito06 Возврат задолженности деньгами, должен учитывать при расчете кредиторской задолженности
 2019-09-19 by ito06 Что бы не попадала пустая строка (в т.ч. население)
 2019-09-17 by ito06 *22* сальдо на конец периода должно браться из табл bee_docs_sheet, как в оборотно-сальдодвой ведомости
 2019-05-17 by ito07 ??? !!! for 1069 -> bee_rep_get_repdata25_content_sheet ->  bdr.sum_no_tax * (1 + bee_get_doc_tax(1163, bdr.linkid))
 2019-04-18 by ito07 for 1069 -> bee_rep_get_repdata25_content_sheet
 2017-08-22 by ito07 for 1069 -> THEN bdr.sum_no_tax * 1.18 
*/
DECLARE
     tmp_kod character varying;
     RowLine bee_repdata25_content%rowtype;
     _amount numeric    = 0;
     _summ numeric      = 0;
     _tar  numeric      = 0;
     _doc_num varchar   = '';
     _debt numeric      = 0;
     debt_trans numeric = 0;
     debt_corr numeric  = 0;
	 bdid int = 0;
     

BEGIN
    SELECT into tmp_kod  kod from denet AS de1 where de1.rowid = loc_id limit 1;
FOR RowLine IN (
SELECT 
    rec.*,
    null::numeric			AS pay_all_sum,			-- *15* 
    null::numeric  			AS fact_adv_sum,		-- *17*
    null::numeric			AS ext_sum			-- *19* 
FROM  
  (
    (SELECT  1			    AS npp,
      cust.abo_name			AS abo_num, 
    amn.docnumber			AS doc_num,
    amn.accdir			    AS accdir,
    amn.locid 			    AS loc,			
    coalesce (bds_min.debit,0)	AS d_start_sum,			-- *3*
    COALESCE(bds_min.kredit,0)	AS k_start_sum,			-- *4*

    sum(
	  CASE 
        WHEN  
           bdr.tar_typ IS NOT NULL 
           AND bdr.param IN (0,2,6) 
           AND bdr.tar_typ NOT IN (1734) 
        THEN 
            bdr.amount 
        ELSE 
           null
    END)						 AS amount,	 		-- *5*

    sum(CASE 
        WHEN  bdr.tar_typ IN (1068,1168) 
          AND bdr.param  IN (0,2,6) 
          AND bdr.tar_grp NOT IN (142,144,147,148) 				--исключаем мощность
        THEN 
            bdr.amount 
        ELSE 
            null
    END)						AS amount1,			-- *6* 

    (
       sum(CASE 
        WHEN  
           bdr.tar_typ IS NOT NULL          
		   AND bdr.param  IN (0,2,6) 
           AND bdr.tar_typ NOT IN (1734) --**2016-05-26
        THEN 
            bdr.amount 
        ELSE 
           0
       END)
    ) -          
    (
        sum(CASE 
        WHEN
            bdr.tar_typ         IN (1068,1168)     
			AND bdr.param       IN (0,2,6) 
            AND bdr.tar_grp NOT IN (142,144,147,148) 				--исключаем мощность
        THEN 
            bdr.amount 
        ELSE 
            0
        END)
    ) AS amount2,
   
    sum(CASE 		
        WHEN bdr.tar_typ IS NOT NULL AND bdr.param IN (1,2)        
           THEN 
		         bdr.sum_with_tax
		ELSE CASE 			   
               WHEN bd.doctyp = 1713 THEN null::numeric --bdp.summ				
    	ELSE null::numeric
             END 			 
    END)								AS sum_with_tax,		-- *8*

    sum(CASE 
		 WHEN bdr.tar_typ IS NOT NULL AND bdr.param IN (0,2)
    THEN bdr.sum_no_tax 
        ELSE CASE 
                WHEN bd.doctyp = 1713
                   THEN null::numeric 
                ELSE null::numeric
             END  
    END)								AS sum_no_tax,			-- *9*
  
    (sum(CASE 
        WHEN  bdr.tar_typ IN (1068,1168,1734) AND bdr.param IN (0,2)
            THEN    bdr.sum_with_tax         
            ELSE CASE 
                    WHEN bd.doctyp = 1713
                        THEN null::numeric--bdp.summ
                    ELSE null::numeric
                 END   
    END))::numeric(20,2)						AS sum_with_tax1068,		 -- *10*

	sum(CASE 
        WHEN  bdr.tar_typ IN (1068,1168,1734) AND bdr.param IN (0,2)
    THEN bdr.sum_no_tax 
        ELSE CASE 
                WHEN bd.doctyp = 1713
                   THEN null::numeric 
                ELSE null::numeric
             END   
    END)								AS sum_no_tax1068,		-- *11*
   (sum(
      CASE 
         WHEN bdr.tar_typ IN (1069,1159, 1707,1142) AND bdr.param IN (0,2,6)
         THEN bdr.sum_with_tax
         ELSE 
            null
      end
    ))::numeric(20,3) *
    sign(
        sum(CASE 
        WHEN bdr.tar_typ IN (1069,1159, 1707,1142) AND bdr.param IN (0,2,6) 
        THEN bdr.sum_no_tax
        ELSE null
        end
        )	
    )
    AS sum_with_tax1069,		-- *12*
   
    sum(CASE 
		WHEN bdr.tar_typ IN (1069,1159, 1707,1142) AND bdr.param IN (0,2, 6) 
        THEN bdr.sum_no_tax
        ELSE null
        end
    )								AS sum_no_tax1069,		-- *13*
    
    CASE
        WHEN sum(bdr.amount)  <> 0
    THEN sum(bdr.sum_with_tax)/sum(bdr.amount)
        ELSE null
    END::numeric (17,6)						AS tar,				-- *14*
                sum(CASE 
        WHEN  bdp.pay_vid in (1171,1172,1173,1661)
    THEN bdp.summ
        ELSE null
    END)								AS fact_all_sum,		-- *16*		

    sum(CASE 
        WHEN  bdp.pay_vid = 1621 
    THEN bdp.summ
        ELSE null
    END)								AS payed_sum,			-- *18*	
                sum(CASE 
        WHEN  bdp.pay_vid = 1720 
    THEN bdp.summ
        ELSE null
    END)								AS retrest_sum,			-- *20*
                sum(CASE 
        WHEN  bdp.pay_vid in(1719,1724)
    THEN bdp.summ
        ELSE null
    END)								    AS disc_sum,		-- *21*
    bds_max.debit							AS d_end_sum, 		-- *22*
    bds_max.kredit							AS k_end_sum		-- *23*
       FROM agreement AS amn
      LEFT JOIN customer AS cust ON (cust.abo_code = amn.abo_code)
           JOIN bee_docs_sheet AS bds ON (bds.linkid1 = amn.rowid)  
	      
      LEFT JOIN bee_docs AS bd ON (bd.rowid = bds.linkid2)
      LEFT JOIN bee_rep_get_repdata25_content_result(bd.rowid) AS bdr 
         ON bd.docdat BETWEEN $2 AND $3 
         AND bd.doctyp IN (1065,1705,1618) 
         AND bdr.linkid  = bd.rowid

      LEFT JOIN bee_docs_pay AS bdp ON (bdp.linkid2 = bd.rowid) AND bd.docdat BETWEEN $2 AND $3 AND bd.doctyp in (1165,1169,1170,1721,1713)
      LEFT JOIN bee_rep_debit_kredit_final($2,$3) AS bds_max ON bds_max.linkid1 = amn.rowid 
      LEFT JOIN bee_rep_debit_kredit_start($2,$3) AS bds_min ON bds_min.linkid1 = amn.rowid 
          WHERE amn.locid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
            AND amn.doctype = 1910 
	        AND bee_is_agreement_get_to_report(amn.rowid, $2) 
            AND doctyp<>1066
            AND (bds_min.debit <>0 OR bds_min.kredit <>0 OR bds_max.debit <>0 OR bds_max.kredit <>0 OR bdr.amount<>0 OR bdp.summ<>0 OR bdr.sum_with_tax<>0)
            AND bds.npp<>0
            AND ( bd.docdat BETWEEN $2 AND $3  OR  bds_min.debit <>0 OR bds_min.kredit <>0 OR bds_max.debit <>0 OR bds_max.kredit <>0 )--ito06 2021-04-22
          GROUP BY abo_num, doc_num, d_start_sum, k_start_sum, d_end_sum, k_end_sum, accdir, amn.locid
          ORDER BY doc_num, abo_num, amn.locid
       )

UNION
    (SELECT 2				AS npp,
    cust.abo_name			AS abo_num, 
    amn.docnumber			AS doc_num,		
    amn.accdir				AS accdir,
    amn.locid 				AS loc,		
    null::numeric			AS d_start_sum,			-- *3*
    null::numeric  			AS k_start_sum,			-- *4*

    sum(CASE 
        WHEN  bdr.tar_typ IS NOT NULL AND bdr.tar_typ NOT IN (1734)
    THEN bdr.amount 
        ELSE null
    END)									AS amount,	 		-- *5*
    sum(CASE 
        WHEN bdr.tar_typ  = 1068 AND bdr.tar_grp NOT IN (142,144,147,148)			--исключаем мощность
    THEN bdr.amount 
        ELSE null
    END)									AS amount1,			-- *6* 
  
    sum(CASE 
        WHEN  bdr.tar_typ IS NOT NULL AND bdr.tar_typ NOT IN (1734)
    THEN bdr.amount 
        ELSE null
    END) -
    sum(CASE 
        WHEN bdr.tar_typ  = 1068 AND bdr.tar_grp NOT IN (142,144,147,148)			--исключаем мощность
    THEN bdr.amount 
        ELSE null
    END) AS amount2,			 
               
    sum(CASE 
        WHEN bdr.tar_typ IS NOT NULL
        THEN bdr.sum_with_tax
        ELSE 
        CASE 
               WHEN bd.doctyp = 1713
               THEN null::numeric
               ELSE null::numeric
            END
    END)									AS sum_with_tax,		-- *8*		
    sum(CASE 
        WHEN bdr.tar_typ IS NOT NULL
    THEN bdr.sum_no_tax 
        ELSE CASE 
                WHEN bd.doctyp = 1713
                   THEN null::numeric 
                ELSE null::numeric
             END  
    END) 									AS sum_no_tax,			-- *9*
	    
    sum(CASE 
        WHEN  bdr.tar_typ  = 1068
      THEN bdr.sum_with_tax       
        ELSE CASE 
      WHEN bd.doctyp = 1713
        THEN null::numeric
      ELSE null::numeric
             END   
    END)									AS sum_with_tax1068,		-- *10*
    sum(CASE 
        WHEN  bdr.tar_typ  = 1068 
    THEN bdr.sum_no_tax 
        ELSE CASE 
                WHEN bd.doctyp = 1713
                   THEN null::numeric
                ELSE null::numeric
             END   
    END)									AS sum_no_tax1068,		-- *11*
  
    max(CASE  WHEN bdr.tar_typ = 1069
              THEN  (SELECT bee_rep_get_repdata25_content_sheet(amn.docnumber,0,$2) as v)::numeric
              ELSE NULL
    end)                                    AS sum_with_tax1069,        -- *12*
    
    sum(CASE 
        WHEN bdr.tar_typ = 1069 
    THEN bdr.sum_no_tax
        ELSE null
    END)									AS sum_no_tax1069,		-- *13*
    
    CASE
        WHEN sum(bdr.amount)  <> 0
    THEN sum(bdr.sum_with_tax)/sum(bdr.amount)
        ELSE null
    END::numeric (17,6)							AS tar,				-- *14*
                sum(CASE 
        WHEN  bdp.pay_vid in (1171,1172,1173,1661)
    THEN bdp.summ
        ELSE null
    END)									AS fact_all_sum,		-- *16*
    sum(CASE 
        WHEN  bdp.pay_vid = 1621 
    THEN bdp.summ
        ELSE null
    END)									AS payed_sum,			-- *18*	
                sum(CASE 
        WHEN  bdp.pay_vid = 1720 
    THEN bdp.summ
        ELSE null
    END)									AS retrest_sum,			-- *20*
                sum(CASE 	
        WHEN  bdp.pay_vid in(1719,1724)
    THEN bdp.summ
        ELSE null
    END)									AS disc_sum,			-- *21*
    null::numeric								AS d_end_sum, 			-- *22*
    null::numeric								AS k_end_sum			-- *23*
       FROM agreement AS amn
      LEFT JOIN customer AS cust ON (cust.abo_code = amn.abo_code)
           JOIN bee_docs_sheet AS bds ON (bds.linkid1 = amn.rowid) 

      LEFT JOIN bee_docs AS bd ON (bd.rowid = bds.linkid2) 
	  
      LEFT JOIN (SELECT *
               FROM bee_docs_result  AS bdr	           
              LEFT JOIN ( select  linkid1 AS linkid, sum(quantity_amo) AS amount, tar_grp AS tar_grp, price, con_sum 
                            from bee_docs_calc group by linkid,  tar_grp, price, con_sum
                        ) AS calc USING (amount, tar_grp, price, linkid)
              LEFT JOIN (      (select -sum(quantity_old) AS amount, tar_grp_old AS tar_grp, price_old AS price, ' корректировка за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_old, price_old, period, con_sum,linkid2)
                         UNION (select  sum(quantity_new) AS amount, tar_grp_new AS tar_grp, price_new AS price, ' корректировка за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_new, price_new, period, con_sum, linkid2) 
                        )AS corr USING (amount, tar_grp, price, name)  
              LEFT JOIN ( (select linkid2 AS linkid, sum(quantity_old) AS amount, tar_grp_old AS tar_grp, price_old AS price, ' исправление за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_old, price_old, period, con_sum,linkid2)
                         UNION (select linkid2 AS linkid, sum(quantity_new) AS amount, tar_grp_new AS tar_grp, price_new AS price, ' исправление за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_new, price_new, period, con_sum, linkid2)                                       
                        ) AS change  USING (linkid,amount,tar_grp, price, name)   
                  WHERE ((corr.con_sum = 850 AND calc.con_sum IS NULL) OR (calc.con_sum = 850 AND corr.con_sum IS NULL) OR (change.con_sum IS NULL OR change.con_sum = 850)) 
                   
                ) AS bdr ON (bdr.linkid = bd.rowid) AND bd.docdat BETWEEN $2 AND $3 AND bd.doctyp IN (1065, 1705,1618)
                AND ((bdr.tar_typ IN(1069,1159,1707,1142) AND bd.doctyp <> 1065) OR (bdr.tar_typ NOT IN(1069,1159,1707,1142)))
      LEFT JOIN bee_docs_pay AS bdp ON (bdp.linkid2 = bd.rowid) AND bd.docdat BETWEEN $2 AND $3 AND bd.doctyp in (1165,1169,1170,1721,1713)
          WHERE amn.locid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
            AND amn.doctype = 1910 
            AND bee_is_agreement_get_to_report(amn.rowid, $2) 
            AND amount IS NOT NULL 
        AND doctyp<>1066 
        AND bds.npp<>0
	  	

      GROUP BY abo_num, doc_num, accdir, amn.locid
          ORDER BY doc_num,  abo_num, amn.locid)  
UNION 
    (SELECT 3				AS npp,
    cust.abo_name			AS abo_num,
    amn.docnumber			AS doc_num,
    amn.accdir			AS accdir,
    amn.locid 			AS loc,	
    null::numeric			AS d_start_sum,			-- *3*
    null::numeric	  		AS k_start_sum,			-- *4*
    sum(CASE 
        WHEN  bdr.tar_typ IS NOT NULL AND bdr.tar_typ NOT IN (1734) 
    THEN bdr.amount 
        ELSE null
    END)								AS amount,	 		-- *5*
    sum(CASE 
        WHEN bdr.tar_typ  = 1068 AND bdr.tar_grp NOT IN (142,144,147,148)			--исключаем мощность
    THEN bdr.amount 
        ELSE null	
    END)								AS amount1,			-- *6* 

    sum(CASE 
        WHEN  bdr.tar_typ IS NOT NULL AND bdr.tar_typ NOT IN (1734)
    THEN bdr.amount 
        ELSE null
    END) -
    sum(CASE 
        WHEN bdr.tar_typ  = 1068 AND bdr.tar_grp NOT IN (142,144,147,148)			--исключаем мощность
    THEN bdr.amount 
        ELSE null	
    END)	AS amount2,			-- *6* 

                
    sum(CASE 
      WHEN bdr.tar_typ IS NOT NULL
        THEN bdr.sum_with_tax
      ELSE 
		CASE 
      WHEN bd.doctyp = 1713
       THEN null::numeric
      ELSE null::numeric
             END 			 
    END)								AS sum_with_tax,		-- *8*		
    sum(CASE 
        WHEN bdr.tar_typ IS NOT NULL
    THEN bdr.sum_no_tax 
        ELSE CASE 
                WHEN bd.doctyp = 1713
                   THEN null::numeric
                ELSE null::numeric
             END  
    END)								AS sum_no_tax,			-- *9*
    sum(CASE 
        WHEN bdr.tar_typ  = 1068
            THEN bdr.sum_with_tax
           
        ELSE CASE 
                 WHEN bd.doctyp = 1713
       THEN null::numeric
    ELSE null::numeric
             END   
    END)	    AS sum_with_tax1068,		-- *10*
    sum(CASE 
        WHEN  bdr.tar_typ  = 1068 
    THEN bdr.sum_no_tax 
        ELSE CASE 
                WHEN bd.doctyp = 1713
                   THEN null::numeric
                ELSE null::numeric
             END   
    END)								AS sum_no_tax1068,		-- *11*
  
    max(CASE  WHEN bdr.tar_typ = 1069
              THEN  (SELECT bee_rep_get_repdata25_content_sheet(amn.docnumber,0,$2) as v)::numeric
              ELSE NULL
    end) 								AS sum_with_tax1069, -- *12*
    
    sum(CASE 
        WHEN bdr.tar_typ = 1069 
    THEN bdr.sum_no_tax
       ELSE null
    END)								AS sum_no_tax1069,		-- *13*
    
    CASE
        WHEN sum(bdr.amount)  <> 0
    THEN sum(bdr.sum_with_tax)/sum(bdr.amount)
        ELSE null
    END::numeric (17,6)						AS tar,				-- *14*
                sum(CASE 
        WHEN  bdp.pay_vid in (1171,1172,1173,1661)
    THEN bdp.summ
        ELSE null
    END)								AS fact_all_sum,		-- *16*
    sum(CASE 
        WHEN  bdp.pay_vid = 1621 
    THEN bdp.summ
        ELSE null
    END)								AS payed_sum,			-- *18*	
                sum(CASE 
        WHEN  bdp.pay_vid = 1720 
    THEN bdp.summ
        ELSE null
    END)								AS retrest_sum,			-- *20*
                sum(CASE 
        WHEN  bdp.pay_vid in(1719,1724)
    THEN bdp.summ
        ELSE null
    END)								AS disc_sum,			-- *21*
    null::numeric							AS d_end_sum, 			-- *22*
    null::numeric							AS k_end_sum			-- *23*
       FROM agreement AS amn
      LEFT JOIN customer AS cust ON (cust.abo_code = amn.abo_code)
           JOIN bee_docs_sheet AS bds ON (bds.linkid1 = amn.rowid) 
	 
      LEFT JOIN bee_docs AS bd ON (bd.rowid = bds.linkid2) 
      LEFT JOIN (SELECT * 
               FROM bee_docs_result  AS bdr
              LEFT JOIN ( select  linkid1 AS linkid, sum(quantity_amo) AS amount, tar_grp AS tar_grp, price, con_sum 
                            from bee_docs_calc group by linkid,  tar_grp, price, con_sum
                        ) AS calc USING (amount, tar_grp, price, linkid)
              LEFT JOIN (      (select -sum(quantity_old) AS amount, tar_grp_old AS tar_grp, price_old AS price, ' корректировка за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_old, price_old, period, con_sum,linkid2)
                         UNION (select  sum(quantity_new) AS amount, tar_grp_new AS tar_grp, price_new AS price, ' корректировка за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_new, price_new, period, con_sum, linkid2) 
                        )AS corr USING (amount, tar_grp, price, name)  
              LEFT JOIN ( (select linkid2 AS linkid, sum(quantity_old) AS amount, tar_grp_old AS tar_grp, price_old AS price, ' исправление за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_old, price_old, period, con_sum,linkid2)
                         UNION (select linkid2 AS linkid, sum(quantity_new) AS amount, tar_grp_new AS tar_grp, price_new AS price, ' исправление за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_new, price_new, period, con_sum, linkid2)                                       
                        ) AS change  USING (linkid,amount,tar_grp, price, name)   
                  WHERE ((corr.con_sum = 1446 AND calc.con_sum IS NULL) OR (calc.con_sum = 1446 AND corr.con_sum IS NULL) OR (change.con_sum = 1446))                 
                  ) AS bdr ON (bdr.linkid = bd.rowid) AND bd.docdat BETWEEN $2 AND $3 AND bd.doctyp IN (1065, 1705,1618)
                  AND ((bdr.tar_typ IN(1069,1159,1707,1142) AND bd.doctyp <> 1065) OR (bdr.tar_typ NOT IN(1069,1159,1707,1142)))
      LEFT JOIN bee_docs_pay AS bdp ON (bdp.linkid2 = bd.rowid) AND bd.docdat BETWEEN $2 AND $3 AND bd.doctyp in (1165,1169,1170,1721,1713)
        WHERE amn.locid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
          AND amn.doctype = 1910
          AND bee_is_agreement_get_to_report(amn.rowid, $2) --2015-08-24
	            AND amount IS NOT NULL AND doctyp<>1066 AND bds.npp<>0
          AND (amount != 0 OR sum_no_tax !=0) --** ito06 2019-09-19 Что бы не попадала пустая строка (в т.ч. население)
          GROUP BY abo_num, doc_num, accdir, amn.locid
          ORDER BY doc_num,  abo_num, amn.locid)  
UNION 
    (SELECT 4				AS npp,
    cust.abo_name			AS abo_num,
    amn.docnumber			AS doc_num,		
    amn.accdir			    AS accdir,
    amn.locid 			    AS loc,		
    null::numeric			AS d_start_sum,			-- *3*
    null::numeric  			AS k_start_sum,			-- *4*

    sum(CASE 
        WHEN  bdr.tar_typ IS NOT NULL AND bdr.tar_typ NOT IN (1734)
    THEN bdr.amount 
        ELSE null
    END)								AS amount,	 		-- *5*

    sum(CASE 
        WHEN bdr.tar_typ = 1168 AND bdr.tar_grp NOT IN (142,144,147,148)			--исключаем мощность
    THEN bdr.amount 
        ELSE null
    END)								AS amount1,			-- *6* 

    sum(CASE 
        WHEN  bdr.tar_typ IS NOT NULL AND bdr.tar_typ NOT IN (1734) 
    THEN bdr.amount 
        ELSE null
    END) -

    sum(CASE 
        WHEN bdr.tar_typ = 1168 AND bdr.tar_grp NOT IN (142,144,147,148)			--исключаем мощность
    THEN bdr.amount 
        ELSE null
    END) AS amount2,			 
        
    sum(CASE 
        WHEN bdr.tar_typ IS NOT NULL
    THEN bdr.sum_with_tax
           
        ELSE CASE 
    WHEN bd.doctyp = 1713
       THEN null::numeric
    ELSE null::numeric
             END 			 
    END)								AS sum_with_tax,		-- *8*
    
    sum(CASE 
        WHEN bdr.tar_typ IS NOT NULL
    THEN bdr.sum_no_tax 
        ELSE CASE 
                WHEN bd.doctyp = 1713
                   THEN null::numeric
                ELSE null::numeric
             END  	
    END)								AS sum_no_tax,			-- *9*
    sum(CASE 
        WHEN  bdr.tar_typ = 1168
    THEN bdr.sum_with_tax
           
        ELSE CASE 
    WHEN bd.doctyp = 1713
       THEN null::numeric--bdp.summ
    ELSE null::numeric
             END   
    END)								AS sum_with_tax1068,		-- *10*
    sum(CASE 
        WHEN  bdr.tar_typ = 1168
    THEN bdr.sum_no_tax 
        ELSE CASE 
                WHEN bd.doctyp = 1713
                   THEN null::numeric
                ELSE null::numeric
             END   
    END)								AS sum_no_tax1068,		-- *11*
    
   
    max(CASE  WHEN bdr.tar_typ = 1069
              THEN  (SELECT bee_rep_get_repdata25_content_sheet(amn.docnumber,0,$2) as v)::numeric
              ELSE NULL
    end) AS sum_with_tax1069,                                     -- *12*

    sum(CASE 
        WHEN bdr.tar_typ = 1159 
    THEN bdr.sum_no_tax
        ELSE null
    END)								AS sum_no_tax1069,		-- *13*
    CASE
        WHEN sum(bdr.amount)  <> 0
    THEN sum(bdr.sum_with_tax)/sum(bdr.amount)
        ELSE null
    END::numeric (17,6)						AS tar,				-- *14*
                sum(CASE 
        WHEN  bdp.pay_vid in (1171,1172,1173,1661)
    THEN bdp.summ
        ELSE null
    END)								AS fact_all_sum,			-- *16*
    sum(CASE 
        WHEN  bdp.pay_vid = 1621 
    THEN bdp.summ
        ELSE null
    END)								AS payed_sum,			-- *18*	
                sum(CASE 
        WHEN  bdp.pay_vid = 1720 
    THEN bdp.summ
        ELSE null
    END)								AS retrest_sum,			-- *20*
                sum(CASE 
        WHEN  bdp.pay_vid in(1719,1724)
    THEN bdp.summ
        ELSE null
    END)								AS disc_sum,			-- *21*
    null::numeric							AS d_end_sum, 			-- *22*
    null::numeric							AS k_end_sum			-- *23*
       FROM agreement AS amn
      LEFT JOIN customer AS cust ON (cust.abo_code = amn.abo_code)
           JOIN bee_docs_sheet AS bds ON (bds.linkid1 = amn.rowid) 
      LEFT JOIN bee_docs AS bd ON (bd.rowid = bds.linkid2) 
	        
	 	      
      LEFT JOIN (SELECT * 
               FROM bee_docs_result  AS bdr
              LEFT JOIN ( select  linkid1 AS linkid, sum(quantity_amo) AS amount, tar_grp AS tar_grp, price, con_sum 
                            from bee_docs_calc group by linkid,  tar_grp, price, con_sum
                        ) AS calc USING (amount, tar_grp, price, linkid)
              LEFT JOIN (      (select -sum(quantity_old) AS amount, tar_grp_old AS tar_grp, price_old AS price, ' корректировка за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_old, price_old, period, con_sum,linkid2)
                         UNION (select  sum(quantity_new) AS amount, tar_grp_new AS tar_grp, price_new AS price, ' корректировка за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_new, price_new, period, con_sum, linkid2) 
                        )AS corr USING (amount, tar_grp, price, name)  

              LEFT JOIN ( (select linkid2 AS linkid, sum(quantity_old) AS amount, tar_grp_old AS tar_grp, price_old AS price, ' исправление за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_old, price_old, period, con_sum,linkid2)
                         UNION (select linkid2 AS linkid, sum(quantity_new) AS amount, tar_grp_new AS tar_grp, price_new AS price, ' исправление за '|| period As name, con_sum 
                                  from bee_docs_corr group by tar_grp_new, price_new, period, con_sum, linkid2)                                       
                        ) AS change  USING (linkid,amount,tar_grp, price, name)   
                  WHERE ((corr.con_sum = 1174 AND calc.con_sum IS NULL) OR (calc.con_sum = 1174 AND corr.con_sum IS NULL) OR (change.con_sum = 1174))
                ) AS bdr ON (bdr.linkid = bd.rowid) AND bd.docdat BETWEEN $2 AND $3 AND bd.doctyp IN (1065, 1705,1618) 
                AND ((bdr.tar_typ IN(1069,1159,1707,1142) AND bd.doctyp <> 1065) OR (bdr.tar_typ NOT IN(1069,1159,1707,1142)))
      LEFT JOIN bee_docs_pay AS bdp ON (bdp.linkid2 = bd.rowid) AND bd.docdat BETWEEN $2 AND $3 AND bd.doctyp in (1165,1169,1170,1721,1713)
          WHERE amn.locid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
           AND amn.doctype = 1910 
           AND bee_is_agreement_get_to_report(amn.rowid, $2)
           AND amount IS NOT NULL
           AND doctyp<>1066
           AND bds.npp<>0
	    
	 	
         GROUP BY abo_num, doc_num, accdir, amn.locid
         ORDER BY doc_num,  abo_num, amn.locid)
ORDER BY doc_num, loc, npp, abo_num ) AS rec ) 

LOOP 
    RowLine.fact_all_sum  = COALESCE(RowLine.fact_all_sum,0) ; --2021-09-16
	RowLine.sum_with_tax1069 = (sign(coalesce(RowLine.sum_no_tax1069,0)) * coalesce(RowLine.sum_with_tax1069,0)::numeric(20,2));

    RowLine.sum_with_tax     = coalesce(RowLine.sum_with_tax1068,0) + coalesce(RowLine.sum_with_tax1069,0); -- today
    RowLine.sum_no_tax       = coalesce(RowLine.sum_no_tax1068,0)   + coalesce(RowLine.sum_no_tax1069,0);

    SELECT COALESCE(summ,0) FROM bee_docs_pay AS bdp 
         WHERE bdp.linkid1 = (select rowid from agreement where docnumber =  RowLine.doc_num limit 1 )
         and bdp.pay_place_typ = 1713 and pay_vid = 1814
         and bdp.bank_doc_dat BETWEEN $2 AND $3 
    INTO debt_trans;
         
    debt_trans :=  COALESCE(debt_trans,0);

    SELECT COALESCE(summ,0) FROM bee_docs_pay AS bdp 
         WHERE bdp.linkid1 = (select rowid from agreement where docnumber =  RowLine.doc_num limit 1 )
         and bdp.pay_place_typ = 1713 and pay_vid IN (1642,1656)
         and bdp.bank_doc_dat BETWEEN $2 AND $3 INTO debt_corr; 
         
         debt_corr := COALESCE(debt_corr,0);

    IF  debt_trans > 0 THEN _debt = debt_trans - debt_corr;    
        ELSE _debt = 0;
    END IF;
     --**     
         
     IF RowLine.npp <> 1 THEN 
        IF RowLine.sum_with_tax = 0 AND RowLine.sum_no_tax <> 0 THEN 
       
           RowLine.sum_with_tax = (RowLine.sum_with_tax1068 + RowLine.sum_with_tax1069)::numeric(20,2);
        END IF; 
        IF RowLine.sum_with_tax1068 = 0 AND RowLine.sum_no_tax1068 <> 0 THEN 
       
		  
		   SELECT bdr.linkid  FROM bee_docs_result AS bdr 
		     join bee_docs AS bd ON bd.rowid = bdr.linkid AND  bd.linkid = (select rowid from agreement where docnumber =  RowLine.doc_num limit 1 )
			 where bd.docdat BETWEEN $2 AND $3
             and bdr.sum_no_tax = RowLine.sum_no_tax1068 into bdid; 
         
           RowLine.sum_with_tax1068 = (RowLine.sum_no_tax1068 * ( 1 + bee_get_doc_tax(1163, bdid)))::numeric(20,2); 
		
        END IF;  
            
    END IF;
    
    IF RowLine.amount IS NOT NULL AND RowLine.amount <> 0 THEN 
       RowLine.tar = (RowLine.sum_with_tax/RowLine.amount)::numeric(20,6); 
    ELSE 
       RowLine.tar = null; 
    END IF;
    
    IF RowLine.npp = 1 THEN _doc_num = RowLine.doc_num; 
       _amount = COALESCE(RowLine.amount,0); --2016-05-27
       _summ = COALESCE(RowLine.sum_with_tax,0); --2016-05-27
       _tar = COALESCE(RowLine.tar,0);  --2016-05-27
    END IF;
	
	
    --кредиторская задолженность
    IF  RowLine.k_start_sum > 0 
       THEN 
	  
        if  (RowLine.sum_with_tax <= RowLine.k_start_sum) OR (RowLine.sum_with_tax IS NULL) 
                then RowLine.fact_adv_sum = RowLine.fact_all_sum;                                                                               --*17*
                     RowLine.ext_sum = RowLine.sum_with_tax;									                --*19*                    
                else 
                     RowLine.ext_sum = RowLine.k_start_sum;                									--*19*
                     IF (RowLine.fact_all_sum - RowLine.sum_with_tax  - debt_corr + RowLine.k_start_sum)>=0
                         THEN RowLine.fact_adv_sum = RowLine.fact_all_sum - RowLine.sum_with_tax  - debt_corr + RowLine.k_start_sum;		--*17*
                         ELSE RowLine.fact_adv_sum = null::numeric;
                     END IF;   
            end if;
            if  (RowLine.sum_with_tax IS NULL) AND (RowLine.fact_all_sum IS NULL) 
                then RowLine.ext_sum = null;
            end if;              

    END IF;
	
	
    --дебиторская задолженность
   IF   RowLine.d_start_sum > 0	
    
    THEN 
	
        IF _debt <> 0 -- есть перевод долга
        THEN 
				IF (RowLine.d_start_sum + RowLine.sum_with_tax - _debt) > 0
             THEN 
			
			   --2020-03-19 Если задолженность дебиторская, то погашено авансов (19: ext_sum) = 0
			    RowLine.ext_sum = 0; --*19*
                IF (RowLine.d_start_sum + RowLine.sum_with_tax - RowLine.ext_sum - RowLine.fact_all_sum) < 0
                THEN RowLine.fact_adv_sum =  RowLine.ext_sum + RowLine.fact_all_sum - RowLine.d_start_sum - RowLine.sum_with_tax;	--*17*
                END IF;											
        ELSE 
		   
			 RowLine.ext_sum = 0; --*19*
             RowLine.fact_adv_sum = _debt - RowLine.ext_sum + RowLine.fact_all_sum; 		--*17*		
			 
			 
        END IF;
		--**
         ELSE --перевода долга нет
		 
		
		 
         RowLine.ext_sum = null::numeric;											 		--*19*
         RowLine.fact_adv_sum = null::numeric;												--*17*
     
         if (debt_corr <= 0)
            then --перевода кредиторской задолженности нет
			  if (RowLine.sum_with_tax > RowLine.d_start_sum) 
              then if (RowLine.fact_all_sum - RowLine.sum_with_tax - RowLine.d_start_sum - debt_corr > 0)
                   then RowLine.fact_adv_sum = RowLine.fact_all_sum - RowLine.d_start_sum - RowLine.sum_with_tax - debt_corr;	--*17*
                   end if;
              else
	 				if (RowLine.fact_all_sum - RowLine.sum_with_tax - RowLine.d_start_sum - debt_corr > 0)
					then RowLine.fact_adv_sum = RowLine.fact_all_sum - RowLine.d_start_sum - RowLine.sum_with_tax - debt_corr;	--*17*
			  		end if;             
             end if;	
			  
             if (RowLine.sum_with_tax IS NULL) AND (RowLine.fact_all_sum > RowLine.d_start_sum)
    		 then  RowLine.ext_sum = null;												--*19*
          		  RowLine.fact_adv_sum = RowLine.fact_all_sum - RowLine.d_start_sum;	--*17*
             end if;
			else --перевод кредиторской задолженности есть 2021-03-23, 2021-05-17 добавили RowLine.sum_with_tax
			   RowLine.fact_adv_sum = RowLine.fact_all_sum - (RowLine.d_start_sum + RowLine.sum_with_tax) ;	--*17*
 		
			end if;	             	               
       END IF;	     
    --**          
    END IF;
     
    IF (RowLine.d_start_sum = 0 AND RowLine.k_start_sum = 0 )
    THEN   
	 	

    if _debt <> 0 -- есть перевод долга
       then IF (RowLine.sum_with_tax - _debt) > 0
          THEN RowLine.ext_sum = _debt;													--*19*
            IF (RowLine.sum_with_tax - RowLine.ext_sum - RowLine.fact_all_sum) < 0
                THEN RowLine.fact_adv_sum =  RowLine.ext_sum + RowLine.fact_all_sum - RowLine.sum_with_tax;				--*17*        
            END IF;											
          ELSE RowLine.ext_sum =  RowLine.sum_with_tax;											--*19* 
               RowLine.fact_adv_sum = _debt - RowLine.ext_sum + RowLine.fact_all_sum; 							--*17*
            END IF;
       else --перевода долга нет
	   
	 	    if (RowLine.sum_with_tax > 0) and (RowLine.fact_all_sum > RowLine.sum_with_tax + debt_corr)
                then RowLine.fact_adv_sum = RowLine.fact_all_sum - RowLine.sum_with_tax - debt_corr;					--*17*  
				else 	 
				    if  (RowLine.sum_with_tax = 0 AND debt_corr = 0 ) 
				        then RowLine.fact_adv_sum = RowLine.fact_all_sum ; --*17*   ito06 2021-02-11
				     end if;
					if  (RowLine.fact_all_sum is null AND debt_corr = 0 ) 
					    then RowLine.fact_adv_sum = -RowLine.sum_with_tax1069 ; --*17*   ito06 2021-04-21
					end if;
            end if;
			 	
            end if;
            
    END IF;
    --**  	
       
    RowLine.pay_all_sum = ( --*15*  
        select sum(COALESCE(a,0)) from  unnest(ARRAY[
        coalesce(RowLine.payed_sum,0),          --*18*      
        coalesce(RowLine.fact_all_sum,0),       --*16*
        coalesce(RowLine.ext_sum,0),            --*19*
        - coalesce(RowLine.fact_adv_sum,0)       --*17*
        ]) AS a); 	--*15*     
  	
  
	
   IF (RowLine.npp = 2) THEN  
       IF ( _doc_num = RowLine.doc_num AND 
            _amount  <> RowLine.amount  AND 
        _summ    <> RowLine.sum_with_tax AND 
        _tar     <> RowLine.tar)
       THEN  
          RETURN NEXT RowLine; 
       END IF;   
    ELSE 
       RETURN NEXT RowLine; 
           
   END IF;  

END LOOP;								
END;
$$;

comment on function bee_rep_get_repdata25_content(integer, date, date) is 'Реализация эл эн. Используется в bee_rep_get_repdata25_all(int, date, date), bee_rep_get_repdata25_summ(int, date, date, int), bee_rep_get_repdata30_tmpmix(integer, date, date), bee_rep_get_repdata30_tmpuni(integer, date, date), bee_rep_get_repdata30_tmpur(integer, date, date)';

alter function bee_rep_get_repdata25_content(integer, date, date) owner to postgres;

