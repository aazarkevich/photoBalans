create function bee_get_points_by_agreement(agreeid integer) returns integer[]
    language plpgsql
as
$$
    --
-- ИДЕНТИФИКАТОРЫ ТОЧЕК УЧЁТА ПОДКЛЮЧЕНИЯ ПО ДОГОВОРУ
-- agreeid : код договора
-- 
BEGIN
   RETURN ARRAY(
     SELECT agreepoint.rowid FROM agreepoint
     JOIN   agreement ON agreepoint.linkid = agreement.rowid
     WHERE  agreement.rowid = agreeid
   );
--
END;
$$;

comment on function bee_get_points_by_agreement(integer) is 'Идентификаторы точек учета подключения по договору. Используется в RepAkt.java, RepAkt1.java, RepAktHistory.java, AppUtils.java';

alter function bee_get_points_by_agreement(integer) owner to postgres;

