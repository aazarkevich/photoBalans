create function bee_docs_change_add_new_doc(_agreeid integer, _pids integer[], _uid integer, _lid integer, _bd_date text, _corr_date text, _docnum integer, _docid integer) returns SETOF docs_corr_new_doc
    language plpgsql
as
$$
/*
	add ito06  2015-01-19
	add ito06  2013-10-09
	ito06 2012-03-26 Исправление счет-фактур
	_agreeid   - agreement.rowid
	_pids      - agreepoint.rowid[]
	_uid       - deusers.rowid
	_lid       - denet.rowid
	_bd_date   - дата изменяемого
	_corr_date -  дата изменения
	_docnum    - номер изменения
	_docid     - bee_docs_rowid (изменяемого)
*/
	DECLARE
		RowLine docs_corr_new_doc%rowtype;
		Rec RECORD;
		Rec2 RECORD;
		_bd_COUNT INTEGER;
		_date_corr date = _corr_date::DATE;
		_date_bd date = _bd_date::DATE;
		_result VARCHAR = '';
		_bd_rowid INTEGER;
		_bdc_result INTEGER;
	        _prefix INTEGER = (SELECT prefix FROM dic_prefix WHERE locid = _lid);
	        _tar_grp_old INTEGER;
	        _quantity_old NUMERIC(10,0);
	        _price_old NUMERIC;
	        _cost_old NUMERIC(12,2);
	        _tar_grp_new INTEGER;
	        _quantity_new NUMERIC(10,0);
	        _price_new NUMERIC;
	        _cost_new NUMERIC(12,2);
		_tax_rate_old NUMERIC(12,2);
		_tax_sum_old NUMERIC(12,2);
	        _cost_with_tax_old NUMERIC(15,2);
		_tax_rate_new NUMERIC(12,2);
		_tax_sum_new NUMERIC(12,2);
	        _cost_with_tax_new NUMERIC(15,2);
	        _diff_kvt NUMERIC(10,0);
	        _diff_sum NUMERIC(12,2);
		_con_sum INTEGER = 0;
		_COUNT INTEGER = 0;
	        _COUNT1 INTEGER = 0;
	        _COUNT2 INTEGER = 0;
	---  
	BEGIN
	---  

		BEGIN
			
				
					INSERT INTO bee_docs (linkid, pref, docnum, doctyp, docdat, docvid, edit, doc_tag, exported)
						VALUES (_agreeid, _prefix, _docnum, 1705, _date_bd, NULL, FALSE, NULL, NULL) RETURNING rowid INTO _bd_rowid;

                                        INSERT INTO bee_docs_change (who, wher) VALUES (_bd_rowid, _docid);

					RowLine.result = 'bee_docs.rowid';
					RowLine.pid = _bd_rowid;
					
					RETURN NEXT RowLine;
				
			
		EXCEPTION
			WHEN unique_violation THEN
				RowLine.result = 'Ошибка при вставке в bee_docs : дублируется уникальный ключ!';
				RowLine.pid = -1;
				
				RETURN NEXT RowLine;
			WHEN OTHERS THEN
				IF _bd_rowid IS NULL THEN
				RowLine.result = 'Ошибка при вставке в bee_docs период закрыт!';
				RowLine.pid = -1;
				
				RETURN NEXT RowLine; 
			
			ELSE
				RowLine.result = 'Ошибка при вставке в bee_docs (OTHERS)!';
				RowLine.pid = -1;
				
				RETURN NEXT RowLine;
				END IF; 
		END;
IF _bd_rowid IS NOT NULL 
           THEN
		FOR Rec IN 
			SELECT rowid FROM agreepoint WHERE rowid = any(_pids)
		LOOP
			begin
				 _COUNT  = 0; --количество записей для 850 параметра
				_COUNT1 = 0; --количество записей для 1446 параметра (по норме)
				_COUNT2 = 0; --количество записей для 1174 параметра (сверх нормы)				
				FOR Rec2 IN 
					(SELECT bee_docs_calc.rowid, bee_docs_calc.con_sum FROM bee_docs_calc
						 JOIN bee_docs ON bee_docs_calc.linkid1 = bee_docs.rowid
						 WHERE bee_docs_calc.linkid2 = Rec.rowid
						 AND bee_docs.docdat = _date_corr::DATE ORDER BY 2)
				LOOP
					IF (Rec2.con_sum = 850) 
                                           THEN  _COUNT = _COUNT + 1;
                                                 _con_sum = 850;
                                           ELSE IF  (Rec2.con_sum = 1446) 
                                                   THEN  _COUNT1 = _COUNT1 + 1;
                                                         _con_sum = 1446;
                                                   ELSE  _COUNT2 = _COUNT2 + 1;
                                                         _con_sum = 1174;
                                                END IF;
                                        END IF; 

					_tar_grp_new = (SELECT tarifid FROM agreepoint_tarif WHERE pointid = Rec.rowid AND period <= _date_corr::DATE ORDER BY period DESC LIMIT 1);
					IF (_tar_grp_new IS NULL) THEN
						RowLine.result = 'Не найден тариф (новый) для точки';
						RowLine.pid = Rec.rowid;						
						RETURN NEXT RowLine;
					END IF;

					IF (Rec2.con_sum = 1174) 
					   THEN _price_new = (SELECT summ1 FROM dic_tarif_sum 
					                       WHERE tarifid = _tar_grp_new AND period <= _date_corr::DATE ORDER BY period DESC LIMIT 1); 
					   ELSE _price_new = (SELECT summ FROM dic_tarif_sum 
						                WHERE tarifid = _tar_grp_new AND period <= _date_corr::DATE ORDER BY period DESC LIMIT 1); 
					END IF;     
					
					IF (_price_new IS NULL) THEN _price_new = 0; END IF;

					_tax_rate_new = (SELECT tax_proc FROM bee_docs_tax WHERE dat1 <= _date_corr::DATE ORDER BY dat1 DESC LIMIT 1);
					IF (_tax_rate_new IS NULL) THEN _tax_rate_new = 0; END IF;
					
					_tar_grp_old = (SELECT tar_grp FROM bee_docs_calc WHERE rowid = Rec2.rowid);
					
					_quantity_old = (SELECT quantity_amo FROM bee_docs_calc WHERE rowid = Rec2.rowid);
					IF (_quantity_old IS NULL) THEN _quantity_old = 0; END IF;
					
					_price_old = (SELECT price FROM bee_docs_calc WHERE rowid = Rec2.rowid);
					IF (_price_old IS NULL) THEN _price_old = 0; END IF;

					_cost_old = (SELECT cost_no_tax FROM bee_docs_calc WHERE rowid = Rec2.rowid);
					IF (_cost_old IS NULL) THEN _cost_old = 0; END IF;
					
					_tax_rate_old = (SELECT tax_rate FROM bee_docs_calc WHERE rowid = Rec2.rowid);
					IF (_tax_rate_old IS NULL) THEN _tax_rate_old = 0; END IF;

					_tax_sum_old = (SELECT tax_sum FROM bee_docs_calc WHERE rowid = Rec2.rowid);
					IF (_tax_sum_old IS NULL) THEN _tax_sum_old = 0; END IF;

					_cost_with_tax_old = (SELECT cost_with_tax FROM bee_docs_calc WHERE rowid = Rec2.rowid);
					IF (_cost_with_tax_old IS NULL) THEN _cost_with_tax_old = 0; END IF;
					
					_quantity_new = _quantity_old;

					_cost_old = round(_cost_old, 2);
					_cost_new = round(_quantity_new * _price_new, 2);
					_diff_kvt = _quantity_new - _quantity_old;
					_diff_sum = _cost_new - _cost_old;
					_tax_sum_new = _cost_new * _tax_rate_new / 100;
					_cost_with_tax_new = _cost_new + _tax_sum_new;

					--2015-01-19
					IF _corr_date>='2014-10-01' 
					   THEN _cost_with_tax_new = 0; 
						_tax_sum_new  = 0;
					END IF;
					
					INSERT INTO bee_docs_corr (linkid1,
								   linkid2,
								   period,
								   tar_grp_new,
								   tar_grp_old,
								   quantity_old,
								   price_old,
								   cost_old,
								   tax_rate_old,
								   tax_sum_old,
								   cost_with_tax_old,
								   quantity_new,
								   price_new,
								   cost_new,
								   tax_rate_new,
								   tax_sum_new,
								   cost_with_tax_new,
								   diff_kvt,
								   diff_sum,
								   userid,
								   con_sum)
							   values (Rec.rowid,
								   _bd_rowid,
								   _date_corr::DATE,
								   _tar_grp_new,
								   _tar_grp_old,
								   _quantity_old,
								   _price_old,
								   _cost_old,
								   _tax_rate_old,
								   _tax_sum_old,
								   _cost_with_tax_old,
								   _quantity_new,
								   _price_new,
								   _cost_new,
								   _tax_rate_new,
								   _tax_sum_new,
								   _cost_with_tax_new,
								   _diff_kvt,
								   _diff_sum,
								   _uid,
								   _con_sum) RETURNING rowid INTO _bdc_result;
							
					IF (_bdc_result < 0) THEN
						RowLine.result = ' для точки ' || Rec.rowid || ' вставка в bee_docs_corr не выполнена';
						RowLine.pid = Rec.rowid;
					END IF;
					
					return next RowLine;
					
				END LOOP;

				  IF (_COUNT < 1 AND ((_COUNT1 < 1 AND _COUNT2 < 1)OR(_COUNT1 = 1 AND _COUNT2 < 1)OR(_COUNT1 < 1 AND _COUNT2 = 1))) THEN

					_tar_grp_new = (SELECT tarifid FROM agreepoint_tarif
					                WHERE pointid = Rec.rowid AND period <= _date_corr::DATE ORDER BY period DESC LIMIT 1);

					IF (_tar_grp_new IS NULL) THEN
						RowLine.result = 'Не найден тариф (новый) для точки';
						RowLine.pid = Rec.rowid;
						
						RETURN NEXT RowLine;
					END IF;

					IF (_tar_grp_new IN (150,156,154,155,152,159,157,158,153,162,160,161) AND _COUNT1 = 1 AND _COUNT2 = 0) 
	                                   THEN _price_new = (SELECT summ1 FROM dic_tarif_sum 
	                                                       WHERE tarifid = _tar_grp_new AND period <= _date_corr::DATE ORDER BY period DESC LIMIT 1);
                                                
					        _con_sum = 1174;
	                                   ELSE _price_new = (SELECT summ FROM dic_tarif_sum WHERE tarifid = _tar_grp_new AND period <= _date_corr::DATE 
					                                  ORDER BY period DESC LIMIT 1);
					        
					        IF _tar_grp_new IN (150,156,154,155,152,159,157,158,153,162,160,161) 
					           THEN _con_sum = 1446;
					           ELSE _con_sum = 850;
					        END IF;
	                                END IF;

	                                IF (_price_new IS NULL) THEN _price_new = 0; END IF;  
				
					_tax_rate_new = (SELECT tax_proc FROM bee_docs_tax WHERE dat1 <= _date_corr::DATE ORDER BY dat1 DESC LIMIT 1);
					IF (_tax_rate_new IS NULL) THEN _tax_rate_new = 0; END IF;
					
					_tar_grp_old = NULL;
					_quantity_old = 0;
					_price_old = 0;
					_cost_old = 0;
					_tax_rate_old = 0;
					_tax_sum_old = 0;
					_cost_with_tax_old = 0;
					_quantity_new = 0;
					_cost_new = 0;
					_diff_kvt = 0;
					_diff_sum = 0;
					_tax_sum_new = 0;
					_cost_with_tax_new = 0;
					
					INSERT INTO bee_docs_corr (linkid1,
								   linkid2,
								   period,
								   tar_grp_new,
								   tar_grp_old,
								   quantity_old,
								   price_old,
								   cost_old,
								   tax_rate_old,
								   tax_sum_old,
								   cost_with_tax_old,
								   quantity_new,
								   price_new,
								   cost_new,
								   tax_rate_new,
								   tax_sum_new,
								   cost_with_tax_new,
								   diff_kvt,
								   diff_sum,
								   userid,
								   con_sum)
							   values (Rec.rowid,
								   _bd_rowid,
								   _date_corr::DATE,
								   _tar_grp_new,
								   _tar_grp_old,
								   _quantity_old,
								   _price_old,
								   _cost_old,
								   _tax_rate_old,
								   _tax_sum_old,
								   _cost_with_tax_old,
								   _quantity_new,
								   _price_new,
								   _cost_new,
								   _tax_rate_new,
								   _tax_sum_new,
								   _cost_with_tax_new,
								   _diff_kvt,
								   _diff_sum,
								   _uid,
								   _con_sum) RETURNING rowid INTO _bdc_result;
							
					IF (_bdc_result < 0) THEN
						RowLine.result = ' для точки ' || Rec.rowid || ' вставка в bee_docs_corr не выполнена';
						RowLine.pid = Rec.rowid;
					END IF;
					
					return next RowLine;
				END IF;
				
			EXCEPTION
				WHEN unique_violation THEN
					RowLine.result = 'корректировка за указанный период уже существует!';
					RowLine.pid = Rec.rowid;
					
					RETURN NEXT RowLine;
				WHEN OTHERS THEN
					delete FROM bee_docs WHERE rowid = _bd_rowid;
					RowLine.result = 'Ошибка при вставке в bee_docs_corr!';
					RowLine.pid = Rec.rowid;
					
					RETURN NEXT RowLine;
			END;
		END LOOP;
	END IF;	
	END;


$$;

comment on function bee_docs_change_add_new_doc(integer, integer[], integer, integer, text, text, integer, integer) is 'Исправление счета-фактуры. Создание записи в bee_docs. Используется в DocsChange.java';

alter function bee_docs_change_add_new_doc(integer, integer[], integer, integer, text, text, integer, integer) owner to pgsql;

