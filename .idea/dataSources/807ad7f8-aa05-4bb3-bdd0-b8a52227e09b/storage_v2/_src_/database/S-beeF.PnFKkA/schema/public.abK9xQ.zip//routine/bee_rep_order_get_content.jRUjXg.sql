create function bee_rep_order_get_content(doc_num integer) returns bee_rep_order_tab
    language sql
as
$$
SELECT
 (SELECT nam FROM denet WHERE kod=substring(den.kod FROM 1 FOR 6)) AS mes_name,
 den.nam AS fil_name,
 cst_i.item AS e1029,
 doc_p.bank_doc_num AS banc_doc_num,
 to_char(doc_p.bank_doc_dat,'DD.MM.YYYY') AS banc_doc_dat,
 doc_p.summ AS summ,
 cst.consum_name||', '||cst.consum_inn||' / '||cst_k.item||' '||amn.docnumber AS cst_inf,
 doc_p.pay_comment AS coment,
 doc_p.summ_tax AS tax_summ,
 den_i.paramval AS buh_name
FROM
 bee_docs AS doc
 JOIN bee_docs_pay AS doc_p ON doc_p.linkid2 = doc.rowid
 JOIN dic_elements AS dic ON dic.rowid=doc.pref
 JOIN agreement AS amn ON amn.rowid=doc.linkid
 JOIN customer AS cst ON cst.abo_code = amn.abo_code
 JOIN denet AS den ON den.rowid=amn.locid
 LEFT JOIN denet_info AS den_i ON den_i.linkid=den.rowid AND den_i.paramid=1093
 LEFT JOIN customer_info AS cst_i ON cst_i.abo = cst.abo_code AND cst_i.elrowid=1029
 LEFT JOIN customer_info AS cst_k ON cst_k.abo = cst.abo_code AND cst_k.elrowid=84
WHERE doc_p.bank_doc_num = $1;
$$;

comment on function bee_rep_order_get_content(integer) is 'Используется в RepOrder.java';

alter function bee_rep_order_get_content(integer) owner to pgsql;

