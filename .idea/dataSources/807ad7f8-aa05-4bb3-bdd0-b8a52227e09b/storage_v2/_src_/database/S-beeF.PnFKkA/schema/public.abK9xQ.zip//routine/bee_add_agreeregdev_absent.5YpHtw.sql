create function bee_add_agreeregdev_absent() returns void
    language plpgsql
as
$$
    ---
---
--- ПОПОЛНЕНИЕ АТРИБУТОВ В agreeregdev из справочника
---
DECLARE
   Rec RECORD;
BEGIN
   --
   -- цикл по введённым устройствам 
   --
   FOR Rec IN (
      SELECT 
         agreepoint.rowid AS pointid, 
         agreepoint.devid AS dev 
      FROM agreepoint
         LEFT JOIN dic_elements ON agreepoint.devid = dic_elements.rowid
      WHERE 
         dic_elements.element_code LIKE '2%' 
   )
   LOOP
      PERFORM bee_fill_agreeregdev(Rec.pointid,Rec.dev,'2%');
   END LOOP;
   --
   --
END;
--
--
$$;

comment on function bee_add_agreeregdev_absent() is 'Пополнение аттрибутов в agreeregdev из справочника. Используется в Dicts.java, RegDevAttr.java, RepAkt5.java, AppUtils.java';

alter function bee_add_agreeregdev_absent() owner to pgsql;

