create function bee_rep_get_repdata24_corr1(tar_id integer, d_start date, d_end date, loc_id integer) returns SETOF bee_repdata24_corr
    language plpgsql
as
$$
/*
	add ito06 2016-03-03 добавляем параметр тип договора amntyp
	add ito06 2015-07-14
	add ito06 2015-06-30
	ito06 2012-02-10 Ведомость по объему услуг
*/
DECLARE
     RowLine bee_repdata24_corr%rowtype;
     tmp_kod character varying;
BEGIN
  SELECT into tmp_kod  kod from denet AS de1 where de1.rowid = loc_id limit 1;

  FOR RowLine IN (
		  SELECT 
                      a.period								AS period,
                      sum(a.amount)							AS amount,
                      sum(a.sum)							AS sum,
                      CASE 
                         WHEN (sum(a.amount))<>0
                           THEN  (sum(a.sum))/(sum(a.amount))
                         ELSE null 											
                       END::numeric(12,4)						AS m_tar
                   FROM ((     SELECT bdc_new.period 				AS period,
		                      sum(bdc_new.quantity_new)			AS amount,
		                      sum(bdc_new.cost_new)			AS sum
	                         FROM denet AS de
		                 JOIN agreement AS amn ON amn.locid = de.rowid AND amn.accdir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623)
			  	 				               AND amn.locid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
									       --AND (amn.docstatus = 79 OR amn.docstatus  = 77 AND amn.closedate >= d_start)--2015-06-30
									       AND bee_is_agreement_get_to_report(amn.rowid, d_start) -- 2015-07-14
		                 JOIN bee_docs AS bd ON bd.linkid = amn.rowid AND bd.docdat BETWEEN $2 AND $3
	                    LEFT JOIN bee_docs_corr AS bdc_new ON bdc_new.linkid2 = bd.rowid AND bdc_new.tar_grp_new = $1
	                    WHERE bdc_new.quantity_new IS NOT NULL OR bdc_new.cost_new IS NOT NULL
	                      AND amn.doctype = 1910 --2016-03-03
	                    GROUP BY bdc_new.period )
                    UNION(      SELECT bdc_old.period				AS period,
			               -sum(bdc_old.quantity_old)		AS amount,
		                       -sum(bdc_old.cost_old)			AS sum
                                  FROM denet AS de
		                  JOIN agreement AS amn ON amn.locid = de.rowid AND amn.accdir NOT IN (835, 836, 832, 837, 838, 839, 840, 841, 842,1623) 
		                                                                AND amn.locid IN (SELECT de.rowid from denet AS de where de.kod ~ tmp_kod)
										--AND (amn.docstatus = 79 OR amn.docstatus = 77 AND amn.closedate  >= d_start )--2015-06-30
										AND bee_is_agreement_get_to_report(amn.rowid, d_start) -- 2015-07-14
		                  JOIN bee_docs AS bd ON bd.linkid = amn.rowid AND bd.docdat BETWEEN $2 AND $3
	                     LEFT JOIN bee_docs_corr AS bdc_old ON bdc_old.linkid2 = bd.rowid AND bdc_old.tar_grp_old =$1
                            WHERE bdc_old.quantity_old IS NOT NULL 
                              AND amn.doctype = 1910 --2016-03-03
	                    GROUP BY  bdc_old.period
                            ORDER BY bdc_old.period )) AS a
            GROUP BY a.period)
	LOOP
		RETURN NEXT RowLine;
	END LOOP;								
END;

$$;

comment on function bee_rep_get_repdata24_corr1(integer, date, date, integer) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24_cont(int, date, date)';

alter function bee_rep_get_repdata24_corr1(integer, date, date, integer) owner to postgres;

