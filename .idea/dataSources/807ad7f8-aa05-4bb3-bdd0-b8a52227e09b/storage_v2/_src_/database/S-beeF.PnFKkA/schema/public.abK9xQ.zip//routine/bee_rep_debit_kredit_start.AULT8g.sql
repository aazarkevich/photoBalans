create function bee_rep_debit_kredit_start(start_d date, end_d date) returns SETOF bee_repdata_dk
    language sql
as
$$
/*
ito06 2011-07-21
Реализация эл эн
*/
SELECT  linkid1, 
        operdate, 
        npp, 
        s_debit,
	s_kredit
  from bee_docs_sheet as bds1 
  join ((select linkid1, 
                operdate, 
                npp, 
                final_debit AS s_debit,
	        final_kredit AS s_kredit
           from bee_docs_sheet as c1
           join (select b.linkid1,
                        b.operdate,
                        max(b.npp) AS npp
                   from bee_docs_sheet as b
                   join ( select linkid1, 
	                         max(operdate) AS operdate
	                    from bee_docs_sheet 
	                   where linkid1 not in (select linkid1       
			     	                   from bee_docs_sheet 
                                                  where operdate between $1 AND $2
                                                ) 
                             and operdate< $1
                           group by linkid1
                           order by linkid1
                         ) as a on a.linkid1=b.linkid1 and a.operdate=b.operdate 
          group by b.linkid1, b.operdate 
          order by b.linkid1 
          ) as c using (linkid1, operdate, npp))
UNION 
   (select linkid1, 
           operdate, 
           npp, 
           start_debit AS s_debit,
   	   start_kredit AS s_kredit
      from bee_docs_sheet as c1
      join ( select b.linkid1,
                    b.operdate,
                    min(b.npp) AS npp
               from bee_docs_sheet as b
               join ( select linkid1, 
	                     min(operdate) AS operdate
	                from bee_docs_sheet 
	               where operdate between $1 AND $2
                       group by linkid1
                       order by linkid1
                    ) as a on a.linkid1=b.linkid1 and a.operdate=b.operdate 
              group by b.linkid1, b.operdate 
              order by b.linkid1
         ) as c using (linkid1, operdate, npp) 
         )
)as bds2 USING (linkid1, operdate, npp)
ORDER BY linkid1 ;

$$;

comment on function bee_rep_debit_kredit_start(date, date) is 'Реализация эл эн. Используется в bee_rep_get_repdata25_content(int, date, date)';

alter function bee_rep_debit_kredit_start(date, date) owner to pgsql;

