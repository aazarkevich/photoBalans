create function bee_del_agreeregdev_transformer_param(rid integer) returns integer
    language plpgsql
as
$$
/*	
    add ito06 2020-05-21 при удалении параметра "коэфициент трансформации" он удаляется со всехе фазы данного трансформатора + удаление периодического параметра "расчетный коэфициент"
    add ito06 2020-05-14
	ito06 2020-04-27 Удаление параметров ТТ/ТН
*/
declare
    param int;--2020-05-14
    rid1 int =0; --2020-05-14
    rid2 int =0; --2020-05-14
    rid3 int =0; --2020-05-14
    trid int = 0; --2020-05-21
    pid int = 0; --2020-05-21
    par int=0; --2020-05-21
    NR int = 0; --2020-05-21
    val varchar; --2020-05-21
 

BEGIN
	BEGIN	
		
		select paramid, linkid2, linkid1, paramval from agreeregdev_transformer where rowid = rid into par, trid, pid, val; --2020-05-14
		
		 --ito06 2020-05-21
	    if (par in (2209,2222,2235, 2248,2261,2274)) --если параметр  "коэфициент трансформации"
        then  --1
	         
      	        select * from public.bee_set_koef_trans(pid , trid , par , val, 'del') into NR;    
      	       return NR;
      	      
		else --1

	 	    --ito06        2020-05-14
			  if (par in (2217, 2230, 2243, 2256, 2269, 2282)) --если параметр МПИ
			  then
			      select at1.rowid  from agreeregdev_transformer as at1
			      join agreeregdev_transformer as at2 on at2.rowid = rid and at1.linkid1 = at2.linkid1 and at1.linkid2 = at2.linkid2 and at1.paramid = at2.paramid + 3 limit 1 into rid1;
			  end if;
			  if (par in (2219,2232,2245, 2258, 2271, 2284)) --если параметр  дата поверки
			  then
			      select at1.rowid from agreeregdev_transformer as at1
			      join agreeregdev_transformer as at2 on at2.rowid = rid and at1.linkid1 = at2.linkid1 and at1.linkid2 = at2.linkid2  and at1.paramid = at2.paramid + 1 limit 1 into rid1;
			  end if;
			--
			
		    if (par in (2220, 2233, 2246, 2259, 2271, 2285)) --если параметр дата  след поверки
			  then
			      select at1.rowid from agreeregdev_transformer as at1
			      join agreeregdev_transformer as at2 on at2.rowid = rid and at1.linkid1 = at2.linkid1 and at1.linkid2 = at2.linkid2  and at1.paramid  = at2.paramid -1  limit 1 into rid2;
	
			      
			     select at1.rowid from agreeregdev_transformer as at1
			      join agreeregdev_transformer as at2 on at2.rowid = rid and at1.linkid1 = at2.linkid1 and at1.linkid2 = at2.linkid2  and at1.paramid  = at2.paramid -3 limit 1 into rid3;
			     
			      if (rid2 is not null and rid3 is not null)
			         then  		      RETURN -1;
			     end if;
	
			  end if;
			 
		    DELETE FROM agreeregdev_transformer WHERE rowid = rid;		
	   	    DELETE FROM agreeregdev_transformer WHERE rowid = rid1;
	   	   end if;


	EXCEPTION
	   WHEN UNIQUE_VIOLATION THEN
	   RETURN -1;
	END;
	RETURN 0;
END;
$$;

comment on function bee_del_agreeregdev_transformer_param(integer) is 'Удаление параметров ТТ/ТН. Используется в DevParamTT.java, DevParamTN.java, AppUtils.java';

alter function bee_del_agreeregdev_transformer_param(integer) owner to pgsql;

