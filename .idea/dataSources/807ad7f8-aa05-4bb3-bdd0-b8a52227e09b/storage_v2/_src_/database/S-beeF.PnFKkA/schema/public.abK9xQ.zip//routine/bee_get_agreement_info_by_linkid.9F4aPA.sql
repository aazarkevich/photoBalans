create function bee_get_agreement_info_by_linkid(agreeid integer) returns SETOF agreement_info_by_linkid
    language plpgsql
as
$$
DECLARE
   RowLine agreement_info_by_linkid%rowtype;
   Rec RECORD;
   Rec2 RECORD;
BEGIN
   FOR Rec IN (
       SELECT agreement_info.rowid FROM agreement_info where agreement_info.linkid = agreeid
   )
   LOOP
	   FOR RowLine IN (
		SELECT
		dic_elements.element_name,
		(SELECT COALESCE 
		   (
		     (select element_name from dic_elements where rowid::text = agreement_info.paramval), 
		     agreement_info.paramval
		   )
		),
		agreement_info.paramid,
		agreement_info.period,
		agreement_info.rowid
		FROM agreement_info
		  join dic_elements on agreement_info.paramid = dic_elements.rowid
		where agreement_info.rowid = Rec.rowid
		AND agreement_info.paramid in (1149,1151,1152,1175)
	   )
	   LOOP
	       RETURN NEXT RowLine; 
	   END LOOP;
   END LOOP;
   --
END;
$$;

comment on function bee_get_agreement_info_by_linkid(integer) is 'Используется в AgreementParams.java, SessionBean1.java';

alter function bee_get_agreement_info_by_linkid(integer) owner to pgsql;

