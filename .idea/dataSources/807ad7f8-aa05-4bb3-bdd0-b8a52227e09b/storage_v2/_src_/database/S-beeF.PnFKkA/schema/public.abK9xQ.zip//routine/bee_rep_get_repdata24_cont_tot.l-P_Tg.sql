create function bee_rep_get_repdata24_cont_tot(loc_id integer, s_date date, e_date date) returns SETOF bee_repdata24
    language plpgsql
as
$$
/*
	add ito06 2014-08-06
	add 2013-10-21	
	ito06 2012-02-10:Ведомость по объему услуг
*/
BEGIN
RETURN QUERY(
	(SELECT
		0::integer AS grp,
		'bold'::text AS row_style,
		'1900-01-01'::date AS dat,
		'0а'::text AS nn,
		'0а'::text AS nn_tmp,
		'Потребление за отчётный период'::text AS name,
		null::text AS doc_name,
		null::numeric,
		null::numeric,
		null::numeric,
		null::numeric,
		CASE 
		WHEN sum(tot_amount) <> 0
			THEN sum(tot_sum) / sum(tot_amount)
		ELSE null
		END::numeric(12,6) AS tar_m_tot,
		CASE WHEN sum(vn_amount) <> 0
			THEN sum(vn_sum) / sum(vn_amount)
		ELSE null
		END::numeric(12,6) AS tar_m_vn,
		CASE WHEN sum(sn1_amount) <> 0
			THEN sum(sn1_sum) / sum(sn1_amount)
		ELSE null
		END::numeric(12,6) AS tar_m_sn1,
		CASE WHEN sum(sn2_amount) <> 0
			THEN sum(sn2_sum) / sum(sn2_amount)
		ELSE null
		END::numeric(12,6) AS tar_m_sn2,
		CASE WHEN sum(nn_amount) <> 0
			THEN sum(nn_sum) / sum(nn_amount)
		ELSE null
		END::numeric(12,6) AS tar_m_nn,
		sum(CASE WHEN (nn<>'2.2.1.1') AND (nn<>'1.2.1.1')
		THEN tot_amount
		ELSE NULL
		END) AS tot_amount,
		sum(CASE WHEN (nn<>'2.2.1.1') AND (nn<>'1.2.1.1')
			THEN vn_amount
		ELSE NULL
		END) AS vn_amount,
		sum(CASE WHEN (nn<>'2.2.1.1') AND (nn<>'1.2.1.1')
			THEN sn1_amount
		ELSE NULL
		END) AS sn1_amount,
		sum ( CASE WHEN (nn<>'2.2.1.1') AND (nn<>'1.2.1.1')
			THEN sn2_amount
		ELSE NULL
		END) AS sn2_amount,
		sum (CASE WHEN (nn<>'2.2.1.1') AND (nn<>'1.2.1.1')
			THEN nn_amount
		ELSE NULL
		END) AS nn_amount,
		sum(tot_sum) AS tot_sum,
		sum(vn_sum) AS vn_sum,
		sum(sn1_sum) AS sn1_sum,
		sum(sn2_sum) AS sn2_sum,
		sum(nn_sum) AS nn_sum
	   FROM bee_rep_get_repdata24_cont_tmp AS a
	  WHERE dat <'1999-12-31'  AND nn NOT IN ('3.1.1','3.2.1','3.3.1')));
END;
$$;

comment on function bee_rep_get_repdata24_cont_tot(integer, date, date) is 'Ведомость по объему услуг. Используется в bee_rep_get_repdata24(int, date, date), bee_rep_get_repdata24_all(int, date, date), bee_rep_get_repdata24_all_cust(int, date, date), bee_rep_get_repdata24_cust(int, date, date)';

alter function bee_rep_get_repdata24_cont_tot(integer, date, date) owner to pgsql;

