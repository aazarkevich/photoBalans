create view vagree_mix(uch, lid, acc, dev, dat, agr) as
SELECT denet.nam                   AS uch,
       agreepoint.lid,
       agreepoint.account          AS acc,
       agreepoint.prodnumber       AS dev,
       regdevoper.operdate         AS dat,
       agreeregdev_period.paramval AS agr
FROM (((agreepoint
    JOIN denet ON ((agreepoint.lid = denet.rowid)))
    JOIN agreeregdev_period ON ((agreepoint.rowid = agreeregdev_period.linkid)))
         JOIN regdevoper ON ((agreepoint.rowid = regdevoper.linkid)))
WHERE ((agreeregdev_period.paramid = 1614) AND (length(btrim((agreeregdev_period.paramval)::text)) > 1) AND
       (regdevoper.paramid = 195) AND (length(btrim((regdevoper.valman)::text)) > 1))
GROUP BY denet.nam, agreepoint.lid, agreepoint.account, agreepoint.prodnumber, agreeregdev_period.paramid,
         regdevoper.operdate, agreeregdev_period.paramval
ORDER BY regdevoper.operdate DESC, agreepoint.lid, agreepoint.account;

alter table vagree_mix
    owner to pgsql;

