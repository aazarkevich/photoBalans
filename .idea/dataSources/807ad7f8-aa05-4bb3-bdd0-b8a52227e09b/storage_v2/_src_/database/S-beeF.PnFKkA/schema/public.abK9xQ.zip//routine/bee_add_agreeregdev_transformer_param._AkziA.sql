create function bee_add_agreeregdev_transformer_param(pid integer, trid integer, par integer, val character varying) returns integer
    language plpgsql
as
$$
/*	
    add ito06 2020-05-21 при вводе параметра "коэфициент трансформации" он распространяется на все фазы данного трансформатора + вводпериодического параметра "расчетный коэфициент"
    add ito06 2020-05-14
	ito06 2020-04-27 Ввод параметров ТТ/ТН
*/
DECLARE
	NR INTEGER;
    NR1 INTEGER;  --2020-05-14
    val1 varchar; --2020-05-14     
  
BEGIN
   begin
	   
	    --ito06 2020-05-21
	    if (par in (2209,2222,2235, 2248,2261,2274)) --если параметр  "коэфициент трансформации"
        then  --1
	        select * from public.bee_set_koef_trans(pid , trid , par , val, 'add') INTO NR;	
            
        else --1
        
	        INSERT INTO agreeregdev_transformer(linkid1,linkid2, paramid,paramval) VALUES(pid,trid, par,val) RETURNING rowid INTO NR;	
			--ito06 2020-05-14
	        if (par in (2217,2230,2243, 2256,2269,2282)) --если параметр  МПИ, 
	        then 
	
			        select paramval  from agreeregdev_transformer where paramid = par + 2 and linkid1 = pid and linkid2 = trid  into val1; 
	                if val1 is not null --если  дата поверки введена, то расчитываем дату следующей поверки
	                  then                        
	                      val1 =  (val1::date + (val ||' year')::interval)::date;               
			               INSERT INTO agreeregdev_transformer(linkid1,linkid2, paramid,paramval) VALUES(pid,trid, par + 3 ,val1 ) RETURNING rowid INTO NR1;
	                end if;
	        end if;
	        if (par in (2219,2232,2245, 2258,2271,2284)) --если параметр дата поверки, 
	            then                 
	                select paramval  from agreeregdev_transformer where paramid = par - 2 and linkid1 = pid and linkid2 = trid  into val1;             
	                if val1 is not null --если МПИ введена, то расчитываем дату следующей поверки
	                then 
	                   val1 =  (val::date + (val1 ||' year')::interval)::date;    
	                   INSERT INTO agreeregdev_transformer(linkid1,linkid2, paramid,paramval) VALUES(pid,trid, par + 1, val1) RETURNING rowid INTO NR1;
	                end if;        
	        end if;
           --
        end if ;--1      
	
   EXCEPTION
	WHEN UNIQUE_VIOLATION THEN
	RETURN -1;
   END;
   RETURN NR;
END;
$$;

comment on function bee_add_agreeregdev_transformer_param(integer, integer, integer, varchar) is ' Ввод  параметров ТТ/ТН Используется в DevParamTT.java, DevParamTN.java, AppUtils.java';

alter function bee_add_agreeregdev_transformer_param(integer, integer, integer, varchar) owner to pgsql;

