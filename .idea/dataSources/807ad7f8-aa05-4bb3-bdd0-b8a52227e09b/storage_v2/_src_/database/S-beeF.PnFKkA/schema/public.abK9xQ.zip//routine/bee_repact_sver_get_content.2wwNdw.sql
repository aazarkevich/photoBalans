create function bee_repact_sver_get_content(amn_rowid integer, start_date date, end_date date) returns SETOF bee_repact_sver_tab
    language plpgsql
as
$$
/*
 	 ito06 2020-02-05 если оборотов нет за период формирования, то берем начальный и конечный дебит, кредит из предыдущего периода, а обороты по тек периоду 0
	 ito07 2018-01-19 Акт сверки исправление
 	1713 Корректировка долга
*/
DECLARE 
	rid int :=0;
BEGIN  

	SELECT rowid FROM bee_docs_sheet AS bds WHERE  bds.operdate BETWEEN $2 AND $3 AND  bds.linkid1 = $1   ORDER BY operdate, npp LIMIT 1 INTO rid;
	IF rid IS NULL THEN
		RETURN QUERY(
		(SELECT
			('s-Сальдо на ' || to_char($2,'YYYY-MM-DD'))::varchar 			AS oper_name,
	  		final_debit::character varying										AS debit,
		 	final_kredit ::character varying										AS kredit     
		 FROM bee_docs_sheet 		AS bds
		 WHERE  bds.operdate < $2 AND  bds.linkid1 = $1
		 ORDER BY operdate DESC, npp DESC LIMIT 1) --сальдо на начало периода
	UNION ALL(
		   select 'x-Обороты за период' ::varchar 			AS oper_name,
	  		'0.00'::character varying										AS debit,
		 	'0.00' ::character varying AS kredit   
	)
		UNION ALL(SELECT
			('e-Сальдо на ' || $3)::varchar 			AS oper_name,
	  		final_debit::character varying										AS debit,
		 	final_kredit ::character varying										AS kredit     
		 FROM bee_docs_sheet 		AS bds
		 WHERE  bds.operdate < $2 AND  bds.linkid1 = $1
		 ORDER BY operdate DESC, npp DESC LIMIT 1)  -- сальдо на конец
			
		);
	ELSE
	RETURN QUERY
		(( SELECT    
	   ('s-Сальдо на ' || to_char($2,'YYYY-MM-DD'))::varchar 			AS oper_name,
	   CASE WHEN b.operdate = $2
			THEN CASE WHEN b.start_kredit = 0
		THEN b.start_debit::character varying
			ELSE ''
	   END
	   ELSE CASE WHEN a.start_kredit = 0
				 THEN a.start_debit::character varying
			 ELSE ''
		END
	   END 								AS debit,
	   CASE WHEN b.operdate = $2
		THEN CASE WHEN b.start_kredit <> 0
				  THEN b.start_kredit::character varying
				  ELSE ''
			 END
		ELSE CASE WHEN a.start_kredit <> 0
				  THEN a.start_kredit::character varying
			  ELSE ''
			 END
	   END 								AS kredit     
	 FROM
		(
		 SELECT start_debit, start_kredit, operdate 
		 FROM bee_docs_sheet AS bds
		 WHERE 
			bds.operdate BETWEEN $2 AND $3 AND 
			bds.linkid1 = $1
		  ORDER BY operdate, npp LIMIT 1
		 ) AS b 
		 LEFT JOIN 
		 (
		  SELECT final_debit AS start_debit,final_kredit AS start_kredit, operdate
		  FROM bee_docs_sheet AS bds
		  WHERE 
			 bds.operdate < $2 AND 
			 bds.linkid1 = $1
		 ORDER BY operdate DESC, npp DESC LIMIT 1
		 ) AS a ON a.operdate IS NOT NULL
	) --сальдо на начало периода
	UNION ALL
	(
	 SELECT
	   CASE WHEN ( (bds.oper_debit <> 0) oR (bds.oper_kredit <> 0)) and bd.doctyp in (1705,1706,1707,1142,1069,1618,1713,1159)  
		 THEN CASE 
			  WHEN bd.doctyp = 1705
				  THEN doctyp || '-'|| 'Исправление (СЧФ) '    || operdate
			WHEN bd.doctyp = 1706
				  THEN doctyp || '-'|| 'Исправление (КСЧФ) '   || operdate
			   WHEN bd.doctyp = 1707
				  THEN doctyp || '- '|| 'Исправление '          || operdate
			   WHEN bd.doctyp = 1142
				  THEN doctyp || '-'|| 'Исправление (СВЕРХ) '  || operdate
			  WHEN bd.doctyp = 1069
				  THEN doctyp || '-'|| '(Корректировка) '      || operdate
			WHEN bd.doctyp = 1618
				  THEN doctyp || '-'|| 'Корректировка '        || operdate
			   WHEN bd.doctyp = 1713
				  THEN doctyp || '-'|| 'Корректировка (ДОЛГ) ' || operdate
			   WHEN bd.doctyp = 1159
				  THEN doctyp || '-'|| 'Корректировка (СВЕРХ) '|| operdate
			 ELSE   
				   doctyp || '-'||  operdate
			  END     
			  -- 
			 WHEN bds.oper_debit <> 0
				  THEN CASE 
					   WHEN bd.doctyp <> 1713 and bd.doctyp not in (1705,1706,1707,1142,1069,1618,1713,1159) 
						  THEN bd.doctyp ||'-'|| 'Оказание услуг ' || operdate
						ELSE 
						bd.doctyp ||'-'||'Корректировка долга '  || operdate
					   END    	 
			   WHEN bds.oper_kredit <> 0
				  THEN CASE 
					   WHEN bd.doctyp = 1165 
						  THEN bd.doctyp ||'-'|| 'Оплата ' || bds.operdate
					   WHEN bd.doctyp = 1169 
						  THEN bd.doctyp ||'-'|| 'Оплата ' || bds.operdate
					   WHEN bd.doctyp <> 1713  
						  THEN bd.doctyp ||'-'|| 'Оплата ' || bds.operdate
				   ELSE 
					bd.doctyp ||'-'|| 'Корректировка долга ' || bds.operdate
				  END   
			END                                             AS oper_name,
					--
			CASE WHEN bds.oper_debit = 0 
				   THEN ''
				 ELSE bds.oper_debit::character varying
			END                                             AS debit,
			CASE WHEN bds.oper_kredit = 0 
				   THEN ''
				 ELSE bds.oper_kredit::character varying
			END 								                    AS kredit
		   FROM bee_docs_sheet AS bds
		   JOIN bee_docs as bd on bd.rowid = bds.linkid2 and bd.linkid = $1
		   WHERE 
			  bds.operdate BETWEEN $2 AND $3 
			  AND bds.linkid1 = $1 
			  AND bds.oper_debit + bds.oper_kredit <> 0
		   ORDER by operdate, npp
	) --перечисление операций

	UNION ALL
	(
	 SELECT
		'x-Обороты за период' 						 AS oper_name,
		(sum(oper_debit))::character varying 	 AS debit,
		(sum(oper_kredit))::character varying  AS kredit
	 FROM bee_docs_sheet
	 WHERE 
		operdate BETWEEN $2 AND $3 
		AND linkid1 = $1 
	) -- обороты за период
	UNION ALL
	(
	  SELECT
		'e-Сальдо на ' || $3,
		 CASE WHEN ( final_debit IS NULL AND final_kredit IS NULL) OR 
				   ( final_debit = 0 AND final_kredit = 0)
			 THEN '0.00'
		  WHEN final_debit = 0 
			 THEN ''
		  ELSE final_debit::character varying
		 END 								          AS debit,
		 --
		 CASE WHEN final_kredit = 0 
			 THEN ''
		  ELSE final_kredit::character varying
		 END 								          AS kredit
	  FROM bee_docs_sheet AS bds
	  WHERE 
		 bds.operdate BETWEEN $2 AND $3 
		 AND bds.linkid1 = $1
	  ORDER BY operdate DESC, npp DESC
	  LIMIT 1
		)); -- сальдо на конец
	
	END IF;
END;
$$;

comment on function bee_repact_sver_get_content(integer, date, date) is 'Акт сверки. Используется в RepActSver.java';

alter function bee_repact_sver_get_content(integer, date, date) owner to pgsql;

