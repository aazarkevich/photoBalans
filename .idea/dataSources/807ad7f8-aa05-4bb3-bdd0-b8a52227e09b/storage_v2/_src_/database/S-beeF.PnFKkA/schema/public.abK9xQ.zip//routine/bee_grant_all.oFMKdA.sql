create function bee_grant_all() returns void
    language plpgsql
as
$$
DECLARE
    rec RECORD;
    db varchar;
    tn varchar;
begin
   db = current_database(); 
   for rec in ( 
      SELECT table_name as tname
      FROM information_schema.tables 
         WHERE 
            table_type = 'BASE TABLE' and
            table_catalog = db 
            AND table_schema = 'public' 
       ORDER BY table_type, table_name
   )
   loop
      tn = rec.tname;
      execute 'GRANT ALL ON TABLE ' ||  tn || ' TO public';
   end loop;
end;
$$;

alter function bee_grant_all() owner to postgres;

