create function bee_docs_result_add(docid integer, _doctyp integer) returns void
    language plpgsql
as
$$
/*
    ito07 2019-07-18 link agreepoint with tarif
    add ito06 2014-11-11
    add ito06 2014-11-11
*/
DECLARE
    LastDate DATE;   
BEGIN
    --
    LastDate  = (SELECT docdat FROM bee_docs WHERE rowid   = docid   ORDER BY docdat DESC LIMIT 1);
    --  
    -- 2014-11-11
    IF (LastDate > '2014-09-30') THEN        
    INSERT INTO bee_docs_result(
        linkid,      -- 1
        tar_grp,     -- 2
        tar_typ,     -- 3 
        row_typ,     -- 4
        name,        -- 5
        amount,      -- 6
        price,       -- 7
        tax_rate,    -- 8
        tax_sum,     -- 9
        sum_with_tax,-- 10
        sum_no_tax   --11
    ) (    
    SELECT 
        calc.linkid1,                  		-- 1
        calc.tar_grp,                  		-- 2
        case 
           when calc.con_sum = 1174
           then 1168
           else 1068
        end AS p1068,                  		-- 3 
        1070 AS p1070,                 		-- 4
        '-',                          		-- 5
        SUM(calc.quantity_amo),        		-- 6 
        calc.price,                    		-- 7
        calc.tax_rate,                 		-- 8
        0, --SUM(calc.tax_sum),      		-- 9 		2014-11-11
        0, --SUM(calc.cost_with_tax),		-- 10 		2014-11-11
        SUM(calc.cost_no_tax)         		-- 11
    FROM bee_docs_calc calc
       -- 190717 ito07
       join agreepoint       on calc.linkid2 = agreepoint.rowid 
       --join agreepoint_tarif on agreepoint_tarif.pointid = agreepoint.rowid
       -- 
       --
       JOIN bee_docs docs         ON calc.linkid1 = docs.rowid
       JOIN dic_tarif_group tarif ON calc.tar_grp = tarif.rowid
      WHERE TRUE
        AND docs.rowid   = docid
        AND docs.docdat  = LastDate
        AND docs.doctyp  = _doctyp
        AND docs.docvid  = 1043
      GROUP BY calc.linkid1,calc.tar_grp,calc.price,calc.tax_rate,calc.con_sum);

    ELSE
    
    INSERT INTO bee_docs_result(
        linkid,      -- 1
        tar_grp,     -- 2
        tar_typ,     -- 3 
        row_typ,     -- 4
        name,        -- 5
        amount,      -- 6
        price,       -- 7
        tax_rate,    -- 8
        tax_sum,     -- 9
        sum_with_tax,-- 10
        sum_no_tax   --11
    ) (    
    SELECT 
        calc.linkid1,                  		-- 1
        calc.tar_grp,                  		-- 2
        case when calc.con_sum = 1174
             then 1168
             else 1068
        end AS p1068,                  		-- 3 
        1070 AS p1070,                 		-- 4
        '-',                          		-- 5
        SUM(calc.quantity_amo),        		-- 6 
        calc.price,                    		-- 7
        calc.tax_rate,                 		-- 8
        SUM(calc.tax_sum),      		-- 9 		2014-11-11
        SUM(calc.cost_with_tax),		-- 10 		2014-11-11
        SUM(calc.cost_no_tax)         		-- 11
       FROM bee_docs_calc calc
       
       -- 190717 ito07
       join agreepoint       on calc.linkid2 = agreepoint.rowid 
       --join agreepoint_tarif on agreepoint_tarif.pointid = agreepoint.rowid
       --  
       JOIN bee_docs docs         ON calc.linkid1 = docs.rowid
       JOIN dic_tarif_group tarif ON calc.tar_grp = tarif.rowid
      WHERE TRUE
        AND docs.rowid   = docid
        AND docs.docdat  = LastDate
        AND docs.doctyp  = _doctyp
        AND docs.docvid  = 1043
      GROUP BY calc.linkid1,calc.tar_grp,calc.price,calc.tax_rate,calc.con_sum);
    END IF;    
END;
$$;

comment on function bee_docs_result_add(integer, integer) is 'Используется в DocMain.java, DocsAdjustment.java, GroupDocsProcessing.java, AppUtils.java';

alter function bee_docs_result_add(integer, integer) owner to pgsql;

