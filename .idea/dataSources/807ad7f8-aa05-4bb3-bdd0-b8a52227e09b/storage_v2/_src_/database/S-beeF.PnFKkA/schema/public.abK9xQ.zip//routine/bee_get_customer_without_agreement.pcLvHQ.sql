create function bee_get_customer_without_agreement(lid integer) returns text
    language plpgsql
as
$$
    --
-- ОТБОР КОД АБОНЕНТОВ БЕЗ ДОГОВОРА
-- lid : код места обработки
-- 
DECLARE
  Rec     RECORD;
  AboList TEXT := '';
--
BEGIN
  FOR Rec IN (   
      SELECT abo_code::text as cod FROM customer  
      WHERE 
         locid = lid AND 
         abo_code NOT IN (SELECT abo_code FROM agreement WHERE locid = lid)  
         
  ) 
  LOOP 
     --
     IF Rec.cod IS NOT NULL THEN
	 AboList = AboList || Rec.cod || '|';
     END IF;
     -- 
  END LOOP;
  --
RETURN AboList;
  --
END;
$$;

comment on function bee_get_customer_without_agreement(integer) is 'Отбор код абонента без договора. Используется в Customer.java, AppUtils.java';

alter function bee_get_customer_without_agreement(integer) owner to pgsql;

