create function bee_has_subabo_agreement(agreeid integer) returns boolean
    language plpgsql
as
$$
    --
-- ПРОВЕРКА НАЛИЧИЯ СУБАБОНЕНТОВ НА >ДОГОВОРЕ<
--
-- agreeid     - код договора
-- agreepoint  - код точки учёта 
-- paramid 664 - код признак субабонента ,
--               т. е. устройство запитано от устройств с сылкой paramval
--
BEGIN
--   	
RETURN EXISTS(
	SELECT 1 FROM agreepoint WHERE 
	linkid = agreeid AND
	rowid IN (
		SELECT paramval::integer FROM agreeregdev
		WHERE 
                  paramid          = 664         AND                   
                  paramval        IS NOT NULL    AND
                  length(paramval) > 0           AND
                  paramval         ~ E'^\\d{1,}' AND                  
                  paramval        <> '0'  
	)
); 
--
--
END;
--
$$;

comment on function bee_has_subabo_agreement(integer) is 'Проверка наличия суббабонетов на договоре. Используется в AgreeByDevice.java, Agreement.java, AppUtils.java';

alter function bee_has_subabo_agreement(integer) owner to pgsql;

