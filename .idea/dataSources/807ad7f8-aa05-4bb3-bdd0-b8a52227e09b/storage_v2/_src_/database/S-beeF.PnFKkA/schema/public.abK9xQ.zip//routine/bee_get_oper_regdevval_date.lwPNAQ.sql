create function bee_get_oper_regdevval_date(integer, integer) returns date
    language sql
as
$$
    -- 1 - pointid
  -- 2 - paramid
  -- 3 - operdate
  --
  --SELECT valman::numeric(12,3) FROM regdevoper 
SELECT to_date(paramval,'YYYY-MM-DD') FROM agreeregdev 
WHERE 
   linkid   = $1 AND
   paramid  = $2 AND 
   paramval LIKE '____-__-__'
;
$$;

comment on function bee_get_oper_regdevval_date(integer, integer) is 'Используется в bee_rep_get_fullrepdata(int, date, date), bee_rep_get_fullrepdata11(int, date, date), bee_rep_get_repdata(int, date, date), bee_rep_get_repdata1(int, date, date), bee_rep_get_repdata11(int, date, date),  bee_rep_get_repdata4(int, date)';

alter function bee_get_oper_regdevval_date(integer, integer) owner to pgsql;

