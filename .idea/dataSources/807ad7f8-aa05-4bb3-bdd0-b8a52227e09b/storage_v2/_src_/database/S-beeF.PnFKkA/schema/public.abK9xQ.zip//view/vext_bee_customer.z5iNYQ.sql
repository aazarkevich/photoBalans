create view vext_bee_customer
            (consum_name, category_code, abo_name, code_des, consum_inn, abo_code, abo_vid, tag, urstatus, valid, locid,
             locnam_cust, locnam_amn, netowner)
as
SELECT cust.consum_name,
       cust.category_code,
       cust.abo_name,
       cust.code_des,
       cust.consum_inn,
       cust.abo_code,
       cust.abo_vid,
       cust.tag,
       cust.urstatus,
       cust.valid,
       CASE
           WHEN (amn.locid IS NULL) THEN cust.locid
           ELSE amn.locid
           END    AS locid,
       decust.nam AS locnam_cust,
       deamn.nam  AS locnam_amn,
       cust.netowner
FROM (((customer cust
    LEFT JOIN agreement amn ON ((amn.abo_code = cust.abo_code)))
    LEFT JOIN denet decust ON ((decust.rowid = cust.locid)))
         LEFT JOIN denet deamn ON ((deamn.rowid = amn.locid)))
ORDER BY CASE
             WHEN (amn.locid IS NULL) THEN cust.locid
             ELSE amn.locid
             END, cust.valid, cust.consum_name, cust.abo_name;

comment on view vext_bee_customer is 'Используется в AgreeRegDev.java, Customer.java, Menu.java, PaymentDocs.java, SessionBean1.java';

alter table vext_bee_customer
    owner to pgsql;

