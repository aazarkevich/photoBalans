create function bee_get_points_by_locid_in_agreeid(agreeid integer) returns character varying[]
    language plpgsql
as
$$
    --
-- ИДЕНТИФИКАТОРЫ ТОЧЕК УЧЁТА ПОДКЛЮЧЕНИЯ ПО ДОГОВОРУ
-- agreeid : код договора
-- 
BEGIN
   RETURN ARRAY(
     SELECT node.nam ||':'|| 
     substring(node.kod from 1 for 6) || ':' || 
     agreepoint.lid::varchar || ':' || 
     agreepoint.rowid::varchar AS line 
     FROM agreepoint
     JOIN   agreement     ON agreepoint.linkid = agreement.rowid
     join   denet as node on agreepoint.lid    = node.rowid
     WHERE  
         agreement.rowid = agreeid 
     order by replace(substring(node.kod from 1 for 6),'g10m64','g10m57')   --node.kod
   );
--
END;
$$;

comment on function bee_get_points_by_locid_in_agreeid(integer) is 'Идентификаторы точек учета подключения по договору. Используется в RepAkt11.java, AppUtils.java';

alter function bee_get_points_by_locid_in_agreeid(integer) owner to postgres;

