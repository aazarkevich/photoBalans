create function bee_add_bee_docs(agreeid integer, prefix integer, docnumber integer, docdate character varying) returns integer
    language plpgsql
as
$$
DECLARE
   NR INTEGER;
BEGIN
   BEGIN
   INSERT INTO bee_docs 
   (linkid,  edit,  pref,   docnum,    doctyp, docvid, docdat) VALUES 
   (agreeid, TRUE,  prefix, docnumber, 1066,   NULL,   docdate::date) RETURNING rowid INTO NR;
   EXCEPTION
      WHEN UNIQUE_VIOLATION THEN
      RETURN -1;
   END;
   RETURN NR;
END;
$$;

comment on function bee_add_bee_docs(integer, integer, integer, varchar) is 'Добавление нового документа. Используется в AppUtils.java';

alter function bee_add_bee_docs(integer, integer, integer, varchar) owner to pgsql;

