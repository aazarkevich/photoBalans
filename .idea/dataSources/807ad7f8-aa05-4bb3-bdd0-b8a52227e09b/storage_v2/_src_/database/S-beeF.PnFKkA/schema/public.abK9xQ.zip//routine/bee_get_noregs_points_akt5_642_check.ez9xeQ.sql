create function bee_get_noregs_points_akt5_642_check(curid integer, val character varying, mask character varying) returns boolean
    language plpgsql
as
$$
BEGIN
   IF curid = 642 THEN
      IF val LIKE mask THEN
         RETURN TRUE ;
      ELSE
         RETURN FALSE; 
      END IF;   
   END IF;
   RETURN TRUE;        
END;
$$;

alter function bee_get_noregs_points_akt5_642_check(integer, varchar, varchar) owner to pgsql;

