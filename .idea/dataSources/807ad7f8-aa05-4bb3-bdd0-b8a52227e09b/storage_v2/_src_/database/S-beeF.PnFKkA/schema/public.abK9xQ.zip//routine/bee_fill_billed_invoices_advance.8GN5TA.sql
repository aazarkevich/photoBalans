create function bee_fill_billed_invoices_advance(_top_locid integer, _df text, _dt text) returns SETOF integer[]
    language plpgsql
as
$$
DECLARE
	_date_from date = _df::date;
	_date_to date = _dt::date;
 
BEGIN

	DROP TABLE IF EXISTS tmp_rep_billed_invoices_advance;
	CREATE TEMPORARY table tmp_rep_billed_invoices_advance  AS 	
		   (SELECT
			dic_elements.element_name::text                      AS c1,   --направление учета
			agreement.docnumber ::text                           AS c2,   --номер договора
			e1.element_name || ' ' || customer.consum_name::text AS c3,   --наименование контрагента 			
			bee_docs.docnum::text                                AS c4,   --номер документа
			bee_docs.docdat::text                                AS c5,    --дата документа
			bee_docs_result_advance.sum_tax::numeric             AS c6,   --сумма НДС
			bee_docs_result_advance.sum::numeric                 AS c7,   --сумма всего
			bee_docs.rowid::integer                              AS c8,   --внутренний код документа по нем нужно сгруппировать записи
			agreement.locid::integer 			     AS c9,   --locid
			agreement.accdir::integer 			     AS c10,  --направление учёта
			'/'||e2.element_name||'/41'::text                    AS pref  --префикс документа

		FROM 
			bee_docs
			
			JOIN bee_docs_result_advance ON bee_docs.rowid = bee_docs_result_advance.linkid2
			JOIN agreement ON bee_docs.linkid = agreement.rowid
			LEFT JOIN dic_elements ON agreement.accdir=dic_elements.rowid
			JOIN customer ON agreement.abo_code = customer.abo_code
			JOIN dic_elements AS e1 ON customer.urstatus = e1.rowid
                        JOIN dic_elements AS e2 ON bee_docs.pref = e2.rowid
			
		    WHERE bee_docs.doctyp = 1615                          --документ выставления (акт приема-передачи)
		      AND bee_docs.docdat BETWEEN _date_from AND _date_to --период выгрузки документов
  		      
                      -- 79- действующий 77- расторгнутый
		      AND ((agreement.docstatus = 79) or ( agreement.docstatus = 77 and agreement.closedate BETWEEN _date_from AND _date_to))

		      AND agreement.doctype = 1910--** 2016-04-25	      
		      AND agreement.locid in (select rowid from denet where kod like ((select kod from denet where rowid = _top_locid) || '%'))  
		      AND agreement.valid=true

		    GROUP BY c4, c5, c10, c1, c3, c2, c8, c9, c6, c7, e2.element_name,agreement.docnumber
		    ORDER BY c9, c3, case when regexp_replace(agreement.docnumber, E'[^\\d*]', E'\\1','g') = '' then 0 else regexp_replace(agreement.docnumber, E'[^\\d*]', E'\\1','g')::bigint end
		);
	END;

$$;

comment on function bee_fill_billed_invoices_advance(integer, text, text) is 'Финансовый отчет: выставление счета-фактуры на аванс. Используется в BilledInvoicesAdvance.java';

alter function bee_fill_billed_invoices_advance(integer, text, text) owner to pgsql;

