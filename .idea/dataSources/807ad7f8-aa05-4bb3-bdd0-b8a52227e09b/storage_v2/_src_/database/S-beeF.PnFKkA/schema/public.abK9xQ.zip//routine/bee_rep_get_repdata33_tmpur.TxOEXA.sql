create function bee_rep_get_repdata33_tmpur(loc_id integer, d_start_sum date) returns SETOF bee_repdata33_tmp
    language plpgsql
as
$$
/*
    ito07 190404 EXCEPTION
	ito06 2016-04-26 Сводный журнал задолжненников (репс), выбирает реализацию из базы юриков (для указанного филиала)
*/
DECLARE rec record;
	host  varchar = 'f66apps0';
	host1 varchar = 'f66apps1';
	host2 varchar = 'f66apps2';
	host3 varchar = 'f66apps3';
	ListConn TEXT[];
	Result   TEXT;

begin

	IF loc_id = 693	   
	      THEN --РГЭС
	        SELECT distinct hostname FROM bee_closed_info WHERE dbstatus = 'U' limit 1 INTO host;
	        IF       host ='f66apps1' THEN host1 = 'f66apps0';
	           ELSIF host ='f66apps2' THEN host2 = 'f66apps0';
	           ELSIF host ='f66apps3' THEN host3 = 'f66apps0';
	        END IF; 

	        SELECT * FROM dblink_get_connections() INTO ListConn;
		IF 'deconn1' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn1') INTO Result; END IF;  
		IF 'deconn2' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn2') INTO Result; END IF;  
		IF 'deconn3' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn3') INTO Result; END IF; 	
		
		SELECT dblink_connect_u('deconn1',' dbname = beeU port = 5432 host = '||host1||' user = pgsql') INTO Result;
		SELECT dblink_connect_u('deconn2',' dbname = beeU port = 5432 host = '||host2||' user = pgsql') INTO Result;
		SELECT dblink_connect_u('deconn3',' dbname = beeU port = 5432 host = '||host3||' user = pgsql') INTO Result;

	        
	    RETURN QUERY (
	        SELECT distinct countt, roww,  loc,  docnum, custname, all_sum_debit, dat_debit, 
				sum_debit, dat_debit20, sum_debit20, dat_debit45, sum_debit45, dat_debit90, sum_debit90, dat_debit365, sum_debit365, 
				dat_measure, meas_measure, comm_measure, 
				dat_collecting,CASE WHEN is_numeric(sum_collecting) THEN sum_collecting::numeric ELSE 0 END, meas_collecting, comm_collecting, 
				style, accdir, host from bee_repdebitor_get_content($1,$2,1910) 
	        
			UNION SELECT DISTINCT points.* 
                FROM dblink('deconn1',
			    'select distinct countt, roww,  loc,  docnum, custname, all_sum_debit, dat_debit, 
				sum_debit, dat_debit20, sum_debit20, dat_debit45, sum_debit45, dat_debit90, sum_debit90, dat_debit365, sum_debit365, 
				dat_measure, meas_measure, comm_measure, 
				dat_collecting,CASE WHEN is_numeric(sum_collecting) THEN sum_collecting::numeric ELSE 0 END, meas_collecting, comm_collecting, 
				style, accdir,'''||host1||''' from bee_repdebitor_get_content('||$1||', '''||$2||''',1910) '
                ) AS points (countt integer, roww integer, loc varchar, docnum varchar, custname varchar, all_sum_debit numeric, dat_debit date,
                sum_debit numeric, dat_debit20 date, sum_debit20 numeric, dat_debit45 date, sum_debit45 numeric, dat_debit90 date, sum_debit90 numeric, dat_debit365 date,
                sum_debit365 numeric, dat_measure varchar, meas_measure varchar, comm_measure varchar, dat_collecting varchar,sum_collecting numeric,meas_collecting varchar,
                comm_collecting varchar, style varchar, accdir int, host varchar)
			UNION SELECT DISTINCT points.* 
                FROM dblink('deconn2',
			    'select distinct countt, roww,  loc,  docnum, custname, all_sum_debit, dat_debit, 
				sum_debit, dat_debit20, sum_debit20, dat_debit45, sum_debit45, dat_debit90, sum_debit90, dat_debit365, sum_debit365, 
				dat_measure, meas_measure, comm_measure, 
				dat_collecting,CASE WHEN is_numeric(sum_collecting) THEN sum_collecting::numeric ELSE 0 END, meas_collecting, comm_collecting, 
				style, accdir,'''||host2||''' from bee_repdebitor_get_content('||$1||', '''||$2||''',1910) '
                ) AS points (countt integer, roww integer, loc varchar, docnum varchar, custname varchar, all_sum_debit numeric, dat_debit date,
                sum_debit numeric, dat_debit20 date, sum_debit20 numeric, dat_debit45 date, sum_debit45 numeric, dat_debit90 date, sum_debit90 numeric, dat_debit365 date,
                sum_debit365 numeric, dat_measure varchar, meas_measure varchar, comm_measure varchar, dat_collecting varchar,sum_collecting numeric,meas_collecting varchar,
                comm_collecting varchar, style varchar, accdir int,host varchar)			      
            UNION SELECT DISTINCT points.* 
                FROM dblink('deconn3',
                'select distinct countt, roww,  loc,  docnum, custname, all_sum_debit, dat_debit, 
				sum_debit, dat_debit20, sum_debit20, dat_debit45, sum_debit45, dat_debit90, sum_debit90, dat_debit365, sum_debit365, 
				dat_measure, meas_measure, comm_measure, 
				dat_collecting,CASE WHEN is_numeric(sum_collecting) THEN sum_collecting::numeric ELSE 0 END, meas_collecting, comm_collecting, 
				style, accdir,'''||host3||''' from bee_repdebitor_get_content('||$1||', '''||$2||''',1910)'
                ) AS points (countt integer, roww integer, loc varchar, docnum varchar, custname varchar, all_sum_debit numeric, dat_debit date,
                sum_debit numeric, dat_debit20 date, sum_debit20 numeric, dat_debit45 date, sum_debit45 numeric, dat_debit90 date, sum_debit90 numeric, dat_debit365 date,
                sum_debit365 numeric, dat_measure varchar, meas_measure varchar, comm_measure varchar, dat_collecting varchar,sum_collecting numeric, meas_collecting varchar,
                comm_collecting varchar, style varchar, accdir int,host varchar));
                 
        SELECT dblink_disconnect('deconn1') INTO Result;
		SELECT dblink_disconnect('deconn2') INTO Result;
		SELECT dblink_disconnect('deconn3') INTO Result;
	
	ELSIF loc_id = 644
	     THEN 
	        FOR rec IN (SELECT distinct hostname FROM bee_closed_info WHERE dbstatus = 'U')
		 loop
		    BEGIN
			SELECT * FROM dblink_get_connections() INTO ListConn;
			IF 'deconn0' = ANY (ListConn) THEN  SELECT dblink_disconnect('deconn0') INTO Result; END IF;  
			SELECT dblink_connect_u('deconn0',' dbname = beeU port = 5432 host = '||rec.hostname||' user = pgsql') INTO Result;		
			
			RETURN QUERY( SELECT DISTINCT points.* 
			    FROM dblink('deconn0',
			   'select distinct countt, roww,  loc,  docnum, custname, all_sum_debit, dat_debit, 
				sum_debit, dat_debit20, sum_debit20, dat_debit45, sum_debit45, dat_debit90, sum_debit90, dat_debit365, sum_debit365, 
				dat_measure, meas_measure, comm_measure, 
				dat_collecting,
                CASE WHEN is_numeric(sum_collecting) THEN sum_collecting::numeric ELSE 0 END, 
                meas_collecting, comm_collecting, 
				style, accdir,'''||rec.hostname||''' 
                from 
                bee_repdebitor_get_content('||$1||', '''||$2||''',1910) '
                ) AS points (countt integer, roww integer, loc varchar, docnum varchar, custname varchar, all_sum_debit numeric, dat_debit date,
                sum_debit numeric, dat_debit20 date, sum_debit20 numeric, dat_debit45 date, sum_debit45 numeric, dat_debit90 date, sum_debit90 numeric, dat_debit365 date,
                sum_debit365 numeric, dat_measure varchar, meas_measure varchar, comm_measure varchar, dat_collecting varchar,sum_collecting numeric, meas_collecting varchar,
                comm_collecting varchar, style varchar, accdir int,host varchar));
		    EXCEPTION
		       WHEN unique_violation THEN CONTINUE;
               WHEN others THEN continue;
            END;
		 END LOOP;
	     SELECT dblink_disconnect('deconn0') INTO Result;
		 	
	ELSE 
		SELECT distinct hostname FROM bee_closed_info WHERE dbstatus = 'U' limit 1 INTO host;
		RETURN QUERY(
		        select DISTINCT countt, roww,  loc,  docnum, custname, all_sum_debit, dat_debit, 
				sum_debit, dat_debit20, sum_debit20, dat_debit45, sum_debit45, dat_debit90, sum_debit90, dat_debit365, sum_debit365, 
				dat_measure, meas_measure, comm_measure, 
				dat_collecting,CASE WHEN is_numeric(sum_collecting) THEN sum_collecting::numeric ELSE 0 END, meas_collecting, comm_collecting, 
				style, accdir, host from bee_repdebitor_get_content($1,$2,1910));			     
	END IF; 
	
END;
$$;

comment on function bee_rep_get_repdata33_tmpur(integer, date) is 'Сводный журнал задолжненников (репс). Используется в bee_rep_get_repdata33_create_tmp_table(int, date, varchar)';

alter function bee_rep_get_repdata33_tmpur(integer, date) owner to postgres;

