create function bee_del_transform(trid integer) returns character varying
    language plpgsql
as
$$
/*
	ito06 2020-04-27 Удаление ТТ/ТН
*/
DECLARE NR INTEGER =-1;

 BEGIN
 NR = -1; 
  DELETE FROM agreeregdev_period  WHERE rowid = trid  RETURNING 1 INTO NR;
 IF NR IS NOT NULL
    THEN  RETURN 'Трансформатор со своими параметрами удален!';
 ELSE RETURN 'Удаление трансформатора не возможно!';
 END IF;

END;
$$;

comment on function bee_del_transform(integer) is 'Удаление договора. Используется в DevParamTT.java, AppUtils.java';

alter function bee_del_transform(integer) owner to pgsql;

