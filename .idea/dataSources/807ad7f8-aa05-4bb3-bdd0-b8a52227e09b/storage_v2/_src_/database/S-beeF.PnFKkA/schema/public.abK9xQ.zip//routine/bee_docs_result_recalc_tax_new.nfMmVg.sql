create function bee_docs_result_recalc_tax_new(docid integer) returns void
    language plpgsql
as
$$
/*    
    ito06 2019-10-01 для исправлений и корректировки считаем сумму налога и сумму с налогом для документа для  1070 и 1071 сразу (регулируемый и не регулируемый сразу)
    так как исправление и корректировка могут быть в периоде, ктр расчитывает по другом НДС, то для них считам отдельно
    
    на основе bee_docs_result_recalc_tax(int) ito06 2015-05-19 Перерасчитываем сумму налога и сумму с налогом для документа.
    
*/
DECLARE
    rid_curr int := 0;
    rid_bef  int := 0;
    nam_curr varchar := NULL;
    nam_bef  varchar := NULL;
    summ     numeric := 0;
    rec      record;	
    doc_typ int = 0;
	_docdat date = null;
    tmp_rid int=0;	
    tmp_summ numeric := 0;
    _tax_proc NUMERIC := 0;
	_tax_proc_bef NUMERIC := 0;    
	CHEK_DATE DATE := '2014-09-30';
   
BEGIN	
	
    doc_typ = (select doctyp from bee_docs where rowid = docid); -- тип документа
    _docdat = (select docdat from bee_docs where rowid = docid); -- дата документа		
    _tax_proc = (SELECT tax_proc FROM bee_docs_tax 
                     WHERE dat1 <= (SELECT (to_char((_docdat::DATE - '1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE + '1 month'::INTERVAL) -- - '1 day'::INTERVAL)  
                     ORDER BY dat1 DESC LIMIT 1);  -- процент ндс в месяце создания документа
   
   IF  _docdat  > CHEK_DATE --00
    THEN  --00
  
	--** bee_docs_loss 
	--** если есть потери ФСК и РСК для них расчитываем сумму налога и стоимость с налогом, для каждой записи (всего 2 строки)	
	FOR rec IN (select * from bee_docs_result AS res 
				 where res.linkid = docid AND row_typ in (1731, 1732) AND tar_grp IS NULL AND tar_typ = 1734
		        order by res.name, row_typ desc, rowid)
	LOOP 
	    UPDATE bee_docs_result 
	       SET tax_sum      = rec.sum_no_tax *    (_tax_proc/100),
	           sum_with_tax = rec.sum_no_tax * (1 +_tax_proc/100)
	     WHERE rowid = rec.rowid; 
	     
	END LOOP; 
	--**
   
   IF doc_typ = 1065 --001 для документов из форм: "Документы по договору и "Груповая обработка" 
   THEN --001 
   
	 summ = 0;				
	 --** для доумента выствления не учитывая записи о корректировке
	 IF _docdat > CHEK_DATE
	  THEN update bee_docs_result set tax_sum = 0, sum_with_tax = 0  where linkid = docid AND row_typ in (1070, 1071) AND length(name) <3;
	 END IF;
	 
	 FOR rec IN (select * from bee_docs_result AS res where res.linkid = docid AND row_typ = 1070 AND length(name) <3 order by res.name, row_typ desc, rowid)
	   LOOP --002 
	     rid_curr = rec.rowid;
	     nam_curr = rec.name;
	     IF nam_curr <> nam_bef AND nam_bef IS NOT NULL
	       THEN UPDATE bee_docs_result 
		   		  SET tax_sum      = summ * (_tax_proc/100),
		              sum_with_tax = summ * (1 +_tax_proc/100)
		 	    WHERE rowid = rid_bef; 
		       summ = 0;		   
	     END IF;
	    summ = summ + rec.sum_no_tax;   						     
	    nam_bef = nam_curr;
	    rid_bef = rid_curr;	    
	 END LOOP; --002
	 tmp_rid = rid_curr;
	 tmp_summ = summ;	
	 summ = 0;			
	 
	 FOR rec IN (select * from bee_docs_result AS res where res.linkid = docid  AND row_typ = 1071 AND length(name) <3 order by res.name, row_typ desc, rowid)
	 LOOP  --003  
	    rid_curr = rec.rowid;
	    nam_curr = rec.name;
	    IF nam_curr <> nam_bef AND nam_bef IS NOT NULL
	       THEN UPDATE bee_docs_result 
		   SET tax_sum      = summ * (_tax_proc/100),
		       sum_with_tax = summ * (1 +_tax_proc/100)
		 WHERE rowid = rid_bef; 
		summ = 0;		   
	    END IF;
	    summ = summ + rec.sum_no_tax;   						     
	    nam_bef = nam_curr;
	    rid_bef = rid_curr;
	 END LOOP; --003
	 
	 UPDATE bee_docs_result 
	   SET tax_sum      = summ *    (_tax_proc/100),
	       sum_with_tax = summ * (1 +_tax_proc/100)
	 WHERE rowid = rid_curr;
	 
	 UPDATE bee_docs_result 
	   SET tax_sum      = tmp_summ *    (_tax_proc/100),
	       sum_with_tax = tmp_summ * (1 +_tax_proc/100)
	 WHERE rowid = tmp_rid; 	 
	 
	 --**
	 --** для документа выствления учитывая только записи о корректировке, если они есть
	 IF (select count(rowid) from bee_docs_result AS res 
		  where res.linkid = docid  AND length(name)>3 AND tar_typ IN (1069, 1707, 1159, 1168, 1142)) > 0
	 THEN --004
	    nam_bef = NULL;
		summ = 0;
		FOR rec IN (select * from bee_docs_result AS res where res.linkid = docid AND tar_typ IN (1069, 1707, 1159, 1168, 1142) AND row_typ in (1070, 1071) AND length(name)>3 order by res.name, row_typ desc, rowid)
			LOOP --005
		    rid_curr = rec.rowid;
			nam_curr = rec.name;
		    _docdat =  (select right(rtrim(name), 10) from bee_docs_result where rowid = rec.rowid)::date;
	        _tax_proc = (SELECT tax_proc FROM bee_docs_tax 
                           WHERE dat1 <= (SELECT (to_char((_docdat::DATE - '1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE + '1 month'::INTERVAL)
                           ORDER BY dat1 DESC LIMIT 1);
		
		   IF _docdat > CHEK_DATE --008
		     THEN  --008
			 update bee_docs_result set tax_sum = 0, sum_with_tax = 0  where rowid = rec.rowid;
		   
		
			IF nam_curr <> nam_bef AND nam_bef IS NOT NULL
			   THEN UPDATE bee_docs_result 
				     SET tax_sum      = summ *    (_tax_proc_bef/100),
				        sum_with_tax = summ * (1 +_tax_proc_bef/100)
				   WHERE rowid = rid_bef; 
				   summ = 0;		   
			END IF;
			END IF; 	--008	
				
			summ = summ + rec.sum_no_tax;   						     
			nam_bef = nam_curr;
			rid_bef = rid_curr;	 
			_tax_proc_bef = _tax_proc;
		 END LOOP; --005
		
		tmp_rid = rid_curr;
		tmp_summ = summ;
	    summ = 0;
	
   		 UPDATE bee_docs_result 
		   SET tax_sum      = tmp_summ *    (_tax_proc/100),
		       sum_with_tax = tmp_summ * (1 +_tax_proc/100)
		 WHERE rowid = tmp_rid;
	 
	 END IF; --004
	
	ELSIF (doc_typ = 1618 OR doc_typ = 1705) --001 для корректировки или для счет-фактуры изменении
	 THEN --001
        summ = 0;			          	
        FOR rec IN (select * from bee_docs_result AS res where res.linkid = docid AND tar_typ IN (1069, 1707, 1159, 1168, 1142) AND row_typ in (1070, 1071) order by res.name, row_typ desc, rowid)
		 LOOP --006
				_docdat =  (select right(rtrim(name), 10) from bee_docs_result where rowid = rec.rowid)::date;
				_tax_proc = (SELECT tax_proc FROM bee_docs_tax 
                           WHERE dat1 <= (SELECT (to_char((_docdat::DATE - '1 month'::INTERVAL)::DATE,'YYYY-MM')||'-01')::DATE + '1 month'::INTERVAL)
                           ORDER BY dat1 DESC LIMIT 1);
						   
			 IF _docdat > CHEK_DATE
		      THEN --007
				update bee_docs_result set tax_sum = 0, sum_with_tax = 0  where rowid = rec.rowid;		     		   
			    rid_curr = rec.rowid;
			    nam_curr = rec.name;
			    IF nam_curr <> nam_bef AND nam_bef IS NOT NULL
			       THEN UPDATE bee_docs_result 
				     SET tax_sum      = summ *    (_tax_proc_bef/100),
				        sum_with_tax = summ * (1 +_tax_proc_bef/100)
				   WHERE rowid = rid_bef; 
				   summ = 0;		   
			    END IF;
			 END IF;--007
			   
			    summ = summ + rec.sum_no_tax;   						     
			    nam_bef = nam_curr;
			    rid_bef = rid_curr;	
				_tax_proc_bef = _tax_proc;
			END LOOP; --006
		
			tmp_rid = rid_curr;
			tmp_summ = summ;
		    summ = 0;
	
   			 UPDATE bee_docs_result 
			   SET tax_sum      = tmp_summ *    (_tax_proc/100),
			       sum_with_tax = tmp_summ * (1 +_tax_proc/100)
			 WHERE rowid = tmp_rid; 	
   	END IF; --001
	END IF; --00
END;
$$;

comment on function bee_docs_result_recalc_tax_new(integer) is 'Используется в bee_docs_result_recalc_tax()';

alter function bee_docs_result_recalc_tax_new(integer) owner to pgsql;

