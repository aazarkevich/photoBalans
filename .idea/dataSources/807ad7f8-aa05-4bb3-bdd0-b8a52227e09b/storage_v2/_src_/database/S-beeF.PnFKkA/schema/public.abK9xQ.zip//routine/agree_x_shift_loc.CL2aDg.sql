create function agree_x_shift_loc() returns void
    language plpgsql
as
$$
DECLARE
i integer;
k integer;
PntIds VARCHAR[];
-- filial specific ids
StrIds varchar :='
121004207,
121004208,
121004209,
121004210,
121004211,
121004212,
121004213,
121004214,
121004215,
121004273,
121004274
';
PointID   varchAR;
Cnt       integer;
MaxRowId  integer;
OPEN_DATE DATE = '1999-01-01';
AgreementLink integer = 120003832;

BEGIN 
 
   ALTER TABLE agreepoint         DISABLE TRIGGER agreepoint_audit;
   ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_audit;
   ALTER TABLE agreepoint_tarif   DISABLE TRIGGER agreepoint_tarif_trig;

   ALTER TABLE agreeregdev        DISABLE TRIGGER agreeregdev_audit;

   ALTER TABLE agreeregdev_period DISABLE TRIGGER agreeregdev_period_trig;
   ALTER TABLE agreeregdev_period DISABLE TRIGGER agreeregdev_period_audit;

   ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_trig;
   ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_audit;
 
   ALTER TABLE regdevconn         DISABLE TRIGGER regdevconn_audit;
   ---
   PERFORM agree_w_info_save(); 
   ---
   UPDATE bee_closed_period     SET period = OPEN_DATE;
   UPDATE bee_closed_period_dir SET period = OPEN_DATE;
   UPDATE bee_closed_period_mix SET period = OPEN_DATE;
   UPDATE bee_closed_period_uni SET period = OPEN_DATE;
   ---
   select max(rowid) from agreepoint into MaxRowId;
   --- 
   PntIds = string_to_array(StrIds,',');
   Cnt = array_length(PntIds,1); -- points amount
   ---
   i = 0;
   k = 0;
   FOREACH PointID IN ARRAY PntIds
   LOOP
      k = k + 1;
      RAISE NOTICE 'SCAN : % : % : % : %',Cnt,MaxRowid + k,i,k;
      begin
        update agreepoint set rowid = MaxRowId + k 
        where 
          linkid = AgreementLink and 
          rowid  = PointID::integer;
      exception
         WHEN others THEN 
            i = i + 1;
            RAISE NOTICE 'Ex 2 Upd: %',PointID; 
            continue;
      end;
   END LOOP;

   ALTER TABLE regdevconn         ENABLE TRIGGER regdevconn_audit;
 
   ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_audit;
   ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_trig;

   ALTER TABLE agreeregdev_period ENABLE TRIGGER agreeregdev_period_trig;
   ALTER TABLE agreeregdev_period ENABLE TRIGGER agreeregdev_period_audit;

   ALTER TABLE agreeregdev        ENABLE TRIGGER agreeregdev_audit;

   ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_audit;
   ALTER TABLE agreepoint_tarif   ENABLE TRIGGER agreepoint_tarif_trig;

   ALTER TABLE agreepoint         ENABLE TRIGGER agreepoint_audit;

   RAISE NOTICE 'Result : % :%:%',Cnt,i,k;
   --
   PERFORM agree_w_info_restore();   
   --
END;
$$;

alter function agree_x_shift_loc() owner to pgsql;

