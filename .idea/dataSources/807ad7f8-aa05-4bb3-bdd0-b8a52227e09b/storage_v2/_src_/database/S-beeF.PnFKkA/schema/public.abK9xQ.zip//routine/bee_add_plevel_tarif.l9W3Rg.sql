create function bee_add_plevel_tarif(_point integer, _param integer, _val integer, _tarif integer, _per date) returns character varying
    language plpgsql
as
$$
/*
	ito06 2019-11-12 Добавление уровня напряжения и тарифа на точку учета
*/
DECLARE
        NR_1 int;
		NR_2 int;
        cl_period date;
		agrp_rid int;
		tarif_rid int ;
		bd_rid int;
		per_ardp date;
		per_tarif date;
		old_val int =0;
BEGIN

	 select period from bee_closed_period_dir AS per
	  join agreepoint as apn on per.filloc = apn.lid 
	 where apn.rowid = _point limit 1 INTO cl_period;

	 IF cl_period >= _per THEN 
	 RETURN 'Период закрыт. Ввод параметров запрещен!'; END IF;
	
	 select ardp.rowid, ardp.period, ardp.paramval from agreeregdev_period AS ardp 
	  where ardp.linkid = _point AND ardp.period >=_per AND ardp.paramid = _param order by ardp.period limit 1 INTO agrp_rid, per_ardp, old_val;
	 
	 select apn_tar.rowid,  apn_tar.period from agreepoint_tarif AS apn_tar
	  where apn_tar.pointid = _point AND apn_tar.period >= _per order by period limit 1 INTO tarif_rid, per_tarif;
	  
	 select bd.rowid from bee_docs AS bd
	   join agreement AS amn ON amn.rowid = bd.linkid
	   join agreepoint as apn ON apn.linkid = amn.rowid 
  	  where bd.doctyp = 1065 AND  bd.docdat >= _per  AND apn.rowid = _point limit 1 INTO bd_rid;
	
	if (bd_rid is null) --0 если ли сформированный документ выставления на эту дату или позже?
	   then --0 документа нет
		if agrp_rid is null --1
	  		  then --1 ввод нового уровня напряжения (после выбранной даты нет уровня напряжения)	
			
	      if tarif_rid is null --2
		   then --2 привязанного тарифа после выбранной даты нет
		   
		      INSERT INTO agreeregdev_period (linkid, period, paramid, paramval) VALUES (_point, _per, _param, _val) RETURNING currval('agreeregdev_period_rowid_seq') INTO NR_1; 
				   IF NR_1 IS NOT NULL --3 если уровень напряжения вставлен, то добавляем тариф
					THEN --3
						INSERT INTO agreepoint_tarif (pointid, tarifid, period) VALUES (_point, _tarif, _per) RETURNING currval('agreepoint_tarif_rowid_seq') INTO NR_2; 
						if NR_2 IS NOT NULL  --4
						  then --4 
							 RETURN 'Уровень напряжения и тариф на точку учета добавлены.';
						  else --4  
							delete from agreeregdev_period  where rowid = NR_1;
							RETURN 'НЕ ВОЗМОЖНО добавить уровень напряжения, ошибка при добавлении тарифа на точку учета';
						 end if;--4		
					  ELSE --3		
					  RETURN 'НЕ ВОЗМОЖНО добавить уровень напряжения'; 
				   END IF; --3   
			   else --2 после выбранной даты есть прявязанный тариф

				if (per_tarif = _per) --5 дата на которую привязываем совпадает с датой привязанного тарифа
				  then --5 тогда замена тарифа 
					 INSERT INTO agreeregdev_period (linkid, period, paramid, paramval) VALUES (_point, _per, _param, _val) RETURNING currval('agreeregdev_period_rowid_seq') INTO NR_1; 

					  IF NR_1 IS NOT NULL --13 если уровень напряжения вставлен, то изменяем тариф
						THEN --13
							UPDATE agreepoint_tarif SET tarifid = _tarif WHERE rowid = tarif_rid;
							  RETURN 'Уровень напряжения вставлен, тариф изменен!'; 
							
						ELSE --13		
						  RETURN 'НЕ ВОЗМОЖНО добавить уровень напряжения'; 
					   END IF; --13

				  else --5 дата на которую привязываем не совпадает с датой привязанного тарифа
					RETURN 'НЕ ВОЗМОЖНО добавить уровень напряжения, к этой точке учета, привязан тариф на более позднюю дату';
				  end if; --5		
			  end if; --2
		 else --1
		  if (per_ardp = _per) --7 дата на которую вводим уровень напряжения совпадает с датой введенного уровня			  
			then --7 
			   if (tarif_rid is null) --8 если тариф не привязан на дату позднее выбранной
			   then --8		  
					UPDATE agreeregdev_period SET paramval = _val where rowid = agrp_rid;
					INSERT INTO agreepoint_tarif (pointid, tarifid, period) VALUES (_point, _tarif, _per) RETURNING currval('agreepoint_tarif_rowid_seq') INTO NR_2; 
					if NR_2 IS NOT NULL  --9 получилось вставить
					  then --9 да
						 RETURN 'Уровень напряжения изменен, тариф на точку учета добавлен';
						  else --9  нет
							UPDATE agreeregdev_period SET paramval = old_val where rowid = agrp_rid;
							RETURN 'НЕ ВОЗМОЖНО изменить уровень напряжения, ошибка при добавлении тарифа на точку учета';
					end if;--9	

			   else --8 если тариф  привязан на дату позже или = выбранной
			   if (per_tarif = _per) --10 дата на которую привязываем совпадает с датой привязанного тарифа, тогда замена
				 then --10 
					UPDATE agreeregdev_period SET paramval = _val where rowid = agrp_rid;
					UPDATE agreepoint_tarif SET tarifid = _tarif WHERE rowid = tarif_rid;
					RETURN 'Уровень напряжения и тариф изменены.';
				 else --10 
				  RETURN 'НЕ ВОЗМОЖНО изменить уровень напряжения, к этой точке учета, привязан тариф на более позднюю дату!';
				end if;  --10
			 end if;  --8
			 else --7
				RETURN 'НЕ ВОЗМОЖНО изменить уровень напряжения, введен уровень напряжения на более позднюю дату!';		 
			end if; --7  
		 end if; --1
	  else  --0
	  RETURN 'НЕ ВОЗМОЖНО ввести/изменить уровень напряжения и тариф, так как сформирован документ выставления!';
	end if; --0
END;
$$;

comment on function bee_add_plevel_tarif(integer, integer, integer, integer, date) is 'Добавление уровня напряжения и тарифа на точку учета. Используется в DeviceParamP.java, AppUtils.java';

alter function bee_add_plevel_tarif(integer, integer, integer, integer, date) owner to pgsql;

