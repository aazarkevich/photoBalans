create view vbee_oper_values(loc, abo, agr, pid, doc, acc, num, pdat, pamo, ldat, lamo) as
SELECT customer.locid                                                    AS loc,
       customer.abo_code                                                 AS abo,
       agreement.rowid                                                   AS agr,
       agreepoint.rowid                                                  AS pid,
       agreement.docnumber                                               AS doc,
       agreepoint.account                                                AS acc,
       agreepoint.prodnumber                                             AS num,
       bee_get_oper_date_prev(agreepoint.rowid, regdevoper.operdate)     AS pdat,
       bee_get_oper_val_prev(agreepoint.rowid, 195, regdevoper.operdate) AS pamo,
       regdevoper.operdate                                               AS ldat,
       regdevoper.valman                                                 AS lamo
FROM (((customer
    JOIN agreement ON ((customer.abo_code = agreement.abo_code)))
    JOIN agreepoint ON ((agreement.rowid = agreepoint.linkid)))
         JOIN regdevoper ON ((agreepoint.rowid = regdevoper.linkid)))
WHERE ((regdevoper.paramid = 195) AND (regdevoper.operdate IS NOT NULL) AND
       (bee_get_oper_date_last(agreepoint.rowid) = regdevoper.operdate) AND
       ((regdevoper.valman)::text ~ '^\d{1,}'::text))
ORDER BY customer.locid, agreement.docnumber, agreepoint.account, agreepoint.prodnumber, regdevoper.operdate DESC;

comment on view vbee_oper_values is 'Используется в bee_get_oper_data(int)';

alter table vbee_oper_values
    owner to pgsql;

