create function bee_rep21_get_rdo_mid_nat(locid integer, start_date date, end_date date, n integer) returns SETOF bee_repakt7_rdo
    language sql
as
$$
/*
ito06 2012-02-02
Сводный баланс за период
*/
SELECT 
   valman.linkid,
  CASE
    WHEN (max_date-min_date) = 0 THEN null
    ELSE ((v/(max_date-min_date))*(dats.dats[$4][2] - dats.dats[$4][1] + 1))::numeric(15,3)
  END AS mid
FROM
  bee_rep_get_dats_for13($2,$3) AS dats

  --вычисление суммы 
  JOIN (SELECT
    linkid AS linkid,
    sum(valman::numeric) AS v
  FROM regdevoper, bee_rep_get_dats_for13($2,$3) AS dats
  WHERE
    operdate BETWEEN dats.dats[$4][2] - '1 year'::interval AND dats.dats[$4][2] AND
    paramid = 850 AND
    valman ~ E'^[\\d{1,},\\-]' AND
    valman <> '-'
  GROUP BY linkid) AS valman ON dats IS NOT NULL
  JOIN(
    --вычисление верхней даты
    SELECT
      linkid AS linkid,
      max(operdate) AS max_date
    FROM regdevoper, bee_rep_get_dats_for13($2,$3) AS dats
    WHERE
      operdate <= dats.dats[$4][2] AND
      paramid = 850 AND
      valman ~ E'^[\\d{1,},\\-]' AND
      valman <> '-'
    GROUP BY linkid
   ) AS max_date ON max_date.linkid = valman.linkid
  JOIN(
    --вычисление нижней даты
    SELECT 
      rdo.linkid AS linkid,
      rdo.valman::date AS min_date
    FROM
      regdevoper AS rdo
      JOIN(
       SELECT
        linkid AS linkid,
        min(operdate) AS min_date
       FROM regdevoper, bee_rep_get_dats_for13($2,$3) AS dats
       WHERE
        operdate BETWEEN dats.dats[$4][2] - '1 year'::interval AND dats.dats[$4][2] AND
        paramid = 197 AND
        valman LIKE '____-__-__' 
       GROUP by linkid) AS a ON a.linkid = rdo.linkid AND a.min_date = rdo.operdate AND rdo.paramid = 197
  ) AS min_date ON min_date.linkid = valman.linkid
left JOIN agreepoint AS apn ON apn.rowid = valman.linkid
left JOIN agreement AS amn ON amn.rowid = apn.linkid
WHERE
    amn.locid IN(SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1))
$$;

comment on function bee_rep21_get_rdo_mid_nat(integer, date, date, integer) is 'Сводный баланс за период. Используется в bee_rep_get_repdata21_nat_mid(int, date, date, boolean, boolean)';

alter function bee_rep21_get_rdo_mid_nat(integer, date, date, integer) owner to pgsql;

