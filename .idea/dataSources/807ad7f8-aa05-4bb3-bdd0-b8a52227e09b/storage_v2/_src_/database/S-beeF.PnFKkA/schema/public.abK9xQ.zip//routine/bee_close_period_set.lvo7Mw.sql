create function bee_close_period_set(per_table character varying, dat date, fill integer) returns integer
    language plpgsql
as
$$
/*
         Установка закрытого периода по участкам 
	 ito06 2013-08-07
	 add ito06 2013-09-03  
*/
BEGIN
   EXECUTE 'UPDATE ' || per_table || ' SET period = ''' || dat || ''' where filloc IN'|| 
   '(select rowid from denet where kod like (select case when length(kod) = 6 then kod ||''%''
                                                         when length(kod) = 9 and substring(kod from 1 for 8) = ''g10m66r0'' then kod ||''%''
                                                         else kod 
                                                     end from (select kod from denet where rowid = '||fill||' order by kod) As a));';
   RETURN 0; 
END;
$$;

comment on function bee_close_period_set(varchar, date, integer) is 'Установка закрытого периода по участкам. Используется в bee_close_period(varchar, varchar, varchar, varchar, int)';

alter function bee_close_period_set(varchar, date, integer) owner to pgsql;

