create function bee_is_agreepoint_restrict(_apnid integer, _curdat character varying) returns boolean
    language plpgsql
as
$$
/*
	ito06 2015-06-18 Есть ли ограничение режима потребления эл.эн.
*/
DECLARE dat_restrict date;
	dat_renewal date;
	curdat date;
BEGIN
	IF _curdat IS NULL OR NOT  is_date(_curdat) 
	   THEN curdat = now()::date; 
	   ELSE  curdat = _curdat::date;
	END IF;

	SELECT period FROM agreeregdev_period
	 WHERE linkid = $1
	   AND paramid = 1862
	   AND paramval IS NOT NULL
	   AND length(paramval) > 0
	   AND period <= curdat
	   AND paramval NOT IN ('0', '-', '', '?')
	 ORDER BY period desc LIMIT 1 INTO dat_restrict;

	IF dat_restrict IS NULL THEN RETURN false; END IF;

	SELECT period FROM agreeregdev_period
	 WHERE linkid = $1
	   AND paramid = 1863
	   AND paramval IS NOT NULL
	   AND length(paramval) > 0
	   AND period <= curdat
	   AND paramval NOT IN ('0', '-', '', '?') 
	 ORDER BY period desc LIMIT 1 INTO dat_renewal;	

	IF dat_renewal IS NULL THEN RETURN true; END IF;   

	IF  dat_restrict > dat_renewal 
	   THEN RETURN true;
	   ELSE RETURN false;
	END IF;   
	RETURN false;
END;
$$;

comment on function bee_is_agreepoint_restrict(integer, varchar) is 'Есть ли ограничение режима потребления эл.эн. Используется в AgreeByDevice.java, Agreement.java, AppUtils.java';

alter function bee_is_agreepoint_restrict(integer, varchar) owner to pgsql;

