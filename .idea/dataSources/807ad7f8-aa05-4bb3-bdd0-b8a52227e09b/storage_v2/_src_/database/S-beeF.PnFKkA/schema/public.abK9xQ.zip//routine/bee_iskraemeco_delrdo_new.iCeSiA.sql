create function bee_iskraemeco_delrdo_new(pointid integer, dat date, devnum character varying) returns integer
    language plpgsql
as
$$
/*
	ito06 2015-11-13 Удаление закаченных показаний из iskraemeco.
*/
DECLARE 	
	listconn text[];
	TagRecord Record;
        res record; 		
BEGIN  
		
	DELETE FROM regdevoper WHERE operdate = dat AND linkid = pointid;
	
	-- получить параметры подключеия
	SELECT * FROM dblink_get_connections() INTO listconn;  
	IF 'iskradell' = ANY (listconn) 
	   THEN -- удаляем соединение
		SELECT dblink_disconnect('iskradell') INTO res;
        END IF;
        SELECT dblink_connect_u('iskradell', 'dbname = beeU port = 5432 host = localhost user = pgsql') into res;
        PERFORM dblink('iskradell','UPDATE bee_external_src SET ready = false, err = 6 
                WHERE dev_num = '''||devnum||''' AND operdate = '''||dat||''' AND ready = true AND err = 0'); 
	IF 'iskradell' = ANY (ListConn) THEN SELECT dblink_disconnect('iskradell') INTO res; END IF;     
	
	RETURN 0;
        
END;
$$;

comment on function bee_iskraemeco_delrdo_new(integer, date, varchar) is 'Удаление закаченных показаний из iskraemeco. Используется в IskraEmeco.java, AppUtils.java';

alter function bee_iskraemeco_delrdo_new(integer, date, varchar) owner to pgsql;

