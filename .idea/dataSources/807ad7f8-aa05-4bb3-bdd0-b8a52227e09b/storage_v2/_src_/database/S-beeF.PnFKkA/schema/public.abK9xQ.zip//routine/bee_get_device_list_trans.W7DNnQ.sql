create function bee_get_device_list_trans(_pointid integer, _type integer, _phase integer) returns SETOF agreeregdev_period
    language plpgsql
as
$$
DECLARE
/*
	ito06 2020-04-27 Получить список номеров ТТ/ТН для указанного устройства и фазы.
	_phase = -1 (фаза не выбрана) _phase = 0 (фаза А); _phase = 1  (фаза B); _phase = 2 (фаза C) Выводит параметры ТТ/ТН для указанной фазы.
	_type = 56 ТТ; _type = 61 ТН
*/
	_code int :=0;
	rec agreeregdev_period%rowtype;
BEGIN

    IF _phase = 0  
	   THEN _code = 501;
	   ELSE IF _phase = 1  
	             THEN _code = 502;
				 ELSE IF _phase = 2  THEN _code = 503;
                      END IF;
            END IF;
    END IF;
	  
	FOR rec IN (	
			select * from agreeregdev_period  AS ard
			JOIN dic_elements  AS de on de.element_code = _code AND de.link = _type AND  de.rowid = ard.paramid 
			where ard.linkid = _pointid
		order by period desc
	)
	 LOOP 
		RETURN NEXT rec;
     END LOOP; 
END;
$$;

comment on function bee_get_device_list_trans(integer, integer, integer) is 'Получить список номеров ТТ/ТН для указанного устройства и фазы. Используется в DevParamTT.java, DevParamTN.java в SessionBean1.java';

alter function bee_get_device_list_trans(integer, integer, integer) owner to postgres;

