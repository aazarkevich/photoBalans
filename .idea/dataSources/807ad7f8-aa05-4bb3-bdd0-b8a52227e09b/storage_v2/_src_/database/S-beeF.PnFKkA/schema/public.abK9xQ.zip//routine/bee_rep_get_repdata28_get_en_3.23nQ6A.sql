create function bee_rep_get_repdata28_get_en_3(amn_rowid integer, year1 date) returns SETOF bee_rep_tab28_en
    language sql
as
$$
/*
ito06 2013-01-18
Приложение 1а, пустые данные эл.эн.
*/

SELECT 
    amn.rowid     AS amnid,
    null::integer AS pointid,
    null::integer AS ul,
    null::varchar AS ulev,
    null::numeric AS sum,
    null::numeric AS m_1,
    null::numeric AS m_2,
    null::numeric AS m_3,
    null::numeric AS m_4,
    null::numeric AS m_5,
    null::numeric AS m_6,
    null::numeric AS m_7,
    null::numeric AS m_8,
    null::numeric AS m_9,
    null::numeric AS m_10,
    null::numeric AS m_11,
    null::numeric AS m_12
FROM agreement AS amn
join customer As cust ON cust.abo_code = amn.abo_code
WHERE amn.rowid = $1
$$;

comment on function bee_rep_get_repdata28_get_en_3(integer, date) is 'Приложение 1, пустые данные - эл.эн. Используется в bee_rep_get_repdata28_get_en(int, date, int)';

alter function bee_rep_get_repdata28_get_en_3(integer, date) owner to postgres;

