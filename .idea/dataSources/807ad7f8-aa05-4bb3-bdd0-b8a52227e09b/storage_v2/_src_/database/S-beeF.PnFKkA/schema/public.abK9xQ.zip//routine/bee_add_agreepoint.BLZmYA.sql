create function bee_add_agreepoint(lnk integer, pro character varying, acc character varying, dev integer, typ integer, devlocid integer) returns integer
    language plpgsql
as
$$
    --
--
BEGIN
    INSERT INTO agreepoint 
    (linkid,prodnumber,account,devid,devtype,lid) VALUES
    (lnk,pro,acc,dev,typ,devlocid);  
    RETURN currval('agreepoint_rowid_seq');
--
--
--
END;
--
$$;

comment on function bee_add_agreepoint(integer, varchar, varchar, integer, integer, integer) is 'Ввод нового устройства. Используется в AgreeAddDev.java, AppUtils.java';

alter function bee_add_agreepoint(integer, varchar, varchar, integer, integer, integer) owner to pgsql;

