create function bee_get_adjustment_param(_docid integer)
    returns TABLE(isconc boolean, docid integer, docdat date, corrid integer, corrdat date)
    language plpgsql
as
$$
/*
 	 	ito06 2020-04-16 Получить парамерты для корректировки 
 	 	_docid 	rowid bee_docs при doctyp=1618
*/
DECLARE rid integer;
        corrid integer;
        corrdate date;
        typ integer;
        isconc1 boolean =false; --корр создана на корр
        docid1 int = null; -- ктр создана изначальная корр
        docdat1 date =null; -- дата док на  ктр создана изнаяальная корр
        corrid1 int = null; -- id корр на ктр создана корр
        corrdate1 date = null; -- дата корр на ктр создана корр
        rid1 int;
        dat date;
        
begin
	if (select rowid from bee_doCs where rowid =_docid and doctyp = 1618) is not null --1
	then --1

		select t1.rowid, t1.docdat from (
			select a.docnum, a.docdat, a.rowid, 
							sum (	case when a.doctyp = 1618
									then bdcorr.quantity_new
									else bdcalc.quantity_amo
									end
								) as sum1, 
								a.linkid2
						 from    (SELECT 
							     bee_docs.docnum,bee_docs.docdat,
							     bee_docs.rowid,bee_docs_corr.period,bee_docs_corr.linkid2, --для проверки 
							      bee_docs.doctyp 
						        FROM
							     bee_docs
							JOIN agreement ON agreement.rowid=bee_docs.linkid   
							JOIN agreepoint ON agreepoint.linkid=agreement.rowid
							JOIN bee_docs_corr  ON bee_docs_corr.linkid1 = agreepoint.rowid 					 					 
						      WHERE bee_docs_corr.period=bee_docs.docdat  
		                     AND bee_docs.doctyp in (1065, 1618)
							 AND bee_docs.linkid = (select linkid from bee_docs where rowid = _docid) 
						      GROUP BY bee_docs.docnum, bee_docs.docdat,bee_docs.rowid,bee_docs_corr.period,bee_docs_corr.linkid2 
						      ) as a
				       left join bee_docs_corr as bdcorr on bdcorr.linkid2 = a.rowid 
				       left join bee_docs_calc as bdcalc on bdcalc.linkid1 = a.rowid 
	  		          GROUP BY a.docnum, a.docdat,a.rowid, a.linkid2
			) AS t1 where t1.sum1 = (select sum(quantity_old) from  bee_docs_corr where linkid2 = _docid) and t1.linkid2 = _docid into corrid, corrdate;

		IF corrid IS not null --2 
	     then  --2
	     	select doctyp from bee_docs where rowid = corrid into typ;
	     
	     	if typ = 1618 --3 корр на корр 
	     	    then --3
	     	         isconc1 = true; 
	     	         corrid1 = corrid;
	     	         corrdate1 = corrdate;
	     	       
	     	         select distinct bd.rowid, bd.docdat
					   from bee_docs_corr AS bdc
					   join agreepoint AS apn ON apn.rowid = bdc.linkid1
					   join agreement AS amn ON amn.rowid = apn.linkid
					   join bee_docs AS bd ON bd.linkid = amn.rowid AND bd.doctyp = 1065 AND bd.docdat = bdc.period
					  where linkid2 = corrid into rid1, dat;
					 
					  if rid1 is not null 
					   then docid1=rid1;
					        docdat1 = dat;
					  end if;
					 
	     		else --3
	     			  isconc1 = false;
 	     			  docid1=corrid;
					  docdat1 = corrdate;
	     	    	  corrid1 = null;
	     	          corrdate1 = null;
	    	end if;   --3          
	    
     	END if;--2
     	
     	end if;--1
     	return query (select isconc1, docid1, docdat1, corrid1, corrdate1);
		 
end;
$$;

alter function bee_get_adjustment_param(integer) owner to postgres;

