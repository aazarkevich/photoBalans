create function bee_rep_get_repdata8_2(loc_id integer, amn_trm character varying, amn_accdir character varying, cd_fiter character varying, sd_fiter character varying) returns SETOF bee_rep_tab8
    language sql
as
$$
/*
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	ito06 2011-10-10 Приложение 2
*/
SELECT
	dn.nam AS fil,       -- филиал
	denet.nam AS loc,  -- участок
	bee_rep8_get_conn(gis.pchain) AS conn,
	bee_rep8_get_subs(gis.pchain) AS subs,
	dic3.element_name AS ulev,
	amn.docnumber ||', '|| replace(bee_rep8_get_adr(dic1.element_name,cst.consum_name,adr1.item,adr2.item,adr3.item,adr4.item),E'\\','/')  AS adrfio,
	apn.account ||', '|| replace(ard1.paramval,E'\\','/')  AS elobj,
	replace(ard2.paramval||', '||ard3.paramval,E'\\','/') AS plc,
	dic2.element_name AS prdtype,
	apn.prodnumber AS prdnum,
	a3.paramval AS subsIcoef, 
	a4.element_name AS subsItype, 
	a2.prodnumber AS subsInum, 
	a6.paramval AS subsUcoef,
	a7.element_name AS subsUtype,
	a5.prodnumber AS subsUnum,
	ard4.paramval  AS coef,
	ard5.paramval  AS lineloss,
	ard6.paramval  AS nagrloss,
	ard7.paramval  AS holhloss,
	CASE WHEN dic3.rowid=306 THEN 0.35
             WHEN dic3.rowid=308 THEN 0.4
             WHEN dic3.rowid=310 THEN 0.4
             WHEN dic3.rowid=311 THEN 0.5
	END AS tg,
	ard9.paramval  AS worktime,
	array_to_string ( ARRAY ( SELECT dic0.element_name		
	                            FROM gis_traces AS gis0
                                    JOIN regdevconn AS rdc0 ON rdc0.traceid=gis0.rowid
                                    JOIN agreepoint AS apn0 ON apn0.rowid=rdc0.pointid 
                                    JOIN agreeregdev AS ard0 ON ard0.linkid=apn0.rowid AND ard0.paramid=189 AND ard0.paramval='434'
                                    JOIN dic_elements AS dic0 ON dic0.rowid=apn0.devid
				   WHERE gis0.rowid = gis.rowid),', '::text
	  	        ) AS contrtype,
	array_to_string ( ARRAY ( SELECT apn0.prodnumber
				    FROM gis_traces AS gis0
				    JOIN regdevconn AS rdc0 ON rdc0.traceid=gis0.rowid
				    JOIN agreepoint AS apn0 ON apn0.rowid=rdc0.pointid 
				    JOIN agreeregdev AS ard0 ON ard0.linkid=apn0.rowid AND ard0.paramid=189 AND ard0.paramval='434'
				    JOIN dic_elements AS dic0 ON dic0.rowid=apn0.devid
				   WHERE gis0.rowid = gis.rowid),', '::text
			) AS contrnum
     FROM agreepoint  AS apn
     JOIN agreement   AS amn ON apn.linkid = amn.rowid
     JOIN agreeregdev AS ard ON ard.linkid=apn.rowid AND ard.paramid=189 AND ard.paramval='432'
LEFT JOIN agreeregdev AS ar0d ON ar0d.linkid=apn.rowid AND ar0d.paramid=690 AND (char_length(ar0d.paramval)>3)
     JOIN denet ON apn.lid=denet.rowid
LEFT JOIN (SELECT nam, kod FROM denet WHERE length(kod)=6) as dn ON substring(denet.kod, 0, 7) = dn.kod
LEFT JOIN customer    AS cst ON amn.abo_code = cst.abo_code
LEFT JOIN regdevconn AS rdc ON apn.rowid=rdc.pointid
LEFT JOIN gis_traces AS gis ON rdc.traceid=gis.rowid
LEFT JOIN customer_info AS adr1 ON cst.abo_code=adr1.abo AND adr1.elrowid=358
LEFT JOIN customer_info AS adr2 ON cst.abo_code=adr2.abo AND adr2.elrowid=361
LEFT JOIN customer_info AS adr3 ON cst.abo_code=adr3.abo AND adr3.elrowid=362
LEFT JOIN customer_info AS adr4 ON cst.abo_code=adr4.abo AND adr4.elrowid=363
LEFT JOIN customer_info AS adr5 ON cst.abo_code=adr5.abo AND adr5.elrowid=364
LEFT JOIN agreeregdev AS ard1 ON apn.rowid=ard1.linkid AND ard1.paramid=418
LEFT JOIN agreeregdev AS ard2 ON apn.rowid=ard2.linkid AND ard2.paramid=643
LEFT JOIN agreeregdev AS ard3 ON apn.rowid=ard3.linkid AND ard3.paramid=417
LEFT JOIN bee_rep_get_ard_per_max(356) AS ard4 ON apn.rowid=ard4.linkid
LEFT JOIN bee_rep_get_ard_per_max(408) AS ard5 ON apn.rowid=ard5.linkid
LEFT JOIN bee_rep_get_ard_per_max(688) AS ard6 ON apn.rowid=ard6.linkid
LEFT JOIN bee_rep_get_ard_per_max(419) AS ard7 ON apn.rowid=ard7.linkid
LEFT JOIN bee_rep_get_ard_per_max(439) AS ard8 ON apn.rowid=ard8.linkid AND ard8.paramval ~ E'^\\d{1,}'
LEFT JOIN agreeregdev AS ard9 ON apn.rowid=ard9.linkid AND ard9.paramid=425
LEFT JOIN dic_elements AS dic1 ON cst.urstatus=dic1.rowid
LEFT JOIN dic_elements AS dic2 ON apn.devid=dic2.rowid
LEFT JOIN dic_elements AS dic3 ON ard8.paramval::numeric(6)=dic3.rowid 
LEFT JOIN agreepoint AS a2 ON apn.account=a2.account AND apn.linkid=a2.linkid AND a2.devtype=645 --ГЮБНДЯЙНИ МНЛЕП рр
LEFT JOIN agreeregdev AS a3 ON a2.rowid=a3.linkid AND a3.paramid=321  --ЙНЩТТХЖХЕМР рр
LEFT JOIN dic_elements AS a4 ON a2.devid=a4.rowid  --РХО рр
LEFT JOIN agreepoint AS a5 ON apn.account=a5.account AND apn.linkid=a5.linkid AND a5.devtype=646 --ГЮБНДЯЙНИ МНЛЕП рм
LEFT JOIN agreeregdev AS a6 ON a5.rowid=a6.linkid  AND a6.paramid=286 --ЙНЩТТХЖХЕМР рм
LEFT JOIN dic_elements AS a7 ON a5.devid=a7.rowid  --РХО рм
LEFT JOIN ( SELECT ap.rowid AS rowid,
                   CASE WHEN a.paramid = 1535     
                            THEN true
                        ELSE false
                   END AS cd
              FROM agreepoint as ap 
         LEFT JOIN (SELECT linkid,    
                           max(period) AS period   
	              FROM agreeregdev_period  
	             WHERE paramid = 1535  
	             GROUP BY linkid
	            ) AS max_per_cd  ON max_per_cd.linkid = ap.rowid   
          LEFT JOIN agreeregdev_period AS a ON ap.rowid = a.linkid AND a.paramid = 1535 AND max_per_cd.period = a.period 
              GROUP BY ap.rowid, a.paramid
              ORDER BY ap.rowid
          ) AS cd_filter ON cd_filter.rowid = apn.rowid
LEFT JOIN ( SELECT ap.rowid AS rowid,
                   CASE WHEN b.paramid = 1614     
                             THEN true
                        ELSE false
                   END AS sd
              FROM agreepoint as ap 
         LEFT JOIN (SELECT linkid,    
                           max(period) AS period   
	              FROM agreeregdev_period  
	             WHERE paramid = 1614  
	             GROUP BY linkid
	            ) AS max_per_sd  ON max_per_sd.linkid = ap.rowid   
          LEFT JOIN agreeregdev_period AS b ON ap.rowid = b.linkid AND b.paramid = 1614 AND max_per_sd.period = b.period 
              GROUP BY ap.rowid,  b.paramid
              ORDER BY ap.rowid
           ) AS sd_filter ON sd_filter.rowid = apn.rowid
      WHERE cst.locid=$1 AND  apn.devtype=644 
        AND (amn.docstatus <> 79 OR ar0d.paramval IS NOT NULL) 
        AND (amn.accdir = 317) IN (CASE WHEN $3 = 'a' 
                                            THEN 'f'::boolean
                                        ELSE $3::boolean
                                   END,
                                   CASE WHEN $3 = 'a' 
                                            THEN 't'::boolean
                                        ELSE $3::boolean
                                   END) 
        AND (amn.doctype = 1910) IN (CASE WHEN $2 = 'a'  --** 2016-04-25
                                       THEN 'f'::boolean
                                  ELSE $2::boolean
                             END,
                             CASE WHEN $2 = 'a' 
                                       THEN 't'::boolean
                                  ELSE $2::boolean
                             END) 
        AND cd_filter.cd IN (CASE WHEN $4 = 'a' 
                                       THEN 'f'::boolean
                                  ELSE $4::boolean
                             END,
                             CASE WHEN $4 = 'a' 
                                       THEN 't'::boolean
                                  ELSE $4::boolean
                             END) 
       AND sd_filter.sd  IN (CASE WHEN $5 = 'a' 
                                      THEN 'f'::boolean
                                  ELSE $5::boolean
                             END,
			     CASE WHEN $5 = 'a' 
                                      THEN 't'::boolean
                                  ELSE $5::boolean
                             END)
  ORDER BY fil,loc,conn,subs,adrfio;
$$;

comment on function bee_rep_get_repdata8_2(integer, varchar, varchar, varchar, varchar) is 'Приложение 2. Используется в RepCreate8.java';

alter function bee_rep_get_repdata8_2(integer, varchar, varchar, varchar, varchar) owner to pgsql;

