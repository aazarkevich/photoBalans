create function bee_rep_get_date_val(integer, date, date) returns SETOF bee_rep_date_valman
    language sql
as
$$
    -- 1 - linkid
  -- 2 - start operdate
  -- 3 - end operdate
  --
  --SELECT valman::numeric(12,3) FROM regdevoper 
SELECT 
	operdate AS date,
	(SELECT round(valman::numeric,0) FROM regdevoper 
	 WHERE 
	 linkid   = $1 AND
	 paramid  = 195 AND 
	 operdate = rdo.operdate AND
	 valman   ~ E'^\\d{1,}'
	) as val195,
	(SELECT round(valman::numeric,0) FROM regdevoper 
	 WHERE 
	 linkid   = $1 AND
	 paramid  = 407 AND 
	 operdate = rdo.operdate AND
	 valman   ~ E'^\\d{1,}'
	) as val407,

	(SELECT valman::DATE FROM regdevoper 
	 WHERE 
	 linkid   = $1 AND
	 paramid  = 197 AND 
	 operdate = rdo.operdate AND 
	 valman   LIKE '____-__-__'
	) as prevdate  
FROM regdevoper as rdo WHERE 
  operdate between $2 AND $3 AND 
  linkid = $1
  group by operdate;
$$;

comment on function bee_rep_get_date_val(integer, date, date) is 'Используется в RepCreate4.java';

alter function bee_rep_get_date_val(integer, date, date) owner to pgsql;

