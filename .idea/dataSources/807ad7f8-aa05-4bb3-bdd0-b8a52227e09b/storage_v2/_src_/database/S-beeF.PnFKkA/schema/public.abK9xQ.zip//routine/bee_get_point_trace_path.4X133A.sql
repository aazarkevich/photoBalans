create function bee_get_point_trace_path(pid integer) returns character varying
    language plpgsql
as
$$
DECLARE
      PTR VARCHAR;
      BEGIN
          PTR := (
             SELECT pchain FROM gis_traces 
             LEFT JOIN regdevconn ON gis_traces.rowid = regdevconn.traceid
             LEFT JOIN agreepoint ON regdevconn.pointid = agreepoint.rowid 
             WHERE agreepoint.rowid = pid  LIMIT 1);
          IF PTR IS NULL THEN
             PTR := '-';      
          END IF;
          RETURN PTR;
    END;
$$;

comment on function bee_get_point_trace_path(integer) is 'Используется в bee_agree_by_device';

alter function bee_get_point_trace_path(integer) owner to pgsql;

