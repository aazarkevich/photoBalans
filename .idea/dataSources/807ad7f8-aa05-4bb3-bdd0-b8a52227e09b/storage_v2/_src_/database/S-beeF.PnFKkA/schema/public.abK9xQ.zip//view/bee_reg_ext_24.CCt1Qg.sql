create view bee_reg_ext_24
            (num, base, dat, devtyp, s00, s01, s02, s03, s04, s05, s06, s07, s08, s09, s10, s11, s12, s13, s14, s15,
             s16, s17, s18, s19, s20, s21, s22, s23)
as
SELECT bee_reg_ext.num,
       bee_reg_ext.base,
       bee_reg_ext.dat,
       bee_reg_ext.devtyp,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v001 + bee_reg_ext.v002) / (2)::numeric)
               ELSE (bee_reg_ext.v001 + bee_reg_ext.v002)
               END)::numeric(14, 4) AS s00,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v011 + bee_reg_ext.v012) / (2)::numeric)
               ELSE (bee_reg_ext.v011 + bee_reg_ext.v012)
               END)::numeric(14, 4) AS s01,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v021 + bee_reg_ext.v022) / (2)::numeric)
               ELSE (bee_reg_ext.v021 + bee_reg_ext.v022)
               END)::numeric(14, 4) AS s02,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v031 + bee_reg_ext.v032) / (2)::numeric)
               ELSE (bee_reg_ext.v031 + bee_reg_ext.v032)
               END)::numeric(14, 4) AS s03,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v041 + bee_reg_ext.v042) / (2)::numeric)
               ELSE (bee_reg_ext.v041 + bee_reg_ext.v042)
               END)::numeric(14, 4) AS s04,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v051 + bee_reg_ext.v052) / (2)::numeric)
               ELSE (bee_reg_ext.v051 + bee_reg_ext.v052)
               END)::numeric(14, 4) AS s05,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v061 + bee_reg_ext.v062) / (2)::numeric)
               ELSE (bee_reg_ext.v061 + bee_reg_ext.v062)
               END)::numeric(14, 4) AS s06,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v071 + bee_reg_ext.v072) / (2)::numeric)
               ELSE (bee_reg_ext.v071 + bee_reg_ext.v072)
               END)::numeric(14, 4) AS s07,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v081 + bee_reg_ext.v082) / (2)::numeric)
               ELSE (bee_reg_ext.v081 + bee_reg_ext.v082)
               END)::numeric(14, 4) AS s08,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v091 + bee_reg_ext.v092) / (2)::numeric)
               ELSE (bee_reg_ext.v091 + bee_reg_ext.v092)
               END)::numeric(14, 4) AS s09,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v101 + bee_reg_ext.v102) / (2)::numeric)
               ELSE (bee_reg_ext.v101 + bee_reg_ext.v102)
               END)::numeric(14, 4) AS s10,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v111 + bee_reg_ext.v112) / (2)::numeric)
               ELSE (bee_reg_ext.v111 + bee_reg_ext.v112)
               END)::numeric(14, 4) AS s11,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v121 + bee_reg_ext.v122) / (2)::numeric)
               ELSE (bee_reg_ext.v121 + bee_reg_ext.v122)
               END)::numeric(14, 4) AS s12,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v131 + bee_reg_ext.v132) / (2)::numeric)
               ELSE (bee_reg_ext.v131 + bee_reg_ext.v132)
               END)::numeric(14, 4) AS s13,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v141 + bee_reg_ext.v142) / (2)::numeric)
               ELSE (bee_reg_ext.v141 + bee_reg_ext.v142)
               END)::numeric(14, 4) AS s14,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v151 + bee_reg_ext.v152) / (2)::numeric)
               ELSE (bee_reg_ext.v151 + bee_reg_ext.v152)
               END)::numeric(14, 4) AS s15,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v161 + bee_reg_ext.v162) / (2)::numeric)
               ELSE (bee_reg_ext.v161 + bee_reg_ext.v162)
               END)::numeric(14, 4) AS s16,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v171 + bee_reg_ext.v172) / (2)::numeric)
               ELSE (bee_reg_ext.v171 + bee_reg_ext.v172)
               END)::numeric(14, 4) AS s17,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v181 + bee_reg_ext.v182) / (2)::numeric)
               ELSE (bee_reg_ext.v181 + bee_reg_ext.v182)
               END)::numeric(14, 4) AS s18,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v191 + bee_reg_ext.v192) / (2)::numeric)
               ELSE (bee_reg_ext.v191 + bee_reg_ext.v192)
               END)::numeric(14, 4) AS s19,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v201 + bee_reg_ext.v202) / (2)::numeric)
               ELSE (bee_reg_ext.v201 + bee_reg_ext.v202)
               END)::numeric(14, 4) AS s20,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v211 + bee_reg_ext.v212) / (2)::numeric)
               ELSE (bee_reg_ext.v211 + bee_reg_ext.v212)
               END)::numeric(14, 4) AS s21,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v221 + bee_reg_ext.v222) / (2)::numeric)
               ELSE (bee_reg_ext.v221 + bee_reg_ext.v222)
               END)::numeric(14, 4) AS s22,
       (
           CASE
               WHEN (bee_reg_ext.devtyp > 1) THEN ((bee_reg_ext.v231 + bee_reg_ext.v232) / (2)::numeric)
               ELSE (bee_reg_ext.v231 + bee_reg_ext.v232)
               END)::numeric(14, 4) AS s23
FROM bee_reg_ext;

alter table bee_reg_ext_24
    owner to postgres;

