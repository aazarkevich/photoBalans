create function bee_rep_annex2_get_trans(apn_linkid integer, apn_account character varying, apn_devtype integer) returns character varying
    language plpgsql
as
$$
/*
	ito16 10.11.23  Приложение 2 из формы "договоры" 
*/
DECLARE
	result character varying :='';
	tmp_row bee_rep_annex2_trans_tmp%ROWTYPE;
BEGIN
   FOR tmp_row IN
	(SELECT apn.prodnumber AS prdnum,
		dic.element_name AS trans_type
           FROM agreepoint AS apn
           JOIN dic_elements AS dic ON dic.rowid = apn.devid
          WHERE apn.linkid = apn_linkid AND
                apn.account = apn_account AND
                apn.devtype = apn_devtype)
   LOOP
	result = result || tmp_row.trans_type || ', №' || tmp_row.prdnum || '<div style="display: inline-block; width:5mm"></div>';
   END LOOP;
   RETURN result;
END;
$$;

comment on function bee_rep_annex2_get_trans(integer, varchar, integer) is 'Приложение 2 из формы "договоры". Используется в bee_rep_annex2_get_content(intr, varchar)';

alter function bee_rep_annex2_get_trans(integer, varchar, integer) owner to pgsql;

