create function agree_x_31_1(dbn character varying, agr_num character varying, tagid integer, src_host character varying, src_port character varying) returns void
    language plpgsql
as
$$
DECLARE
   Pnt RECORD; -- for agreepoint
   Rec RECORD; -- for params 
   XRec RECORD;
   agreement_rowid INTEGER;
BEGIN
      -- 
      ALTER TABLE agreeregdev   DISABLE TRIGGER agreeregdev_audit;
      
      --RAISE NOTICE '*** agree_x_31_1 : enter : % : %: %',src_host,agr_num,tagid;
      SELECT rowid 
      from agreement 
      where docnumber = agr_num and docstatus = 79 LIMIT 1 
      INTO agreement_rowid;
     
      -- SCAN POINTS
      FOR Pnt IN (
          SELECT DISTINCT rowid
          FROM agree_get_agreepoint(dbn,agr_num,tagid,src_host, src_port) ORDER BY rowid
      ) 
      LOOP -- NEXT POINT
         -- DELETE
         begin -- CLEAR agreeregdev           
            delete from agreeregdev
            WHERE  
                linkid =  Pnt.rowid;
            --RAISE NOTICE '*** agree_x_31_1 : deleted agreeregdev %',Pnt.rowid;    
         EXception
            WHEN others THEN 
            RAISE NOTICE '*** agree_x_31_0  : err delete from agreeregdev %', Pnt.rowid;
         END;
         ------------------------------
         -- INSERT NEW ONE
         FOR XRec IN (
            SELECT DISTINCT rowid,paramid,paramval,linkid
            FROM agree_get_agreeregdev(dbn,agr_num,tagid,src_host, src_port) x
            WHERE  
               x.linkid = Pnt.rowid
         ) 
         LOOP -- FILL agreeregdev
            --RAISE NOTICE '*** agree_x_31_1 : SCANED in agreeregdev : %',Pnt.rowid;
            BEGIN
               INSERT INTO agreeregdev 
               (     paramid,  paramval,      linkid) VALUES
               ( XRec.paramid, XRec.paramval, XRec.linkid);
              -- RAISE NOTICE '*** agree_x_31_1 : inserted in agreeregdev %',Pnt.rowid;
            EXCEPTION
               WHEN unique_violation THEN 
                  RAISE NOTICE '*** agree_x_31_1 unique : err %',Pnt.rowid;
                  CONTINUE;
               WHEN others THEN 
                  RAISE NOTICE '*** agree_x_31_1 other : err %',Pnt.rowid;
                  CONTINUE;
            END;
         END LOOP; 
      ------------------------------------------
      END LOOP; -- POINTS DONE
      ALTER TABLE agreeregdev ENABLE TRIGGER agreeregdev_audit;
      --RAISE NOTICE '*** agree_x_31_1 : exit';
END;
--
--
$$;

comment on function agree_x_31_1(varchar, varchar, integer, varchar, varchar) is 'Добавление/изменение постоянных параметров точки учета из указанного филиала в базу централизованных/смешнных для указанного договора. Используется в agree_w(int, varchar, varchar), agree_x(varchar, int, varchar)';

alter function agree_x_31_1(varchar, varchar, integer, varchar, varchar) owner to pgsql;

