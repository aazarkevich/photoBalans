create function bee_rep_get_ard_per_max_with_per(param_id integer) returns SETOF bee_ard_tab_with_per
    language plpgsql
as
$$
/*
	ito06 2015-06-18 
*/
DECLARE 
RowLine bee_ard_tab%RowType;
filt varchar;
BEGIN

IF param_id NOT IN (439,689,664,1015)
 THEN 
	   filt =' AND paramval IS NOT NULL 
		      AND paramval <> '||quote_literal('-')||'
		      AND paramval <> '||quote_literal('')||'
		      AND paramval <> '||quote_literal('0')||'
		      AND paramval <> '||quote_literal('?')||' ';

   ELSE
	 IF param_id  = 664 THEN filt = ' AND ((is_numeric(paramval) AND length(paramval)>7) OR (paramval = '||quote_literal('0')||'))';
	      ELSE filt = ' AND is_numeric(paramval)';
	    END IF;
	 
	END IF;

RETURN QUERY EXECUTE 
	'SELECT
		ard.linkid,
		paramval, 
		ard.period
	 FROM agreeregdev_period AS ard 
	 JOIN (SELECT
		      linkid,
		      max(period) AS period
		 FROM agreeregdev_period
		WHERE paramid='||$1||'
		     '||filt||'
		GROUP BY linkid
	      ) AS per ON per.linkid = ard.linkid AND per.period = ard.period
	 WHERE paramid ='||$1||';';
	 
 END;
$$;

comment on function bee_rep_get_ard_per_max_with_per(integer) is 'Используется в bee_repagreepointlist_get_agreeregdev_period(integer)';

alter function bee_rep_get_ard_per_max_with_per(integer) owner to pgsql;

