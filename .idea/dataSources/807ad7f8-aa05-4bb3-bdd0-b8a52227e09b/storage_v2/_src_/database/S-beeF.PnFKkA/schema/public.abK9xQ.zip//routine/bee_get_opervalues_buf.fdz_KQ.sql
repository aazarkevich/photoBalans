create function bee_get_opervalues_buf(locid integer, x_num character varying, x_doc character varying, x_acc character varying, x_nam character varying, x_adr character varying, x_pchain character varying) returns SETOF vbee_get_opervalues_buf
    language plpgsql
as
$$
BEGIN
      RETURN QUERY 
      SELECT loc, per, abo, agr, pid, nam, doc, acc, num, adr, pdat, pdopsumm, prep, pamo, cdat, crep, camo, prim, snorm, oversnorm, rdo850, pchain 
        FROM vbee_get_opervalues_buf
       WHERE  
		loc IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = locid)) AND 
		num ILIKE x_num AND 
		doc ILIKE x_doc AND 
		acc ILIKE x_acc AND 
		nam ILIKE x_nam AND 
		adr ILIKE x_adr AND
		pchain ILIKE x_pchain AND
		pamo is NOT null
            AND bee_is_calc_vid(pid::integer,435,cdat::date);
END;
$$;

comment on function bee_get_opervalues_buf(integer, varchar, varchar, varchar, varchar, varchar, varchar) is 'Используется в AdvanceInvoices.java, Finances.java, GisTracesOwner.java, OperVal.java, SessionBean1.java';

alter function bee_get_opervalues_buf(integer, varchar, varchar, varchar, varchar, varchar, varchar) owner to pgsql;

