create function bee_rep_get_repdata3_info(locid integer, str_date date, end_date date) returns SETOF bee_repdata3_info
    language plpgsql
as
$$
/*
    add ito06 2021-01-19 выбираем все договоры 
    add ito06 2020-06-10 выбираем только действующие договоры
	add ito06 2016-04-25 убираем поле transmit из таблицы agreement
	add ito06 2013-10-11
	ito06 2012-02-14:Сводный акт первичного учета эл.эн.; по абонентам; в разрезе лицевых счетов
*/
DECLARE Rec bee_repdata3_info%ROWTYPE;
BEGIN
  FOR Rec IN (
	(SELECT

		res.nam 				AS fil_name,
		res.kod 				AS fil_kod,
		prv.element_name 			AS provider,
		dir.element_name			AS direction, 
		dir.element_code			AS direction_code,
		amn.docnumber 				AS docnumber,
		apn.account  				AS account,
		cst.abo_name 				AS cst_name,
		CASE
		    WHEN p418.paramval IS NOT null
			THEN p418.paramval || ', ' 
		    ELSE ''
		END ||  CASE
		    WHEN p417.paramval IS NOT null
			THEN p417.paramval || ', ' 
		    ELSE ''
		END || apn.prodnumber			AS obj_name,
		p715.paramval 				AS p715,
		apn.rowid,
		CASE
		    WHEN amn.doctype = 1910 --** 2016-04-25
		       THEN 'Прямой договор'
		    ELSE NULL :: character varying
		END					AS amn_trmt,
		CASE
		    WHEN length(ardCD.paramval)>2
			THEN 'Централизованный договор'
		    WHEN length(ardSD.paramval)>2
			THEN 'Смешанный договор'
		    ELSE 'Договор':: character varying
		END 					AS amn_cd_sd,
		tgrp.element_name 			AS targrp,
		850 					AS rdo_param,
		1 					AS npp
	 
	     FROM customer 	AS cst
	     JOIN agreement 	AS amn 	ON cst.abo_code = amn.abo_code
	     JOIN agreepoint 	AS apn 	ON apn.linkid = amn.rowid
	LEFT JOIN agreeregdev 	AS p418 ON p418.linkid = apn.rowid AND p418.paramid = 418 AND p418.paramval NOT IN ('0','?','-')
	LEFT JOIN agreeregdev 	AS p417 ON p417.linkid = apn.rowid AND p417.paramid = 417 AND p417.paramval NOT IN ('0','?','-')
	LEFT JOIN agreeregdev 	AS p715 ON p715.linkid = apn.rowid AND p715.paramid = 715
	LEFT JOIN regdevoper    AS rdo  ON rdo.linkid = apn.rowid and rdo.paramid = 850 
				       AND (rdo.operdate between str_date AND end_date) AND rdo.valman ~  E'^[\\d{1,}\\-]' AND rdo.valman<>'-' 
	 
	LEFT JOIN ( SELECT linkid, max(period) AS period 
		      FROM agreeregdev_period 
		     WHERE period<$3 
		     GROUP BY linkid
		  ) AS prv_per 		ON prv_per.linkid = apn.rowid
	LEFT JOIN agreeregdev_period AS ard_prv ON ard_prv.linkid = prv_per.linkid AND ard_prv.period = prv_per.period 
	                                       AND ard_prv.paramid = 1450 AND ard_prv.paramval ~ E'^\\d{1,}'
	LEFT JOIN dic_elements 	AS prv ON prv.rowid = ard_prv.paramval::integer
	LEFT JOIN agreeregdev 	AS ard_tgrp ON ard_tgrp.linkid = apn.rowid AND ard_tgrp.paramid = 1631 AND ard_tgrp.paramval ~ E'^\\d{1,}'
	LEFT JOIN dic_elements	 AS tgrp ON tgrp.rowid = ard_tgrp.paramval::integer
	LEFT JOIN ( SELECT linkid, max(period) AS period    
		      FROM agreeregdev_period  
		     WHERE paramid = 1535 AND period < $3 
		     GROUP BY linkid
		  ) AS max_per_cd ON max_per_cd.linkid = apn.rowid
	LEFT JOIN agreeregdev_period AS ardCD ON ardCD.linkid = apn.rowid AND ardCD.paramid = 1535 AND max_per_cd.period = ardCD.period 
	LEFT JOIN ( SELECT linkid,   max(period) AS period    
		      FROM agreeregdev_period  
		     WHERE paramid = 1614  AND period < $3 
		     GROUP BY linkid) AS max_per_sd ON max_per_sd.linkid = apn.rowid
	LEFT JOIN agreeregdev_period AS ardSD ON ardSD.linkid = apn.rowid AND ardSD.paramid = 1614 AND max_per_sd.period = ardSD.period 
	LEFT JOIN agreeregdev AS p690 ON p690.linkid = apn.rowid AND p690.paramid = 690 AND p690.paramval LIKE '____-__-__'
	     JOIN dic_elements AS dir ON dir.rowid = amn.accdir AND dir.element_code>1000
	     JOIN denet AS res ON res.rowid=cst.locid
	     JOIN denet AS mes ON mes.kod = substring(res.kod from 1 for 6)
	    WHERE cst.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1))
	      --2021-01-19 and amn.docstatus <>77 -- 2020-06-10
	      AND (p690.paramval::date >= $2 OR p690.paramval IS NULL)
	)
	UNION
	(SELECT
		res.nam 				AS fil_name,
		res.kod 				AS fil_kod,
		prv.element_name 			AS provider,
		dir.element_name			AS direction, 
		dir.element_code			AS direction_code,
		amn.docnumber 				AS docnumber,
		apn.account  				AS account,
		cst.abo_name 				AS cst_name,
		'в т.ч. по соц норме'			AS obj_name,
		p715.paramval 				AS p715,
		apn.rowid,
		CASE
		    
		    WHEN amn.doctype = 1910 --** 2016-04-25
		       THEN 'Прямой договор'
		    ELSE NULL :: character varying
		END					AS amn_trmt,
		CASE
		    WHEN length(ardCD.paramval)>2
			THEN 'Централизованный договор'
		    WHEN length(ardSD.paramval)>2
			THEN 'Смешанный договор'
		    ELSE 'Договор':: character varying
		END 					AS amn_cd_sd,
		tgrp.element_name 			AS targrp,
		1446					AS rdo_param,
		2 					AS npp
	 
	     FROM customer 	AS cst
	     JOIN agreement 	AS amn 	ON cst.abo_code = amn.abo_code
	     JOIN agreepoint 	AS apn 	ON apn.linkid = amn.rowid
	LEFT JOIN agreeregdev 	AS p418 ON p418.linkid = apn.rowid AND p418.paramid = 418 AND p418.paramval NOT IN ('0','?','-')
	LEFT JOIN agreeregdev 	AS p417 ON p417.linkid = apn.rowid AND p417.paramid = 417 AND p417.paramval NOT IN ('0','?','-')
	LEFT JOIN agreeregdev 	AS p715 ON p715.linkid = apn.rowid AND p715.paramid = 715
	LEFT JOIN regdevoper    AS rdo  ON rdo.linkid = apn.rowid and rdo.paramid = 1446
				       AND (rdo.operdate between str_date AND end_date) AND rdo.valman ~  E'^[\\d{1,}\\-]' AND rdo.valman <> '-'  

	    
					  

	LEFT JOIN ( SELECT linkid, max(period) AS period 
		      FROM agreeregdev_period 
		     WHERE period<$3 
		     GROUP BY linkid
		  ) AS prv_per 		ON prv_per.linkid = apn.rowid
	LEFT JOIN agreeregdev_period AS ard_prv ON ard_prv.linkid = prv_per.linkid AND ard_prv.period = prv_per.period 
	                                       AND ard_prv.paramid = 1450 AND ard_prv.paramval ~ E'^\\d{1,}'
	LEFT JOIN dic_elements 	AS prv ON prv.rowid = ard_prv.paramval::integer
	LEFT JOIN agreeregdev 	AS ard_tgrp ON ard_tgrp.linkid = apn.rowid AND ard_tgrp.paramid = 1631 AND ard_tgrp.paramval ~ E'^\\d{1,}'
	LEFT JOIN dic_elements	 AS tgrp ON tgrp.rowid = ard_tgrp.paramval::integer
	LEFT JOIN ( SELECT linkid, max(period) AS period    
		      FROM agreeregdev_period  
		     WHERE paramid = 1535 AND period < $3 
		     GROUP BY linkid
		  ) AS max_per_cd ON max_per_cd.linkid = apn.rowid
	LEFT JOIN agreeregdev_period AS ardCD ON ardCD.linkid = apn.rowid AND ardCD.paramid = 1535 AND max_per_cd.period = ardCD.period 
	LEFT JOIN ( SELECT linkid,   max(period) AS period    
		      FROM agreeregdev_period  
		     WHERE paramid = 1614  AND period < $3 
		     GROUP BY linkid) AS max_per_sd ON max_per_sd.linkid = apn.rowid
	LEFT JOIN agreeregdev_period AS ardSD ON ardSD.linkid = apn.rowid AND ardSD.paramid = 1614 AND max_per_sd.period = ardSD.period 
	LEFT JOIN agreeregdev AS p690 ON p690.linkid = apn.rowid AND p690.paramid = 690 AND p690.paramval LIKE '____-__-__'
	     JOIN dic_elements AS dir ON dir.rowid = amn.accdir AND dir.element_code>1000
	     JOIN denet AS res ON res.rowid=cst.locid
	     JOIN denet AS mes ON mes.kod = substring(res.kod from 1 for 6)
	    WHERE cst.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1))
	     --2021-01-19 and amn.docstatus <>77 --2020-06-10
	      AND (p690.paramval::date >= $2 OR p690.paramval IS NULL))      
	UNION 
	(SELECT
		res.nam 				AS fil_name,
		res.kod 				AS fil_kod,
		prv.element_name 			AS provider,
		dir.element_name			AS direction, 
		dir.element_code			AS direction_code,
		amn.docnumber 				AS docnumber,
		apn.account  				AS account,
		cst.abo_name 				AS cst_name,
		'сверх соц. нормы'			AS obj_name,
		p715.paramval 				AS p715,
		apn.rowid,
		CASE
		    WHEN amn.doctype = 1910 --** 2016-04-25
		       THEN 'Прямой договор'
		    ELSE NULL :: character varying
		END					AS amn_trmt,
		CASE
		    WHEN length(ardCD.paramval)>2
			THEN 'Централизованный договор'
		    WHEN length(ardSD.paramval)>2
			THEN 'Смешанный договор'
		    ELSE 'Договор':: character varying
		END 					AS amn_cd_sd,
		tgrp.element_name 			AS targrp,
		1174 					AS rdo_param,
		3 					AS npp
	 
	     FROM customer 	AS cst
	     JOIN agreement 	AS amn 	ON cst.abo_code = amn.abo_code
	     JOIN agreepoint 	AS apn 	ON apn.linkid = amn.rowid
	LEFT JOIN agreeregdev 	AS p418 ON p418.linkid = apn.rowid AND p418.paramid = 418 AND p418.paramval NOT IN ('0','?','-')
	LEFT JOIN agreeregdev 	AS p417 ON p417.linkid = apn.rowid AND p417.paramid = 417 AND p417.paramval NOT IN ('0','?','-')
	LEFT JOIN agreeregdev 	AS p715 ON p715.linkid = apn.rowid AND p715.paramid = 715
	LEFT JOIN regdevoper    AS rdo  ON rdo.linkid = apn.rowid and rdo.paramid = 1174
				       AND (rdo.operdate between str_date AND end_date) AND rdo.valman ~  E'^[\\d{1,}\\-]' AND rdo.valman<>'-'      
	LEFT JOIN ( SELECT linkid, max(period) AS period 
		      FROM agreeregdev_period 
		     WHERE period<$3 
		     GROUP BY linkid
		  ) AS prv_per 		ON prv_per.linkid = apn.rowid
	LEFT JOIN agreeregdev_period AS ard_prv ON ard_prv.linkid = prv_per.linkid AND ard_prv.period = prv_per.period 
	                                       AND ard_prv.paramid = 1450 AND ard_prv.paramval ~ E'^\\d{1,}'
	LEFT JOIN dic_elements 	AS prv ON prv.rowid = ard_prv.paramval::integer
	LEFT JOIN agreeregdev 	AS ard_tgrp ON ard_tgrp.linkid = apn.rowid AND ard_tgrp.paramid = 1631 AND ard_tgrp.paramval ~ E'^\\d{1,}'
	LEFT JOIN dic_elements	 AS tgrp ON tgrp.rowid = ard_tgrp.paramval::integer
	LEFT JOIN ( SELECT linkid, max(period) AS period    
		      FROM agreeregdev_period  
		     WHERE paramid = 1535 AND period < $3 
		     GROUP BY linkid
		  ) AS max_per_cd ON max_per_cd.linkid = apn.rowid
	LEFT JOIN agreeregdev_period AS ardCD ON ardCD.linkid = apn.rowid AND ardCD.paramid = 1535 AND max_per_cd.period = ardCD.period 
	LEFT JOIN ( SELECT linkid,   max(period) AS period    
		      FROM agreeregdev_period  
		     WHERE paramid = 1614  AND period < $3 
		     GROUP BY linkid) AS max_per_sd ON max_per_sd.linkid = apn.rowid
	LEFT JOIN agreeregdev_period AS ardSD ON ardSD.linkid = apn.rowid AND ardSD.paramid = 1614 AND max_per_sd.period = ardSD.period 
	LEFT JOIN agreeregdev AS p690 ON p690.linkid = apn.rowid AND p690.paramid = 690 AND p690.paramval LIKE '____-__-__'
	     JOIN dic_elements AS dir ON dir.rowid = amn.accdir AND dir.element_code>1000
	     JOIN denet AS res ON res.rowid=cst.locid
	     JOIN denet AS mes ON mes.kod = substring(res.kod from 1 for 6)
	    WHERE cst.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = $1))
	     --2021-01-19 and amn.docstatus <>77   --2021-01-19 2020-06-10
	      AND (p690.paramval::date >= $2 OR p690.paramval IS NULL))      
	ORDER BY  docnumber, account)
    LOOP
        IF Rec.rdo_param = 850
           THEN RETURN NEXT Rec;
           ELSEIF (SELECT ul from bee_rep_get_agreepoint_tarif(Rec.apn_rowid, str_date, end_date) AS a order by a.end_date limit 1)  
                       IN ('150','156','154','155','152','159','157','158','153','162','160','161')
	        THEN RETURN NEXT Rec;
	END IF;
    END LOOP;
END
$$;

comment on function bee_rep_get_repdata3_info(integer, date, date) is 'Сводный акт первичного учета эл.эн.; по абонентам; в разрезе лицевых счетов. Используется в public.bee_rep_get_repdata3(int,date.date)"';

alter function bee_rep_get_repdata3_info(integer, date, date) owner to postgres;

