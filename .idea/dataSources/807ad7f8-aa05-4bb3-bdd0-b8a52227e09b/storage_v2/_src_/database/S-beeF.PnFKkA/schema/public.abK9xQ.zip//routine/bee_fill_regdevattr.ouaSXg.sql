create function bee_fill_regdevattr(devid integer, parid integer, tag integer) returns integer
    language plpgsql
as
$$
    --
-- заполнение параметров устройств
--
DECLARE 
  Edi      integer; -- ед измер
  PerTAG   integer := 43;
  Per      integer; -- периодичность 
  
  Result   integer; -- код возврата
 
BEGIN
  Edi    = null;
  Per    = null;
  Result = null;
  -- выбор ед измерения
  SELECT INTO Edi dic_elements.rowid FROM dic_elements
  INNER JOIN dic_category ON dic_elements.link = dic_category.rowid
  WHERE dic_category.rowid = tag LIMIT 1;
  IF Edi IS NULL THEN
	RETURN -1;	
  END IF;
  -- выбор периода изменения
  SELECT INTO Per dic_elements.rowid FROM dic_elements
  INNER JOIN dic_category ON dic_elements.link = dic_category.rowid
  WHERE dic_category.rowid = PerTAG LIMIT 1;
  IF Per IS NULL THEN
	RETURN -2;
  END IF;
  --
  INSERT INTO regdevattr (deviceid,paramid,val,ed,timeperiod) 
        (SELECT devid,rowid,0,Edi,Per FROM dic_elements 
         WHERE (link = parid  AND rowid NOT IN (SELECT paramid FROM regdevattr 
                                               WHERE deviceid = devid)) 
	);
  --
  RETURN 0;
--
END;
$$;

comment on function bee_fill_regdevattr(integer, integer, integer) is 'Заполнение параметров устройств bee_add_regdevattr_absent(int, int, int)';

alter function bee_fill_regdevattr(integer, integer, integer) owner to pgsql;

