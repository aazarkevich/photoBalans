create function agree_x_35(dbn character varying, agr_num character varying, tagid integer, src_host character varying, src_port character varying) returns void
    language plpgsql
as
$$
/*
	add ito06 2020-02-06 Удаляем показания в открытом периоде если изменились, проверить сравнение даты
*/
DECLARE
   Pnt RECORD; -- for agreepoint
   Rec RECORD;
   XRec RECORD;
   fromDate date; 
begin

     ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_trig;
     ALTER TABLE regdevoper         DISABLE TRIGGER regdevoper_audit;
     
      -- SCAN POINTS
     FOR Pnt IN (SELECT DISTINCT rowid
          FROM agree_get_agreepoint(dbn,agr_num,tagid,src_host, src_port) ORDER BY rowid
     )
     LOOP 
         ---
         select max(period) from agreeregdev_period 
         where 
            linkid   = Pnt.rowid and
            paramid  = tagid and
            paramval = agr_num 
         into fromDate;   
         ---	 
         BEGIN

		DELETE FROM regdevoper WHERE linkid = Pnt.rowid AND operdate < fromDate ; 
		-- 2020-02-06   DELETE FROM regdevoper WHERE linkid = Pnt.rowid AND operdate >= fromDate ; Проверить удаляет ли 
            EXCEPTION
               WHEN others THEN RAISE NOTICE '*** 35-1 *** : %',sqlstate;
         END;
         
         --
        
         FOR XRec IN (
             SELECT paramid,val,ed,timeperiod,valman,rowid,operdate,linkid
             FROM agree_get_regdevoper(dbn,agr_num,tagid,src_host, src_port) x
             WHERE 
                x.linkid = Pnt.rowid
                AND x.rowid NOT IN (SELECT rowid FROM regdevoper WHERE linkid = x.linkid)
         )
         loop 

           if XRec.operdate < fromDate then continue; end if;

           BEGIN
              INSERT INTO regdevoper 
              (     paramid,      val,      ed,      timeperiod,      valman, /*     rowid ,*/      operdate,      linkid) VALUES
              (XRec.paramid, XRec.val, XRec.ed, XRec.timeperiod, XRec.valman, /* XRec.rowid,*/ XRec.operdate, XRec.linkid);

           EXCEPTION
              WHEN unique_violation THEN 
                 RAISE NOTICE '*** 35-2 *** : %' ,sqlstate;
                 CONTINUE;
              WHEN others  THEN 
                 CONTINUE; 
           END;
        END LOOP;
     END LOOP;
   
     ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_trig;
     ALTER TABLE regdevoper         ENABLE TRIGGER regdevoper_audit;

END;
--
$$;

comment on function agree_x_35(varchar, varchar, integer, varchar, varchar) is 'Добавление/изменение показаний для точки учета из указанного филиала в базу централизованных/смешнных для указанного договора. Используется в agree_w(int, varchar, varchar), agree_x(varchar, int, varchar)';

alter function agree_x_35(varchar, varchar, integer, varchar, varchar) owner to pgsql;

