create function bee_del_agreeregdev_param(rid integer) returns integer
    language plpgsql
as
$$
/*	
	ito06 2016-01-14 Удаление постоянных параметров точки учета
*/
DECLARE
	NR INTEGER;
	par INTEGER;	
	
BEGIN
	BEGIN
	   SELECT linkid, paramid from agreeregdev WHERE rowid = rid INTO NR, par;
	   IF (par = 1900) 
	      THEN 		
	      	   DELETE FROM agreeregdev WHERE linkid = NR AND paramid = 1901; 
	   END IF; 

	   
	   DELETE FROM agreeregdev WHERE rowid = rid;

	EXCEPTION
	   WHEN UNIQUE_VIOLATION THEN
	   RETURN -1;
	END;
	RETURN 0;
END;
$$;

comment on function bee_del_agreeregdev_param(integer) is 'Добавление постоянных параметров. Используется в DeviceParamA.java, DeviceParamC.java, AppUtils.java';

alter function bee_del_agreeregdev_param(integer) owner to pgsql;

