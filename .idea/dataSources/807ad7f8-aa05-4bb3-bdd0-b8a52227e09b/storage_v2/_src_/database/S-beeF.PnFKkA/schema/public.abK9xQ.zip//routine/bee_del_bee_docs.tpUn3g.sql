create function bee_del_bee_docs(rid integer) returns integer
    language plpgsql
as
$$
/*
ito06 2014-10-20 Удаление документа
*/
DECLARE NR INTEGER =-1;

BEGIN
	delete from bee_docs where rowid = rid RETURNING 1 INTO NR;
	IF NR IS NULL
		THEN NR =  - 1;		
	END IF;
	RETURN NR;

END;
$$;

comment on function bee_del_bee_docs(integer) is 'Удаление договора. Используется в PaymentDocs.java';

alter function bee_del_bee_docs(integer) owner to pgsql;

