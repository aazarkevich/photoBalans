create function bee_get_child_chained_devices(xlid integer, pid integer) returns refcursor
    language plpgsql
as
$$
/*
   ito07 190111 remed locid selection
    add ito06 2015-03-20 Хотим учитывать и субабонентов, находящихся в других участках
    add ito06 2015-01-29
    add ito06 2012-06-28
    ito07: ПОЛУЧИТЬ СПИСОК УСТРОЙСТВ СУБАБОНЕНТОВ 
    lid LOCID (denet.rowid)
    pid POINTID (agreepoint.rowid идентификатор устройсва по договору)
    pid запитывающее устройство
*/	
DECLARE
    rf REFCURSOR;
BEGIN
    OPEN rf FOR   	
	SELECT agreepoint.rowid,agreepoint.prodnumber FROM agreepoint
         LEFT JOIN agreement   ON agreepoint.linkid = agreement.rowid
	  JOIN  bee_rep_get_ard_per_max(664) AS ard ON ard.linkid = agreepoint.rowid 
	    AND paramval IS NOT NULL AND paramval NOT IN ('?','-','0') AND paramval ~ E'^\\d{1,}'   
	    AND  ard.paramval::integer = pid
	  --WHERE agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE rowid = xlid)) --2015-03-20
	  WHERE 
	    --agreement.locid IN (SELECT rowid FROM denet where kod ~ (SELECT kod FROM denet WHERE length(kod)=6)) AND 
	    agreepoint.prodnumber    IS NOT NULL      
           GROUP BY agreepoint.rowid,agreepoint.prodnumber
           ORDER BY agreepoint.prodnumber;
    RETURN rf; 
END;
$$;

comment on function bee_get_child_chained_devices(integer, integer) is 'Получить список устройств субабонентов. Используется в AgreeByDevice.java, AppUtils.java';

alter function bee_get_child_chained_devices(integer, integer) owner to pgsql;

