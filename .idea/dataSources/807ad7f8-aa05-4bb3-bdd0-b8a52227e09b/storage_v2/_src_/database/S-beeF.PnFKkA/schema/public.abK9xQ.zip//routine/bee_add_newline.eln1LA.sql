create function bee_add_newline(point integer, line integer, len character varying, volt character varying) returns integer
    language plpgsql
as
$$
/*
ito06 2012-08-27 Добавление линии на точку учета
*/
DECLARE NR INTEGER =-1;

BEGIN

    INSERT INTO agreepoint_line
       (pointid,lineid,linlen,voltage) VALUES
       (point, line, len::numeric(8,3), volt::numeric(6,2))  RETURNING currval('agreepoint_line_rowid_seq') INTO NR;

    IF NR IS NOT NULL  THEN  RETURN 1;
          ELSE RETURN -1;
    END IF;

END;
$$;

comment on function bee_add_newline(integer, integer, varchar, varchar) is 'Добавление линии на точку учета. Используется в DeviceParamL.java, AppUtils.java';

alter function bee_add_newline(integer, integer, varchar, varchar) owner to pgsql;

