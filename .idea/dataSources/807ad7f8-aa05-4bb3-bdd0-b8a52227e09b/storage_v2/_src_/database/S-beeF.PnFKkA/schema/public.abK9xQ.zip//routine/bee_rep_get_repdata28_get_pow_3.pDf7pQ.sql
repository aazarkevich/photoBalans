create function bee_rep_get_repdata28_get_pow_3(amn_rowid integer, year1 date) returns SETOF bee_rep_tab28_pow
    language sql
as
$$
/*
ito06 2013-01-18 
Приложение 1а, пустые данные - мощность
*/
SELECT 
	ard_nam.paramval||', '|| apn.prodnumber AS obj_name,
	ard.paramval::integer 			AS ul,
	null::varchar 				AS ulev,
        null::numeric 				AS m_1,
	null::numeric  				AS m_2,
	null::numeric  				AS m_3,
	null::numeric  				AS m_4,
	null::numeric  				AS m_5,
	null::numeric  				AS m_6,
	null::numeric  				AS m_7,
	null::numeric  				AS m_8,
	null::numeric  				AS m_9,
	null::numeric 				AS m_10,
	null::numeric 				AS m_11,
	null::numeric 				AS m_12,
	ard_maxpow.paramval 			AS max_pow,
	ard_addpow.paramval 			AS add_pow,
	ard_okved.paramval 			AS okved,
	null::text 				AS tg,
	null::bigint 				AS hours
      
     FROM agreement AS amn 
     JOIN agreepoint AS apn ON apn.linkid = amn.rowid
     JOIN agreeregdev AS ard_nam ON ard_nam.linkid = apn.rowid AND ard_nam.paramid = 418

LEFT JOIN agreeregdev AS ard_okved ON ard_okved.linkid = apn.rowid AND ard_okved.paramid = 1030
LEFT JOIN bee_rep_get_ard_per_max(439) AS ard  ON apn.rowid = ard.linkid
LEFT JOIN bee_rep_get_ard_per_max(426) AS ard_maxpow  ON apn.rowid = ard_maxpow.linkid
LEFT JOIN bee_rep_get_ard_per_max(685) AS ard_addpow  ON apn.rowid = ard_addpow.linkid
    WHERE amn.rowid = $1
    ORDER BY ul,obj_name;
$$;

comment on function bee_rep_get_repdata28_get_pow_3(integer, date) is 'Приложение 1а, пустые данные - мощность. Используется в bee_rep_get_repdata28_get_pow(int, date, int), bee_rep_get_repdata28_get_pow_tot(int, date, int)';

alter function bee_rep_get_repdata28_get_pow_3(integer, date) owner to postgres;

